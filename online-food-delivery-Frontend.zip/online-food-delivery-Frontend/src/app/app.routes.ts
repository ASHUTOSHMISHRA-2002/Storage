// src/app/app.routes.ts
import { Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { CustomerLoginComponent } from './pages/customer-login/customer-login.component';
import { CustomerRegisterComponent } from './pages/customer-register/customer-register.component';
import { RestaurantLoginComponent } from './pages/restaurant-login/restaurant-login.component';
import { RestaurantRegisterComponent } from './pages/restaurant-register/restaurant-register.component';
import { AuthGuard } from './services/auth.guard';

export const routes: Routes = [
  // Home route
  { path: '', component: HomeComponent },

  // ============ AUTHENTICATION ROUTES (No Guard) ============
  { path: 'customer-login', component: CustomerLoginComponent },
  { path: 'customer-register', component: CustomerRegisterComponent },
  { path: 'restaurant-login', component: RestaurantLoginComponent },
  { path: 'restaurant-register', component: RestaurantRegisterComponent },

  // ============ CUSTOMER ROUTES (Require Auth) ============
  // Main customer dashboard
  {
    path: 'customer-main',
    loadComponent: () =>
      import('./pages/customer-main/customer-main.component')
        .then(m => m.CustomerComponent),
    canActivate: [AuthGuard]
  },

  // Restaurant browsing and details
  {
    path: 'restaurant/:id',
    loadComponent: () =>
      import('./pages/restaurant-detail/restaurant-detail.component')
        .then(m => m.RestaurantDetailComponent),
    canActivate: [AuthGuard]
  },

  // Restaurant menu viewing
  {
    path: 'restaurant/:id/menu',
    loadComponent: () =>
      import('./pages/menu-list/menu-list.component')
        .then(m => m.MenuListComponent),
    canActivate: [AuthGuard]
  },

  // ============ SHOPPING CART & CHECKOUT FLOW ============
  // Shopping cart
  {
    path: 'cart',
    loadComponent: () =>
      import('./pages/cart/cart.component')
        .then(m => m.CartComponent),
    canActivate: [AuthGuard]
  },

  // Order review/summary (customer details form)
  {
    path: 'orders',
    loadComponent: () =>
      import('./pages/orders/orders.component')
        .then(m => m.OrdersComponent),
    canActivate: [AuthGuard]
  },

  // Payment processing
  {
    path: 'payments',
    loadComponent: () =>
      import('./pages/payments/payments.component')
        .then(m => m.PaymentsComponent),
    canActivate: [AuthGuard]
  },

  // ============ ORDER TRACKING (Existing Component) ============
  // Order tracking by ID
  {
    path: 'order-tracking/:orderId',
    loadComponent: () =>
      import('./pages/order-tracking/order-tracking.component')
        .then(m => m.OrderTrackingComponent),
    canActivate: [AuthGuard]
  },

  // Alternative order tracking route
  {
    path: 'track-order/:orderId',
    loadComponent: () =>
      import('./pages/order-tracking/order-tracking.component')
        .then(m => m.OrderTrackingComponent),
    canActivate: [AuthGuard]
  },

  // ============ RESTAURANT MANAGEMENT ROUTES ============
  // Restaurant dashboard (order management, menu management)
  {
    path: 'restaurant-dashboard',
    loadComponent: () =>
      import('./pages/restaurant-dashboard/restaurant-dashboard.component')
        .then(m => m.RestaurantDashboardComponent),
    canActivate: [AuthGuard]
  },

  // Add new menu items
  {
    path: 'add-menu',
    loadComponent: () =>
      import('./pages/add-menu/add-menu.component')
        .then(m => m.AddMenuComponent),
    canActivate: [AuthGuard]
  },
  {
    path: 'order-tracking/:orderId',
    loadComponent: () =>
      import('./pages/order-tracking/order-tracking.component')
        .then(m => m.OrderTrackingComponent),
    canActivate: [AuthGuard]
  },
  
  // Alternative order tracking route
  {
    path: 'track/:orderId',
    loadComponent: () =>
      import('./pages/order-tracking/order-tracking.component')
        .then(m => m.OrderTrackingComponent),
    canActivate: [AuthGuard]
  },
  
  // Order tracking without parameters (for manual entry)
  {
    path: 'order-tracking',
    loadComponent: () =>
      import('./pages/order-tracking/order-tracking.component')
        .then(m => m.OrderTrackingComponent),
    canActivate: [AuthGuard]
  },
  
  // Track order without authentication (for sharing)
  {
    path: 'public-track/:orderId',
    loadComponent: () =>
      import('./pages/order-tracking/order-tracking.component')
        .then(m => m.OrderTrackingComponent)
    // No auth guard for public tracking
  },

  // ============ LEGACY REDIRECTS ============
  { path: 'customer/menu', redirectTo: '/customer-main', pathMatch: 'full' },

  // ============ FALLBACK ROUTE ============
  // Wildcard route - must be last
  { path: '**', redirectTo: '' }
];

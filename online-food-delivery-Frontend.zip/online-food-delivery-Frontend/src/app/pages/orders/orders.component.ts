import { Component, OnInit, OnDestroy, Inject } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { PLATFORM_ID } from '@angular/core';
import { Subject } from 'rxjs';

interface CartItem {
  id: number;
  name: string;
  price: number;
  quantity: number;
  restaurantId: number;
  restaurantName: string;
  description?: string;
  image?: string;
  isVegetarian?: boolean;
}

@Component({
  selector: 'app-orders',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit, OnDestroy {
  error = '';
  
  cartItems: CartItem[] = [];
  cartSubtotal = 0;
  deliveryFee = 30;
  serviceFee = 15;
  taxes = 0;
  discount = 0;
  grandTotal = 0;
  
  restaurantName = '';
  restaurantId = '';
  
  // Customer details form
  customerDetails = {
    name: 'John Doe',
    phone: '+91 9876543210',
    email: 'john@example.com'
  };
  
  deliveryAddress = '123 Main Street, City, State - 123456';
  
  private destroy$ = new Subject<void>();

  constructor(
    private router: Router,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {}

  ngOnInit(): void {
    this.loadCartData();
    this.calculateTotals();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  private loadCartData(): void {
    if (isPlatformBrowser(this.platformId)) {
      try {
        const saved = localStorage.getItem('customerCart');
        this.cartItems = saved ? JSON.parse(saved) : [];
        
        if (this.cartItems.length > 0) {
          const firstItem = this.cartItems[0];
          this.restaurantName = firstItem.restaurantName;
          this.restaurantId = firstItem.restaurantId.toString();
        } else {
          this.error = 'No items in cart. Please add items before placing an order.';
          setTimeout(() => this.router.navigate(['/cart']), 2000);
        }
      } catch (error) {
        console.error('Error loading cart data:', error);
        this.error = 'Failed to load order data';
      }
    }
  }

  private calculateTotals(): void {
    this.cartSubtotal = this.cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    this.deliveryFee = this.cartSubtotal >= 300 ? 0 : 30;
    this.serviceFee = Math.round(this.cartSubtotal * 0.02);
    this.taxes = Math.round((this.cartSubtotal + this.deliveryFee + this.serviceFee) * 0.05);
    this.discount = this.calculateDiscount();
    this.grandTotal = this.cartSubtotal + this.deliveryFee + this.serviceFee + this.taxes - this.discount;
  }

  private calculateDiscount(): number {
    if (this.cartSubtotal > 200) {
      return Math.min(Math.round(this.cartSubtotal * 0.10), 100);
    }
    return 0;
  }

  // ✅ UPDATED: Redirect to payment instead of placing order
  proceedToPayment(): void {
    if (this.cartItems.length === 0) {
      this.error = 'Your cart is empty!';
      return;
    }

    if (this.cartSubtotal < 100) {
      this.error = `Minimum order amount is ₹100. Add ₹${100 - this.cartSubtotal} more to proceed.`;
      return;
    }

    if (!this.validateForm()) {
      return;
    }

    // Save order details to localStorage for payment page
    const orderSummary = {
      items: this.cartItems,
      restaurantId: parseInt(this.restaurantId),
      restaurantName: this.restaurantName,
      totalAmount: this.grandTotal,
      customerDetails: this.customerDetails,
      deliveryAddress: this.deliveryAddress,
      pricing: {
        subtotal: this.cartSubtotal,
        deliveryFee: this.deliveryFee,
        serviceFee: this.serviceFee,
        taxes: this.taxes,
        discount: this.discount,
        total: this.grandTotal
      }
    };

    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem('orderSummary', JSON.stringify(orderSummary));
    }

    console.log('💳 Proceeding to payment');
    this.router.navigate(['/payments']);
  }

  private validateForm(): boolean {
    if (!this.customerDetails.name.trim()) {
      this.error = 'Please enter your name';
      return false;
    }

    if (!this.customerDetails.phone.trim()) {
      this.error = 'Please enter your phone number';
      return false;
    }

    if (!this.deliveryAddress.trim()) {
      this.error = 'Please enter delivery address';
      return false;
    }

    return true;
  }

  // Navigation methods
  goBackToCart(): void {
    this.router.navigate(['/cart']);
  }

  goHome(): void {
    this.router.navigate(['/customer-main']);
  }

  // Utility methods
  formatPrice(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  }

  formatItemTotal(item: CartItem): string {
    return this.formatPrice(item.price * item.quantity);
  }

  getTotalItemCount(): number {
    return this.cartItems.reduce((sum, item) => sum + item.quantity, 0);
  }

  getVegIcon(item: CartItem): string {
    return item.isVegetarian ? '🟢' : '🔴';
  }

  getSavings(): number {
    let savings = this.discount;
    if (this.deliveryFee === 0 && this.cartSubtotal >= 300) {
      savings += 30;
    }
    return savings;
  }
}

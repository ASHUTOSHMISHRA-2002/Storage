import { Component, OnInit, OnDestroy, Inject } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { PLATFORM_ID } from '@angular/core';

interface CartItem {
  id: number;
  name: string;
  price: number;
  quantity: number;
  restaurantId: number;
  restaurantName: string;
  description?: string;
  image?: string;
  isVegetarian?: boolean;
}

@Component({
  selector: 'app-cart',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit, OnDestroy {
  cartItems: CartItem[] = [];
  
  // Pricing
  cartSubtotal = 0;
  deliveryFee = 30;
  serviceFee = 15;
  taxes = 0;
  discount = 0;
  grandTotal = 0;

  // State
  loading = false;
  error = '';
  
  // UI State
  showPriceBreakdown = false;
  isCheckingOut = false;
  
  // Restaurant info
  restaurantName = '';
  restaurantId = '';

  // Delivery estimate
  deliveryEstimate: string = '';

  constructor(
    private router: Router,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {}

  ngOnInit(): void {
    this.loadCart();
    this.generateDeliveryEstimate();
  }

  ngOnDestroy(): void {}

  // Cart loading and saving
  private loadCart(): void {
    if (isPlatformBrowser(this.platformId)) {
      try {
        const saved = localStorage.getItem('customerCart');
        this.cartItems = saved ? JSON.parse(saved) : [];
        this.extractRestaurantInfo();
        this.calculateTotals();
      } catch (error) {
        console.error('❌ Error loading cart:', error);
        this.cartItems = [];
        this.error = 'Failed to load cart items';
      }
    }
  }

  private saveCart(): void {
    if (isPlatformBrowser(this.platformId)) {
      try {
        localStorage.setItem('customerCart', JSON.stringify(this.cartItems));
        this.calculateTotals();
      } catch (error) {
        console.error('❌ Error saving cart:', error);
      }
    }
  }

  private extractRestaurantInfo(): void {
    if (this.cartItems.length > 0) {
      const firstItem = this.cartItems[0];
      this.restaurantName = firstItem.restaurantName;
      this.restaurantId = firstItem.restaurantId.toString();
    } else {
      this.restaurantName = '';
      this.restaurantId = '';
    }
  }

  private calculateTotals(): void {
    this.cartSubtotal = this.cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    this.deliveryFee = this.cartSubtotal >= 300 ? 0 : 30;
    this.serviceFee = Math.round(this.cartSubtotal * 0.02);
    this.taxes = Math.round((this.cartSubtotal + this.deliveryFee + this.serviceFee) * 0.05);
    this.discount = this.calculateDiscount();
    this.grandTotal = this.cartSubtotal + this.deliveryFee + this.serviceFee + this.taxes - this.discount;
  }

  private calculateDiscount(): number {
    let discount = 0;
    if (this.cartSubtotal > 200) {
      discount = Math.round(this.cartSubtotal * 0.1);
    }
    return Math.min(discount, 100);
  }

  // Cart operations
  increaseQuantity(item: CartItem): void {
    item.quantity++;
    this.saveCart();
    this.showFeedback(`Added one more ${item.name}`);
  }

  decreaseQuantity(item: CartItem): void {
    if (item.quantity > 1) {
      item.quantity--;
      this.saveCart();
      this.showFeedback(`Removed one ${item.name}`);
    } else {
      this.removeItemCompletely(item);
    }
  }

  removeItemCompletely(item: CartItem): void {
    if (confirm(`Remove ${item.name} from cart?`)) {
      this.cartItems = this.cartItems.filter(cartItem => cartItem.id !== item.id);
      this.saveCart();
      this.showFeedback(`${item.name} removed from cart`);
      if (this.cartItems.length === 0) {
        setTimeout(() => {
          this.router.navigate(['/customer-main']);
        }, 2000);
      }
    }
  }

  clearCart(): void {
    if (confirm('Are you sure you want to clear your cart? This action cannot be undone.')) {
      this.cartItems = [];
      this.saveCart();
      this.showFeedback('Cart cleared');
      setTimeout(() => {
        this.router.navigate(['/customer-main']);
      }, 1500);
    }
  }

  // Navigation
  continueShopping(): void {
    if (this.restaurantId) {
      this.router.navigate(['/restaurant', this.restaurantId, 'menu']);
    } else {
      this.router.navigate(['/customer-main']);
    }
  }

  goBackToRestaurant(): void {
    if (this.restaurantId) {
      this.router.navigate(['/restaurant', this.restaurantId]);
    } else {
      this.router.navigate(['/customer-main']);
    }
  }

  goHome(): void {
    this.router.navigate(['/customer-main']);
  }

  // ✅ FIXED: Proceed to payment instead of processing order directly
  proceedToCheckout(): void {
    if (this.cartItems.length === 0) {
      alert('Your cart is empty!');
      return;
    }

    const minOrder = 100;
    if (this.cartSubtotal < minOrder) {
      alert(`Minimum order amount is ₹${minOrder}. Add ₹${minOrder - this.cartSubtotal} more to proceed.`);
      return;
    }

    console.log('💳 Proceeding to payment page');
    
    // Save order summary for payment page
    const orderSummary = {
      items: this.cartItems,
      restaurantId: parseInt(this.restaurantId),
      restaurantName: this.restaurantName,
      subtotal: this.cartSubtotal,
      deliveryFee: this.deliveryFee,
      serviceFee: this.serviceFee,
      taxes: this.taxes,
      discount: this.discount,
      total: this.grandTotal
    };

    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem('orderSummary', JSON.stringify(orderSummary));
    }

    // ✅ REDIRECT TO PAYMENT PAGE
    this.router.navigate(['/payments']);
  }

  // Utility methods
  generateDeliveryEstimate(): void {
    const baseTime = 25;
    const randomVariation = Math.floor(Math.random() * 10);
    const deliveryTime = baseTime + randomVariation;
    this.deliveryEstimate = `${deliveryTime}-${deliveryTime + 10} mins`;
  }

  getItemImage(item: CartItem): string {
    return item.image || 'assets/images/food-placeholder.png';
  }

  onImageError(event: Event): void {
    const target = event.target as HTMLImageElement;
    if (target) {
      target.src = 'assets/images/food-placeholder.png';
    }
  }

  formatPrice(price: number): string {
    return new Intl.NumberFormat('en-IN', { 
      style: 'currency', 
      currency: 'INR', 
      maximumFractionDigits: 0 
    }).format(price);
  }

  formatItemTotal(item: CartItem): string {
    return this.formatPrice(item.price * item.quantity);
  }

  isCartEmpty(): boolean {
    return this.cartItems.length === 0;
  }

  getTotalItemCount(): number {
    return this.cartItems.reduce((sum, item) => sum + item.quantity, 0);
  }

  getVegIcon(item: CartItem): string {
    return item.isVegetarian ? '🟢' : '🔴';
  }

  getSavings(): number {
    let savings = this.discount;
    if (this.deliveryFee === 0 && this.cartSubtotal >= 300) savings += 30;
    return savings;
  }

  canProceedToCheckout(): boolean {
    return this.cartItems.length > 0 && this.cartSubtotal >= 100 && !this.isCheckingOut;
  }

  getMinOrderMessage(): string {
    const minOrder = 100;
    const remaining = minOrder - this.cartSubtotal;
    if (remaining > 0) return `Add ${this.formatPrice(remaining)} more to place order`;
    return '';
  }

  shareCart(): void {
    const cartSummary = this.cartItems.map(item => 
      `${item.name} x${item.quantity} - ${this.formatItemTotal(item)}`
    ).join('\n');  
    const shareText = `My cart from ${this.restaurantName}:\n\n${cartSummary}\n\nTotal: ${this.formatPrice(this.grandTotal)}`;
    if (navigator.share) {
      navigator.share({ title: `Cart from ${this.restaurantName}`, text: shareText })
        .catch(err => {});
    } else {
      navigator.clipboard.writeText(shareText)
        .then(() => this.showFeedback('Cart details copied to clipboard!'))
        .catch(() => {});
    }
  }

  trackByItemId(index: number, item: CartItem): number {
    return item ? item.id : index;
  }

  togglePriceBreakdown(): void {
    this.showPriceBreakdown = !this.showPriceBreakdown;
  }
  
  private showFeedback(message: string): void {
    if (isPlatformBrowser(this.platformId)) {
      const feedback = document.createElement('div');
      feedback.textContent = message;
      feedback.style.cssText = `
        position: fixed; top: 20px; right: 20px;
        background: #4CAF50; color: white; padding: 12px 24px;
        border-radius: 4px; z-index: 9999; font-size: 14px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.2);
      `;
      document.body.appendChild(feedback);
      setTimeout(() => {
        if (feedback.parentNode) feedback.parentNode.removeChild(feedback);
      }, 3000);
    }
  }
}

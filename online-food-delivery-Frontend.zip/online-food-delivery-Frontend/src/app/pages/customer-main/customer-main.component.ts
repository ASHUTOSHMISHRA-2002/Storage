import { Component, OnInit, OnDestroy, Inject } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClient,  HttpHeaders } from '@angular/common/http';
import { catchError, of, finalize, Subject, takeUntil, Observable } from 'rxjs';
import { PLATFORM_ID } from '@angular/core';
import { MenuService, MenuItem } from '../../services/menu.service';
import { AuthService } from '../../services/auth.service';
import { CartService } from '../../services/cart.service';
import { timeout } from 'rxjs/operators';

interface Restaurant {
  id: number;
  name: string;
  location: string;
  menu: MenuItem[];
  rating?: string;
  cuisineType?: string;
  isActive?: boolean;
  deliveryTime?: string;
  minOrder?: number;
  deliveryFee?: number;
}

interface Category {
  id: number;
  name: string;
  image: string;
  description?: string;
}

interface CartItem {
  id: number;
  name: string;
  price: number;
  quantity: number;
  restaurantId: number;
  restaurantName: string;
}

@Component({
  selector: 'app-customer-main',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './customer-main.component.html',
  styleUrls: ['./customer-main.component.css'],
})
export class CustomerComponent implements OnInit, OnDestroy {
  // ✅ ADD: Component lifecycle management
  private destroy$ = new Subject<void>();

  // Search and filtering
  searchTerm = '';
  selectedCategory = '';
  sortBy = 'rating';
  priceFilter = 'all';

  // Restaurant data
  restaurants: Restaurant[] = [];
  filteredRestaurants: Restaurant[] = [];
  categories: Category[] = [
    { id: 1, name: 'Biryani', image: 'https://images.pexels.com/photos/1624487/pexels-photo-1624487.jpeg?auto=compress&cs=tinysrgb&w=300', description: 'Traditional dishes' },
    { id: 2, name: 'Pizza', image: 'https://images.pexels.com/photos/315755/pexels-photo-315755.jpeg?auto=compress&cs=tinysrgb&w=300', description: 'Italian cuisine' },
    { id: 3, name: 'Burger', image: 'https://images.pexels.com/photos/1556698/pexels-photo-1556698.jpeg?auto=compress&cs=tinysrgb&w=300', description: 'Burgers and sandwiches' },
    { id: 4, name: 'Indian', image: 'https://images.pexels.com/photos/4874487/pexels-photo-4874487.jpeg?auto=compress&cs=tinysrgb&w=300', description: 'Authentic Indian cuisine' },
    { id: 5, name: 'Chinese', image: 'https://images.pexels.com/photos/2453457/pexels-photo-2453457.jpeg?auto=compress&cs=tinysrgb&w=300', description: 'Oriental dishes' },
    { id: 6, name: 'Desserts', image: 'https://images.pexels.com/photos/291528/pexels-photo-291528.jpeg?auto=compress&cs=tinysrgb&w=300', description: 'Delicious desserts' },
  ];

  // UI state
  loading = false;
  error = '';
  cart: CartItem[] = [];
  deliveryTimes: { [key: number]: string } = {};

  // ✅ ENHANCED: User and authentication state
  currentUser: any = null;
  isAuthenticated = false;
  userDisplayName = '';

  // API endpoints
  private readonly RESTAURANT_API = 'http://localhost:8082/api/restaurants';

  constructor(
    private router: Router,
    private http: HttpClient,
    private menuService: MenuService,
    private auth: AuthService, // ✅ ADD: AuthService injection
    private cartService: CartService, // ✅ ADD: CartService injection
    @Inject(PLATFORM_ID) private platformId: Object
  ) {
    console.log('🏗️ CustomerComponent initialized');
    this.initializeComponent();
  }

  ngOnInit(): void {
    console.log('🚀 CustomerComponent ngOnInit called');
    
    // ✅ ENHANCED: Comprehensive initialization
    this.checkAuthentication();
    this.initializeUserData();
    this.initializeCart();
    this.fetchRestaurants();
    this.initializeFilters();
    this.subscribeToCartChanges();
  }

  ngOnDestroy(): void {
    console.log('🧹 CustomerComponent destroying...');
    this.destroy$.next();
    this.destroy$.complete();
  }

  // ✅ ADD: Initialize component data
  private initializeComponent(): void {
    try {
      // Set initial state
      this.loading = false;
      this.error = '';
      
      console.log('✅ Component initialized successfully');
    } catch (error) {
      console.error('❌ Error initializing component:', error);
    }
  }

  // ✅ ENHANCED: Check authentication with AuthService
  private checkAuthentication(): void {
    if (!isPlatformBrowser(this.platformId)) {
      console.log('🔍 Server-side rendering, skipping auth check');
      return;
    }

    try {
      this.isAuthenticated = this.auth.isAuthenticated();
      
      if (!this.isAuthenticated) {
        console.warn('⚠️ User not authenticated, redirecting to login');
        this.router.navigate(['/customer-login']);
        return;
      }
      
      console.log('✅ User authentication verified');
    } catch (error) {
      console.error('❌ Error checking authentication:', error);
      this.router.navigate(['/customer-login']);
    }
  }

  // ✅ ADD: Initialize user data
  private initializeUserData(): void {
    if (!this.isAuthenticated) return;

    try {
      this.currentUser = this.auth.getUserInfo();
      this.userDisplayName = this.auth.getUserDisplayName();
      
      // Try to restore preserved cart for returning user
      const userId = this.currentUser?.userId?.toString();
      if (userId) {
        this.cartService.restorePreservedCart(userId);
      }
      
      console.log('👤 User data initialized:', {
        userId: this.currentUser?.userId,
        displayName: this.userDisplayName,
        userType: this.currentUser?.userType
      });
    } catch (error) {
      console.error('❌ Error initializing user data:', error);
    }
  }

  // ✅ ENHANCED: Initialize cart with CartService
  private initializeCart(): void {
    if (!isPlatformBrowser(this.platformId)) {
      console.log('🔍 Server-side rendering, initializing empty cart');
      this.cart = [];
      return;
    }

    try {
      const userId = this.currentUser?.userId?.toString();
      
      // Load cart from CartService
      this.cartService.loadCart(userId);
      this.cart = this.cartService.getCart();
      
      console.log('🛒 Cart initialized:', this.cart.length, 'items');
    } catch (error) {
      console.error('❌ Error initializing cart:', error);
      this.cart = [];
    }
  }

  // ✅ ADD: Subscribe to cart changes
  private subscribeToCartChanges(): void {
    this.cartService.cart$
      .pipe(takeUntil(this.destroy$))
      .subscribe(cartItems => {
        this.cart = cartItems;
        console.log('🔄 Cart updated via service:', cartItems.length, 'items');
      });
  }

  // ✅ ENHANCED: Initialize filters
  private initializeFilters(): void {
    this.applyFilters();
  }

  // ✅ ENHANCED: Fetch restaurants with better error handling
  fetchRestaurants(): void {
    if (this.loading) return;
    
    this.loading = true;
    this.error = '';
    
    console.log('🔍 Fetching restaurants from database...');
    
    this.http.get<Restaurant[]>(`${this.RESTAURANT_API}`, {
      headers: this.getAuthHeaders()
    }).pipe(
      takeUntil(this.destroy$),
      timeout(15000), // 15 second timeout
      catchError(err => {
        console.error('❌ Error fetching restaurants from database:', err);
        
        if (err.status === 401) {
          this.error = 'Authentication required. Please login again.';
        } else if (err.status >= 500) {
          this.error = 'Restaurant service is temporarily unavailable. Please try again later.';
        } else if (err.status === 404) {
          this.error = 'No restaurants found in database.';
        } else {
          this.error = `Failed to load restaurants: ${err.message || 'Unknown error'}`;
        }
        
        this.loading = false;
        return of([]);
      }),
      finalize(() => {
        this.loading = false;
      })
    ).subscribe(restaurants => {
      if (restaurants && restaurants.length > 0) {
        console.log(`✅ Successfully fetched ${restaurants.length} restaurants from database`);
        this.processRestaurants(restaurants);
      } else {
        console.log('⚠️ No restaurants found in database');
        this.error = 'No restaurants available at the moment.';
        this.restaurants = [];
        this.filteredRestaurants = [];
      }
    });
  }

  // ✅ ADD: Fallback restaurant fetching
  private fetchRestaurantsFallback(): Observable<Restaurant[]> {
    console.log('🔄 Trying fallback approach for restaurants');
    
    const fallbackHeaders = new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    });

    return this.http.get<Restaurant[]>(this.RESTAURANT_API, { headers: fallbackHeaders })
      .pipe(
        catchError((err: any) => {
          console.error('❌ Fallback approach also failed:', err);
          
          // Return fallback restaurant data
          return of(this.createFallbackRestaurants());
        })
      );
  }

  // ✅ ADD: Create fallback restaurant data
  private createFallbackRestaurants(): Restaurant[] {
    console.log('🛠️ Creating fallback restaurant data');
    
    const fallbackRestaurants: Restaurant[] = [
      {
        id: 1,
        name: 'Pizza Palace',
        location: 'Downtown',
        menu: [],
        rating: '4.5',
        cuisineType: 'Italian',
        isActive: true,
        deliveryTime: '30-45 mins',
        minOrder: 100,
        deliveryFee: 30
      },
      {
        id: 2,
        name: 'Burger House',
        location: 'Mall Road',
        menu: [],
        rating: '4.2',
        cuisineType: 'American',
        isActive: true,
        deliveryTime: '25-40 mins',
        minOrder: 80,
        deliveryFee: 25
      },
      {
        id: 3,
        name: 'Sushi Express',
        location: 'Business District',
        menu: [],
        rating: '4.7',
        cuisineType: 'Japanese',
        isActive: true,
        deliveryTime: '35-50 mins',
        minOrder: 150,
        deliveryFee: 40
      },
      {
        id: 4,
        name: 'Taco Town',
        location: 'University Area',
        menu: [],
        rating: '4.0',
        cuisineType: 'Mexican',
        isActive: true,
        deliveryTime: '20-35 mins',
        minOrder: 60,
        deliveryFee: 20
      }
    ];

    console.log('✅ Fallback restaurants created:', fallbackRestaurants.length, 'restaurants');
    return fallbackRestaurants;
  }

  // ✅ ADD: Process restaurant data
  private processRestaurants(restaurants: Restaurant[]): void {
    this.restaurants = restaurants.map(r => ({
      ...r,
      rating: r.rating ?? (Math.random() * 2 + 3).toFixed(1),
      deliveryTime: r.deliveryTime ?? this.generateDeliveryTime(),
      minOrder: r.minOrder ?? 100,
      deliveryFee: r.deliveryFee ?? 30,
      menu: [],
      isActive: r.isActive !== false,
    }));

    // Set delivery times
    this.restaurants.forEach(restaurant => {
      this.deliveryTimes[restaurant.id] = restaurant.deliveryTime || this.generateDeliveryTime();
    });

    console.log('🏪 Processed restaurants:', this.restaurants.map(r => `${r.id}: ${r.name}`));

    // Load menus
    this.restaurants.forEach(restaurant => {
      this.loadMenuForRestaurant(restaurant);
    });

    this.applyFilters();
  }

  // ✅ ADD: Get authentication headers
  private getAuthHeaders(): HttpHeaders {
    const token = this.auth.getToken();
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': token ? `Bearer ${token}` : ''
    });
  }

  // ✅ ENHANCED: Error message handling
  private getErrorMessage(err: any): string {
    if (err.status === 0) {
      return 'Cannot connect to restaurant service. Please check if the server is running on port 8082.';
    } else if (err.status === 403) {
      return 'Access denied. Please try refreshing or contact support.';
    } else if (err.status === 404) {
      return 'Restaurant service not found. Please verify the service is running on port 8082.';
    } else if (err.status === 500) {
      return 'Server error occurred while fetching restaurants.';
    } else if (err.status === 401) {
      return 'Authentication failed. Please login again.';
    } else {
      return `Error ${err.status}: ${err.message || 'Unknown error occurred'}`;
    }
  }

  // ✅ ENHANCED: Load menu with lifecycle management
  private loadMenuForRestaurant(restaurant: Restaurant): void {
    console.log(`🔍 Loading menu for restaurant ${restaurant.id} - ${restaurant.name}`);
    
    this.menuService.getMenuItemsByRestaurant(restaurant.id, false)
      .pipe(
        takeUntil(this.destroy$),
        catchError((err: any) => {
          console.error(`❌ Failed to load menu for restaurant ${restaurant.id} (${restaurant.name}):`, err);
          return of([]);
        })
      )
      .subscribe((menuItems: MenuItem[]) => {
        console.log(`✅ Received menu for restaurant ${restaurant.id} (${restaurant.name}):`, menuItems.length, 'items');
        
        restaurant.menu = menuItems || [];
        this.applyFilters();
        
        if (menuItems && menuItems.length > 0) {
          console.log(`📋 Menu items for ${restaurant.name}:`, 
            menuItems.map(item => `${item.itemName} - ₹${item.price} (${item.isVegetarian ? 'Veg' : 'Non-Veg'})`));
        } else {
          console.log(`📋 No menu items found for ${restaurant.name}`);
        }
      });
  }

  generateDeliveryTime(): string {
    const min = Math.floor(Math.random() * 20) + 25;
    const max = min + Math.floor(Math.random() * 10) + 5;
    return `${min}-${max} mins`;
  }

  // ✅ ENHANCED: Cart calculations using CartService
  get cartTotal(): number {
    return this.cartService.getCartTotal();
  }

  get cartTotalFormatted(): string {
    return this.formatPrice(this.cartTotal);
  }

  get cartCount(): number {
    return this.cartService.getCartItemCount();
  }

  // ✅ ENHANCED: Add to cart using CartService
  addToCart(item: MenuItem, restaurant: Restaurant): void {
    try {
      console.log('🛒 Adding to cart:', item.itemName, 'from', restaurant.name);
      
      if (!item.itemId || !item.itemName || !item.price) {
        console.error('❌ Invalid menu item data:', item);
        return;
      }

      const cartItem: CartItem = {
        id: item.itemId,
        name: item.itemName,
        price: item.price,
        quantity: 1,
        restaurantId: restaurant.id,
        restaurantName: restaurant.name,
      };

      const userId = this.currentUser?.userId?.toString();
      this.cartService.addToCart(cartItem, userId);
      
      console.log('🛒 Cart updated. Total items:', this.cartCount, 'Total value:', this.cartTotalFormatted);
    } catch (error) {
      console.error('❌ Error adding item to cart:', error);
    }
  }

  // ✅ ENHANCED: Apply filters (unchanged but improved logging)
  applyFilters(): void {
    let filtered = [...this.restaurants];
    
    if (this.searchTerm && this.searchTerm.trim()) {
      const term = this.searchTerm.toLowerCase().trim();
      filtered = filtered.filter(r => {
        const nameMatch = r.name && r.name.toLowerCase().includes(term);
        const locationMatch = r.location && r.location.toLowerCase().includes(term);
        const cuisineMatch = r.cuisineType && r.cuisineType.toLowerCase().includes(term);
        const menuMatch = r.menu && r.menu.some(m => 
          (m.itemName && m.itemName.toLowerCase().includes(term)) ||
          (m.description && m.description.toLowerCase().includes(term))
        );
        
        return nameMatch || locationMatch || cuisineMatch || menuMatch;
      });
    }
    
    if (this.selectedCategory && this.selectedCategory !== 'all') {
      const cat = this.selectedCategory.toLowerCase();
      filtered = filtered.filter(r => {
        const nameMatch = r.name && r.name.toLowerCase().includes(cat);
        const cuisineMatch = r.cuisineType && r.cuisineType.toLowerCase().includes(cat);
        const menuMatch = r.menu && r.menu.some(m => 
          m.itemName && m.itemName.toLowerCase().includes(cat)
        );
        
        return nameMatch || cuisineMatch || menuMatch;
      });
    }
    
    if (this.priceFilter === 'budget') {
      filtered = filtered.filter(r => r.minOrder && r.minOrder < 200);
    } else if (this.priceFilter === 'premium') {
      filtered = filtered.filter(r => r.minOrder && r.minOrder >= 300);
    }
    
    filtered.sort((a, b) => {
      switch (this.sortBy) {
        case 'rating': 
          const ratingA = parseFloat(a.rating || '0');
          const ratingB = parseFloat(b.rating || '0');
          return ratingB - ratingA;
        case 'deliveryTime': 
          return this.getTimeMinutes(a.deliveryTime || '') - this.getTimeMinutes(b.deliveryTime || '');
        case 'name': 
          return (a.name || '').localeCompare(b.name || '');
        default: 
          return 0;
      }
    });
    
    this.filteredRestaurants = filtered;
    console.log('✅ Applied filters. Showing', filtered.length, 'of', this.restaurants.length, 'restaurants');
  }

  getTimeMinutes(timeStr: string): number {
    if (!timeStr) return 0;
    const match = timeStr.match(/(\d+)-/);
    return match ? parseInt(match[1]) : 0;
  }

  // Filter and search methods (unchanged)
  onSearchChange(): void {
    this.applyFilters();
  }

  handleCategoryClick(categoryName: string): void {
    this.selectedCategory = this.selectedCategory === categoryName ? '' : categoryName;
    this.searchTerm = '';
    this.applyFilters();
    console.log('🏷️ Category filter applied:', this.selectedCategory || 'None');
  }

  onSortChange(sortValue: string): void {
    this.sortBy = sortValue;
    this.applyFilters();
    console.log('🔄 Sort changed to:', sortValue);
  }

  onPriceChange(priceValue: string): void {
    this.priceFilter = priceValue;
    this.applyFilters();
    console.log('💰 Price filter changed to:', priceValue);
  }

  clearFilters(): void {
    this.selectedCategory = '';
    this.searchTerm = '';
    this.sortBy = 'rating';
    this.priceFilter = 'all';
    this.applyFilters();
    console.log('🧹 All filters cleared');
  }

  refresh(): void {
    console.log('🔄 Refreshing restaurants and menus...');
    this.clearFilters();
    this.fetchRestaurants();
  }

  retryFetch(): void {
    console.log('🔄 Retrying restaurant fetch...');
    this.error = '';
    this.fetchRestaurants();
  }

  // Template helper methods (unchanged)
  trackByCategoryId(index: number, item: Category): number {
    return item.id;
  }

  trackByRestaurantId(index: number, item: Restaurant): number {
    return item.id;
  }

  isRestaurantOpen(restaurant: Restaurant): boolean {
    return restaurant.isActive !== false;
  }

  getMenuCount(menu: MenuItem[], predicate: (item: MenuItem) => boolean): number {
    return menu ? menu.filter(predicate).length : 0;
  }

  getVegCount(menu: MenuItem[]): number {
    return this.getMenuCount(menu, (item: MenuItem) => item.isVegetarian === true);
  }

  getNonVegCount(menu: MenuItem[]): number {
    return this.getMenuCount(menu, (item: MenuItem) => item.isVegetarian === false);
  }

  getMenuPreview(menu: MenuItem[]): string {
    if (!menu || menu.length === 0) return 'No items available';
    const preview = menu.slice(0, 3).map(m => m.itemName).filter(name => name).join(', ');
    return preview || 'Menu loading...';
  }

  formatPrice(amount: number): string {
    return new Intl.NumberFormat('en-IN', { 
      style: 'currency', 
      currency: 'INR', 
      maximumFractionDigits: 0 
    }).format(amount);
  }

  // ✅ ENHANCED: Navigation methods
  goToRestaurant(id: number): void {
    try {
      const restaurantId = id.toString();
      console.log('🏪 Navigating to restaurant:', restaurantId);
      
      const restaurant = this.restaurants.find(r => r.id === id);
      if (!restaurant) {
        console.error('❌ Restaurant not found:', id);
        alert('Restaurant not found. Please try refreshing the page.');
        return;
      }
      
      console.log('✅ Found restaurant:', restaurant.name);
      
      // Preserve cart before navigation
      this.preserveCartBeforeNavigation();
      
      this.router.navigate(['/restaurant', restaurantId]).then(
        (success) => {
          if (success) {
            console.log('✅ Navigation successful to restaurant:', restaurantId);
          } else {
            console.error('❌ Navigation failed to restaurant:', restaurantId);
            alert('Failed to navigate to restaurant. Please try again.');
          }
        }
      ).catch((error) => {
        console.error('❌ Navigation error:', error);
        alert('Navigation error occurred. Please try again.');
      });
      
    } catch (error) {
      console.error('❌ Error in goToRestaurant:', error);
      alert('An error occurred. Please try again.');
    }
  }

  goToRestaurantMenu(id: number): void {
    try {
      const restaurantId = id.toString();
      console.log('🍽️ Navigating to restaurant menu:', restaurantId);
      
      const restaurant = this.restaurants.find(r => r.id === id);
      if (!restaurant) {
        console.error('❌ Restaurant not found:', id);
        alert('Restaurant not found. Please try refreshing the page.');
        return;
      }
      
      console.log('✅ Found restaurant for menu:', restaurant.name);
      
      // Preserve cart before navigation
      this.preserveCartBeforeNavigation();
      
      this.router.navigate(['/restaurant', restaurantId, 'menu']).then(
        (success) => {
          if (success) {
            console.log('✅ Navigation successful to menu:', restaurantId);
          } else {
            console.error('❌ Navigation failed to menu:', restaurantId);
            alert('Failed to navigate to menu. Please try again.');
          }
        }
      ).catch((error) => {
        console.error('❌ Menu navigation error:', error);
        alert('Menu navigation error occurred. Please try again.');
      });
      
    } catch (error) {
      console.error('❌ Error in goToRestaurantMenu:', error);
      alert('An error occurred. Please try again.');
    }
  }

  // ✅ ENHANCED: Cart navigation with preservation
  goToCart(): void {
    console.log('🛒 Navigating to cart. Items:', this.cartCount);
    
    // Preserve cart before navigation
    this.preserveCartBeforeNavigation();
    
    this.router.navigate(['/cart']).then(
      (success) => {
        if (success) {
          console.log('✅ Navigation successful to cart');
        } else {
          console.error('❌ Navigation failed to cart');
        }
      }
    ).catch((error) => {
      console.error('❌ Cart navigation error:', error);
    });
  }

  // ✅ ADD: Preserve cart before navigation
  private preserveCartBeforeNavigation(): void {
    const userId = this.currentUser?.userId?.toString();
    if (userId && this.cartCount > 0) {
      this.cartService.preserveCartForUser(userId);
      console.log('🔐 Cart preserved before navigation');
    }
  }

  goToProfile(): void {
    console.log('👤 Navigating to profile');
    this.router.navigate(['/profile']).then(
      (success) => {
        if (success) {
          console.log('✅ Navigation successful to profile');
        } else {
          console.error('❌ Navigation failed to profile');
        }
      }
    ).catch((error) => {
      console.error('❌ Profile navigation error:', error);
    });
  }

  // ✅ ADD: Go to order tracking
  goToOrderTracking(): void {
    console.log('📦 Navigating to order tracking');
    this.router.navigate(['/order-tracking']).then(
      (success) => {
        if (success) {
          console.log('✅ Navigation successful to order tracking');
        } else {
          console.error('❌ Navigation failed to order tracking');
        }
      }
    ).catch((error) => {
      console.error('❌ Order tracking navigation error:', error);
    });
  }

  // ✅ ADD: Go to order history
  goToOrders(): void {
    console.log('📋 Navigating to orders');
    this.router.navigate(['/orders']).then(
      (success) => {
        if (success) {
          console.log('✅ Navigation successful to orders');
        } else {
          console.error('❌ Navigation failed to orders');
        }
      }
    ).catch((error) => {
      console.error('❌ Orders navigation error:', error);
    });
  }

  // ✅ ENHANCED: Method to handle order completion and redirect to tracking
  onOrderPlaced(orderId: number): void {
    console.log('✅ Order placed successfully:', orderId);
    
    try {
      // Store order for tracking
      this.auth.storeOrderForTracking(orderId.toString(), this.auth.getCustomerDetails());
      
      // Clear cart after successful order
      const userId = this.currentUser?.userId?.toString();
      if (userId) {
        this.cartService.clearCart(userId);
      }
      
      // Navigate to order tracking
      this.router.navigate(['/order-tracking', orderId]);
      
      console.log('🎉 Order placement process completed');
    } catch (error) {
      console.error('❌ Error handling order placement:', error);
    }
  }

  // ✅ ENHANCED: Logout with AuthService
  logout(): void {
    if (this.cartCount > 0) {
      const confirmLogout = confirm(`You have ${this.cartCount} items in your cart. Are you sure you want to logout?`);
      if (!confirmLogout) {
        return;
      }
    }

    try {
      // Preserve cart and user data before logout
      const userId = this.currentUser?.userId?.toString();
      if (userId) {
        this.cartService.preserveCartForUser(userId);
        this.auth.preserveCartForRoleSwitch();
      }
      
      // Use AuthService logout
      this.auth.logout();
      
      console.log('🚪 User logged out');
      this.router.navigate(['/customer-login']);
    } catch (error) {
      console.error('❌ Error during logout:', error);
      // Force navigation even if error occurs
      this.router.navigate(['/customer-login']);
    }
  }

  // ✅ ENHANCED: Debug method
  debugComponent(): void {
    console.log('🔍 Customer Main Debug Info:', {
      restaurantsCount: this.restaurants.length,
      filteredCount: this.filteredRestaurants.length,
      cartItems: this.cartCount,
      cartTotal: this.cartTotalFormatted,
      loading: this.loading,
      error: this.error,
      isBrowser: isPlatformBrowser(this.platformId),
      restaurantAPI: this.RESTAURANT_API,
      currentRoute: this.router.url,
      restaurantIds: this.restaurants.map(r => r.id),
      userInfo: this.currentUser,
      isAuthenticated: this.isAuthenticated,
      filters: {
        search: this.searchTerm,
        category: this.selectedCategory,
        sort: this.sortBy,
        price: this.priceFilter
      }
    });
    
    // Debug auth state
    this.auth.debugAuthState();
    
    console.log('🧪 Testing route configuration...');
    console.log('Available routes:', this.router.config.map(r => r.path));
  }

  // ✅ ADD: Check if user has active orders for order tracking button
  hasActiveOrders(): boolean {
    // This would typically check with order service
    // For now, return true if user has tracking data
    return !!this.auth.getOrderTrackingData();
  }

  // ✅ ADD: Get user greeting
  getUserGreeting(): string {
    const hour = new Date().getHours();
    let greeting = 'Hello';
    
    if (hour < 12) {
      greeting = 'Good Morning';
    } else if (hour < 17) {
      greeting = 'Good Afternoon';
    } else {
      greeting = 'Good Evening';
    }
    
    const name = this.userDisplayName || 'Foodie';
    return `${greeting}, ${name}!`;
  }

  // ✅ ADD: Quick actions
  clearCart(): void {
    if (this.cartCount === 0) return;
    
    const confirmClear = confirm(`Are you sure you want to clear all ${this.cartCount} items from your cart?`);
    if (confirmClear) {
      const userId = this.currentUser?.userId?.toString();
      this.cartService.clearCart(userId);
      console.log('🗑️ Cart cleared by user');
    }
  }

  // ✅ ADD: Remove item from cart
  removeFromCart(itemId: number, restaurantId: number): void {
    const userId = this.currentUser?.userId?.toString();
    this.cartService.removeFromCart(itemId, restaurantId, userId);
    console.log('🗑️ Item removed from cart:', itemId);
  }

  // ✅ ADD: Update cart item quantity
  updateCartQuantity(itemId: number, restaurantId: number, newQuantity: number): void {
    const userId = this.currentUser?.userId?.toString();
    this.cartService.updateQuantity(itemId, restaurantId, newQuantity, userId);
    console.log('🔢 Cart quantity updated:', itemId, 'New quantity:', newQuantity);
  }
}

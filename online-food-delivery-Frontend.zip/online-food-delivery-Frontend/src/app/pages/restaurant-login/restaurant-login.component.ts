


import { Component, inject, PLATFORM_ID } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { isPlatformBrowser, CommonModule } from '@angular/common';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-restaurant-login',
  standalone: true,
  imports: [ReactiveFormsModule, RouterLink, CommonModule],
  templateUrl: './restaurant-login.component.html',
  styleUrls: ['./restaurant-login.component.css']
})
export class RestaurantLoginComponent {
  loginForm: FormGroup;
  message = '';
  submitting = false;

  private http = inject(HttpClient);
  private router = inject(Router);
  private auth = inject(AuthService);
  private platformId = inject(PLATFORM_ID);
  private fb = inject(FormBuilder);

  constructor() {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(5)]]
    });
  }

  login(): void {
    if (this.loginForm.invalid || this.submitting) {
      return;
    }

    this.submitting = true;
    this.message = '';

    const credentials = {
      email: this.loginForm.get('email')?.value,
      password: this.loginForm.get('password')?.value
    };

    console.log('🔍 Restaurant login attempt:', credentials.email);

    // Restaurant service is running on port 8082
    const loginUrl = 'http://localhost:8082/api/restaurants/login';

    this.http.post<any>(loginUrl, credentials)
      .subscribe({
        next: (response) => {
          console.log('✅ Restaurant login successful:', response);

          // Store the JWT token
          if (response.jwtToken || response.token) {
            const token = response.jwtToken || response.token;
            if (isPlatformBrowser(this.platformId)) {
              localStorage.setItem('jwtToken', token);
              localStorage.setItem('authToken', token); // Also store as authToken for compatibility
              console.log('✅ Token stored successfully:', token.substring(0, 20) + '...');
              
              // Decode and store user info from JWT
              try {
                const payload = token.split('.')[1];
                const decodedPayload = JSON.parse(atob(payload));
                console.log('✅ Decoded JWT payload:', decodedPayload);
                
                // Store user type and roles
                if (decodedPayload.userType) {
                  localStorage.setItem('userType', decodedPayload.userType);
                }
                if (decodedPayload.roles) {
                  localStorage.setItem('userRoles', JSON.stringify(decodedPayload.roles));
                }
                if (decodedPayload.email) {
                  localStorage.setItem('userEmail', decodedPayload.email);
                }
                if (decodedPayload.userId) {
                  localStorage.setItem('userId', decodedPayload.userId.toString());
                }
              } catch (decodeError) {
                console.error('❌ Error decoding JWT:', decodeError);
              }
            }
          } else {
            console.warn('⚠️ No token found in response:', response);
          }

          // Store restaurant data if available
          if (response.restaurant) {
            console.log('✅ Storing restaurant data:', response.restaurant);
            this.auth.storeRestaurantInfo({
              name: response.restaurant.name,
              location: response.restaurant.location,
              email: response.restaurant.email,
              phone: response.restaurant.phone || '',
              address: response.restaurant.address || '',
              city: response.restaurant.city || '',
              state: response.restaurant.state || '',
              pincode: response.restaurant.pincode || ''
            });

            // Store restaurant ID
            if (response.restaurant.id) {
              if (isPlatformBrowser(this.platformId)) {
                localStorage.setItem('restaurantId', response.restaurant.id.toString());
                console.log('✅ Restaurant ID stored:', response.restaurant.id);
              }
            }
          } else {
            console.warn('⚠️ No restaurant data in response:', response);
          }

          // Store user info
          if (response.user) {
            if (isPlatformBrowser(this.platformId)) {
              localStorage.setItem('userInfo', JSON.stringify(response.user));
              console.log('✅ User info stored:', response.user);
            }
          }

          // Force AuthService to refresh its state
          setTimeout(() => {
            this.auth.debugAuthState();
          }, 100);

          this.message = 'Login successful! Redirecting to dashboard...';
          setTimeout(() => {
            this.router.navigate(['/restaurant-dashboard']);
          }, 1500);
        },
        error: (error) => {
          console.error(`❌ Login failed:`, error);
          this.submitting = false;
          
          if (error.status === 401) {
            this.message = 'Invalid email or password.';
          } else if (error.status === 404) {
            this.message = 'Restaurant service not found. Please check if the backend is running.';
          } else if (error.status === 500) {
            this.message = 'Server error. Please try again later.';
          } else {
            this.message = `Login failed: ${error.message || 'Unknown error'}`;
          }
        }
      });
  }

  getErrorMessage(controlName: string): string {
    const control = this.loginForm.get(controlName);
    if (control?.errors && control.touched) {
      if (control.errors['required']) {
        return `${controlName.charAt(0).toUpperCase() + controlName.slice(1)} is required`;
      }
      if (control.errors['email']) {
        return 'Please enter a valid email address';
      }
      if (control.errors['minlength']) {
        return `${controlName.charAt(0).toUpperCase() + controlName.slice(1)} must be at least ${control.errors['minlength'].requiredLength} characters`;
      }
    }
    return '';
  }
}

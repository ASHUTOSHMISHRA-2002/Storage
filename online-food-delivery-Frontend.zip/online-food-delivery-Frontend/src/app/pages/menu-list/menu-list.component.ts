
// src/app/pages/menu-list/menu-list.component.ts
import { Component, OnInit, OnDestroy, Inject } from '@angular/core';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { HttpClient, HttpHeaders} from '@angular/common/http';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { PLATFORM_ID } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil, catchError, finalize } from 'rxjs/operators';
import { of } from 'rxjs';

interface MenuItem {
  itemId: number;
  restaurantId: number;
  itemName: string;
  description: string;
  price: number;
  isVegetarian: boolean;
  image?: string;
}

interface Restaurant {
  id: number;
  name: string;
  location: string;
  email: string;
  cuisineType?: string;
  rating?: number;
  deliveryTime?: string;
  minOrder?: number;
  deliveryFee?: number;
  isOpen?: boolean;
}

interface CartItem {
  id: number;
  name: string;
  price: number;
  quantity: number;
  restaurantId: number;
  restaurantName: string;
}

@Component({
  selector: 'app-menu-list',
  standalone: true,
  imports: [CommonModule,RouterModule, FormsModule],
  templateUrl: './menu-list.component.html',
  styleUrls: ['./menu-list.component.css']
})
export class MenuListComponent implements OnInit, OnDestroy {
  // Core data
  menuItems: MenuItem[] = [];
  restaurant: Restaurant | null = null;
  restaurantId: string = '';
  isLoading = true;
  error = '';
  
  // Filter states
  showVegOnly = false;
  searchTerm = '';
  filteredMenuItems: MenuItem[] = [];
  
  // Cart state
  cart: CartItem[] = [];
  
  // Cleanup
  private destroy$ = new Subject<void>();
  
  // API endpoints
  private readonly MENU_API = 'http://localhost:9096/api/menu';
  private readonly RESTAURANT_API = 'http://localhost:8082/api/restaurants';

  constructor(
    private http: HttpClient,
    private route: ActivatedRoute,
    private router: Router,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {
    this.loadCartFromStorage();
  }

  ngOnInit(): void {
    console.log('🍽️ MenuListComponent initialized');
    
    this.restaurantId = this.route.snapshot.paramMap.get('id') || '';
    
    if (this.restaurantId) {
      console.log('📋 Loading menu for restaurant ID:', this.restaurantId);
      this.loadRestaurantInfo();
      this.loadMenuItems();
    } else {
      this.error = 'Restaurant ID not found';
      this.isLoading = false;
      console.error('❌ No restaurant ID provided in route');
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  // 🔥 CART STORAGE METHODS

  private loadCartFromStorage(): void {
    if (isPlatformBrowser(this.platformId)) {
      try {
        const saved = localStorage.getItem('customerCart');
        this.cart = saved ? JSON.parse(saved) : [];
        console.log('🛒 Loaded cart from storage:', this.cart.length, 'items');
      } catch (error) {
        console.error('❌ Error loading cart:', error);
        this.cart = [];
      }
    }
  }

  private saveCartToStorage(): void {
    if (isPlatformBrowser(this.platformId)) {
      try {
        localStorage.setItem('customerCart', JSON.stringify(this.cart));
        console.log('💾 Saved cart to storage:', this.cart.length, 'items');
      } catch (error) {
        console.error('❌ Error saving cart:', error);
      }
    }
  }

  // 🔥 HTTP METHODS

  private getAuthHeaders(): HttpHeaders {
    let headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });

    if (isPlatformBrowser(this.platformId)) {
      const token = localStorage.getItem('jwtToken') || localStorage.getItem('authToken');
      if (token) {
        headers = headers.set('Authorization', `Bearer ${token}`);
      }
    }

    return headers;
  }

  private loadRestaurantInfo(): void {
    const headers = this.getAuthHeaders();
    
    this.http.get<Restaurant>(`${this.RESTAURANT_API}/${this.restaurantId}`, { headers })
      .pipe(
        takeUntil(this.destroy$),
        catchError((err) => {
          console.error('❌ Error loading restaurant info:', err);
          return of(null);
        })
      )
      .subscribe((restaurant) => {
        if (restaurant) {
          this.restaurant = restaurant;
          console.log('✅ Restaurant info loaded:', restaurant.name);
        }
      });
  }

  private loadMenuItems(): void {
    const headers = this.getAuthHeaders();
    const restaurantIdNum = parseInt(this.restaurantId);

    this.http.get<MenuItem[]>(`${this.MENU_API}/restaurant/${restaurantIdNum}`, { headers })
      .pipe(
        takeUntil(this.destroy$),
        catchError((err) => {
          console.error('❌ Error loading menu items:', err);
          this.error = 'Unable to load menu items. Please try again.';
          return of([]);
        }),
        finalize(() => {
          this.isLoading = false;
        })
      )
      .subscribe({
        next: (data) => {
          console.log('✅ Menu items loaded:', data.length, 'items');
          this.menuItems = data;
          this.applyFilters();
        }
      });
  }

  // 🔥 CART OPERATIONS

  addToCart(item: MenuItem): void {
    try {
      console.log('🛒 Adding to cart:', item.itemName);
      
      if (!item.itemId || !item.itemName || item.price === undefined || item.price === null) {
        console.error('❌ Invalid menu item data:', item);
        this.showCartFeedback('Invalid item data. Please try again.');
        return;
      }
      
      const existing = this.cart.find(c => c.id === item.itemId);
      
      if (existing) {
        existing.quantity++;
        console.log('📈 Increased quantity for:', item.itemName, 'New quantity:', existing.quantity);
        this.showCartFeedback(`Added one more ${item.itemName}`);
      } else {
        const cartItem: CartItem = {
          id: item.itemId,
          name: item.itemName,
          price: item.price,
          quantity: 1,
          restaurantId: parseInt(this.restaurantId),
          restaurantName: this.restaurant?.name || 'Unknown Restaurant'
        };
        this.cart.push(cartItem);
        console.log('➕ Added new item to cart:', cartItem);
        this.showCartFeedback(`Added ${item.itemName} to cart`);
      }
      
      this.saveCartToStorage();
    } catch (error) {
      console.error('❌ Error adding item to cart:', error);
      this.showCartFeedback('Failed to add item to cart. Please try again.');
    }
  }

  removeFromCart(item: MenuItem): void {
    try {
      console.log('🗑️ Removing from cart:', item.itemName);
      
      const existing = this.cart.find(c => c.id === item.itemId);
      
      if (existing) {
        if (existing.quantity > 1) {
          existing.quantity--;
          console.log('📉 Decreased quantity for:', item.itemName, 'New quantity:', existing.quantity);
          this.showCartFeedback(`Removed one ${item.itemName}`);
        } else {
          this.cart = this.cart.filter(c => c.id !== item.itemId);
          console.log('🗑️ Removed item completely from cart:', item.itemName);
          this.showCartFeedback(`${item.itemName} removed from cart`);
        }
        
        this.saveCartToStorage();
      } else {
        console.warn('⚠️ Item not found in cart:', item.itemName);
      }
    } catch (error) {
      console.error('❌ Error removing item from cart:', error);
      this.showCartFeedback('Failed to remove item. Please try again.');
    }
  }

  removeItemCompletely(item: MenuItem): void {
    try {
      const existing = this.cart.find(c => c.id === item.itemId);
      
      if (existing) {
        const removedQuantity = existing.quantity;
        this.cart = this.cart.filter(c => c.id !== item.itemId);
        console.log('🗑️ Removed all quantities:', item.itemName, 'Quantity removed:', removedQuantity);
        this.saveCartToStorage();
        this.showCartFeedback(`All ${item.itemName} removed from cart`);
      }
    } catch (error) {
      console.error('❌ Error removing item completely:', error);
      this.showCartFeedback('Failed to remove item. Please try again.');
    }
  }

  clearCart(): void {
    if (this.cart.length === 0) {
      this.showCartFeedback('Cart is already empty');
      return;
    }

    const confirmClear = confirm(`Remove all ${this.cartCount} items from cart?`);
    
    if (confirmClear) {
      this.cart = [];
      this.saveCartToStorage();
      console.log('🗑️ Cart cleared completely');
      this.showCartFeedback('Cart cleared successfully');
    }
  }

  // 🔥 CART HELPER METHODS

  getCartItemQuantity(itemId: number): number {
    const item = this.cart.find(c => c.id === itemId);
    return item ? item.quantity : 0;
  }

  isInCart(itemId: number): boolean {
    return this.cart.some(c => c.id === itemId);
  }

  get cartCount(): number {
    return this.cart.reduce((sum, item) => sum + item.quantity, 0);
  }

  get cartTotal(): number {
    return this.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  }

  get cartTotalFormatted(): string {
    return this.formatPrice(this.cartTotal);
  }

  get hasCartItems(): boolean {
    return this.cart.length > 0;
  }

  // 🔥 FILTER METHODS

  applyFilters(): void {
    let filtered = [...this.menuItems];

    // Apply search filter
    if (this.searchTerm.trim()) {
      const term = this.searchTerm.toLowerCase();
      filtered = filtered.filter(item =>
        item.itemName.toLowerCase().includes(term) ||
        (item.description && item.description.toLowerCase().includes(term))
      );
    }

    // Apply vegetarian filter
    if (this.showVegOnly) {
      filtered = filtered.filter(item => item.isVegetarian === true);
    }

    this.filteredMenuItems = filtered;
    console.log('🔍 Applied filters. Showing', filtered.length, 'of', this.menuItems.length, 'items');
  }

  onSearchChange(): void {
    this.applyFilters();
  }

  toggleVegFilter(): void {
    this.showVegOnly = !this.showVegOnly;
    this.applyFilters();
    console.log('🥬 Veg filter:', this.showVegOnly ? 'ON' : 'OFF');
  }

  clearSearch(): void {
    this.searchTerm = '';
    this.applyFilters();
  }

  clearFilters(): void {
    this.searchTerm = '';
    this.showVegOnly = false;
    this.applyFilters();
    console.log('🔄 All filters cleared');
  }

  // 🔥 UTILITY METHODS

  formatPrice(amount: number): string {
    if (amount === undefined || amount === null || isNaN(amount)) {
      return '₹0';
    }
    
    return new Intl.NumberFormat('en-IN', { 
      style: 'currency', 
      currency: 'INR', 
      maximumFractionDigits: 0 
    }).format(amount);
  }

  getVegCount(): number {
    return this.menuItems.filter(item => item.isVegetarian === true).length;
  }

  getNonVegCount(): number {
    return this.menuItems.filter(item => item.isVegetarian === false).length;
  }

  trackByItemId(index: number, item: MenuItem): number {
    return item?.itemId || index;
  }

  // 🔥 NAVIGATION METHODS

  goBack(): void {
    console.log('⬅️ Going back to restaurant details');
    this.router.navigate(['/restaurant', this.restaurantId]);
  }

  goToCustomerMain(): void {
    console.log('🏠 Going to customer main');
    this.router.navigate(['/customer-main']);
  }

  goToCart(): void {
    console.log('🛒 Going to cart');
    this.router.navigate(['/cart']);
  }

  retry(): void {
    console.log('🔄 Retrying menu load');
    this.error = '';
    this.isLoading = true;
    this.loadRestaurantInfo();
    this.loadMenuItems();
  }

  // 🔥 UI FEEDBACK

  private showCartFeedback(message: string): void {
    console.log('💬 Cart feedback:', message);
    
    if (isPlatformBrowser(this.platformId)) {
      // Remove any existing feedback
      const existingFeedback = document.querySelector('.cart-feedback');
      if (existingFeedback) {
        existingFeedback.remove();
      }

      const feedback = document.createElement('div');
      feedback.className = 'cart-feedback';
      feedback.textContent = message;
      feedback.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #4CAF50;
        color: white;
        padding: 12px 24px;
        border-radius: 8px;
        z-index: 9999;
        font-size: 14px;
        font-weight: 500;
        box-shadow: 0 4px 12px rgba(76, 175, 80, 0.3);
        animation: slideInRight 0.3s ease-out;
        max-width: 300px;
        word-wrap: break-word;
      `;
      
      // Add CSS animation keyframes if not already present
      if (!document.querySelector('#cartFeedbackStyles')) {
        const style = document.createElement('style');
        style.id = 'cartFeedbackStyles';
        style.textContent = `
          @keyframes slideInRight {
            from {
              transform: translateX(100%);
              opacity: 0;
            }
            to {
              transform: translateX(0);
              opacity: 1;
            }
          }
          @keyframes slideOutRight {
            from {
              transform: translateX(0);
              opacity: 1;
            }
            to {
              transform: translateX(100%);
              opacity: 0;
            }
          }
        `;
        document.head.appendChild(style);
      }
      
      document.body.appendChild(feedback);
      
      // Auto remove after 3 seconds
      setTimeout(() => {
        if (feedback.parentNode) {
          feedback.style.animation = 'slideOutRight 0.3s ease-in';
          setTimeout(() => {
            if (feedback.parentNode) {
              feedback.parentNode.removeChild(feedback);
            }
          }, 300);
        }
      }, 3000);
    }
  }
}




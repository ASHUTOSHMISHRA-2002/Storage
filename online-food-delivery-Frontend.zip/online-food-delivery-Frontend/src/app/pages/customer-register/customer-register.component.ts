import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-customer-register',
  standalone: true,
  imports: [FormsModule, RouterLink, CommonModule],
  templateUrl: './customer-register.component.html',
  styleUrls: ['./customer-register.component.css']
})
export class CustomerRegisterComponent {
  name = '';
  email = '';
  password = '';
  phone = '';
  address = '';

  private http = inject(HttpClient);
  private router = inject(Router);

  register() {
    if (!this.name || !this.email || !this.password || !this.phone || !this.address) {
      alert('⚠️ Please fill in all fields.');
      return;
    }

    const payload = {
      name: this.name,
      email: this.email,
      password: this.password,
      phone: this.phone,
      address: this.address
    };

    this.http.post('http://localhost:9090/api/customers/register', payload, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'X-Requested-With': 'XMLHttpRequest'
      }),
      withCredentials: true
    }).subscribe({
      next: (res) => {
        console.log('✅ Registration successful:', res);
        this.router.navigate(['/customer-login']);
      },
      error: (err) => {
        console.error('❌ Registration error:', err);
        alert('Registration failed. Please check the server or permissions.');
      }
    });
  }
}

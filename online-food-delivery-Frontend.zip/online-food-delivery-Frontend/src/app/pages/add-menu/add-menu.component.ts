import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-menu',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './add-menu.component.html',
  styleUrls: ['./add-menu.component.css']
})
export class AddMenuComponent {
  menuForm: FormGroup;
  message = '';
  isSuccess = false;
  submitting = false;

  private readonly MENU_API = 'http://localhost:9096/api/menu';

  constructor(
    private fb: FormBuilder, 
    private http: HttpClient,
    private router: Router
  ) {
    this.menuForm = this.fb.group({
      itemName: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(50)]],
      description: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(100)]],
      price: [null, [Validators.required, Validators.min(0.01)]],
      isVegetarian: [null, Validators.required]
    });
  }

  closeModal(): void {
    // Navigate back to restaurant dashboard
    this.router.navigate(['/restaurant-dashboard']);
  }

  clearMessage(): void {
    this.message = '';
    this.isSuccess = false;
  }

  submit(): void {
    this.submitting = true;
    this.message = '';
    this.isSuccess = false;

    const rawId = localStorage.getItem('restaurantId');
    const restaurantId = rawId && !isNaN(Number(rawId)) ? rawId : null;

    console.log('🔍 Validating restaurantId from localStorage:', rawId);

    if (!restaurantId) {
      this.message = '⚠️ Restaurant ID missing or invalid. Please log in again.';
      this.submitting = false;
      return;
    }

    const payload = this.menuForm.value;

    const headers = new HttpHeaders({
      'X-Internal-User-Id': restaurantId,
      'X-Internal-User-Roles': 'RESTAURANT'
    });

    this.http.post(`${this.MENU_API}/restaurant`, payload, { headers })
      .subscribe({
        next: () => {
          this.message = '✅ Dish added successfully!';
          this.isSuccess = true;
          this.menuForm.reset();
          
          // Auto-close modal after successful submission (optional)
          setTimeout(() => {
            this.closeModal();
          }, 2000);
        },
        error: (err) => {
          console.error('❌ Add menu failed:', err);
          this.message = err?.error?.message || '❌ Failed to add dish.';
          this.isSuccess = false;
        }
      }).add(() => {
        this.submitting = false;
      });
  }
}

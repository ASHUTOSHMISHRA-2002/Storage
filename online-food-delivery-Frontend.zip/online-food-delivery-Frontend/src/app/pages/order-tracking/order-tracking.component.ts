


import { Component, OnInit, OnDestroy, Inject } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { RouterModule, Router, ActivatedRoute } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { interval, Subject, Subscription } from 'rxjs';
import { takeUntil, switchMap, catchError, timeout, retry } from 'rxjs/operators';
import { of } from 'rxjs';
import { PLATFORM_ID } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { OrderService } from '../../services/order.service';

interface OrderStatus {
  orderId: number;
  status: string;
  customerName?: string;
  restaurantName?: string;
  deliveryAddress?: string;
  totalAmount?: number;
  items?: any[];
  createdAt?: string;
  estimatedDeliveryTime?: string;
  trackingHistory?: TrackingEvent[];
}

interface TrackingEvent {
  status: string;
  timestamp: string;
  description: string;
  isCompleted: boolean;
}

interface DeliveryInfo {
  deliveryId?: number;
  agentName?: string;
  agentPhone?: string;
  estimatedDeliveryTime?: string;
  status?: string;
}

@Component({
  selector: 'app-order-tracking',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './order-tracking.component.html',
  styleUrls: ['./order-tracking.component.css']
})
export class OrderTrackingComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();
  private trackingSubscription: Subscription | null = null;

  // Core properties
  orderId: string = '';
  currentOrder: OrderStatus | null = null;
  deliveryInfo: DeliveryInfo | null = null;
  
  // UI state
  loading = false;
  error: string | null = null;
  lastUpdated: Date | null = null;
  
  // Manual tracking
  manualOrderId = '';
  showManualTracker = false;
  
  // Tracking status
  isActiveTracking = false;

  // ✅ ENHANCED: Updated status progression to match backend
  statusProgression = [
    { key: 'PENDING', label: 'Order Placed', icon: '📝' },
    { key: 'ACCEPTED', label: 'Order Confirmed', icon: '✅' },
    { key: 'IN_COOKING', label: 'Being Prepared', icon: '👨‍🍳' },
    { key: 'READY_FOR_PICKUP', label: 'Ready for Pickup', icon: '📦' },
    { key: 'OUT_FOR_DELIVERY', label: 'Out for Delivery', icon: '🚗' },
    { key: 'COMPLETED', label: 'Delivered', icon: '🎉' }
  ];

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private http: HttpClient,
    private auth: AuthService,
    private orderService: OrderService,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {}

  ngOnInit(): void {
    console.log('🚀 OrderTrackingComponent initializing...');
    this.initializeTracking();
  }

  ngOnDestroy(): void {
    console.log('🧹 OrderTrackingComponent destroying...');
    this.destroy$.next();
    this.destroy$.complete();
    this.stopTracking();
  }

  private initializeTracking(): void {
    try {
      // Try to get order ID from multiple sources
      this.orderId = this.getOrderIdFromSources();
      
      if (this.orderId) {
        console.log('✅ Order ID found:', this.orderId);
        this.startOrderTracking(this.orderId);
      } else {
        console.log('⚠️ No order ID found, showing manual tracker');
        this.showManualTracker = true;
        this.checkForStoredTrackingData();
      }
    } catch (error) {
      console.error('❌ Error initializing tracking:', error);
      this.error = 'Failed to initialize order tracking';
    }
  }

  private getOrderIdFromSources(): string {
    // 1. From URL parameters
    const urlOrderId = this.route.snapshot.paramMap.get('orderId');
    if (urlOrderId) {
      console.log('✅ Order ID from URL:', urlOrderId);
      return urlOrderId;
    }

    // 2. From query parameters
    const queryOrderId = this.route.snapshot.queryParamMap.get('orderId');
    if (queryOrderId) {
      console.log('✅ Order ID from query params:', queryOrderId);
      return queryOrderId;
    }

    // 3. From stored tracking data
    const trackingData = this.auth.getOrderTrackingData();
    if (trackingData?.orderId) {
      console.log('✅ Order ID from stored tracking data:', trackingData.orderId);
      return trackingData.orderId.toString();
    }

    // 4. From localStorage (fallback)
    if (isPlatformBrowser(this.platformId)) {
      const stored = localStorage.getItem('current_order_id');
      if (stored) {
        console.log('✅ Order ID from localStorage:', stored);
        return stored;
      }
    }

    return '';
  }

  private checkForStoredTrackingData(): void {
    const trackingData = this.auth.getOrderTrackingData();
    if (trackingData) {
      console.log('📦 Found stored tracking data:', trackingData);
      this.orderId = trackingData.orderId.toString();
      this.manualOrderId = this.orderId;
      this.showManualTracker = false;
      this.startOrderTracking(this.orderId);
    }
  }

  startOrderTracking(orderId: string): void {
    if (!orderId) {
      this.error = 'Order ID is required for tracking';
      return;
    }

    this.stopTracking(); // Stop any existing tracking
    this.loading = true;
    this.error = null;
    this.orderId = orderId;

    console.log('🔍 Starting order tracking for:', orderId);

    // Store order ID for persistence
    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem('current_order_id', orderId);
    }

    // Initial fetch
    this.fetchOrderStatus(orderId).then(() => {
      // Start periodic tracking if order is not completed
      if (this.shouldContinueTracking()) {
        this.startPeriodicTracking(orderId);
      }
    });
  }

  // ✅ ENHANCED: More efficient periodic tracking
  private startPeriodicTracking(orderId: string): void {
    this.isActiveTracking = true;
    
    // Poll every 15 seconds (reduced frequency to be more efficient)
    this.trackingSubscription = interval(15000)
      .pipe(
        takeUntil(this.destroy$),
        switchMap(() => {
          // First check order status (primary)
          return this.orderService.getOrderById(parseInt(orderId))
            .pipe(
              catchError(error => {
                console.error('❌ Order tracking error:', error);
                return of(null);
              })
            );
        })
      )
      .subscribe(orderData => {
        if (orderData) {
          this.updateOrderStatus(orderData);
          
          // ✅ EFFICIENT: Only fetch delivery info if order is out for delivery
          if (this.currentOrder?.status === 'OUT_FOR_DELIVERY' || this.currentOrder?.status === 'COMPLETED') {
            this.fetchDeliveryInfoSafely(orderId);
          }
        }
      });

    console.log('⏰ Periodic tracking started for order:', orderId);
  }

  private stopTracking(): void {
    if (this.trackingSubscription) {
      this.trackingSubscription.unsubscribe();
      this.trackingSubscription = null;
      this.isActiveTracking = false;
      console.log('🛑 Order tracking stopped');
    }
  }

  // ✅ ENHANCED: More resilient order status fetching
  private async fetchOrderStatus(orderId: string): Promise<void> {
    try {
      this.loading = true;
      this.error = null;

      // ✅ PRIMARY: Get order status from order service (most important)
      const orderData = await this.orderService.getOrderById(parseInt(orderId))
        .pipe(
          takeUntil(this.destroy$),
          timeout(10000),
          retry(2) // Retry twice
        )
        .toPromise();

      if (orderData) {
        this.updateOrderStatus(orderData);
        console.log('✅ Order status updated successfully');
        
        // ✅ SECONDARY: Try to fetch delivery info (non-critical)
        this.fetchDeliveryInfoSafely(orderId);
      } else {
        this.error = 'Order not found';
      }

    } catch (error) {
      console.error('❌ Error fetching order status:', error);
      this.handleTrackingError(error);
    } finally {
      this.loading = false;
      this.lastUpdated = new Date();
    }
  }

  // ✅ CRITICAL FIX: Updated to use correct port and enhanced error handling
  private async fetchDeliveryInfo(orderId: string): Promise<void> {
    try {
      // ✅ FIXED: Use port 8081 instead of 9098
      const deliveryUrl = `http://localhost:8081/api/delivery/order/${orderId}`;
      const headers = this.getHeaders();

      console.log('🔍 Fetching delivery info from:', deliveryUrl);

      const deliveryData = await this.http.get<any>(deliveryUrl, { headers })
        .pipe(
          takeUntil(this.destroy$),
          timeout(10000), // 10 second timeout
          catchError(error => {
            console.warn('⚠️ Delivery service unavailable:', error.message);
            // ✅ FIX: Return null instead of throwing error (non-blocking)
            return of(null);
          })
        )
        .toPromise();

      if (deliveryData) {
        this.deliveryInfo = {
          deliveryId: deliveryData.deliveryId,
          agentName: deliveryData.agentName,
          agentPhone: deliveryData.agentPhone,
          estimatedDeliveryTime: deliveryData.estimatedDeliveryTime,
          status: deliveryData.status
        };
        console.log('✅ Delivery info loaded:', this.deliveryInfo);
      } else {
        console.log('ℹ️ No delivery info available for this order yet');
      }

    } catch (error) {
      console.warn('⚠️ Could not fetch delivery info:', error);
      // ✅ IMPORTANT: Don't treat this as a critical error
      // Order tracking should work even without delivery info
    }
  }

  // ✅ NEW: Safe delivery info fetching that won't break order tracking
  private fetchDeliveryInfoSafely(orderId: string): void {
    // Use setTimeout to make this completely non-blocking
    setTimeout(async () => {
      try {
        await this.fetchDeliveryInfo(orderId);
      } catch (error) {
        console.warn('⚠️ Delivery info fetch failed, but order tracking continues:', error);
        // Order tracking continues even if delivery service is unavailable
      }
    }, 500); // Small delay to prioritize order status loading
  }

  private updateOrderStatus(orderData: any): void {
    this.currentOrder = {
      orderId: orderData.orderId,
      status: orderData.status?.toUpperCase() || 'UNKNOWN',
      customerName: orderData.customerName,
      restaurantName: orderData.restaurantName,
      deliveryAddress: orderData.deliveryAddress,
      totalAmount: orderData.totalAmount,
      items: orderData.items,
      createdAt: orderData.orderTime || orderData.createdAt,
      estimatedDeliveryTime: orderData.deliveryTime || orderData.estimatedDeliveryTime
    };

    this.lastUpdated = new Date();
    console.log('📈 Order status updated:', this.currentOrder);

    // Stop tracking if order is completed
    if (!this.shouldContinueTracking()) {
      this.stopTracking();
    }
  }

  private shouldContinueTracking(): boolean {
    if (!this.currentOrder) return true;
    
    const completedStatuses = ['DELIVERED', 'CANCELLED', 'COMPLETED'];
    return !completedStatuses.includes(this.currentOrder.status);
  }

  // ✅ ENHANCED: Better error handling
  private handleTrackingError(error: any): void {
    if (error.message) {
      this.error = error.message;
    } else if (error.status === 404) {
      this.error = 'Order not found. Please check the order ID.';
    } else if (error.status === 403) {
      this.error = 'Access denied. Please login to track your order.';
    } else if (error.status === 401) {
      this.error = 'Authentication required. Please login to track your order.';
    } else if (error.status === 0) {
      this.error = 'Connection error. Please check your internet connection.';
    } else {
      this.error = 'Unable to track order. Please try again later.';
    }
  }

  private getHeaders(): HttpHeaders {
    const token = this.auth.getToken();
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token || ''}`
    });
  }

  // ✅ ENHANCED: Better delivery time handling (CRITICAL FIX)
  formatDeliveryTime(order: OrderStatus | null): { label: string; time: string } {
    if (!order) return { label: 'Expected Delivery', time: 'Not available' };
    
    const isCompleted = ['COMPLETED', 'DELIVERED'].includes(order.status);
    
    if (isCompleted) {
      // For completed orders, show actual delivery time
      const deliveryTime = order.estimatedDeliveryTime || order.createdAt;
      return {
        label: 'Delivered At',
        time: deliveryTime ? this.formatTime(deliveryTime) : 'Just now'
      };
    } else {
      // For pending orders, show expected delivery time
      return {
        label: 'Expected Delivery',
        time: order.estimatedDeliveryTime ? this.formatTime(order.estimatedDeliveryTime) : 'Calculating...'
      };
    }
  }

  // ✅ NEW: Check if order is completed
  isOrderCompleted(): boolean {
    if (!this.currentOrder) return false;
    return ['COMPLETED', 'DELIVERED'].includes(this.currentOrder.status);
  }

  // ✅ NEW: Get appropriate delivery message
  getDeliveryMessage(): string {
    if (!this.currentOrder) return '';
    
    if (this.isOrderCompleted()) {
      return '🎉 Your order has been delivered successfully!';
    } else if (this.currentOrder.status === 'OUT_FOR_DELIVERY') {
      return '🚗 Your order is on the way!';
    } else if (this.currentOrder.status === 'READY_FOR_PICKUP') {
      return '📦 Your order is ready for pickup!';
    } else {
      return '👨‍🍳 Your order is being prepared...';
    }
  }

  // ✅ ENHANCED: Better status icon handling
  getStatusIcon(): string {
    if (!this.currentOrder) return '📝';
    
    switch (this.currentOrder.status) {
      case 'PENDING': return '📝';
      case 'ACCEPTED': return '✅';
      case 'IN_COOKING': return '👨‍🍳';
      case 'READY_FOR_PICKUP': return '📦';
      case 'OUT_FOR_DELIVERY': return '🚗';
      case 'COMPLETED':
      case 'DELIVERED': return '🎉';
      default: return '📝';
    }
  }

  // Template methods
  trackManualOrder(): void {
    if (!this.manualOrderId || !this.manualOrderId.trim()) {
      this.error = 'Please enter a valid order ID';
      return;
    }

    const orderId = this.manualOrderId.trim();
    this.showManualTracker = false;
    
    // Update URL without page reload
    this.router.navigate(['/order-tracking', orderId], { replaceUrl: true });
    
    this.startOrderTracking(orderId);
  }

  refreshTracking(): void {
    if (this.orderId) {
      console.log('🔄 Refreshing order tracking...');
      this.fetchOrderStatus(this.orderId);
    }
  }

  getStatusProgress(): number {
    if (!this.currentOrder) return 0;
    
    const currentIndex = this.statusProgression.findIndex(
      status => status.key === this.currentOrder!.status
    );
    
    return currentIndex >= 0 ? ((currentIndex + 1) / this.statusProgression.length) * 100 : 0;
  }

  isStatusCompleted(statusKey: string): boolean {
    if (!this.currentOrder) return false;
    
    const currentIndex = this.statusProgression.findIndex(
      status => status.key === this.currentOrder!.status
    );
    const checkIndex = this.statusProgression.findIndex(
      status => status.key === statusKey
    );
    
    return checkIndex <= currentIndex;
  }

  // ✅ ENHANCED: Better status class handling
  getStatusClass(statusKey: string): string {
    if (this.isStatusCompleted(statusKey)) {
      const isCurrentStatus = this.currentOrder?.status === statusKey || 
                             (this.currentOrder?.status === 'COMPLETED' && statusKey === 'COMPLETED');
      return isCurrentStatus ? 'status-current completed' : 'status-completed';
    }
    return 'status-pending';
  }

  formatTime(timeString: string | undefined): string {
    if (!timeString) return 'Not available';
    
    try {
      const date = new Date(timeString);
      return date.toLocaleString();
    } catch (error) {
      return timeString;
    }
  }

  formatCurrency(amount: number | undefined): string {
    if (!amount) return '₹0';
    
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0
    }).format(amount);
  }

  goHome(): void {
    this.router.navigate(['/customer-main']);
  }

  goToOrders(): void {
    this.router.navigate(['/orders']);
  }

  callDeliveryAgent(): void {
    if (this.deliveryInfo?.agentPhone) {
      window.open(`tel:${this.deliveryInfo.agentPhone}`);
    }
  }

  shareTracking(): void {
    if (navigator.share && this.orderId) {
      navigator.share({
        title: `Order #${this.orderId} Tracking`,
        text: `Track my food order #${this.orderId}`,
        url: window.location.href
      });
    } else {
      // Fallback: copy to clipboard
      const url = window.location.href;
      navigator.clipboard.writeText(url).then(() => {
        alert('Tracking link copied to clipboard!');
      });
    }
  }

  retryTracking(): void {
    this.error = null;
    if (this.orderId) {
      this.startOrderTracking(this.orderId);
    }
  }

  getDeliveryStatusLabel(): string {
    if (!this.deliveryInfo?.status) return 'Preparing for delivery';
    
    switch (this.deliveryInfo.status) {
      case 'ASSIGNED': return 'Delivery agent assigned';
      case 'PICKED_UP': return 'Order picked up by agent';
      case 'IN_TRANSIT': return 'On the way to you';
      case 'DELIVERED': return 'Delivered successfully';
      default: return this.deliveryInfo.status;
    }
  }

  showDeliveryInfo(): boolean {
    return !!(this.deliveryInfo && (this.currentOrder?.status === 'OUT_FOR_DELIVERY' || this.currentOrder?.status === 'COMPLETED'));
  }

  debugInfo(): void {
    console.log('🔍 Order Tracking Debug Info:', {
      orderId: this.orderId,
      currentOrder: this.currentOrder,
      deliveryInfo: this.deliveryInfo,
      loading: this.loading,
      error: this.error,
      isActiveTracking: this.isActiveTracking,
      shouldContinueTracking: this.shouldContinueTracking()
    });
  }
}

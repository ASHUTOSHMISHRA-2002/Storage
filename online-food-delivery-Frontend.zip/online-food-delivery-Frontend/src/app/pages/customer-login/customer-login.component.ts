
import { Component, inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-customer-login',
  standalone: true,
  imports: [FormsModule, RouterLink, CommonModule],
  templateUrl: './customer-login.component.html',
  styleUrls: ['./customer-login.component.css']
})
export class CustomerLoginComponent {
  email = '';
  password = '';
  errorMessage = '';

  private http = inject(HttpClient);
  private router = inject(Router);

  login(): void {
    if (!this.email || !this.password) {
      this.errorMessage = '🚨 Please enter both email and password.';
      return;
    }

    const payload = { email: this.email, password: this.password };

    this.http.post('http://localhost:9092/api/auth/customer/login', payload, {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
      withCredentials: true
    }).subscribe({
      next: (res: any) => {
        console.log('✅ Login successful:', res);
        
        // 🔥 SAVE JWT TOKEN TO LOCALSTORAGE
        if (res.jwtToken || res.token || res.accessToken) {
          const token = res.jwtToken || res.token || res.accessToken;
          localStorage.setItem('authToken', token);
          console.log('✅ Token saved to localStorage:', token);
        } else {
          console.warn('⚠️ No token found in response:', res);
        }

        // Navigate to customer menu
        this.router.navigate(['/customer/menu']);
      },
      error: (err) => {
        console.error('❌ Login error:', err);
        this.errorMessage = 'Login failed. Please check credentials or server status.';
      }
    });
  }
}

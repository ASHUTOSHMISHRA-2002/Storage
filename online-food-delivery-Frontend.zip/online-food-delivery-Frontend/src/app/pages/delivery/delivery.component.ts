

// src/app/pages/delivery/delivery.component.ts
import { Component, OnInit } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DeliveryService, DeliveryStatus } from '../../services/delivery.service';
import { OrderService } from '../../services/order.service';

@Component({
  selector: 'app-delivery',
  standalone: true,
  imports: [CommonModule, DatePipe, FormsModule],
  templateUrl: './delivery.component.html',
  styleUrls: ['./delivery.component.css']
})
export class DeliveryComponent implements OnInit {
  deliveries: any[] = [];
  loading = false;

  constructor(
    private deliveryService: DeliveryService,
    private orderService: OrderService
  ) {}

  ngOnInit(): void {
    this.loadDeliveries();
  }

  loadDeliveries(): void {
    this.loading = true;
    this.deliveryService.getAllDeliveries().subscribe({
      next: (deliveries) => {
        this.deliveries = deliveries;
        this.loading = false;
        console.log('✅ Deliveries loaded:', deliveries);
      },
      error: (error) => {
        console.error('❌ Error loading deliveries:', error);
        this.loading = false;
      }
    });
  }

  
  // In DeliveryComponent
completeDelivery(delivery: any): void {
  if (confirm('Are you sure you want to mark this delivery as completed?')) {
    // ✅ This should update BOTH delivery status AND order status
    this.deliveryService.completeDelivery(delivery.deliveryId, delivery.orderId)
      .subscribe({
        next: (updatedDelivery) => {
          console.log('✅ Delivery completed:', updatedDelivery);
          this.loadDeliveries(); // Refresh delivery list
          
          // ✅ ALSO refresh the orders to show updated status
          this.refreshOrderStatus(delivery.orderId);
          
          alert('Delivery completed successfully! Order status updated to COMPLETED.');
        },
        error: (error) => {
          console.error('❌ Error completing delivery:', error);
          alert('Error completing delivery. Please try again.');
        }
      });
  }
}
// ✅ ADD: Method to refresh order status
private refreshOrderStatus(orderId: number): void {
  this.orderService.getOrderById(orderId).subscribe({
    next: (order) => {
      console.log('✅ Order status refreshed:', order);
    },
    error: (error) => {
      console.error('❌ Error refreshing order:', error);
    }
  });
}

  // ✅ FIXED: Proper null-safe event handling
  updateDeliveryStatus(deliveryId: number, event: Event): void {
    // Type guard and null check
    const target = event?.target as HTMLSelectElement | null;
    
    if (!target || !target.value) {
      console.warn('Invalid event target or value');
      return;
    }
    
    const newStatus = target.value;
    
    if (confirm(`Are you sure you want to update status to "${this.getStatusDisplay(newStatus)}"?`)) {
      this.deliveryService.updateStatus(deliveryId, newStatus)
        .subscribe({
          next: (updatedDelivery) => {
            console.log('✅ Status updated:', updatedDelivery);
            this.loadDeliveries();
            alert(`Status updated to ${this.getStatusDisplay(newStatus)}`);
          },
          error: (error) => {
            console.error('❌ Error updating status:', error);
            alert('Error updating status. Please try again.');
            // Reset select to original value
            const delivery = this.deliveries.find(d => d.deliveryId === deliveryId);
            if (delivery && target) {
              target.value = delivery.status;
            }
          }
        });
    } else {
      // Reset select to original value if cancelled
      const delivery = this.deliveries.find(d => d.deliveryId === deliveryId);
      if (delivery && target) {
        target.value = delivery.status;
      }
    }
  }

  // ✅ ALTERNATIVE: Even safer approach using template reference
  updateDeliveryStatusSafe(deliveryId: number, newStatus: string): void {
    if (!newStatus) {
      console.warn('No status provided');
      return;
    }
    
    if (confirm(`Are you sure you want to update status to "${this.getStatusDisplay(newStatus)}"?`)) {
      this.deliveryService.updateStatus(deliveryId, newStatus)
        .subscribe({
          next: (updatedDelivery) => {
            console.log('✅ Status updated:', updatedDelivery);
            this.loadDeliveries();
            alert(`Status updated to ${this.getStatusDisplay(newStatus)}`);
          },
          error: (error) => {
            console.error('❌ Error updating status:', error);
            alert('Error updating status. Please try again.');
          }
        });
    }
  }

  getStatusDisplay(status: string): string {
    return this.deliveryService.getDeliveryStatusDisplay(status);
  }

  canCompleteDelivery(delivery: any): boolean {
    return delivery.status !== DeliveryStatus.DELIVERED && 
           delivery.status !== DeliveryStatus.FAILED &&
           delivery.status !== 'delivered' &&
           delivery.status !== 'failed';
  }

  isStatusReached(targetStatus: string, currentStatus: string): boolean {
    const statusOrder = ['assigned', 'picked_up', 'in_transit', 'out_for_delivery', 'delivered'];
    const targetIndex = statusOrder.indexOf(targetStatus);
    const currentIndex = statusOrder.indexOf(currentStatus);
    return currentIndex >= targetIndex;
  }
}


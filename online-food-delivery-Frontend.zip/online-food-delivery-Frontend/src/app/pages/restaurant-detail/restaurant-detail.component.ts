// src/app/pages/restaurant-detail/restaurant-detail.component.ts
import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MenuService, Restaurant } from '../../services/menu.service';
import { CartService } from '../../services/cart.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { HttpHeaders } from '@angular/common/http';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Component({
  selector: 'app-restaurant-detail',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './restaurant-detail.component.html',
  styleUrl: './restaurant-detail.component.css'
})
export class RestaurantDetailComponent implements OnInit, OnDestroy {
  restaurant: Restaurant | null = null;
  restaurantId: string = '';
  loading = true;
  error = '';
  
  // Cart state
  cartItemCount = 0;
  hasCartItems = false;
  
  // Menu preview
  menuItemCount = 0;
  menuLoading = false;
  
  // Destroy subject for unsubscribing
  private destroy$ = new Subject<void>();

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private menuService: MenuService,
    public cartService: CartService,
    private http: HttpClient
  ) {}

  ngOnInit(): void {
    console.log('🏪 RestaurantDetailComponent initialized');
    
    // Get restaurant ID from route
    this.restaurantId = this.route.snapshot.paramMap.get('id') || '';
    
    if (this.restaurantId) {
      this.loadRestaurantDetails();
      this.loadMenuCount();
      this.subscribeToCart();
    } else {
      this.error = 'Restaurant ID not found';
      this.loading = false;
      console.error('❌ No restaurant ID provided in route');
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  private loadRestaurantDetails(): void {
    console.log('🔍 Loading restaurant details for ID:', this.restaurantId);
    this.loading = true;
    this.error = '';
    
    this.menuService.getRestaurantById(this.restaurantId)
      .pipe(
        takeUntil(this.destroy$),
        catchError((err) => {
          console.error('❌ Error loading restaurant details:', err);
          
          // Try fallback approach using direct HTTP call
          return this.loadRestaurantDetailsFallback();
        })
      )
      .subscribe({
        next: (restaurant) => {
          console.log('✅ Restaurant details loaded:', restaurant);
          this.restaurant = restaurant;
          this.loading = false;
        },
        error: (err) => {
          console.error('❌ All attempts to load restaurant details failed:', err);
          this.error = 'Failed to load restaurant details. Please try again.';
          this.loading = false;
          
          // Set fallback restaurant data
          this.setFallbackRestaurantData();
        }
      });
  }

  private loadRestaurantDetailsFallback(): Observable<Restaurant> {
    console.log('🔄 Trying fallback approach for restaurant details');
    
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    });

    return this.http.get<Restaurant>(`http://localhost:8082/api/restaurants/${this.restaurantId}`, { headers })
      .pipe(
        catchError((err) => {
          console.error('❌ Fallback approach also failed:', err);
          return throwError(() => err);
        })
      );
  }

  private setFallbackRestaurantData(): void {
    console.log('🛠️ Setting fallback restaurant data');
    
    // Create fallback restaurant data based on ID
    this.restaurant = {
      id: this.restaurantId,
      name: `Restaurant ${this.restaurantId}`,
      location: 'Location not available',
      email: `restaurant${this.restaurantId}@example.com`,
      rating: 4.0,
      deliveryTime: '30-45 mins',
      deliveryFee: 30,
      minOrder: 100,
      cuisineType: 'Multi-cuisine',
      isOpen: true
    };
    
    console.log('✅ Fallback restaurant data set:', this.restaurant);
  }

  private loadMenuCount(): void {
    console.log('📋 Loading menu count for restaurant:', this.restaurantId);
    this.menuLoading = true;
    
    const restaurantIdNum = parseInt(this.restaurantId);
    
    this.menuService.getMenuItemsByRestaurant(restaurantIdNum)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (menuItems) => {
          this.menuItemCount = menuItems.length;
          this.menuLoading = false;
          console.log(`📊 Menu has ${this.menuItemCount} items`);
        },
        error: (err) => {
          console.error('❌ Error loading menu count:', err);
          this.menuItemCount = 0;
          this.menuLoading = false;
        }
      });
  }

  private subscribeToCart(): void {
    this.cartService.cartItems$
      .pipe(takeUntil(this.destroy$))
      .subscribe(items => {
        this.cartItemCount = this.cartService.getCartItemCount();
        this.hasCartItems = this.cartItemCount > 0;
      });
  }

  // Navigation methods
  viewMenu(): void {
    if (this.restaurantId && this.restaurant) {
      console.log('🍽️ Navigating to menu for restaurant:', this.restaurant.name);
      this.router.navigate(['/restaurant', this.restaurantId, 'menu']);
    }
  }

  goBack(): void {
    console.log('⬅️ Going back to customer main');
    this.router.navigate(['/customer-main']);
  }

  goToCart(): void {
    console.log('🛒 Navigating to cart');
    this.router.navigate(['/cart']);
  }

  // Retry methods
  // Debug method
  debugRestaurantFetch(): void {
    console.log('🔍 Debugging restaurant fetch...');
    console.log('Restaurant ID:', this.restaurantId);
    console.log('Current restaurant:', this.restaurant);
    console.log('Loading state:', this.loading);
    console.log('Error state:', this.error);
    
    // Check service health
    this.menuService.checkServiceHealth().subscribe({
      next: (health) => {
        console.log('🏥 Service health:', health);
        const status = this.menuService.getServiceStatus();
        console.log('🔗 Service URLs:', status);
      },
      error: (err) => {
        console.error('❌ Health check failed:', err);
      }
    });
  }

  // Enhanced retry with debug info
  retryLoadRestaurant(): void {
    console.log('🔄 Retrying to load restaurant details with debug info');
    this.debugRestaurantFetch();
    this.loadRestaurantDetails();
  }

  retryLoadMenu(): void {
    console.log('🔄 Retrying to load menu count');
    this.loadMenuCount();
  }

  // Utility methods
  formatPrice(price: number | undefined): string {
    return price ? `₹${price}` : 'Free';
  }

  formatDeliveryTime(time: string | undefined): string {
    return time || '30-45 mins';
  }

  getRestaurantStatus(): { text: string; class: string } {
    const isOpen = this.restaurant?.isOpen !== false; // Default to open if undefined
    return {
      text: isOpen ? 'Open' : 'Closed',
      class: isOpen ? 'status-open' : 'status-closed'
    };
  }

  getRatingStars(rating: number | undefined): string {
    if (!rating) return '⭐⭐⭐⭐⭐';
    
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    
    let stars = '⭐'.repeat(fullStars);
    if (hasHalfStar) stars += '⭐'; // You could use a half-star emoji if available
    
    return stars.padEnd(5, '☆');
  }

  getDeliveryFeeText(): string {
    const fee = this.restaurant?.deliveryFee;
    if (fee === undefined) return '₹30';
    return fee === 0 ? 'Free' : `₹${fee}`;
  }

  getMinOrderText(): string {
    const minOrder = this.restaurant?.minOrder;
    return minOrder ? `₹${minOrder}` : '₹100';
  }

  getCuisineType(): string {
    return this.restaurant?.cuisineType || 'Multi-Cuisine';
  }

  canViewMenu(): boolean {
    return !!this.restaurant && this.restaurant.isOpen !== false && this.menuItemCount > 0;
  }

  getMenuButtonText(): string {
    if (!this.restaurant) return 'Loading...';
    if (this.restaurant.isOpen === false) return 'Restaurant Closed';
    if (this.menuLoading) return 'Loading Menu...';
    if (this.menuItemCount === 0) return 'No Menu Available';
    return `View Menu (${this.menuItemCount} items)`;
  }

  // Share restaurant (optional feature)
  shareRestaurant(): void {
    if (this.restaurant) {
      const url = window.location.href;
      const text = `Check out ${this.restaurant.name} on FoodDelivery App!`;
      
      if (navigator.share) {
        navigator.share({
          title: this.restaurant.name,
          text: text,
          url: url
        }).catch(err => console.log('Error sharing:', err));
      } else {
        // Fallback: copy to clipboard
        navigator.clipboard.writeText(`${text} ${url}`)
          .then(() => alert('Restaurant link copied to clipboard!'))
          .catch(() => console.log('Could not copy to clipboard'));
      }
    }
  }

  // Call restaurant (optional feature)
  callRestaurant(): void {
    if (this.restaurant?.email) {
      // You could implement a phone number field in Restaurant interface
      alert(`Contact: ${this.restaurant.email}`);
    }
  }
}

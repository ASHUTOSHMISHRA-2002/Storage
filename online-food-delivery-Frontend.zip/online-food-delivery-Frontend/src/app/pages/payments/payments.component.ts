

// src/app/pages/payments/payments.component.ts
import { Component, OnInit, OnDestroy, Inject } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { RouterModule, Router, ActivatedRoute } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { PLATFORM_ID } from '@angular/core';
import { PaymentService, PaymentRequestDTO } from '../../services/payment.service';
import { OrderService, OrderSummary } from '../../services/order.service';
import { CartService } from '../../services/cart.service';
import { AuthService } from '../../services/auth.service';
import { Subject, of } from 'rxjs';
import { takeUntil, finalize, retry, timeout, catchError } from 'rxjs/operators';

interface PaymentMethod {
  id: string;
  name: string;
  icon: string;
  enabled: boolean;
  description?: string;
  processingFee?: number;
  minAmount?: number;
  maxAmount?: number;
  isPopular?: boolean;
}

interface CardDetails {
  number: string;
  expiry: string;
  cvv: string;
  name: string;
  cardType?: string;
}

interface UpiDetails {
  id: string;
  verified: boolean;
  provider?: string;
}

interface NetBankingDetails {
  bankCode: string;
  bankName: string;
}

interface WalletDetails {
  provider: string;
  phoneNumber?: string;
}

interface CustomerDetails {
  name: string;
  phone: string;
  email: string;
  address: string;
  city?: string;
  state?: string;
  pincode?: string;
  firstName?: string;
  lastName?: string;
  alternatePhone?: string;
  landmark?: string;
  addressType?: 'HOME' | 'WORK' | 'OTHER';
  isDefault?: boolean;
}

interface PaymentState {
  step: number;
  isProcessing: boolean;
  error: string;
  success: string;
  orderCreated: boolean;
  paymentProcessed: boolean;
  processingProgress: number;
  isDuplicatePayment: boolean;
  existingPaymentData?: any;
}

interface OrderValidation {
  isValid: boolean;
  errors: string[];
  warnings: string[];
}

@Component({
  selector: 'app-payments',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './payments.component.html',
  styleUrls: ['./payments.component.css']
})
export class PaymentsComponent implements OnInit, OnDestroy {
  orderSummary: OrderSummary | null = null;
  selectedPaymentMethod = '';
  currentOrderId: number | null = null;
  
  // ✅ ENHANCED: Payment methods with comprehensive details
  paymentMethods: PaymentMethod[] = [
    { 
      id: 'UPI', 
      name: 'UPI Payment', 
      icon: '📱', 
      enabled: true, 
      description: 'Pay using Google Pay, PhonePe, Paytm',
      processingFee: 0,
      minAmount: 1,
      maxAmount: 100000,
      isPopular: true
    },
    { 
      id: 'CARD', 
      name: 'Credit/Debit Card', 
      icon: '💳', 
      enabled: true, 
      description: 'Visa, Mastercard, Rupay accepted',
      processingFee: 0,
      minAmount: 1,
      maxAmount: 500000,
      isPopular: true
    },
    { 
      id: 'NET_BANKING', 
      name: 'Net Banking', 
      icon: '🏦', 
      enabled: true, 
      description: 'All major banks supported',
      processingFee: 5,
      minAmount: 10,
      maxAmount: 1000000,
      isPopular: false
    },
    { 
      id: 'WALLET', 
      name: 'Digital Wallet', 
      icon: '💰', 
      enabled: true, 
      description: 'Paytm, Amazon Pay, PayPal',
      processingFee: 0,
      minAmount: 1,
      maxAmount: 50000,
      isPopular: false
    },
    { 
      id: 'COD', 
      name: 'Cash on Delivery', 
      icon: '💵', 
      enabled: true, 
      description: 'Pay when your order arrives',
      processingFee: 25,
      minAmount: 100,
      maxAmount: 2000,
      isPopular: false
    }
  ];

  // ✅ ENHANCED: Payment details with better structure
  cardDetails: CardDetails = { number: '', expiry: '', cvv: '', name: '', cardType: '' };
  upiDetails: UpiDetails = { id: '', verified: false, provider: '' };
  netBankingDetails: NetBankingDetails = { bankCode: '', bankName: '' };
  walletDetails: WalletDetails = { provider: '', phoneNumber: '' };
  customerDetails: CustomerDetails = { 
    name: '', 
    phone: '', 
    email: '', 
    address: '', 
    city: '', 
    state: '', 
    pincode: '',
    firstName: '',
    lastName: '',
    alternatePhone: '',
    landmark: '',
    addressType: 'HOME',
    isDefault: true
  };

  // ✅ ENHANCED: Centralized state management with duplicate payment support
  paymentState: PaymentState = {
    step: 1,
    isProcessing: false,
    error: '',
    success: '',
    orderCreated: false,
    paymentProcessed: false,
    processingProgress: 0,
    isDuplicatePayment: false,
    existingPaymentData: null
  };
  
  // ✅ ENHANCED: Loading states
  isLoadingOrderSummary = true;
  isValidatingPayment = false;
  isPlacingOrder = false;
  isSavingCustomerDetails = false;
  isInitializingPayment = false;
  isCheckingExistingPayment = false;

  // ✅ ENHANCED: Request deduplication
  private pendingRequests = new Set<string>();
  private requestCooldown = new Map<string, number>();
  private readonly COOLDOWN_PERIOD = 5000; // 5 seconds

  // ✅ ENHANCED: Payment processing
  private paymentTimeout: any = null;
  private progressInterval: any = null;
  private readonly PAYMENT_TIMEOUT_MS = 45000;
  private readonly MAX_RETRY_ATTEMPTS = 3;
  private retryAttempts = 0;

  // ✅ ADD: Popular banks and UPI providers
  popularBanks = [
    { code: 'SBI', name: 'State Bank of India' },
    { code: 'HDFC', name: 'HDFC Bank' },
    { code: 'ICICI', name: 'ICICI Bank' },
    { code: 'AXIS', name: 'Axis Bank' },
    { code: 'KOTAK', name: 'Kotak Mahindra Bank' },
    { code: 'PNB', name: 'Punjab National Bank' }
  ];

  walletProviders = [
    { id: 'paytm', name: 'Paytm' },
    { id: 'amazonpay', name: 'Amazon Pay' },
    { id: 'mobikwik', name: 'Mobikwik' },
    { id: 'freecharge', name: 'FreeCharge' }
  ];

  private destroy$ = new Subject<void>();

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private paymentService: PaymentService,
    private orderService: OrderService,
    private cartService: CartService,
    private authService: AuthService,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {
    console.log('🔧 PaymentsComponent initialized');
  }

  ngOnInit(): void {
    console.log('🚀 PaymentsComponent ngOnInit called');
    this.initializeComponent();
  }

  ngOnDestroy(): void {
    console.log('🧹 PaymentsComponent destroyed');
    this.cleanup();
  }

  getPopularPaymentMethods(): PaymentMethod[] {
    return this.paymentMethods.filter(method => Boolean(method.isPopular) && Boolean(method.enabled));
  }

  // ✅ ENHANCED: Component initialization
  private async initializeComponent(): Promise<void> {
    try {
      await this.checkAuthentication();
      await this.loadOrderSummary();
      await this.loadCustomerDetails();
      this.setupPaymentMethods();
      this.validateInitialState();
    } catch (error) {
      console.error('❌ Component initialization failed:', error);
      this.paymentState.error = 'Failed to initialize payment page. Please try again.';
    }
  }

  // ✅ ENHANCED: Cleanup method
  private cleanup(): void {
    // Clear timeouts
    if (this.paymentTimeout) {
      clearTimeout(this.paymentTimeout);
      this.paymentTimeout = null;
    }
    
    if (this.progressInterval) {
      clearInterval(this.progressInterval);
      this.progressInterval = null;
    }
    
    // Clear pending requests
    this.pendingRequests.clear();
    this.requestCooldown.clear();
    
    // Complete observables
    this.destroy$.next();
    this.destroy$.complete();
  }

  // ✅ ENHANCED: Setup payment methods based on order amount
  private setupPaymentMethods(): void {
    if (!this.orderSummary) return;

    const totalAmount = this.orderSummary.totalAmount;
    console.log('🔧 Setting up payment methods for amount:', totalAmount);

    this.paymentMethods.forEach(method => {
      if (method.minAmount && totalAmount < method.minAmount) {
        method.enabled = false;
        method.description = `Minimum amount: ${this.formatPrice(method.minAmount)}`;
      } else if (method.maxAmount && totalAmount > method.maxAmount) {
        method.enabled = false;
        method.description = `Maximum amount: ${this.formatPrice(method.maxAmount)}`;
      } else {
        method.enabled = true;
        this.restoreMethodDescription(method);
      }

      if (method.processingFee && method.processingFee > 0) {
        method.description += ` (Processing fee: ${this.formatPrice(method.processingFee)})`;
      }
    });

    console.log('✅ Payment methods configured:', this.paymentMethods.filter(m => m.enabled).length, 'enabled');
  }

  private restoreMethodDescription(method: PaymentMethod): void {
    const originalDescriptions: { [key: string]: string } = {
      'UPI': 'Pay using Google Pay, PhonePe, Paytm',
      'CARD': 'Visa, Mastercard, Rupay accepted',
      'NET_BANKING': 'All major banks supported',
      'WALLET': 'Paytm, Amazon Pay, PayPal',
      'COD': 'Pay when your order arrives'
    };
    
    method.description = originalDescriptions[method.id] || method.description;
  }

  // ✅ ENHANCED: Authentication check
  private async checkAuthentication(): Promise<void> {
    if (!isPlatformBrowser(this.platformId)) {
      return;
    }

    try {
      if (!this.authService.isAuthenticated()) {
        console.warn('⚠️ User not authenticated, redirecting to login');
        await this.router.navigate(['/customer-login'], {
          queryParams: { returnUrl: '/payments' }
        });
        throw new Error('Authentication required');
      }

      if (this.authService.isTokenExpiringSoon?.()) {
        console.log('🔄 Token expiring soon, attempting refresh...');
        this.authService.autoRefreshToken?.();
      }

      console.log('✅ User authenticated for payment');
    } catch (error) {
      console.error('❌ Authentication check failed:', error);
      this.paymentState.error = 'Authentication failed. Please login again.';
      throw error;
    }
  }

  // ✅ ENHANCED: Load order summary with comprehensive validation
  private async loadOrderSummary(): Promise<void> {
    this.isLoadingOrderSummary = true;
    this.paymentState.error = '';
    
    try {
      console.log('📋 Loading order summary...');

      const savedOrderSummary = this.orderService.getOrderSummary();
      if (savedOrderSummary?.orderData) {
        console.log('✅ Order summary from OrderService:', savedOrderSummary);
        this.orderSummary = savedOrderSummary.orderData;
        this.validateOrderSummary();
        return;
      }

      const cartSummary = this.cartService.getCartSummary();
      if (cartSummary.itemCount > 0) {
        console.log('✅ Creating order summary from cart:', cartSummary);
        
        this.orderSummary = this.orderService.createOrderSummary({
          items: cartSummary.items,
          restaurantId: cartSummary.restaurantId!,
          restaurantName: cartSummary.restaurantName!,
          totalAmount: cartSummary.totalAmount,
          customerDetails: this.customerDetails
        });
        
        this.validateOrderSummary();
        return;
      }

      if (isPlatformBrowser(this.platformId)) {
        const saved = localStorage.getItem('orderSummary');
        if (saved) {
          const parsedSummary = JSON.parse(saved);
          console.log('✅ Order summary from localStorage:', parsedSummary);
          this.orderSummary = parsedSummary.orderData || parsedSummary;
          this.validateOrderSummary();
          return;
        }
      }

      throw new Error('No order found. Please add items to cart first.');
      
    } catch (error) {
      console.error('❌ Error loading order summary:', error);
      this.paymentState.error = error instanceof Error ? error.message : 'Failed to load order details.';
      
      setTimeout(() => {
        this.router.navigate(['/cart']);
      }, 3000);
      
      throw error;
    } finally {
      this.isLoadingOrderSummary = false;
    }
  }

  private validateOrderSummary(): OrderValidation {
    const validation: OrderValidation = {
      isValid: true,
      errors: [],
      warnings: []
    };

    if (!this.orderSummary) {
      validation.errors.push('Order summary is missing');
      validation.isValid = false;
      return validation;
    }

    if (!this.orderSummary.items || this.orderSummary.items.length === 0) {
      validation.errors.push('No items in order');
      validation.isValid = false;
    }

    if (!this.orderSummary.restaurantId) {
      validation.errors.push('Restaurant information missing');
      validation.isValid = false;
    }

    if (this.orderSummary.totalAmount <= 0) {
      validation.errors.push('Invalid order amount');
      validation.isValid = false;
    }

    if (!this.orderSummary.deliveryAddress) {
      validation.warnings.push('Delivery address not specified');
    }

    if (this.orderSummary.totalAmount < 50) {
      validation.warnings.push('Order amount is quite low. Some payment methods may not be available.');
    }

    if (validation.errors.length > 0) {
      console.error('❌ Order validation failed:', validation.errors);
      this.paymentState.error = validation.errors[0];
    } else if (validation.warnings.length > 0) {
      console.warn('⚠️ Order validation warnings:', validation.warnings);
    } else {
      console.log('✅ Order summary validation passed');
    }

    return validation;
  }

  private validateInitialState(): void {
    if (!this.orderSummary) {
      this.paymentState.error = 'Order summary is required to proceed with payment';
      return;
    }

    if (!this.customerDetails.name || !this.customerDetails.email) {
      console.log('⚠️ Customer details incomplete, user will need to fill them');
    }

    this.paymentState.step = 1;
  }

  // ✅ ENHANCED: Load customer details
  private async loadCustomerDetails(): Promise<void> {
    try {
      console.log('👤 Loading customer details...');
      
      const userInfo = this.authService.getUserInfo();
      const savedCustomerDetails = this.authService.getCustomerDetails?.() || {};
      
      this.customerDetails = {
        name: savedCustomerDetails.name || userInfo.username || userInfo.restaurantName || '',
        phone: savedCustomerDetails.phone || userInfo.phone || '',
        email: savedCustomerDetails.email || userInfo.email || '',
        address: savedCustomerDetails.address || userInfo.location || userInfo.address || '',
        city: savedCustomerDetails.city || '',
        state: savedCustomerDetails.state || '',
        pincode: savedCustomerDetails.pincode || '',
      };
      
      console.log('✅ Customer details loaded:', this.customerDetails);
      
      const isComplete = this.authService.areCustomerDetailsComplete?.() ?? false;
      if (!isComplete) {
        console.log('⚠️ Customer details are incomplete');
      }
      
    } catch (error) {
      console.error('❌ Error loading customer details:', error);
      this.customerDetails = {
        name: 'Customer',
        phone: '',
        email: '',
        address: '',
        city: '',
        state: '',
        pincode: '',
        firstName: '',
        lastName: '',
        alternatePhone: '',
        landmark: '',
        addressType: 'HOME',
        isDefault: true
      };
    }
  }
  // ✅ ADD: Update bank name when selection changes
updateBankName(): void {
  if (this.netBankingDetails.bankCode) {
    const bank = this.popularBanks.find(b => b.code === this.netBankingDetails.bankCode);
    this.netBankingDetails.bankName = bank ? bank.name : '';
  } else {
    this.netBankingDetails.bankName = '';
  }
}


  // ✅ ENHANCED: Payment method selection
  selectPaymentMethod(methodId: string): void {
    console.log('💳 Selecting payment method:', methodId);
    
    const method = this.paymentMethods.find(m => m.id === methodId);
    
    if (!method) {
      this.setError('Invalid payment method selected');
      return;
    }

    if (!method.enabled) {
      this.setError(`${method.name} is currently not available`);
      return;
    }

    const totalAmount = this.getTotalAmountWithFees(methodId);
    const validationResult = this.validatePaymentMethodAmount(method, totalAmount);
    
    if (!validationResult.isValid) {
      this.setError(validationResult.error);
      return;
    }

    this.selectedPaymentMethod = methodId;
    this.paymentState.step = 3;
    this.clearMessages();
    this.resetPaymentDetails();

    console.log('✅ Payment method selected:', method.name);
  }

  private validatePaymentMethodAmount(method: PaymentMethod, amount: number): { isValid: boolean; error: string } {
    if (method.minAmount && amount < method.minAmount) {
      return {
        isValid: false,
        error: `Minimum amount for ${method.name} is ${this.formatPrice(method.minAmount)}`
      };
    }

    if (method.maxAmount && amount > method.maxAmount) {
      return {
        isValid: false,
        error: `Maximum amount for ${method.name} is ${this.formatPrice(method.maxAmount)}`
      };
    }

    return { isValid: true, error: '' };
  }

  private resetPaymentDetails(): void {
    this.cardDetails = { number: '', expiry: '', cvv: '', name: '', cardType: '' };
    this.upiDetails = { id: '', verified: false, provider: '' };
    this.netBankingDetails = { bankCode: '', bankName: '' };
    this.walletDetails = { provider: '', phoneNumber: '' };
  }

  // ✅ CRITICAL FIX: Process payment with duplicate handling and request deduplication
  async processPayment(): Promise<void> {
    console.log('🚀 Starting payment process...');

    // ✅ FIXED: Prevent multiple simultaneous requests
    if (this.paymentState.isProcessing) {
      console.log('⚠️ Payment already in progress');
      return;
    }

    try {
      if (!this.validatePayment() || !this.validateCustomerDetails()) {
        return;
      }

      if (!this.orderSummary) {
        this.setError('Order summary not found. Please start over.');
        return;
      }

      this.initializePaymentProcess();
      await this.placeOrderWithItems();

      if (this.currentOrderId) {
        await this.initiatePaymentWithDuplicateCheck(this.currentOrderId);
      }

    } catch (error) {
      console.error('❌ Payment process failed:', error);
      this.handlePaymentError(error instanceof Error ? error.message : 'Payment process failed');
    }
  }

  // ✅ NEW: Initiate payment with duplicate check and deduplication
  private async initiatePaymentWithDuplicateCheck(orderId: number): Promise<void> {
    const requestKey = `payment_${orderId}_${this.selectedPaymentMethod}`;
    
    // ✅ FIXED: Check if request is already in progress
    if (this.pendingRequests.has(requestKey)) {
      console.log('⚠️ Payment request already in progress for:', requestKey);
      return;
    }

    // ✅ FIXED: Check cooldown period
    const lastRequest = this.requestCooldown.get(requestKey);
    if (lastRequest && (Date.now() - lastRequest) < this.COOLDOWN_PERIOD) {
      console.log('⚠️ Request in cooldown period for:', requestKey);
      this.setError('Please wait a moment before trying again.');
      return;
    }

    // Mark request as pending
    this.pendingRequests.add(requestKey);
    this.requestCooldown.set(requestKey, Date.now());

    try {
      console.log('🔍 Checking for existing payment before initiating new one...');
      
      const existingPayment = await this.checkExistingPayment(orderId);
      
      if (existingPayment) {
        console.log('✅ Payment already exists for order:', orderId, existingPayment);
        await this.handleExistingPayment(existingPayment, orderId);
        return;
      }

      console.log('📤 No existing payment found, proceeding with new payment...');
      if (this.selectedPaymentMethod === 'COD') {
        await this.handleCODPayment(orderId);
      } else {
        await this.initiatePayment(orderId);
      }

    } catch (error) {
      console.error('❌ Error in payment initiation with duplicate check:', error);
      
      // ✅ FIXED: Handle duplicate payment error specifically
      if (error instanceof Error && (
        error.message?.includes('already processed') || 
        error.message?.includes('already initiated') ||
        error.message?.includes('already exists')
      )) {
        await this.handleDuplicatePaymentError(orderId);
      } else {
        throw error;
      }
    } finally {
      // Clean up pending request
      this.pendingRequests.delete(requestKey);
    }
  }

  // ✅ NEW: Check if payment already exists
  private async checkExistingPayment(orderId: number): Promise<any> {
    try {
      this.isCheckingExistingPayment = true;
      console.log('🔍 Checking for existing payment for order:', orderId);
      
      const payment = await this.paymentService.getPaymentByOrderId(orderId)
        .pipe(
          timeout(10000),
          catchError(() => of(null)),
          takeUntil(this.destroy$)
        )
        .toPromise();
      
      if (payment) {
        console.log('✅ Found existing payment:', payment);
        return payment;
      }
      
      return null;
      
    } catch (error) {
      console.log('📭 No existing payment found for order:', orderId);
      return null;
    } finally {
      this.isCheckingExistingPayment = false;
    }
  }

  // ✅ NEW: Handle existing payment scenario
  private async handleExistingPayment(existingPayment: any, orderId: number): Promise<void> {
    console.log('🔄 Handling existing payment scenario...');
    
    const paymentStatus = existingPayment.paymentStatus?.toUpperCase();
    this.paymentState.isDuplicatePayment = true;
    this.paymentState.existingPaymentData = existingPayment;
    
    switch (paymentStatus) {
      case 'PENDING':
        console.log('⏳ Payment is pending, proceeding with confirmation...');
        this.paymentState.processingProgress = 50;
        await this.confirmExistingPayment(existingPayment, orderId);
        break;
        
      case 'COMPLETED':
      case 'SUCCESS':
        console.log('✅ Payment already completed, redirecting to success...');
        this.handlePaymentAlreadyCompleted(existingPayment, orderId);
        break;
        
      case 'FAILED':
        console.log('❌ Previous payment failed, offering retry...');
        this.handleFailedPaymentRetry(existingPayment, orderId);
        break;
        
      default:
        console.log('🤔 Unknown payment status, proceeding with confirmation...');
        await this.confirmExistingPayment(existingPayment, orderId);
    }
  }

  // ✅ NEW: Handle duplicate payment error
  private async handleDuplicatePaymentError(orderId: number): Promise<void> {
    console.log('🔄 Handling duplicate payment error for order:', orderId);

    try {
      const existingPayment = await this.paymentService.getPaymentByOrderId(orderId)
        .pipe(
          timeout(10000),
          catchError(() => of(null))
        )
        .toPromise();

      if (existingPayment) {
        console.log('✅ Found existing payment:', existingPayment);
        
        switch (existingPayment.paymentStatus?.toUpperCase()) {
          case 'PENDING':
            this.setSuccess('Payment is being processed. Confirming...');
            await this.confirmExistingPayment(existingPayment, orderId);
            break;
            
          case 'COMPLETED':
          case 'SUCCESS':
            this.handlePaymentAlreadyCompleted(existingPayment, orderId);
            break;
            
          default:
            await this.confirmExistingPayment(existingPayment, orderId);
        }
      } else {
        this.setError('Payment conflict detected. Please refresh and try again.');
      }

    } catch (error) {
      console.error('❌ Error handling duplicate payment:', error);
      this.setError('Payment verification failed. Please check your order status.');
    }
  }

  // ✅ NEW: Confirm existing payment
  private async confirmExistingPayment(existingPayment: any, orderId: number): Promise<void> {
    try {
      const confirmationData = {
        orderId: orderId,
        paymentMethod: this.selectedPaymentMethod,
        paymentAmount: this.getTotalAmountWithFees(),
        createdBy: this.customerDetails.name,
        customerDetails: this.customerDetails,
        notes: `Confirming payment for order #${orderId}`
      };

      const response = await this.paymentService.confirmPayment(confirmationData)
        .pipe(
          timeout(15000), 
          catchError(() => of(existingPayment)),
          takeUntil(this.destroy$)
        )
        .toPromise();
      
      console.log('✅ Payment confirmed:', response);
      this.handlePaymentSuccess(response || existingPayment, orderId);
      
    } catch (error) {
      console.error('❌ Error confirming existing payment:', error);
      this.handlePaymentSuccess(existingPayment, orderId);
    }
  }

  // ✅ NEW: Handle payment already completed
  private handlePaymentAlreadyCompleted(existingPayment: any, orderId: number): void {
    console.log('✅ Payment already completed for order:', orderId);
    
    this.paymentState.processingProgress = 100;
    this.paymentState.paymentProcessed = true;
    this.paymentState.isProcessing = false;
    this.paymentState.step = 5;
    
    this.setSuccess(`Payment already completed! Your order #${orderId} is being processed.`);
    
    this.cleanup();
    this.clearOrderData();
    
    setTimeout(() => {
      this.router.navigate(['/order-tracking', orderId], {
        queryParams: { 
          paymentSuccess: true,
          amount: existingPayment.paymentAmount || this.getTotalAmountWithFees(),
          method: existingPayment.paymentMethod || this.selectedPaymentMethod,
          existing: true
        }
      });
    }, 2000);
  }

  // ✅ NEW: Handle failed payment retry
  private handleFailedPaymentRetry(existingPayment: any, orderId: number): void {
    this.paymentState.step = 3;
    this.paymentState.isProcessing = false;
    this.setError(`Previous payment failed. Click retry to attempt payment again for order #${orderId}.`);
    
    setTimeout(() => {
      const retryConfirm = confirm('Previous payment attempt failed. Would you like to retry the payment?');
      if (retryConfirm) {
        this.retryFailedPayment(orderId);
      } else {
        this.router.navigate(['/order-history']);
      }
    }, 1000);
  }

  // ✅ NEW: Retry failed payment
  private async retryFailedPayment(orderId: number): Promise<void> {
    try {
      console.log('🔄 Retrying failed payment for order:', orderId);
      
      this.paymentState.isDuplicatePayment = false;
      this.paymentState.existingPaymentData = null;
      this.clearMessages();
      
      if (this.selectedPaymentMethod === 'COD') {
        await this.handleCODPayment(orderId);
      } else {
        await this.initiatePayment(orderId);
      }
      
    } catch (error) {
      console.error('❌ Error retrying failed payment:', error);
      throw new Error('Failed to retry payment: ' + (error as any).message);
    }
  }

  private initializePaymentProcess(): void {
    this.paymentState.isProcessing = true;
    this.paymentState.step = 4;
    this.paymentState.processingProgress = 0;
    this.clearMessages();
    this.retryAttempts = 0;

    this.paymentTimeout = setTimeout(() => {
      if (this.paymentState.isProcessing) {
        this.handlePaymentError('Payment timeout. Please try again.');
      }
    }, this.PAYMENT_TIMEOUT_MS);

    this.startProgressTracking();
  }

  private startProgressTracking(): void {
    let progress = 0;
    this.progressInterval = setInterval(() => {
      if (progress < 90) {
        progress += Math.random() * 10;
        this.paymentState.processingProgress = Math.min(progress, 90);
      }
    }, 500);
  }

  private async placeOrderWithItems(): Promise<void> {
    if (!this.orderSummary) {
      throw new Error('Order summary not available');
    }
  
    this.isPlacingOrder = true;
    console.log('📦 Placing order with items...');
  
    const cartSummary = this.cartService.getCartSummary();
    
    
    // ✅ NEW: Try to fix cart data issues
    this.cartService.fixCartData();
    
    const validation = this.cartService.validateCart();
    console.log('🔍 Cart validation result:', validation);
    
    if (!validation.isValid) {
      console.error('❌ Cart validation failed:', validation.errors);
      
      // ✅ NEW: Provide more helpful error message
      const errorDetails = validation.errors.join('\n');
      throw new Error(`Cart validation failed:\n${errorDetails}\n\nPlease refresh the page and try again.`);
    }
  

    const orderRequest = {
      userId: this.authService.getUserInfo()?.userId || 1,
      restaurantId: cartSummary.restaurantId || this.orderSummary.restaurantId,
      deliveryAddress: this.customerDetails.address,
      
      items: cartSummary.items.map(item => ({
        menuItemId: item.menuItemId || item.id, // ✅ FIXED: Handle both ID fields
        itemName: item.itemName,
        quantity: item.quantity,
        price: item.price
      })),
      
      totalAmount: this.getTotalAmountWithFees(),
      customerName: this.customerDetails.name,
      customerPhone: this.customerDetails.phone,
      customerEmail: this.customerDetails.email,
      restaurantName: cartSummary.restaurantName || this.orderSummary.restaurantName,
      paymentMethod: this.selectedPaymentMethod,
      notes: this.buildOrderNotes()
    };
  
    console.log('🚀 Order request with fixed items:', orderRequest);
  
    try {
      const order = await this.sendOrderRequest(orderRequest);
  
      if (!order) {
        throw new Error('Order placement failed - no response');
      }
  
      console.log('✅ Order placed successfully:', order);
      this.currentOrderId = order.orderId;
      this.paymentState.orderCreated = true;
      this.paymentState.processingProgress = 50;
  
    } catch (error) {
      console.error('❌ Error placing order:', error);
      throw this.enhanceOrderError(error);
    } finally {
      this.isPlacingOrder = false;
    }
  }

  private async sendOrderRequest(orderRequest: any): Promise<any> {
    console.log('📤 Sending order request to backend:', orderRequest);

    const headers = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${this.authService.getToken() || ''}`,
      'X-Idempotency-Key': this.generateIdempotencyKey()
    };

    try {
      const response = await fetch('http://localhost:9097/api/orders', {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(orderRequest)
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`HTTP ${response.status}: ${errorText}`);
      }

      const order = await response.json();
      console.log('✅ Order response received:', order);
      return order;

    } catch (error) {
      console.error('❌ Order request failed:', error);
      throw error;
    }
  }

  private generateIdempotencyKey(): string {
    return `order_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  // ✅ ADD: Handle COD payment separately
  private async handleCODPayment(orderId: number): Promise<void> {
    console.log('💵 Processing Cash on Delivery payment for order:', orderId);
    
    try {
      const codPaymentRequest = {
        orderId: orderId,
        paymentMethod: 'COD',
        paymentAmount: this.getTotalAmountWithFees(),
        createdBy: this.customerDetails.name,
        customerDetails: {
          name: this.customerDetails.name,
          phone: this.customerDetails.phone,
          email: this.customerDetails.email,
          address: this.customerDetails.address,
          city: this.customerDetails.city || '',
          state: this.customerDetails.state || '',
          pincode: this.customerDetails.pincode || '',
          firstName: this.customerDetails.firstName || '',
          lastName: this.customerDetails.lastName || '',
          alternatePhone: this.customerDetails.alternatePhone || '',
          landmark: this.customerDetails.landmark || '',
          addressType: this.customerDetails.addressType || 'HOME',
          isDefault: this.customerDetails.isDefault ?? true
        },
        notes: `Cash on Delivery payment for order #${orderId}. Amount: ${this.formatPrice(this.getTotalAmountWithFees())}`,
        currency: 'INR',
        paymentDetails: {
          deliveryAddress: this.customerDetails.address,
          contactPhone: this.customerDetails.phone,
          paymentType: 'CASH_ON_DELIVERY',
          processingFee: this.getProcessingFee()
        }
      };

      console.log('📤 Sending COD payment request:', codPaymentRequest);

      const payment = await this.paymentService.initiatePayment(codPaymentRequest)
        .pipe(
          timeout(15000),
          takeUntil(this.destroy$)
        )
        .toPromise();
      
      console.log('✅ COD Payment recorded:', payment);
      this.paymentState.processingProgress = 75;

      await this.confirmCODPayment(codPaymentRequest, orderId);

    } catch (error) {
      console.error('❌ Error processing COD payment:', error);
      throw new Error('Failed to process Cash on Delivery payment: ' + (error as any).message);
    }
  }

  private async confirmCODPayment(paymentRequest: any, orderId: number): Promise<void> {
    console.log('✅ Confirming COD payment...');

    try {
      const confirmationData = {
        ...paymentRequest,
        paymentStatus: 'PENDING',
        notes: `COD payment confirmed for order #${orderId}. Payment will be collected on delivery.`
      };

      const response = await this.paymentService.confirmPayment(confirmationData)
        .pipe(
          timeout(15000),
          takeUntil(this.destroy$)
        )
        .toPromise();
      
      console.log('✅ COD Payment confirmed:', response);
      this.handlePaymentSuccess(response, orderId);

    } catch (error) {
      console.error('❌ COD payment confirmation failed:', error);
      throw new Error('COD payment confirmation failed: ' + (error as any).message);
    }
  }

  // ✅ ENHANCED: Initiate payment with deduplication
  private async initiatePayment(orderId: number): Promise<void> {
    if (!this.orderSummary) {
      throw new Error('Order summary not available');
    }

    this.isInitializingPayment = true;
    console.log('💳 Initiating payment for order:', orderId);

    const paymentRequest: PaymentRequestDTO = {
      orderId: orderId,
      paymentMethod: this.selectedPaymentMethod,
      paymentAmount: this.getTotalAmountWithFees(),
      createdBy: this.customerDetails.name,
      customerDetails: this.customerDetails,
      notes: `Payment for order #${orderId}`,
      currency: 'INR',
      paymentDetails: this.getPaymentMethodDetails()
    };

    try {
      const payment = await this.paymentService.initiatePayment(paymentRequest)
        .pipe(
          timeout(15000),
          takeUntil(this.destroy$)
        )
        .toPromise();

      console.log('✅ Payment initiated:', payment);
      this.paymentState.processingProgress = 75;
      await this.simulatePaymentProcessing(paymentRequest, orderId);

    } catch (error) {
      console.error('❌ Error initiating payment:', error);
      throw this.enhancePaymentError(error);
    } finally {
      this.isInitializingPayment = false;
    }
  }

  private getPaymentMethodDetails(): any {
    switch (this.selectedPaymentMethod) {
      case 'CARD':
        return {
          cardNumber: this.maskCardNumber(this.cardDetails.number),
          cardHolderName: this.cardDetails.name,
          cardType: this.detectCardType(this.cardDetails.number)
        };
      case 'UPI':
        return {
          upiId: this.upiDetails.id,
          provider: this.detectUpiProvider(this.upiDetails.id)
        };
      case 'NET_BANKING':
        return {
          bankCode: this.netBankingDetails.bankCode,
          bankName: this.netBankingDetails.bankName
        };
      case 'WALLET':
        return {
          provider: this.walletDetails.provider,
          phoneNumber: this.walletDetails.phoneNumber
        };
      case 'COD':
        return {
          deliveryAddress: this.customerDetails.address,
          contactPhone: this.customerDetails.phone
        };
      default:
        return {};
    }
  }

  private buildOrderNotes(): string {
    const notes = [
      `Payment method: ${this.selectedPaymentMethod}`,
      `Customer: ${this.customerDetails.name}`,
      `Phone: ${this.customerDetails.phone}`
    ];

    if (this.selectedPaymentMethod === 'COD') {
      notes.push('Cash on Delivery - Please keep exact change ready');
    }

    return notes.join('. ');
  }

  private enhanceOrderError(error: any): Error {
    if (error.name === 'TimeoutError') {
      return new Error('Order placement timed out. Please check your connection and try again.');
    }
    
    if (error.message && error.message.includes('Cannot place order with empty cart')) {
      return new Error('Cart synchronization failed. Please refresh the page and try again.');
    }
    
    switch (error.status) {
      case 400:
        return new Error('Invalid order data. Please check your details.');
      case 409:
        return new Error('Order already exists. Please check your order history.');
      case 422:
        return new Error('Order validation failed. Please review your order details.');
      case 503:
        return new Error('Restaurant service temporarily unavailable. Please try again.');
      default:
        return new Error(error.message || 'Failed to place order. Please try again.');
    }
  }

  private enhancePaymentError(error: any): Error {
    if (error.name === 'TimeoutError') {
      return new Error('Payment initiation timed out. Please try again.');
    }
    
    switch (error.status) {
      case 402:
        return new Error('Payment declined. Please check your payment details.');
      case 429:
        return new Error('Too many payment attempts. Please try again after a few minutes.');
      case 503:
        return new Error('Payment service temporarily unavailable. Please try again.');
      default:
        return new Error(error.message || 'Failed to initiate payment. Please try again.');
    }
  }

  private async simulatePaymentProcessing(paymentRequest: PaymentRequestDTO, orderId: number): Promise<void> {
    const processingTime = this.getProcessingTime();
    console.log(`⏳ Processing payment for ${processingTime}ms...`);

    await new Promise(resolve => setTimeout(resolve, processingTime));
    await this.confirmPayment(paymentRequest, orderId);
  }

  private async confirmPayment(paymentRequest: PaymentRequestDTO, orderId: number): Promise<void> {
    console.log('✅ Confirming payment...');

    try {
      const response = await this.paymentService.confirmPayment(paymentRequest)
        .pipe(
          timeout(15000),
          takeUntil(this.destroy$)
        )
        .toPromise();

      console.log('✅ Payment confirmed successfully:', response);
      this.handlePaymentSuccess(response, orderId);

    } catch (error) {
      console.error('❌ Payment confirmation failed:', error);
      throw new Error('Payment confirmation failed. Please contact support if amount was debited.');
    }
  }

  // ✅ NEW: Handle payment success (common method)
  private handlePaymentSuccess(payment: any, orderId: number): void {
    console.log('✅ Payment success handled:', payment);
    
    this.paymentState.processingProgress = 100;
    this.paymentState.paymentProcessed = true;
    this.paymentState.isProcessing = false;
    this.paymentState.step = 5;
    
    if (this.selectedPaymentMethod === 'COD') {
      this.setSuccess('Order placed successfully! Payment will be collected on delivery.');
    } else {
      this.setSuccess('Payment successful! Your order has been placed.');
    }
    
    this.savePaymentSuccess(payment, orderId);
    this.cleanup();
    this.clearOrderData();
    
    setTimeout(() => {
      this.router.navigate(['/order-tracking', orderId], {
        queryParams: { 
          paymentSuccess: true,
          amount: payment.paymentAmount || this.getTotalAmountWithFees(),
          method: payment.paymentMethod || this.selectedPaymentMethod
        }
      });
    }, 3000);
  }

  // ✅ ENHANCED: Payment validation
  private validatePayment(): boolean {
    this.isValidatingPayment = true;
    
    try {
      if (!this.selectedPaymentMethod) {
        this.setError('Please select a payment method');
        return false;
      }

      const method = this.getSelectedPaymentMethod();
      if (!method?.enabled) {
        this.setError('Selected payment method is not available');
        return false;
      }

      switch (this.selectedPaymentMethod) {
        case 'CARD':
          return this.validateCardDetails();
        case 'UPI':
          return this.validateUpiDetails();
        case 'NET_BANKING':
          return this.validateNetBankingDetails();
        case 'WALLET':
          return this.validateWalletDetails();
        case 'COD':
          return this.validateCodDetails();
        default:
          this.setError('Invalid payment method');
          return false;
      }
    } finally {
      this.isValidatingPayment = false;
    }
  }

  private validateCardDetails(): boolean {
    const cardNumber = this.cardDetails.number.replace(/\s/g, '');
    
    if (!cardNumber || cardNumber.length < 16 || cardNumber.length > 19) {
      this.setError('Please enter a valid card number (16-19 digits)');
      return false;
    }

    if (!this.isValidCardNumber(cardNumber)) {
      this.setError('Please enter a valid card number');
      return false;
    }

    if (!this.cardDetails.expiry || !/^\d{2}\/\d{2}$/.test(this.cardDetails.expiry)) {
      this.setError('Please enter expiry date in MM/YY format');
      return false;
    }

    if (this.isCardExpired(this.cardDetails.expiry)) {
      this.setError('Card has expired. Please use a different card.');
      return false;
    }

    if (!this.cardDetails.cvv || this.cardDetails.cvv.length < 3 || this.cardDetails.cvv.length > 4) {
      this.setError('Please enter a valid CVV (3-4 digits)');
      return false;
    }

    if (!this.cardDetails.name.trim() || this.cardDetails.name.length < 2) {
      this.setError('Please enter cardholder name (minimum 2 characters)');
      return false;
    }

    this.cardDetails.cardType = this.detectCardType(cardNumber);
    return true;
  }

  private validateUpiDetails(): boolean {
    if (!this.upiDetails.id.trim()) {
      this.setError('Please enter UPI ID');
      return false;
    }

    const upiRegex = /^[a-zA-Z0-9.\-_]{3,}@[a-zA-Z0-9.\-_]{2,}$/;
    if (!upiRegex.test(this.upiDetails.id)) {
      this.setError('Please enter a valid UPI ID (e.g., user@paytm)');
      return false;
    }

    this.upiDetails.provider = this.detectUpiProvider(this.upiDetails.id);
    return true;
  }

  private validateNetBankingDetails(): boolean {
    if (!this.netBankingDetails.bankCode) {
      this.setError('Please select your bank');
      return false;
    }

    return true;
  }

  private validateWalletDetails(): boolean {
    if (!this.walletDetails.provider) {
      this.setError('Please select wallet provider');
      return false;
    }

    if (this.walletDetails.provider === 'paytm' && !this.walletDetails.phoneNumber) {
      this.setError('Please enter phone number for Paytm wallet');
      return false;
    }

    return true;
  }

  private validateCodDetails(): boolean {
    if (!this.customerDetails.address.trim()) {
      this.setError('Delivery address is required for Cash on Delivery');
      return false;
    }

    const totalAmount = this.getTotalAmountWithFees();
    const codMethod = this.paymentMethods.find(m => m.id === 'COD');
    
    if (codMethod?.minAmount && totalAmount < codMethod.minAmount) {
      this.setError(`Minimum order amount for COD is ${this.formatPrice(codMethod.minAmount)}`);
      return false;
    }

    if (codMethod?.maxAmount && totalAmount > codMethod.maxAmount) {
      this.setError(`Maximum order amount for COD is ${this.formatPrice(codMethod.maxAmount)}`);
      return false;
    }

    return true;
  }

  private validateCustomerDetails(): boolean {
    if (!this.customerDetails.name.trim() || this.customerDetails.name.length < 2) {
      this.setError('Customer name must be at least 2 characters');
      return false;
    }

    if (!this.customerDetails.phone.trim()) {
      this.setError('Phone number is required');
      return false;
    }

    const phoneRegex = /^[6-9]\d{9}$/;
    const cleanPhone = this.customerDetails.phone.replace(/\D/g, '');
    if (!phoneRegex.test(cleanPhone)) {
      this.setError('Please enter a valid 10-digit phone number');
      return false;
    }

    if (!this.customerDetails.email.trim()) {
      this.setError('Email address is required');
      return false;
    }

    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailRegex.test(this.customerDetails.email)) {
      this.setError('Please enter a valid email address');
      return false;
    }

    if (!this.customerDetails.address.trim() || this.customerDetails.address.length < 10) {
      this.setError('Delivery address must be at least 10 characters');
      return false;
    }

    return true;
  }

  // ✅ HELPER METHODS
  private isValidCardNumber(cardNumber: string): boolean {
    let sum = 0;
    let isEven = false;
    
    for (let i = cardNumber.length - 1; i >= 0; i--) {
      let digit = parseInt(cardNumber[i]);
      
      if (isEven) {
        digit *= 2;
        if (digit > 9) {
          digit -= 9;
        }
      }
      
      sum += digit;
      isEven = !isEven;
    }
    
    return sum % 10 === 0;
  }

  private isCardExpired(expiry: string): boolean {
    const [month, year] = expiry.split('/').map(num => parseInt(num));
    const expiryDate = new Date(2000 + year, month - 1);
    const now = new Date();
    
    return expiryDate < now;
  }

  private detectCardType(cardNumber: string): string {
    const cleaned = cardNumber.replace(/\s/g, '');
    
    if (cleaned.startsWith('4')) return 'Visa';
    if (cleaned.startsWith('5') || cleaned.startsWith('2')) return 'Mastercard';
    if (cleaned.startsWith('3')) return 'American Express';
    if (cleaned.startsWith('6')) return 'RuPay';
    
    return 'Unknown';
  }

  private detectUpiProvider(upiId: string): string {
    const domain = upiId.split('@')[1]?.toLowerCase();
    
    const providers: { [key: string]: string } = {
      'paytm': 'Paytm',
      'gpay': 'Google Pay',
      'phonepe': 'PhonePe',
      'okaxis': 'Axis Bank',
      'okhdfcbank': 'HDFC Bank',
      'okicici': 'ICICI Bank',
      'oksbi': 'SBI'
    };
    
    for (const [key, provider] of Object.entries(providers)) {
      if (domain?.includes(key)) {
        return provider;
      }
    }
    
    return 'Other';
  }

  // ✅ NAVIGATION METHODS
  goBack(): void {
    if (this.paymentState.isProcessing) {
      const confirmCancel = confirm('Payment is being processed. Are you sure you want to cancel?');
      if (!confirmCancel) return;
      
      this.cancelPayment();
      return;
    }

    switch (this.paymentState.step) {
      case 2:
        this.paymentState.step = 1;
        break;
      case 3:
        this.paymentState.step = 2;
        this.selectedPaymentMethod = '';
        this.resetPaymentDetails();
        break;
      case 4:
      case 5:
        return;
      default:
        this.router.navigate(['/cart']);
        break;
    }
    
    this.clearMessages();
  }

  goToNextStep(): void {
    switch (this.paymentState.step) {
      case 1:
        if (!this.orderSummary?.items?.length) {
          this.setError('Please review your order before proceeding');
          return;
        }
        this.paymentState.step = 2;
        break;
        
      case 2:
        if (!this.selectedPaymentMethod) {
          this.setError('Please select a payment method');
          return;
        }
        this.paymentState.step = 3;
        break;
        
      case 3:
        this.processPayment();
        return;
    }
    
    this.clearMessages();
  }

  private handlePaymentError(message: string): void {
    console.error('❌ Payment error:', message);
    
    this.cleanup();
    this.setError(message);
    this.paymentState.isProcessing = false;
    this.isPlacingOrder = false;
    this.isInitializingPayment = false;
    
    if (message.includes('order')) {
      this.paymentState.step = 1;
    } else if (message.includes('payment method')) {
      this.paymentState.step = 2;
    } else {
      this.paymentState.step = 3;
    }
  }

  retryPayment(): void {
    if (this.retryAttempts >= this.MAX_RETRY_ATTEMPTS) {
      this.setError('Maximum retry attempts reached. Please try again later.');
      return;
    }

    this.retryAttempts++;
    console.log(`🔄 Retrying payment (attempt ${this.retryAttempts}/${this.MAX_RETRY_ATTEMPTS})`);
    
    this.cleanup();
    this.paymentState = {
      step: 3,
      isProcessing: false,
      error: '',
      success: '',
      orderCreated: false,
      paymentProcessed: false,
      processingProgress: 0,
      isDuplicatePayment: false,
      existingPaymentData: null
    };
    
    this.currentOrderId = null;
  }

  cancelPayment(): void {
    const confirmCancel = confirm('Are you sure you want to cancel? Your order will not be placed.');
    
    if (confirmCancel) {
      this.cleanup();
      
      if (this.currentOrderId && this.paymentState.orderCreated && !this.paymentState.paymentProcessed) {
        console.log('🗑️ Cancelling order due to payment cancellation');
      }
      
      this.router.navigate(['/cart']);
    }
  }

  async saveCustomerDetails(): Promise<void> {
    if (!this.validateCustomerDetails()) {
      return;
    }

    this.isSavingCustomerDetails = true;

    try {
      if (this.authService.updateCustomerDetails) {
        this.authService.updateCustomerDetails(this.customerDetails);
      }

      if (isPlatformBrowser(this.platformId)) {
        localStorage.setItem('customerDetails', JSON.stringify(this.customerDetails));
      }

      this.setSuccess('Customer details saved successfully');
      console.log('✅ Customer details saved');

    } catch (error) {
      console.error('❌ Error saving customer details:', error);
      this.setError('Failed to save customer details');
    } finally {
      this.isSavingCustomerDetails = false;
    }
  }

  private clearOrderData(): void {
    if (!isPlatformBrowser(this.platformId)) return;

    try {
      this.orderService.clearOrderSummary();
      
      this.cartService.clearCart().subscribe({
        next: () => console.log('✅ Cart cleared'),
        error: (error) => console.error('❌ Cart clear error (non-critical):', error)
      });
      
      ['orderSummary', 'customerCart', 'tempOrderData'].forEach(item => {
        localStorage.removeItem(item);
      });
      
      console.log('✅ Order data cleared');
    } catch (error) {
      console.error('❌ Error clearing order data:', error);
    }
  }

  private savePaymentSuccess(paymentResponse: any, orderId: number): void {
    if (!isPlatformBrowser(this.platformId)) return;

    try {
      const successData = {
        orderId,
        paymentId: paymentResponse.paymentId,
        amount: this.getTotalAmountWithFees(),
        method: this.selectedPaymentMethod,
        timestamp: new Date().toISOString(),
        transactionId: paymentResponse.transactionId
      };
      
      localStorage.setItem('lastPaymentSuccess', JSON.stringify(successData));
      console.log('✅ Payment success details saved');
    } catch (error) {
      console.error('❌ Error saving payment success:', error);
    }
  }

  // ✅ NEW: Check if error is duplicate payment
  isDuplicatePaymentError(): boolean {
    return this.paymentState.error.includes('already processed') || 
           this.paymentState.error.includes('already initiated') ||
           this.paymentState.error.includes('already exists') ||
           Boolean(this.paymentState.isDuplicatePayment);
  }

  // ✅ NEW: Check order status
  checkOrderStatus(): void {
    if (this.currentOrderId) {
      this.router.navigate(['/order-tracking', this.currentOrderId]);
    } else if (this.paymentState.existingPaymentData?.orderId) {
      this.router.navigate(['/order-tracking', this.paymentState.existingPaymentData.orderId]);
    } else {
      this.router.navigate(['/order-history']);
    }
  }

  // ✅ NEW: Go to order history
  goToOrderHistory(): void {
    this.router.navigate(['/order-history']);
  }

  // ✅ NEW: Get payment button text
  getPaymentButtonText(): string {
    if (this.isPlacingOrder) return 'Placing Order...';
    if (this.isInitializingPayment) return 'Initiating Payment...';
    if (this.isValidatingPayment) return 'Validating...';
    if (this.isCheckingExistingPayment) return 'Checking Payment...';
    
    const amount = this.formatPrice(this.getTotalAmountWithFees());
    const method = this.getSelectedPaymentMethod()?.name || 'Payment';
    
    return `${this.getPaymentMethodIcon(this.selectedPaymentMethod)} Pay ${amount}`;
  }

  // ✅ UTILITY METHODS
  getSelectedPaymentMethod(): PaymentMethod | null {
    return this.paymentMethods.find(m => m.id === this.selectedPaymentMethod) || null;
  }

  getTotalAmountWithFees(methodId?: string): number {
    if (!this.orderSummary) return 0;
    
    const method = methodId ? 
      this.paymentMethods.find(m => m.id === methodId) : 
      this.getSelectedPaymentMethod();
    
    return this.orderSummary.totalAmount + (method?.processingFee || 0);
  }

  getProcessingFee(): number {
    return this.getSelectedPaymentMethod()?.processingFee || 0;
  }

  hasProcessingFee(): boolean {
    return Boolean(this.getProcessingFee() > 0);
  }

  getChargeBreakdown(): { subtotal: number; processingFee: number; total: number } {
    const subtotal = this.orderSummary?.totalAmount || 0;
    const processingFee = this.getProcessingFee();
    return { subtotal, processingFee, total: subtotal + processingFee };
  }

  private getProcessingTime(): number {
    const times = { CARD: 3000, UPI: 2000, NET_BANKING: 4000, WALLET: 2500, COD: 1000 };
    const baseTime = times[this.selectedPaymentMethod as keyof typeof times] || 3000;
    return baseTime + Math.random() * 1000;
  }

  formatPrice(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(amount);
  }

  formatCardNumber(cardNumber: string): string {
    return cardNumber.replace(/(.{4})/g, '$1 ').trim();
  }

  maskCardNumber(cardNumber: string): string {
    const cleaned = cardNumber.replace(/\s/g, '');
    if (cleaned.length < 4) return cardNumber;
    
    const lastFour = cleaned.slice(-4);
    const maskedPart = '*'.repeat(cleaned.length - 4);
    return this.formatCardNumber(maskedPart + lastFour);
  }

  getOrderProgress(): number {
    if (this.paymentState.paymentProcessed) return 100;
    if (this.paymentState.processingProgress > 0) return this.paymentState.processingProgress;
    if (this.paymentState.orderCreated) return 60;
    if (this.selectedPaymentMethod) return 20;
    return 0;
  }

  getStepTitle(): string {
    const titles = {
      1: 'Review Your Order',
      2: 'Choose Payment Method',
      3: 'Enter Payment Details',
      4: 'Processing Payment',
      5: 'Payment Complete'
    };
    return titles[this.paymentState.step as keyof typeof titles] || 'Payment';
  }

  getStepDescription(): string {
    const descriptions = {
      1: 'Please review your order details before proceeding',
      2: 'Select your preferred payment method',
      3: 'Enter your payment details securely',
      4: 'Please wait while we process your payment',
      5: 'Your payment has been processed successfully'
    };
    return descriptions[this.paymentState.step as keyof typeof descriptions] || '';
  }

  isStepCompleted(step: number): boolean {
    return Boolean(this.paymentState.step > step);
  }

  isStepActive(step: number): boolean {
    return Boolean(this.paymentState.step === step);
  }

  isStepAccessible(step: number): boolean {
    if (step === 1) return true;
    if (step === 2) return Boolean(this.orderSummary?.items?.length);
    if (step === 3) return Boolean(this.selectedPaymentMethod);
    return Boolean(this.paymentState.step >= step);
  }

  canModifyOrder(): boolean {
    return Boolean(this.paymentState.step < 4 && !this.paymentState.isProcessing);
  }

  getEstimatedDeliveryTime(): string {
    const now = new Date();
    let minutes = 45;
    
    if (this.selectedPaymentMethod === 'COD') minutes = 60;
    
    const hour = now.getHours();
    if (hour >= 12 && hour <= 14) minutes += 15;
    else if (hour >= 19 && hour <= 21) minutes += 20;
    
    const deliveryTime = new Date(now.getTime() + minutes * 60000);
    return deliveryTime.toLocaleTimeString('en-IN', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  }

  getPaymentMethodIcon(methodId: string): string {
    return this.paymentMethods.find(m => m.id === methodId)?.icon || '💳';
  }

  // ✅ MESSAGE HELPERS
  private setError(message: string): void {
    this.paymentState.error = message;
    this.paymentState.success = '';
    this.autoHideMessage('error', 8000);
  }

  private setSuccess(message: string): void {
    this.paymentState.success = message;
    this.paymentState.error = '';
    this.autoHideMessage('success', 5000);
  }

  private clearMessages(): void {
    this.paymentState.error = '';
    this.paymentState.success = '';
  }

  private autoHideMessage(type: 'error' | 'success', delay: number): void {
    setTimeout(() => {
      if (type === 'error') {
        this.paymentState.error = '';
      } else {
        this.paymentState.success = '';
      }
    }, delay);
  }

  debugPaymentState(): void {
    console.log('🔍 Payment State Debug:', {
      orderSummary: this.orderSummary,
      selectedPaymentMethod: this.selectedPaymentMethod,
      currentOrderId: this.currentOrderId,
      paymentState: this.paymentState,
      customerDetails: this.customerDetails,
      pendingRequests: Array.from(this.pendingRequests),
      requestCooldown: Array.from(this.requestCooldown.entries()),
      loadingStates: {
        isLoadingOrderSummary: this.isLoadingOrderSummary,
        isValidatingPayment: this.isValidatingPayment,
        isPlacingOrder: this.isPlacingOrder,
        isSavingCustomerDetails: this.isSavingCustomerDetails,
        isInitializingPayment: this.isInitializingPayment,
        isCheckingExistingPayment: this.isCheckingExistingPayment
      },
      calculations: this.getChargeBreakdown(),
      progress: this.getOrderProgress(),
      retryAttempts: this.retryAttempts
    });
  }
}


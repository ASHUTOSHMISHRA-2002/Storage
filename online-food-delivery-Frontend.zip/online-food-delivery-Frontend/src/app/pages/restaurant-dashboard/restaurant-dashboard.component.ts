


// src/app/pages/restaurant-dashboard/restaurant-dashboard.component.ts
import { Component, OnInit, OnDestroy, Inject, PLATFORM_ID } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule, Router, ActivatedRoute } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { lastValueFrom, Subject } from 'rxjs';
import { takeUntil, finalize } from 'rxjs/operators';
import { AuthService } from '../../services/auth.service';
import { OrderService, OrderDTO } from '../../services/order.service';
import { isPlatformBrowser } from '@angular/common';

interface MenuItem {
  id: number;
  name: string;
  description: string;
  price: number;
  isVeg: boolean;
}

interface OrderItem {
  menuItemId: number;
  itemName: string;
  quantity: number;
  price: number;
}

interface Order {
  id?: number;
  orderId: number;
  customerName?: string;
  customer?: { name: string };
  status: string;
  totalAmount: number;
  items: OrderItem[];
  createdAt?: string;
  updatedAt?: string;
}

interface NewMenuItem {
  name: string;
  isVeg: string;
  price: string;
  description: string;
}

@Component({
  selector: 'app-restaurant-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './restaurant-dashboard.component.html',
  styleUrls: ['./restaurant-dashboard.component.css'],
})
export class RestaurantDashboardComponent implements OnInit, OnDestroy {
  private readonly RESTAURANT_API = 'http://localhost:8082/api/restaurants';
  private readonly MENU_API = 'http://localhost:9096/api/menu';
  private readonly ORDER_API = 'http://localhost:9097/api/orders';

  // ✅ ADD: Destroy subject for cleanup
  private destroy$ = new Subject<void>();

  // Core data properties
  restaurantId = '';
  restaurantName = 'Loading...';
  restaurantLocation = 'Loading...';

  orders: Order[] = [];
  menu: MenuItem[] = [];
  filteredMenu: MenuItem[] = [];
  
  // UI state properties
  loading = false;
  error: string | null = null;
  successMessage: string | null = null;
  initializing = true; // ✅ ADD: Track initialization state

  // Menu statistics
  vegCount = 0;
  nonVegCount = 0;

  // Modal states
  showAddForm = false;
  editingItem: MenuItem | null = null;

  // Form data
  newItem: NewMenuItem = {
    name: '',
    isVeg: 'yes',
    price: '',
    description: '',
  };

  // Filter state
  dietFilter = 'all';

  constructor(
    private auth: AuthService,
    private router: Router,
    private route: ActivatedRoute, // ✅ ADD: ActivatedRoute for URL params
    private http: HttpClient,
    private orderService: OrderService,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {}

  ngOnInit(): void {
    console.log('🚀 RestaurantDashboardComponent initializing...');
    this.initializeDashboard();
  }

  ngOnDestroy(): void {
    console.log('🧹 RestaurantDashboardComponent destroying...');
    this.destroy$.next();
    this.destroy$.complete();
  }



  // ✅ ENHANCED: Better initialization flow
  private async initializeDashboard(): Promise<void> {
    try {
      console.log('🚀 Initializing restaurant dashboard...');
      this.initializing = true;
      this.error = null;

      // Step 1: Validate authentication
      if (!this.validateAuthentication()) {
        throw new Error('Authentication validation failed');
      }

      // Step 2: Get restaurant ID with validation
      const restaurantId = await this.getRestaurantId();
      if (!restaurantId) {
        throw new Error('Could not obtain restaurant ID');
      }
      this.restaurantId = restaurantId;

      console.log('✅ Restaurant ID obtained:', this.restaurantId);

      // Step 2.5: Debug authentication info
      this.debugAuthInfo();

      // Step 2.6: Check and fix restaurant ID if needed
      await this.checkAndFixRestaurantId();

      // Step 3: Clear any stale data and fetch fresh restaurant details
      await this.clearStaleDataAndFetchFreshDetails();

      // Step 4: Fetch dashboard data
      await this.fetchData();

      console.log('✅ Dashboard initialization completed successfully');
      this.initializing = false;

    } catch (error: any) {
      console.error('❌ Dashboard initialization failed:', error);
      this.handleInitializationError(error);
      this.initializing = false;
    }
  }

  // 🔥 FIXED: Clear stale data and fetch fresh details from database
  private async clearStaleDataAndFetchFreshDetails(): Promise<void> {
    console.log('🔄 Clearing stale data and fetching fresh details...');
    
    // Clear any cached restaurant data
    this.auth.clearStaleRestaurantData();
    
    // Reset to loading state
    this.restaurantName = 'Loading...';
    this.restaurantLocation = 'Loading...';
    this.error = null;
    
    // Step 1: Try to fetch from backend API first (database)
    await this.fetchRestaurantDetailsFromAPI();
    
    // Step 2: Only if API fails, try to get from JWT token
    if (this.restaurantName === 'Loading...' || this.restaurantLocation === 'Loading...') {
      console.log('⚠️ API fetch failed, trying JWT token data...');
      this.setRestaurantDetailsFromAuth();
    }
    
    // Step 3: Only if both fail, use fallback data
    if (this.restaurantName === 'Loading...' || this.restaurantLocation === 'Loading...') {
      console.log('⚠️ JWT data also failed, using fallback data...');
      this.setFallbackRestaurantData();
    }
    
    console.log('✅ Restaurant data fetch completed:', {
      name: this.restaurantName,
      location: this.restaurantLocation
    });
  }

  // 🔥 NEW: Validate restaurant data
  private async validateRestaurantData(): Promise<void> {
    console.log('🔍 Validating restaurant data...');
    
    const authRestaurantId = this.auth.getRestaurantId();
    const authRestaurantName = this.auth.getRestaurantName();
    const authRestaurantLocation = this.auth.getRestaurantLocation();
    
    console.log('Auth data:', {
      id: authRestaurantId,
      name: authRestaurantName,
      location: authRestaurantLocation
    });
    
    console.log('Current data:', {
      id: this.restaurantId,
      name: this.restaurantName,
      location: this.restaurantLocation
    });
    
    // If there's a mismatch, force refresh
    if (authRestaurantId !== this.restaurantId) {
      console.warn('⚠️ Restaurant ID mismatch, forcing refresh...');
      this.restaurantId = authRestaurantId || this.restaurantId;
      await this.fetchRestaurantDetailsFromAPI();
    }
    
    // If name/location are still loading or don't match auth, try API again
    if (this.restaurantName === 'Loading...' || 
        this.restaurantLocation === 'Loading...' ||
        (authRestaurantName && authRestaurantName !== this.restaurantName) ||
        (authRestaurantLocation && authRestaurantLocation !== this.restaurantLocation)) {
      
      console.log('🔄 Restaurant details need refresh, fetching from API...');
      await this.fetchRestaurantDetailsFromAPI();
    }
  }

  // ✅ ENHANCED: Better authentication validation
  private validateAuthentication(): boolean {
    console.log('🔍 Validating authentication...');

    // Check if user is logged in
    if (!this.auth.isLoggedIn()) {
      console.warn('⚠️ User not logged in');
      this.handleAuthError('Please login to access the dashboard.');
      return false;
    }

    // Check if user is authenticated
    if (!this.auth.isAuthenticated()) {
      console.warn('⚠️ User not authenticated');
      this.handleAuthError('Authentication expired. Please login again.');
      return false;
    }

    // Check if user has restaurant role
    if (!this.auth.isRestaurant()) {
      console.warn('⚠️ User is not a restaurant');
      this.handleAuthError('Access denied. Restaurant account required.');
      return false;
    }

    console.log('✅ Authentication validation passed');
    return true;
  }

  // ✅ ENHANCED: Get restaurant ID from multiple sources
  private async getRestaurantId(): Promise<string | null> {
    console.log('🔍 Getting restaurant ID from multiple sources...');

    // Try 1: From JWT token directly
    const token = this.auth.getToken();
    if (token) {
      try {
        const decoded = this.auth.decodeJWT(token);
        if (decoded && decoded.restaurantId) {
          console.log('✅ Restaurant ID from JWT token:', decoded.restaurantId);
          return decoded.restaurantId.toString();
        }
      } catch (error) {
        console.warn('⚠️ Error decoding JWT for restaurant ID:', error);
      }
    }

    // Try 2: From AuthService
    let restaurantId = this.auth.getRestaurantId();
    if (restaurantId && restaurantId.trim() !== '') {
      console.log('✅ Restaurant ID from AuthService:', restaurantId);
      return restaurantId;
    }

    // Try 3: From URL params
    const urlId = this.route.snapshot.paramMap.get('id');
    if (urlId && urlId.trim() !== '') {
      console.log('✅ Restaurant ID from URL params:', urlId);
      return urlId;
    }

    // Try 4: From URL query params
    const queryId = this.route.snapshot.queryParamMap.get('restaurantId');
    if (queryId && queryId.trim() !== '') {
      console.log('✅ Restaurant ID from query params:', queryId);
      return queryId;
    }

    // Try 5: Extract from user email (fallback method)
    const userEmail = this.auth.getUserEmail();
    if (userEmail) {
      const extractedId = this.extractRestaurantIdFromEmail(userEmail);
      if (extractedId) {
        console.log('✅ Restaurant ID extracted from email:', extractedId);
        return extractedId;
      }
    }

    // Try 6: Wait a moment and try AuthService again (for async loading)
    await new Promise(resolve => setTimeout(resolve, 500));
    restaurantId = this.auth.getRestaurantId();
    if (restaurantId && restaurantId.trim() !== '') {
      console.log('✅ Restaurant ID from AuthService (delayed):', restaurantId);
      return restaurantId;
    }

    // Try 7: Force refresh auth data and try again
    console.log('🔄 Forcing auth data refresh...');
    this.auth.refreshRestaurantData();
    await new Promise(resolve => setTimeout(resolve, 200));
    
    restaurantId = this.auth.getRestaurantId();
    if (restaurantId && restaurantId.trim() !== '') {
      console.log('✅ Restaurant ID after refresh:', restaurantId);
      return restaurantId;
    }

    // Try 8: Get from predefined restaurant data based on email
    if (userEmail) {
      const restaurantData = this.auth.getRestaurantDataByEmail(userEmail);
      if (restaurantData) {
        console.log('✅ Found restaurant data for email:', userEmail);
        // Store the restaurant ID for future use
        this.auth.storeRestaurantInfo({
          name: restaurantData.name,
          location: restaurantData.location,
          email: restaurantData.email,
          phone: restaurantData.phone,
          address: restaurantData.address,
          city: restaurantData.city,
          state: restaurantData.state,
          pincode: restaurantData.pincode
        });
        return userEmail; // Use email as ID for now
      }
    }

    console.error('❌ Could not obtain restaurant ID from any source');
    return null;
  }

  // 🔥 NEW: Extract restaurant ID from email
  private extractRestaurantIdFromEmail(email: string): string | null {
    console.log('🔍 Extracting restaurant ID from email:', email);
    
    // Check if email matches any predefined restaurant
    const restaurantData = this.auth.getRestaurantDataByEmail(email);
    if (restaurantData) {
      console.log('✅ Found restaurant data for email:', email);
      return email; // Use email as identifier
    }
    
    // Try to extract numeric ID from email if it contains one
    const match = email.match(/(\d+)/);
    if (match) {
      console.log('✅ Extracted numeric ID from email:', match[1]);
      return match[1];
    }
    
    return null;
  }

  // ✅ ENHANCED: Better error handling for initialization
  private handleInitializationError(error: any): void {
    console.error('❌ Initialization error:', error);

    if (error?.message?.includes('authentication') || error?.message?.includes('login')) {
      this.handleAuthError('Authentication failed. Please login again.');
    } else if (error?.message?.includes('restaurant')) {
      this.handleAuthError('Restaurant access denied. Please check your account.');
    } else {
      this.error = 'Failed to initialize dashboard. Please refresh the page.';
      // Don't redirect, let user try to refresh
    }
  }

  private setRestaurantDetailsFromAuth(): void {
    try {
      const storedName = this.auth.getRestaurantName();
      const storedLocation = this.auth.getRestaurantLocation();

      console.log('🔍 Setting restaurant details from auth:', { 
        storedName, 
        storedLocation, 
        restaurantId: this.restaurantId 
      });

      if (storedName) {
        this.restaurantName = storedName;
        console.log('✅ Restaurant name set:', storedName);
      }

      if (storedLocation) {
        this.restaurantLocation = storedLocation;
        console.log('✅ Restaurant location set:', storedLocation);
      }

      // If we don't have the data from auth, try to fetch from API
      if (!storedName || !storedLocation) {
        this.fetchRestaurantDetailsFromAPI();
      }

      // Force refresh restaurant data if needed
      this.auth.refreshRestaurantData();
      
      const refreshedName = this.auth.getRestaurantName();
      const refreshedLocation = this.auth.getRestaurantLocation();
      
      if (refreshedName && refreshedName !== this.restaurantName) {
        this.restaurantName = refreshedName;
      }
      
      if (refreshedLocation && refreshedLocation !== this.restaurantLocation) {
        this.restaurantLocation = refreshedLocation;
      }

      console.log('✅ Final restaurant details set:', {
        name: this.restaurantName,
        location: this.restaurantLocation,
        id: this.restaurantId
      });
    } catch (error) {
      console.error('❌ Error setting restaurant details:', error);
      // Try API fallback
      this.fetchRestaurantDetailsFromAPI();
    }
  }

  // 🔥 FIXED: Fetch restaurant details from actual backend API
  private async fetchRestaurantDetailsFromAPI(): Promise<void> {
    if (!this.restaurantId) {
      console.warn('⚠️ No restaurant ID available for API fetch');
      return;
    }

    try {
      console.log('🔍 Fetching restaurant details from backend API for ID:', this.restaurantId);
      console.log('🔗 API URL:', `${this.RESTAURANT_API}/${this.restaurantId}`);
      console.log('🔑 Headers:', this.getHeaders());
      
      // Try the restaurant service API first
      const restaurantResponse = await this.http.get<any>(`${this.RESTAURANT_API}/${this.restaurantId}`, {
        headers: this.getHeaders()
      }).toPromise();

      console.log('✅ Restaurant API response:', restaurantResponse);

      if (restaurantResponse) {
        // Update with actual database data
        this.restaurantName = restaurantResponse.name || 'Restaurant Name Not Available';
        this.restaurantLocation = restaurantResponse.location || 'Location Not Available';
        
        console.log('✅ Restaurant details updated from API:', {
          name: this.restaurantName,
          location: this.restaurantLocation,
          fullResponse: restaurantResponse
        });
        
        // Store the fetched data
        this.auth.storeRestaurantInfo({
          name: this.restaurantName,
          location: this.restaurantLocation,
          email: restaurantResponse.email,
          phone: restaurantResponse.phone || '',
          address: restaurantResponse.address || '',
          city: restaurantResponse.city || '',
          state: restaurantResponse.state || '',
          pincode: restaurantResponse.pincode || ''
        });
        
        // Clear any error messages since we have valid data
        if (this.error && this.error.includes('Backend services')) {
          this.error = null;
        }
        
        return;
      }
    } catch (error: any) {
      console.error('❌ Error fetching restaurant details from API:', error);
      console.error('❌ Error details:', {
        status: error.status,
        statusText: error.statusText,
        message: error.message,
        url: error.url,
        error: error.error
      });
      
      // Check if it's a server error (500, 502, 503, etc.)
      if (error.status >= 500) {
        console.warn('⚠️ Backend server error detected');
        this.error = 'Backend services are temporarily unavailable. Please try again later.';
      } else if (error.status === 404) {
        console.warn('⚠️ Restaurant not found in database');
        this.error = 'Restaurant not found in database. Please check your account.';
      } else if (error.status === 401) {
        console.warn('⚠️ Authentication error');
        this.error = 'Authentication error. Please login again.';
      } else if (error.status === 0) {
        console.warn('⚠️ Network error - cannot connect to server');
        this.error = 'Cannot connect to server. Please check your connection.';
      } else {
        this.error = `Failed to fetch restaurant data: ${error.message || 'Unknown error'}`;
      }
    }
  }

  // 🔥 REMOVED: No longer using predefined data - fetching from database instead

  // 🔥 NEW: Set fallback restaurant data
  private setFallbackRestaurantData(): void {
    console.log('🛠️ Setting fallback restaurant data');
    
    if (this.restaurantName === 'Loading...') {
      this.restaurantName = `Restaurant ${this.restaurantId}`;
    }
    
    if (this.restaurantLocation === 'Loading...') {
      this.restaurantLocation = 'Location not available';
    }
    
    console.log('✅ Fallback data set:', {
      name: this.restaurantName,
      location: this.restaurantLocation
    });
  }

  private async checkAndFixRestaurantId(): Promise<void> {
    console.log('🔍 Checking and fixing restaurant ID...');
    
    const token = this.auth.getToken();
    if (!token) {
      console.error('❌ No token found');
      return;
    }

    try {
      const payload = token.split('.')[1];
      const decodedPayload = JSON.parse(atob(payload));
      console.log('🔍 JWT payload:', decodedPayload);
      
      const jwtRestaurantId = decodedPayload.restaurantId;
      const currentRestaurantId = this.restaurantId;
      
      console.log('🔍 JWT restaurant ID:', jwtRestaurantId);
      console.log('🔍 Current restaurant ID:', currentRestaurantId);
      
      // If there's a mismatch, update the restaurant ID
      if (jwtRestaurantId && jwtRestaurantId.toString() !== currentRestaurantId) {
        console.log('🔄 Fixing restaurant ID mismatch...');
        this.restaurantId = jwtRestaurantId.toString();
        
        // Also update localStorage if available
        if (isPlatformBrowser(this.platformId)) {
          localStorage.setItem('restaurantId', this.restaurantId);
        }
        
        console.log('✅ Restaurant ID updated to:', this.restaurantId);
      }
      
      // Check if user has restaurant role
      const roles = decodedPayload.roles || [];
      const hasRestaurantRole = roles.some((role: string) => 
        role.toUpperCase() === 'RESTAURANT' || 
        role.toUpperCase() === 'ROLE_RESTAURANT' ||
        role.toUpperCase() === 'RESTAURANT_OWNER'
      );
      
      console.log('🔍 User roles:', roles);
      console.log('🔍 Has restaurant role:', hasRestaurantRole);
      
      if (!hasRestaurantRole) {
        console.error('❌ User does not have restaurant role');
        this.error = 'Access denied. You do not have restaurant permissions.';
      }
      
      // Check token expiration
      const now = Math.floor(Date.now() / 1000);
      if (decodedPayload.exp && decodedPayload.exp < now) {
        console.error('🚨 TOKEN EXPIRED!');
        console.error('🚨 Token expired at:', new Date(decodedPayload.exp * 1000));
        console.error('🚨 Current time:', new Date(now * 1000));
        this.error = 'Your session has expired. Please login again.';
      }
      
    } catch (error) {
      console.error('❌ Error checking restaurant ID:', error);
    }
  }

  // 🔥 ENHANCED: Debug auth info
  private debugAuthInfo(): void {
    console.log('🔍 === AUTH DEBUG INFO ===');
    console.log('🔍 Current restaurant ID:', this.restaurantId);
    console.log('🔍 Restaurant name:', this.restaurantName);
    console.log('🔍 Restaurant location:', this.restaurantLocation);
    
    const token = this.auth.getToken();
    console.log('🔍 Has JWT token:', !!token);
    console.log('🔍 Token preview:', token ? token.substring(0, 50) + '...' : 'No token');
    
    if (token) {
      try {
        const payload = token.split('.')[1];
        const decodedPayload = JSON.parse(atob(payload));
        console.log('🔍 Decoded JWT payload:', decodedPayload);
        console.log('🔍 JWT restaurant ID:', decodedPayload.restaurantId);
        console.log('🔍 JWT user ID:', decodedPayload.userId);
        console.log('🔍 JWT email:', decodedPayload.email);
        console.log('🔍 JWT roles:', decodedPayload.roles);
        console.log('🔍 JWT sub:', decodedPayload.sub);
        console.log('🔍 JWT exp:', new Date(decodedPayload.exp * 1000));
        console.log('🔍 JWT iat:', new Date(decodedPayload.iat * 1000));
        
        // Check for mismatch
        if (decodedPayload.restaurantId && decodedPayload.restaurantId.toString() !== this.restaurantId) {
          console.error('🚨 RESTAURANT ID MISMATCH!');
          console.error('🚨 JWT restaurant ID:', decodedPayload.restaurantId);
          console.error('🚨 Current restaurant ID:', this.restaurantId);
        }
        
        // Check token expiration
        const now = Math.floor(Date.now() / 1000);
        if (decodedPayload.exp && decodedPayload.exp < now) {
          console.error('🚨 TOKEN EXPIRED!');
          console.error('🚨 Token expired at:', new Date(decodedPayload.exp * 1000));
          console.error('🚨 Current time:', new Date(now * 1000));
        }
        
        // Check user roles
        const roles = decodedPayload.roles || [];
        const hasRestaurantRole = roles.some((role: string) => 
          role.toUpperCase() === 'RESTAURANT' || 
          role.toUpperCase() === 'ROLE_RESTAURANT' ||
          role.toUpperCase() === 'RESTAURANT_OWNER'
        );
        
        console.log('🔍 User roles:', roles);
        console.log('🔍 Has restaurant role:', hasRestaurantRole);
        
        if (!hasRestaurantRole) {
          console.error('❌ User does not have restaurant role');
        }
        
      } catch (decodeError) {
        console.error('❌ Error decoding JWT:', decodeError);
      }
    }
    
    console.log('🔍 === END AUTH DEBUG ===');
  }

  private getHeaders(): HttpHeaders {
    const token = this.auth.getToken();
    
    // Try multiple authorization header formats
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token || ''}`,
      'X-Restaurant-ID': this.restaurantId || '',
      'X-User-Type': 'RESTAURANT'
    });
    
    console.log('🔍 Using headers:', {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token ? token.substring(0, 50) + '...' : 'No token'}`,
      'X-Restaurant-ID': this.restaurantId || '',
      'X-User-Type': 'RESTAURANT'
    });
    
    return headers;
  }

  // Main data fetching method
  private async fetchData(): Promise<void> {
    if (!this.restaurantId) {
      throw new Error('Restaurant ID is required for data fetching');
    }

    this.loading = true;
    this.error = null;

    try {
      console.log('🔄 Fetching dashboard data for restaurant:', this.restaurantId);
      await Promise.all([this.fetchMenu(), this.fetchOrders()]);
      console.log('✅ Dashboard data fetched successfully');
    } catch (err: any) {
      console.error('❌ Dashboard data fetch error:', err);
      this.error = err.message || 'Could not load dashboard data.';
      throw err; // Re-throw to handle in initialization
    } finally {
      this.loading = false;
    }
  }

  // Refresh methods for individual sections
  async refreshData(): Promise<void> {
    try {
      await this.fetchData();
      this.showSuccess('Dashboard data refreshed successfully!');
    } catch (error) {
      console.error('❌ Error refreshing data:', error);
      this.showError('Failed to refresh dashboard data.');
    }
  }

  async refreshOrders(): Promise<void> {
    try {
      await this.fetchOrders();
      this.showSuccess('Orders refreshed successfully!');
    } catch (error) {
      console.error('❌ Error refreshing orders:', error);
      this.showError('Failed to refresh orders.');
    }
  }

  async refreshMenu(): Promise<void> {
    try {
      await this.fetchMenu();
      this.showSuccess('Menu refreshed successfully!');
    } catch (error) {
      console.error('❌ Error refreshing menu:', error);
      this.showError('Failed to refresh menu.');
    }
  }

  // 🔥 ENHANCED: Fetch menu with better error handling
  private async fetchMenu(): Promise<void> {
    if (!this.restaurantId) {
      console.warn('⚠️ No restaurant ID available for menu fetch');
      return;
    }

    try {
      console.log('🍽️ Fetching menu for restaurant ID:', this.restaurantId);
      
      // Use the correct endpoint for restaurant to get their own menu
      const endpoint = `${this.MENU_API}/restaurant`;
      console.log('🔗 Using correct menu endpoint:', endpoint);

      const response = await this.http.get<any[]>(endpoint, {
        headers: this.getHeaders()
      }).toPromise();

      if (response && Array.isArray(response)) {
        console.log('✅ Menu fetched successfully:', response);
        this.menu = response.map(item => ({
          id: item.itemId || item.id,
          name: item.itemName || item.name,
          description: item.description,
          price: item.price,
          isVeg: item.isVegetarian || item.isVeg
        }));
        
        this.filteredMenu = [...this.menu];
        this.updateVegNonVegCounts();
        return;
      }

      // If the authenticated endpoint fails, try the public endpoint as fallback
      console.log('🔄 Trying public menu endpoint as fallback...');
      const publicEndpoint = `${this.MENU_API}/restaurant/${this.restaurantId}`;
      
      const publicResponse = await this.http.get<any[]>(publicEndpoint).toPromise();

      if (publicResponse && Array.isArray(publicResponse)) {
        console.log('✅ Menu fetched via public endpoint:', publicResponse);
        this.menu = publicResponse.map(item => ({
          id: item.itemId || item.id,
          name: item.itemName || item.name,
          description: item.description,
          price: item.price,
          isVeg: item.isVegetarian || item.isVeg
        }));
        
        this.filteredMenu = [...this.menu];
        this.updateVegNonVegCounts();
        return;
      }

      // If both fail, set empty menu
      console.warn('⚠️ Both menu endpoints failed, setting empty menu');
      this.menu = [];
      this.filteredMenu = [];
      this.updateVegNonVegCounts();

    } catch (error: any) {
      console.error('❌ Error fetching menu:', error);
      this.handleApiError(error, 'Failed to fetch menu items');
      this.menu = [];
      this.filteredMenu = [];
      this.updateVegNonVegCounts();
    }
  }

  // Removed complex authorization format testing - simplified approach

  private updateVegNonVegCounts(): void {
    this.vegCount = this.menu.filter(item => item.isVeg).length;
    this.nonVegCount = this.menu.filter(item => !item.isVeg).length;
  }

  // 🔥 ENHANCED: Fetch orders with better error handling
  private async fetchOrders(): Promise<void> {
    if (!this.restaurantId) {
      console.warn('⚠️ No restaurant ID available for orders fetch');
      return;
    }

    try {
      console.log('🔍 Fetching orders for restaurant:', this.restaurantId);
      console.log('🔍 Using headers:', this.getHeaders());
      
      const response = await this.http.get<any[]>(`${this.ORDER_API}/restaurant/${this.restaurantId}`, {
        headers: this.getHeaders()
      }).toPromise();

      console.log('✅ Orders API response:', response);

      if (response && Array.isArray(response)) {
        this.orders = response.map(order => ({
          id: order.id,
          orderId: order.orderId || order.id,
          customerName: order.customerName || order.customer?.name || 'Unknown Customer',
          customer: order.customer,
          status: order.status || 'pending',
          totalAmount: order.totalAmount || 0,
          items: order.items || [],
          createdAt: order.createdAt,
          updatedAt: order.updatedAt
        }));
        
        console.log('✅ Orders loaded successfully:', this.orders.length, 'orders');
      } else {
        console.warn('⚠️ Invalid orders response format');
        this.orders = [];
      }
    } catch (error: any) {
      console.error('❌ Error fetching orders:', error);
      
      // Handle 403 Forbidden specifically
      if (error.status === 403) {
        console.error('🚫 Access denied for orders - 403 Forbidden');
        console.error('🔍 Current restaurant ID:', this.restaurantId);
        console.error('🔍 User token:', this.auth.getToken()?.substring(0, 50) + '...');
        
        // Don't show error for orders since it's not critical for dashboard functionality
        console.warn('⚠️ Access denied for orders - likely no orders yet or insufficient permissions');
        this.orders = [];
        return;
      }
      
      // Check if it's a server error
      if (error.status >= 500) {
        console.warn('⚠️ Backend server error for orders, using fallback');
        // Don't set error message for orders since it's not critical
        this.orders = [];
      } else if (error.status === 404) {
        console.warn('⚠️ No orders found for restaurant');
        this.orders = [];
      } else {
        console.warn('⚠️ Other error fetching orders:', error.message);
        this.orders = [];
      }
    }
  }

  // ✅ Enhanced error handling method for orders fetch
  private handleOrdersFetchError(err: any): void {
    if (err.status === 403) {
      console.warn('🚨 Order access denied - likely no orders yet or insufficient permissions');
    } else if (err.status === 401) {
      console.warn('🚨 Order access authentication failed');
    } else if (err.status === 0) {
      console.warn('⚠️ Cannot connect to order service - service may be down');
    } else {
      console.warn('⚠️ Orders could not be loaded:', err.message);
    }
  }

  // Menu item management methods
  openAddForm(): void {
    console.log('➕ Opening add item form');
    this.showAddForm = true;
    this.editingItem = null;
    this.resetForm();
    
    // Focus on the first input field after modal opens
    setTimeout(() => {
      const nameInput = document.getElementById('name') as HTMLInputElement;
      if (nameInput) {
        nameInput.focus();
      }
    }, 100);
  }

  closeModal(): void {
    console.log('❌ Closing modal');
    this.showAddForm = false;
    this.editingItem = null;
    this.resetForm();
    this.error = null;
    this.successMessage = null;
  }

  handleEditItem(item: MenuItem): void {
    this.editingItem = { ...item };
    this.newItem = {
      name: item.name,
      description: item.description,
      price: item.price.toString(),
      isVeg: item.isVeg ? 'yes' : 'no',
    };
    this.showAddForm = true;
  }

  private resetForm(): void {
    this.newItem = {
      name: '',
      isVeg: 'yes',
      price: '',
      description: '',
    };
  }

  // Form validation
  validateForm(): boolean {
    const price = parseFloat(this.newItem.price);
    
    if (!this.newItem.name.trim()) {
      this.showError('Item name is required.');
      return false;
    }

    if (!this.newItem.description.trim()) {
      this.showError('Item description is required.');
      return false;
    }

    if (!this.newItem.price || isNaN(price) || price <= 0) {
      this.showError('Valid price is required (minimum ₹1).');
      return false;
    }

    if (price > 9999) {
      this.showError('Price cannot exceed ₹9999.');
      return false;
    }

    return true;
  }

  // 🔥 ENHANCED: Handle form submission
  async handleAddItem(): Promise<void> {
    if (!this.validateForm()) {
      return;
    }

    this.loading = true;
    this.error = null;

    try {
      console.log('➕ Adding new menu item:', this.newItem);
      console.log('🔍 Restaurant ID:', this.restaurantId);

      // Create payload that matches backend MenuItemRequestDto
      const menuItemData = {
        itemName: this.newItem.name,
        description: this.newItem.description,
        price: parseFloat(this.newItem.price),
        isVegetarian: this.newItem.isVeg === 'yes',
        category: 'Main Course',
        isAvailable: true
      };

      console.log('📤 Sending menu item data:', menuItemData);

      // Use the correct endpoint from the backend controller
      const endpoint = `${this.MENU_API}/restaurant`;
      console.log('🔗 Using correct endpoint:', endpoint);

      const response = await this.http.post(endpoint, menuItemData, {
        headers: this.getHeaders()
      }).toPromise();

      console.log('✅ Menu item added successfully:', response);
      this.showSuccess('Menu item added successfully!');
      this.closeModal();
      await this.refreshMenu();
      return;

    } catch (error: any) {
      console.error('❌ Error adding menu item:', error);
      console.error('❌ Error details:', {
        status: error.status,
        statusText: error.statusText,
        message: error.message,
        error: error.error
      });
      
      if (error.status === 403) {
        this.error = 'Access denied. Please check your authentication.';
      } else if (error.status === 500) {
        console.error('🚫 Server error details:', error.error);
        this.error = 'Server error. Please check the backend logs and try again.';
      } else if (error.status === 0) {
        this.error = 'Cannot connect to server. Please check your connection.';
      } else {
        this.error = 'Failed to add menu item. Please try again.';
      }
    } finally {
      this.loading = false;
    }
  }



  // Removed complex JWT validation - simplified approach

  async handleUpdateItem(): Promise<void> {
    if (!this.editingItem || !this.validateForm()) return;

    this.loading = true;
    this.error = null;

    const payload = {
      itemName: this.newItem.name.trim(),
      description: this.newItem.description.trim(),
      price: parseFloat(this.newItem.price),
      isVegetarian: this.newItem.isVeg === 'yes',
      restaurantId: this.restaurantId,
    };

    const endpointsToTry = [
      `${this.MENU_API}/${this.editingItem.id}`,
      `${this.MENU_API}/update/${this.editingItem.id}`,
      `${this.MENU_API}/restaurant/menu/${this.editingItem.id}`,
    ];

    let success = false;
    let lastError: any = null;

    for (const url of endpointsToTry) {
      try {
        console.log('🔍 Updating menu item via:', url);
        await lastValueFrom(this.http.put(url, payload, { headers: this.getHeaders() }));
        success = true;
        break;
      } catch (err: any) {
        console.warn('❌ Update item failed via:', url, err.status, err.message);
        lastError = err;
        if (err.status !== 403 && err.status !== 404 && err.status !== 405 && err.status !== 0) break;
      }
    }

    if (success) {
      await this.fetchMenu();
      this.closeModal();
      this.showSuccess('Menu item updated successfully!');
    } else {
      this.handleApiError(lastError, 'Failed to update menu item');
    }

    this.loading = false;
  }

  async handleDeleteItem(itemId: number): Promise<void> {
    if (!confirm('Are you sure you want to delete this item? This action cannot be undone.')) return;

    this.loading = true;
    this.error = null;

    const endpointsToTry = [
      `${this.MENU_API}/${itemId}`,
      `${this.MENU_API}/delete/${itemId}`,
      `${this.MENU_API}/restaurant/menu/${itemId}`,
    ];

    let success = false;
    let lastError: any = null;

    for (const url of endpointsToTry) {
      try {
        console.log('🔍 Deleting menu item via:', url);
        await lastValueFrom(this.http.delete(url, { headers: this.getHeaders() }));
        success = true;
        break;
      } catch (err: any) {
        console.warn('❌ Delete item failed via:', url, err.status, err.message);
        lastError = err;
        if (err.status !== 403 && err.status !== 404 && err.status !== 405 && err.status !== 0) break;
      }
    }

    if (success) {
      await this.fetchMenu();
      this.showSuccess('Menu item deleted successfully!');
    } else {
      this.handleApiError(lastError, 'Failed to delete menu item');
    }

    this.loading = false;
  }

  // ✅ FIXED: Updated handleStatusChange method using OrderService properly
  async handleStatusChange(order: Order, newStatus: string): Promise<void> {
    this.loading = true;
    this.error = null;

    try {
      const restaurantId = parseInt(this.restaurantId);
      console.log(`🔄 Updating order ${order.orderId} status to ${newStatus} via OrderService`);
      
      // ✅ FIXED: Use proper async handling
      await this.orderService.updateOrderStatus(
        order.orderId, 
        newStatus.toUpperCase(), 
        restaurantId
      ).pipe(takeUntil(this.destroy$)).toPromise();
      
      await this.fetchOrders(); // Refresh orders
      this.showSuccess(`Order #${order.orderId} status updated to ${newStatus}!`);
    } catch (error: any) {
      console.error('❌ Error updating order status via OrderService:', error);
      this.handleStatusUpdateError(error);
    } finally {
      this.loading = false;
    }
  }

  // ✅ Enhanced error handling method for status updates
  private handleStatusUpdateError(error: any): void {
    if (error.status === 403) {
      this.handleAuthorizationError('You do not have permission to update this order.');
    } else if (error.status === 401) {
      this.handleAuthError('Your session has expired.');
    } else if (error.status === 400) {
      this.error = 'Invalid status transition or order data.';
    } else if (error.status === 404) {
      this.error = 'Order not found.';
    } else if (error.status === 0) {
      this.error = 'Cannot connect to order service. Please check your connection.';
    } else {
      this.error = error.error?.message || error.message || 'Failed to update order status.';
    }
  }

  // Event handlers
  onStatusChange(event: Event, order: Order): void {
    const target = event.target as HTMLSelectElement;
    const newStatus = target.value;
    if (newStatus !== order.status) {
      this.handleStatusChange(order, newStatus);
    }
  }

  onFilterChange(filter: string): void {
    this.dietFilter = filter;
    this.applyFilter();
  }

  // Filter and utility methods
  applyFilter(): void {
    if (this.dietFilter === 'veg') {
      this.filteredMenu = this.menu.filter(item => item.isVeg);
    } else if (this.dietFilter === 'non-veg') {
      this.filteredMenu = this.menu.filter(item => !item.isVeg);
    } else {
      this.filteredMenu = [...this.menu];
    }
  }



  // Helper methods for template
  getCustomerName(order: Order): string {
    return order.customerName || order.customer?.name || 'Unknown Customer';
  }

  getStatusBadgeClass(status: string): string {
    const statusMap: { [key: string]: string } = {
      pending: 'badge-warning',
      accepted: 'badge-info',
      in_cooking: 'badge-primary',
      cooking: 'badge-primary',
      out_for_delivery: 'badge-secondary',
      delivery: 'badge-secondary',
      completed: 'badge-success',
      cancelled: 'badge-danger',
    };
    return statusMap[status.toLowerCase()] || 'badge-secondary';
  }

  getOrderTime(order: Order): string {
    if (order.createdAt) {
      const orderDate = new Date(order.createdAt);
      const now = new Date();
      const diffMs = now.getTime() - orderDate.getTime();
      const diffMins = Math.floor(diffMs / 60000);
      
      if (diffMins < 1) return 'Just now';
      if (diffMins < 60) return `${diffMins} min ago`;
      if (diffMins < 1440) return `${Math.floor(diffMins / 60)} hr ago`;
      return orderDate.toLocaleDateString();
    }
    return 'Just now';
  }

  // Statistics methods for dashboard
  getTotalOrderValue(): number {
    return this.orders.reduce((total, order) => total + order.totalAmount, 0);
  }

  getAverageOrderValue(): number {
    if (this.orders.length === 0) return 0;
    return this.getTotalOrderValue() / this.orders.length;
  }

  getPendingOrdersCount(): number {
    return this.orders.filter(order => 
      order.status.toLowerCase() === 'pending' || 
      order.status.toLowerCase() === 'accepted'
    ).length;
  }

  getCompletedOrdersCount(): number {
    return this.orders.filter(order => 
      order.status.toLowerCase() === 'completed'
    ).length;
  }

  getPopularItems(): MenuItem[] {
    // Simple implementation - returns first 3 items
    // You can enhance this based on order frequency
    return this.menu.slice(0, 3);
  }

  // Error handling methods
  private handleApiError(err: any, defaultMessage: string): void {
    console.error('❌ API Error:', err);

    if (err.status === 403) {
      this.handleAuthorizationError('You do not have permission to perform this action.');
    } else if (err.status === 401) {
      this.handleAuthError('Your session has expired.');
    } else if (err.status === 0) {
      this.error = 'Cannot connect to server. Please check your connection and ensure all services are running.';
      this.showError(this.error);
    } else {
      const errorMsg = err.error?.message || err.message || defaultMessage;
      this.error = errorMsg;
      this.showError(errorMsg);
    }
  }

  private handleAuthorizationError(message: string): void {
    console.error('🚨 Authorization Error:', message);
    this.error = `Access Denied: ${message}`;
    this.showError(this.error);
  }

  // ✅ ENHANCED: Better auth error handling - prevent unwanted redirects
  private handleAuthError(message: string): void {
    console.error('🔒 Authentication Error:', message);
    this.error = message;
    
    // Give user a chance to see the error before redirecting
    this.showError(message);
    
    // Only logout and redirect if it's a real auth failure
    if (message.includes('expired') || message.includes('authentication') || message.includes('login')) {
      setTimeout(() => {
        this.auth.logout();
        this.router.navigate(['/restaurant-login'], {
          queryParams: { returnUrl: this.router.url, error: 'session_expired' }
        });
      }, 3000); // Give 3 seconds to read the error
    }
  }

  // Notification methods
  private showSuccess(message: string): void {
    this.successMessage = message;
    this.error = null;
    
    // Auto-hide success message after 5 seconds
    setTimeout(() => {
      this.successMessage = null;
    }, 5000);
  }

  private showError(message: string | null): void {
    if (message) {
      this.error = message;
      this.successMessage = null;
      
      // Auto-hide error message after 10 seconds
      setTimeout(() => {
        if (this.error === message) {
          this.error = null;
        }
      }, 10000);
    }
  }

  // Navigation methods
  logout(): void {
    const confirmed = confirm('Are you sure you want to logout?');
    if (confirmed) {
      this.auth.logout();
      this.router.navigate(['/']);
    }
  }





  // 🔥 NEW: Handle form submission
  async onSubmit(): Promise<void> {
    if (this.editingItem) {
      await this.handleUpdateItem();
    } else {
      await this.handleAddItem();
    }
  }

  // TrackBy functions for performance optimization
  trackByOrderId(index: number, order: Order): number {
    return order.orderId;
  }

  trackByMenuId(index: number, item: MenuItem): number {
    return item.id;
  }

  trackByItemId(index: number, item: OrderItem): number {
    return item.menuItemId;
  }

  // Utility methods
  getRestaurantInfo(): { name: string; location: string; id: string } {
    return {
      name: this.restaurantName,
      location: this.restaurantLocation,
      id: this.restaurantId
    };
  }

  // Method to get formatted currency (if needed)
  formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  }

  // Method to check if order can be modified
  canModifyOrder(order: Order): boolean {
    const nonModifiableStatuses = ['completed', 'cancelled'];
    return !nonModifiableStatuses.includes(order.status.toLowerCase());
  }

  // Method to get next possible status for an order
  getNextPossibleStatuses(currentStatus: string): string[] {
    const statusFlow: { [key: string]: string[] } = {
      'pending': ['accepted', 'cancelled'],
      'accepted': ['in_cooking', 'cancelled'],
      'in_cooking': ['out_for_delivery', 'completed'],
      'cooking': ['delivery', 'completed'],
      'out_for_delivery': ['completed'],
      'delivery': ['completed'],
      'completed': [],
      'cancelled': []
    };

    return statusFlow[currentStatus.toLowerCase()] || [];
  }

  // 🔥 NEW: Test backend connectivity
  private async testBackendConnectivity(): Promise<void> {
    console.log('🔍 === BACKEND CONNECTIVITY TEST ===');
    
    const testEndpoints = [
      // Restaurant service endpoints
      `${this.RESTAURANT_API}/health`,
      `${this.RESTAURANT_API}`,
      `${this.RESTAURANT_API}/${this.restaurantId}`,
      
      // Menu service endpoints (correct ones from backend controller)
      `${this.MENU_API}/restaurant/${this.restaurantId}`, // Public endpoint for viewing menus
      `${this.MENU_API}/restaurant`, // Authenticated endpoint for restaurant's own menu
      
      // Order service endpoints
      `${this.ORDER_API}/health`,
      `${this.ORDER_API}`
    ];

    for (const endpoint of testEndpoints) {
      try {
        console.log(`🔍 Testing endpoint: ${endpoint}`);
        
        // Try without authentication first
        const response = await this.http.get(endpoint, {
          headers: new HttpHeaders({
            'Content-Type': 'application/json'
          })
        }).toPromise();
        
        console.log(`✅ Endpoint ${endpoint} is accessible (no auth):`, response);
        
        // Try with authentication
        try {
          const authResponse = await this.http.get(endpoint, {
            headers: this.getHeaders()
          }).toPromise();
          
          console.log(`✅ Endpoint ${endpoint} is accessible (with auth):`, authResponse);
        } catch (authError: any) {
          console.log(`❌ Endpoint ${endpoint} failed with auth:`, authError.status, authError.message);
        }
        
      } catch (error: any) {
        console.log(`❌ Endpoint ${endpoint} is not accessible:`, error.status, error.message);
      }
    }
    
    console.log('🔍 === END BACKEND CONNECTIVITY TEST ===');
  }

  // 🔥 NEW: Try different authorization approaches
  private async tryDifferentAuthorizationApproaches(): Promise<void> {
    console.log('🔍 === TRYING DIFFERENT AUTHORIZATION APPROACHES ===');
    
    const menuItemData = {
      itemName: this.newItem.name,
      description: this.newItem.description,
      price: parseFloat(this.newItem.price),
      isVegetarian: this.newItem.isVeg === 'yes',
      category: 'Main Course',
      isAvailable: true,
      restaurantId: parseInt(this.restaurantId)
    };

    const token = this.auth.getToken();
    const endpoint = `${this.MENU_API}`;

    const authApproaches = [
      {
        name: 'Bearer token only',
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        })
      },
      {
        name: 'Token without Bearer',
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': token || ''
        })
      },
      {
        name: 'With restaurant ID header',
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
          'X-Restaurant-ID': this.restaurantId || ''
        })
      },
      {
        name: 'With user type header',
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
          'X-User-Type': 'RESTAURANT'
        })
      },
      {
        name: 'All custom headers',
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
          'X-Restaurant-ID': this.restaurantId || '',
          'X-User-Type': 'RESTAURANT'
        })
      },
      {
        name: 'No authorization (public endpoint)',
        headers: new HttpHeaders({
          'Content-Type': 'application/json'
        })
      }
    ];

    for (const approach of authApproaches) {
      try {
        console.log(`🔄 Trying authorization approach: ${approach.name}`);
        
        const response = await this.http.post(endpoint, menuItemData, {
          headers: approach.headers
        }).toPromise();
        
        console.log(`✅ Success with approach: ${approach.name}`, response);
        this.showSuccess('Menu item added successfully!');
        this.closeModal();
        await this.refreshMenu();
        return;
      } catch (error: any) {
        console.log(`❌ Failed with approach: ${approach.name}`, error.status);
        
        if (error.status === 403) {
          console.error(`🚫 403 Forbidden for approach: ${approach.name}`);
        }
      }
    }
    
    console.error('❌ All authorization approaches failed');
    console.log('🔍 === END AUTHORIZATION APPROACHES TEST ===');
  }

  // 🔥 NEW: Check if menu service is running
  private async checkMenuServiceStatus(): Promise<boolean> {
    console.log('🔍 === CHECKING MENU SERVICE STATUS ===');
    
    try {
      // Try to connect to the menu service
      const response = await this.http.get(`${this.MENU_API}/health`, {
        headers: new HttpHeaders({
          'Content-Type': 'application/json'
        })
      }).toPromise();
      
      console.log('✅ Menu service is running:', response);
      return true;
    } catch (error: any) {
      console.log('❌ Menu service health check failed:', error.status);
      
      // Try the base endpoint
      try {
        const baseResponse = await this.http.get(`${this.MENU_API}`, {
          headers: new HttpHeaders({
            'Content-Type': 'application/json'
          })
        }).toPromise();
        
        console.log('✅ Menu service base endpoint is accessible:', baseResponse);
        return true;
      } catch (baseError: any) {
        console.log('❌ Menu service base endpoint also failed:', baseError.status);
        return false;
      }
    }
  }

  // 🔥 NEW: Try to add item with different approaches
  private async tryAddItemWithDifferentApproaches(): Promise<void> {
    console.log('🔍 === TRYING DIFFERENT ADD ITEM APPROACHES ===');
    
    const menuItemData = {
      itemName: this.newItem.name,
      description: this.newItem.description,
      price: parseFloat(this.newItem.price),
      isVegetarian: this.newItem.isVeg === 'yes',
      category: 'Main Course',
      isAvailable: true,
      restaurantId: parseInt(this.restaurantId || '0')
    };

    // Check if menu service is running
    const isServiceRunning = await this.checkMenuServiceStatus();
    if (!isServiceRunning) {
      this.error = 'Menu service is not accessible. Please check if the backend is running on port 9096.';
      return;
    }

    // Try different endpoints
    const endpoints = [
      `${this.MENU_API}`,
      `${this.MENU_API}/add`,
      `${this.MENU_API}/restaurant/${this.restaurantId}`,
      `${this.MENU_API}/restaurant/menu`,
      `${this.MENU_API}/create`,
      `${this.MENU_API}/item/add`,
      `${this.MENU_API}/restaurant/${this.restaurantId}/add`
    ];

    for (const endpoint of endpoints) {
      try {
        console.log(`🔄 Trying endpoint: ${endpoint}`);
        
        const response = await this.http.post(endpoint, menuItemData, {
          headers: this.getHeaders()
        }).toPromise();
        
        console.log(`✅ Success with endpoint: ${endpoint}`, response);
        this.showSuccess('Menu item added successfully!');
        this.closeModal();
        await this.refreshMenu();
        return;
      } catch (error: any) {
        console.log(`❌ Failed with endpoint: ${endpoint}`, error.status);
        
        if (error.status === 500) {
          console.error(`🚫 500 Server Error for endpoint: ${endpoint}`);
          console.error('🔍 Server error details:', error.error);
          
          // If it's a 500 error, try with different data format
          await this.tryWithDifferentDataFormats(endpoint, menuItemData);
        } else if (error.status === 403) {
          console.error(`🚫 403 Forbidden for endpoint: ${endpoint}`);
        } else if (error.status === 404) {
          console.error(`🚫 404 Not Found for endpoint: ${endpoint}`);
        }
      }
    }
    
    console.error('❌ All endpoints failed for adding menu item');
    this.error = 'All endpoints failed. The menu service may be experiencing issues. Please try again later.';
  }

  // 🔥 NEW: Try with different data formats
  private async tryWithDifferentDataFormats(endpoint: string, originalData: any): Promise<void> {
    console.log('🔄 === TRYING DIFFERENT DATA FORMATS ===');
    
    const dataFormats = [
      // Format 1: Original format
      originalData,
      
      // Format 2: Without restaurantId in payload (let backend infer)
      {
        itemName: originalData.itemName,
        description: originalData.description,
        price: originalData.price,
        isVegetarian: originalData.isVegetarian,
        category: originalData.category,
        isAvailable: originalData.isAvailable
      },
      
      // Format 3: Different field names
      {
        name: originalData.itemName,
        description: originalData.description,
        price: originalData.price,
        isVeg: originalData.isVegetarian,
        category: originalData.category,
        available: originalData.isAvailable,
        restaurantId: originalData.restaurantId
      },
      
      // Format 4: Minimal data
      {
        itemName: originalData.itemName,
        price: originalData.price,
        isVegetarian: originalData.isVegetarian
      }
    ];

    for (let i = 0; i < dataFormats.length; i++) {
      try {
        console.log(`🔄 Trying data format ${i + 1}:`, dataFormats[i]);
        
        const response = await this.http.post(endpoint, dataFormats[i], {
          headers: this.getHeaders()
        }).toPromise();
        
        console.log(`✅ Success with data format ${i + 1}:`, response);
        this.showSuccess('Menu item added successfully!');
        this.closeModal();
        await this.refreshMenu();
        return;
      } catch (formatError: any) {
        console.log(`❌ Data format ${i + 1} failed:`, formatError.status);
      }
    }
    
    console.error('❌ All data formats failed');
  }

  // 🔥 NEW: Comprehensive backend diagnostics
  private async runBackendDiagnostics(): Promise<any> {
    console.log('🔍 === RUNNING BACKEND DIAGNOSTICS ===');
    
    const diagnostics: any = {
      timestamp: new Date().toISOString(),
      restaurantId: this.restaurantId,
      menuServiceUrl: this.MENU_API,
      restaurantServiceUrl: this.RESTAURANT_API,
      orderServiceUrl: this.ORDER_API
    };

    // Test 1: Menu Service Health
    console.log('🔍 Testing Menu Service Health...');
    try {
      const healthResponse = await this.http.get(`${this.MENU_API}/health`).toPromise();
      console.log('✅ Menu Service Health:', healthResponse);
      diagnostics.menuServiceHealth = 'OK';
    } catch (error: any) {
      console.log('❌ Menu Service Health Failed:', error.status);
      diagnostics.menuServiceHealth = `FAILED: ${error.status}`;
    }

    // Test 2: Menu Service Base Endpoint
    console.log('🔍 Testing Menu Service Base Endpoint...');
    try {
      const baseResponse = await this.http.get(`${this.MENU_API}`).toPromise();
      console.log('✅ Menu Service Base:', baseResponse);
      diagnostics.menuServiceBase = 'OK';
    } catch (error: any) {
      console.log('❌ Menu Service Base Failed:', error.status);
      diagnostics.menuServiceBase = `FAILED: ${error.status}`;
    }

    // Test 3: Restaurant Service Health
    console.log('🔍 Testing Restaurant Service Health...');
    try {
      const restaurantHealth = await this.http.get(`${this.RESTAURANT_API}/health`).toPromise();
      console.log('✅ Restaurant Service Health:', restaurantHealth);
      diagnostics.restaurantServiceHealth = 'OK';
    } catch (error: any) {
      console.log('❌ Restaurant Service Health Failed:', error.status);
      diagnostics.restaurantServiceHealth = `FAILED: ${error.status}`;
    }

    // Test 4: Specific Menu Endpoint with Auth
    console.log('🔍 Testing Specific Menu Endpoint with Auth...');
    try {
      const menuResponse = await this.http.get(`${this.MENU_API}/restaurant/${this.restaurantId}`, {
        headers: this.getHeaders()
      }).toPromise();
      console.log('✅ Menu Endpoint with Auth:', menuResponse);
      diagnostics.menuEndpointWithAuth = 'OK';
    } catch (error: any) {
      console.log('❌ Menu Endpoint with Auth Failed:', error.status, error.error);
      diagnostics.menuEndpointWithAuth = `FAILED: ${error.status} - ${JSON.stringify(error.error)}`;
    }

    // Test 5: Menu Endpoint without Auth
    console.log('🔍 Testing Menu Endpoint without Auth...');
    try {
      const menuNoAuthResponse = await this.http.get(`${this.MENU_API}/restaurant/${this.restaurantId}`).toPromise();
      console.log('✅ Menu Endpoint without Auth:', menuNoAuthResponse);
      diagnostics.menuEndpointNoAuth = 'OK';
    } catch (error: any) {
      console.log('❌ Menu Endpoint without Auth Failed:', error.status);
      diagnostics.menuEndpointNoAuth = `FAILED: ${error.status}`;
    }

    // Log comprehensive diagnostics
    console.log('📊 === BACKEND DIAGNOSTICS SUMMARY ===');
    console.log(JSON.stringify(diagnostics, null, 2));

    // Store diagnostics for debugging
    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem('backendDiagnostics', JSON.stringify(diagnostics));
    }

    return diagnostics;
  }

  // 🔥 SIMPLIFIED: Basic debug method
  async debugBackendIssues(): Promise<void> {
    console.log('🔧 === BASIC DEBUG INFO ===');
    
    const debugInfo = {
      timestamp: new Date().toISOString(),
      restaurantId: this.restaurantId,
      restaurantName: this.restaurantName,
      restaurantLocation: this.restaurantLocation,
      menuServiceUrl: this.MENU_API,
      restaurantServiceUrl: this.RESTAURANT_API,
      orderServiceUrl: this.ORDER_API,
      menuCount: this.menu.length,
      ordersCount: this.orders.length,
      hasToken: !!this.auth.getToken(),
      tokenLength: this.auth.getToken()?.length || 0
    };
    
    console.log('📊 Debug Info:', debugInfo);
    
    const message = `
Basic Debug Info:
- Restaurant ID: ${debugInfo.restaurantId}
- Restaurant Name: ${debugInfo.restaurantName}
- Menu Items: ${debugInfo.menuCount}
- Orders: ${debugInfo.ordersCount}
- Has Token: ${debugInfo.hasToken}
- Token Length: ${debugInfo.tokenLength}

Check console for detailed logs.
    `;
    
    alert(message);
  }

  // 🔥 NEW: Test menu service connectivity
  private async testMenuServiceConnectivity(): Promise<void> {
    console.log('🔍 === TESTING MENU SERVICE CONNECTIVITY ===');
    
    try {
      // Test basic connectivity
      const healthResponse = await this.http.get(`${this.MENU_API}/health`).toPromise();
      console.log('✅ Menu service health check:', healthResponse);
    } catch (error: any) {
      console.log('❌ Menu service health check failed:', error.status);
    }

    try {
      // Test base endpoint
      const baseResponse = await this.http.get(`${this.MENU_API}`).toPromise();
      console.log('✅ Menu service base endpoint:', baseResponse);
    } catch (error: any) {
      console.log('❌ Menu service base endpoint failed:', error.status);
    }

    try {
      // Test restaurant-specific endpoint
      const restaurantResponse = await this.http.get(`${this.MENU_API}/restaurant/${this.restaurantId}`).toPromise();
      console.log('✅ Menu service restaurant endpoint:', restaurantResponse);
    } catch (error: any) {
      console.log('❌ Menu service restaurant endpoint failed:', error.status);
    }
  }






}

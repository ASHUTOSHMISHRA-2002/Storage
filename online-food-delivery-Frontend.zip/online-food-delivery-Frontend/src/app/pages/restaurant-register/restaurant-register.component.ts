import { Component, inject, PLATFORM_ID } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { isPlatformBrowser, CommonModule } from '@angular/common';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-restaurant-register',
  standalone: true,
  imports: [ReactiveFormsModule, RouterLink, CommonModule],
  templateUrl: './restaurant-register.component.html',
  styleUrls: ['./restaurant-register.component.css']
})
export class RestaurantRegisterComponent {
  registerForm: FormGroup;
  submitting: boolean = false;
  message: string = '';

  private http = inject(HttpClient);
  private router = inject(Router);
  private auth = inject(AuthService);
  private platformId = inject(PLATFORM_ID);
  private fb = inject(FormBuilder);

  constructor() {
    this.registerForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(2)]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(5)]],
      location: ['', [Validators.required, Validators.minLength(2)]]
    });
  }

  register(): void {
    if (this.registerForm.invalid || this.submitting) {
      return;
    }

    this.submitting = true;
    this.message = '';
    
    const restaurantData = {
      name: this.registerForm.get('name')?.value,
      email: this.registerForm.get('email')?.value,
      password: this.registerForm.get('password')?.value,
      location: this.registerForm.get('location')?.value
    };
    
    console.log('🔍 Registering restaurant:', restaurantData);
    
    // Restaurant service is running on port 8082
    const registerUrl = 'http://localhost:8082/api/restaurants/register';

    this.http.post<any>(registerUrl, restaurantData)
      .subscribe({
        next: (response) => {
          console.log('✅ Restaurant registration successful:', response);
          
          // Store the restaurant data in AuthService for immediate use
          if (response.restaurant) {
            this.auth.storeRestaurantInfo({
              name: response.restaurant.name,
              location: response.restaurant.location,
              email: response.restaurant.email,
              phone: response.restaurant.phone || '',
              address: response.restaurant.address || '',
              city: response.restaurant.city || '',
              state: response.restaurant.state || '',
              pincode: response.restaurant.pincode || ''
            });
            
            // Also store the restaurant ID if available
            if (response.restaurant.id) {
              if (isPlatformBrowser(this.platformId)) {
                localStorage.setItem('restaurantId', response.restaurant.id.toString());
              }
            }
          }
          
          this.message = 'Restaurant registered successfully! Redirecting to login...';
          setTimeout(() => {
            this.router.navigate(['/restaurant-login']);
          }, 2000);
        },
        error: (error) => {
          console.error(`❌ Registration failed:`, error);
          this.submitting = false;
          
          if (error.status === 409) {
            this.message = 'A restaurant with this email already exists.';
          } else if (error.status === 400) {
            this.message = error.error?.message || 'Invalid registration data.';
          } else if (error.status === 404) {
            this.message = 'Restaurant service not found. Please check if the backend is running.';
          } else if (error.status === 500) {
            this.message = 'Server error. Please try again later.';
          } else {
            this.message = 'Registration failed. Please try again.';
          }
        }
      });
  }



  getErrorMessage(controlName: string): string {
    const control = this.registerForm.get(controlName);
    if (control?.errors && control.touched) {
      if (control.errors['required']) {
        return `${controlName.charAt(0).toUpperCase() + controlName.slice(1)} is required`;
      }
      if (control.errors['email']) {
        return 'Please enter a valid email address';
      }
      if (control.errors['minlength']) {
        return `${controlName.charAt(0).toUpperCase() + controlName.slice(1)} must be at least ${control.errors['minlength'].requiredLength} characters`;
      }
    }
    return '';
  }
}


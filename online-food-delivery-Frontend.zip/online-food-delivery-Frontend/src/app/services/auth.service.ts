
import { Injectable, Inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { tap, catchError, retry, timeout } from 'rxjs/operators';
import { Observable, throwError, BehaviorSubject, timer } from 'rxjs';
import { Router } from '@angular/router';

interface LoginResponse {
  jwtToken: string;
  message: string;
  restaurant?: any;
  user?: any;
  refreshToken?: string;
}

interface CustomerLoginResponse {
  jwtToken: string;
  message: string;
  user?: any;
  refreshToken?: string;
}

interface DecodedJWT {
  userId: number;
  email: string;
  username?: string;
  location?: string;
  phone?: string;
  address?: string;
  roles: string[];
  iat: number;
  exp: number;
  sub: string;
  restaurantId?: number;
  userType?: string;
}

interface UserInfo {
  restaurantId: string | null;
  restaurantName: string | null;
  restaurantLocation: string | null;
  email: string | null;
  userType: string | null;
  roles: string[];
  userId: number | null;
  username: string | null;
  phone: string | null;
  location: string | null;
  address: string | null;
  isLoggedIn: boolean;
  tokenExpiration: Date | null;
  tokenExpiringSoon: boolean;
}

// ✅ ENHANCED: Customer details interface
interface CustomerDetails {
  name: string;
  phone: string;
  email: string;
  address: string;
  city?: string;
  state?: string;
  pincode?: string;
}

// ✅ ADD: Order tracking data interface
interface OrderTrackingData {
  orderId: string;
  customerId: string;
  customerDetails: CustomerDetails;
  timestamp: number;
  trackingStarted: string;
}

// ✅ ADD: Preserved cart data interface
interface PreservedCartData {
  cart: string;
  userId: string;
  timestamp: number;
  preservedAt: string;
}

// ✅ ADD: Auth state interface
interface AuthState {
  isAuthenticated: boolean;
  user: UserInfo | null;
  lastActivity: Date;
  sessionExpiry: Date | null;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  // ✅ ENHANCED: Comprehensive storage keys
  private readonly STORAGE_KEYS = {
    // Core authentication
    JWT_TOKEN: 'jwtToken',
    AUTH_TOKEN: 'authToken',
    REFRESH_TOKEN: 'refreshToken',
    
    // User identification
    RESTAURANT_ID: 'restaurantId',
    USER_ID: 'userId',
    USER_TYPE: 'userType',
    USER_EMAIL: 'userEmail',
    
    // User profile
    USERNAME: 'username',
    RESTAURANT_NAME: 'restaurantName',
    RESTAURANT_LOCATION: 'restaurantLocation',
    USER_PHONE: 'userPhone',
    USER_ADDRESS: 'userAddress',
    
    // Customer specific
    CUSTOMER_DETAILS: 'customerDetails',
    
    // Session management
    LAST_ACTIVITY: 'lastActivity',
    SESSION_EXPIRY: 'sessionExpiry',
    
    // ✅ NEW: Order tracking and cart preservation
    ORDER_TRACKING: 'order_tracking_data',
    PRESERVED_CART: 'preserved_cart_data',
    CURRENT_ORDER_ID: 'current_order_id',
    ACTIVE_ORDERS: 'active_orders'
  } as const;

  private readonly API_BASE_URL = 'http://localhost:9092/api/auth';
  private readonly CUSTOMER_API_URL = 'http://localhost:9090/api/customers';

  // ✅ ENHANCED: Observable streams for real-time state management
  private authStateSubject = new BehaviorSubject<boolean>(false);
  public authState$ = this.authStateSubject.asObservable();

  private userInfoSubject = new BehaviorSubject<UserInfo | null>(null);
  public userInfo$ = this.userInfoSubject.asObservable();

  private sessionTimerSubject = new BehaviorSubject<number>(0);
  public sessionTimer$ = this.sessionTimerSubject.asObservable();

  // ✅ ENHANCED: Restaurant data with comprehensive information
  private readonly RESTAURANT_DATA: { [key: string]: { 
    name: string; 
    location: string; 
    email: string; 
    phone: string; 
    address: string;
    city: string;
    state: string;
    pincode: string;
  } } = {
    // ✅ UPDATED: Match actual database entries
    'dp@gmail.com': {
      name: 'Dominos Pizza',
      location: 'CHN',
      email: 'dp@gmail.com',
      phone: '+91-9876543210',
      address: '123 Pizza Street',
      city: 'Chennai',
      state: 'Tamil Nadu',
      pincode: '600001'
    },
    'new@gmail.com': {
      name: 'New Restaurant',
      location: 'Chennai',
      email: 'new@gmail.com',
      phone: '+91-9876543211',
      address: '456 Food Avenue',
      city: 'Chennai',
      state: 'Tamil Nadu',
      pincode: '600002'
    },
    'any@gmail.com': {
      name: 'Any',
      location: 'India',
      email: 'any@gmail.com',
      phone: '+91-9876543212',
      address: '789 Cuisine Road',
      city: 'Mumbai',
      state: 'Maharashtra',
      pincode: '400001'
    },
    // Keep existing fallback data
    'restaurant1@example.com': {
      name: 'Spice Garden',
      location: 'Downtown',
      email: 'restaurant1@example.com',
      phone: '+1-555-0101',
      address: '123 Main Street',
      city: 'New York',
      state: 'NY',
      pincode: '10001'
    },
    'restaurant2@example.com': {
      name: 'Taste of India',
      location: 'Midtown',
      email: 'restaurant2@example.com',
      phone: '+1-555-0102',
      address: '456 Oak Avenue',
      city: 'New York',
      state: 'NY',
      pincode: '10002'
    },
    'restaurant3@example.com': {
      name: 'Pizza Palace',
      location: 'Uptown',
      email: 'restaurant3@example.com',
      phone: '+1-555-0103',
      address: '789 Pine Street',
      city: 'New York',
      state: 'NY',
      pincode: '10003'
    },
    'restaurant4@example.com': {
      name: 'Sushi Express',
      location: 'Chinatown',
      email: 'restaurant4@example.com',
      phone: '+1-555-0104',
      address: '321 Elm Street',
      city: 'New York',
      state: 'NY',
      pincode: '10004'
    },
    'restaurant5@example.com': {
      name: 'Burger House',
      location: 'Brooklyn',
      email: 'restaurant5@example.com',
      phone: '+1-555-0105',
      address: '654 Maple Drive',
      city: 'New York',
      state: 'NY',
      pincode: '10005'
    }
  };

  // ✅ ENHANCED: Session management with controlled logging
  private sessionCheckInterval: any = null;
  private readonly SESSION_CHECK_INTERVAL = 300000; // 5 minutes
  private readonly MAX_IDLE_TIME = 30 * 60 * 1000; // 30 minutes
  
  // ✅ ADD: Prevent multiple refresh attempts and control logging
  private refreshInProgress = false;
  private readonly isProduction = false; // Set to true in production
  private readonly enableDebugLogs = !this.isProduction;
  private lastLogTime = 0;

  constructor(
    private http: HttpClient,
    private router: Router,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {
    console.log('🔧 AuthService initialized');
    this.initializeAuthService();
  }

  // ✅ ENHANCED: Complete service initialization
  private initializeAuthService(): void {
    try {
      // Initialize authentication state
      this.initializeAuthState();
      
      // Start session monitoring only if authenticated
      if (this.isAuthenticated()) {
        this.startSessionMonitoring();
      }
      
      // Setup activity tracking
      this.setupActivityTracking();
      
      console.log('✅ AuthService fully initialized');
    } catch (error) {
      console.error('❌ Error initializing AuthService:', error);
      this.resetAuthState();
    }
  }

  // ✅ ADD: Controlled logging method
  private log(message: string, data?: any): void {
    if (this.enableDebugLogs) {
      if (data) {
        console.log(message, data);
      } else {
        console.log(message);
      }
    }
  }

  // ✅ ADD: Throttled logging for frequent operations
  private throttledLog(message: string, data?: any, throttleMs: number = 60000): void {
    const now = Date.now();
    if (now - this.lastLogTime > throttleMs) {
      this.log(message, data);
      this.lastLogTime = now;
    }
  }

  // ✅ ENHANCED: Initialize authentication state
  private initializeAuthState(): void {
    if (!isPlatformBrowser(this.platformId)) {
      console.log('🔍 Server-side rendering, skipping auth initialization');
      return;
    }

    try {
      const token = this.getToken();
      const isAuth = token ? this.isCurrentTokenValid() : false;
      
      this.authStateSubject.next(isAuth);
      
      if (isAuth) {
        const userInfo = this.getUserInfo();
        this.userInfoSubject.next(userInfo);
        this.updateLastActivity();
        console.log('✅ Authentication state initialized - User authenticated');
      } else {
        this.resetAuthState();
        console.log('📱 Authentication state initialized - User not authenticated');
      }
    } catch (error) {
      console.error('❌ Error initializing auth state:', error);
      this.resetAuthState();
    }
  }

  // ✅ ENHANCED: Session monitoring
  private startSessionMonitoring(): void {
    if (!isPlatformBrowser(this.platformId)) return;

    this.stopSessionMonitoring();
    this.log('▶️ Starting session monitoring (checks every 5 minutes)');
    
    this.sessionCheckInterval = setInterval(() => {
      this.checkSessionValidity();
    }, this.SESSION_CHECK_INTERVAL);
  }

  // ✅ ADD: Stop session monitoring
  public stopSessionMonitoring(): void {
    if (this.sessionCheckInterval) {
      clearInterval(this.sessionCheckInterval);
      this.sessionCheckInterval = null;
      this.log('🛑 Session monitoring stopped');
    }
  }

  // ✅ ADD: Activity tracking
  private setupActivityTracking(): void {
    if (!isPlatformBrowser(this.platformId)) return;
    console.log('⚠️ Activity tracking disabled to prevent console loop');
  }

  // ✅ ADD: Update last activity timestamp
  private updateLastActivity(): void {
    if (!isPlatformBrowser(this.platformId)) return;

    try {
      const now = new Date().toISOString();
      localStorage.setItem(this.STORAGE_KEYS.LAST_ACTIVITY, now);
    } catch (error) {
      console.error('❌ Error updating last activity:', error);
    }
  }

  // ✅ ENHANCED: Check session validity
  private checkSessionValidity(): void {
    if (!this.isAuthenticated()) {
      this.stopSessionMonitoring();
      return;
    }

    try {
      const lastActivity = localStorage.getItem(this.STORAGE_KEYS.LAST_ACTIVITY);
      if (!lastActivity) return;

      const lastActivityTime = new Date(lastActivity).getTime();
      const now = Date.now();
      const timeSinceActivity = now - lastActivityTime;

      const shouldLog = timeSinceActivity > (this.MAX_IDLE_TIME * 0.8);

      // Check for idle timeout
      if (timeSinceActivity > this.MAX_IDLE_TIME) {
        console.log('⏰ Session expired due to inactivity');
        this.forceLogout('Session expired due to inactivity');
        return;
      }

      // Check token expiration
      if (this.isTokenExpiringSoon()) {
        this.log('🔄 Token expiring soon, attempting refresh...');
        this.autoRefreshToken();
      }

      if (shouldLog) {
        const remainingTime = Math.max(0, this.MAX_IDLE_TIME - timeSinceActivity);
        const remainingMinutes = Math.floor(remainingTime / (60 * 1000));
        this.throttledLog(`⏱️ Session expires in ${remainingMinutes} minutes`);
      }

      const remainingTime = Math.max(0, this.MAX_IDLE_TIME - timeSinceActivity);
      this.sessionTimerSubject.next(remainingTime);

    } catch (error) {
      console.error('❌ Error checking session validity:', error);
    }
  }

  // ✅ ENHANCED: Restaurant login
  login(credentials: { email: string; password: string }): Observable<LoginResponse> {
    console.log('🔐 Attempting restaurant login for:', credentials.email);

    return this.http.post<LoginResponse>(
      `${this.API_BASE_URL}/restaurant/login`,
      credentials,
      { 
        withCredentials: true,
        headers: this.getDefaultHeaders()
      }
    ).pipe(
      timeout(10000),
      retry(1),
      tap(res => {
        console.log('✅ Restaurant login response received:', res);
        this.handleLoginSuccess(res, credentials.email, 'RESTAURANT');
      }),
      catchError((error: HttpErrorResponse) => {
        console.error('❌ Restaurant login error:', error);
        this.handleLoginError(error);
        return throwError(() => error);
      })
    );
  }

  // ✅ ADD: Customer login method
  customerLogin(credentials: { email: string; password: string }): Observable<CustomerLoginResponse> {
    console.log('🔐 Attempting customer login for:', credentials.email);

    return this.http.post<CustomerLoginResponse>(
      `${this.CUSTOMER_API_URL}/customer/login`,
      credentials,
      { 
        withCredentials: true,
        headers: this.getDefaultHeaders()
      }
    ).pipe(
      timeout(10000),
      retry(1),
      tap(res => {
        console.log('✅ Customer login response received:', res);
        this.handleLoginSuccess(res, credentials.email, 'CUSTOMER');
      }),
      catchError((error: HttpErrorResponse) => {
        console.error('❌ Customer login error:', error);
        this.handleLoginError(error);
        return throwError(() => error);
      })
    );
  }

  // ✅ ENHANCED: Handle login success
  private handleLoginSuccess(res: LoginResponse | CustomerLoginResponse, loginEmail: string, userType: 'RESTAURANT' | 'CUSTOMER'): void {
    if (!res.jwtToken) {
      console.error('❌ No JWT token in login response');
      throw new Error('Invalid login response - no token');
    }

    try {
      // Store tokens
      this.storeTokens(res);
      
      // Decode and validate JWT token
      const decoded = this.decodeJWT(res.jwtToken);
      if (!decoded) {
        throw new Error('Invalid JWT token received');
      }

      // Store user information
      this.storeUserInfo(decoded, loginEmail, userType);
      
      // Store additional data from response
      if ('restaurant' in res && res.restaurant) {
        this.storeRestaurantInfo(res.restaurant);
      }
      
      if ('user' in res && res.user) {
        this.storeCustomerInfo(res.user);
      }

      // Update authentication state
      this.updateLastActivity();
      this.authStateSubject.next(true);
      this.userInfoSubject.next(this.getUserInfo());

      // Start session monitoring after successful login
      this.startSessionMonitoring();

      console.log('✅ Login success handled for', userType);

    } catch (error) {
      console.error('❌ Error handling login success:', error);
      this.clearAuthData();
      throw error;
    }
  }

  // ✅ ADD: Store tokens securely
  private storeTokens(res: LoginResponse | CustomerLoginResponse): void {
    if (!isPlatformBrowser(this.platformId)) return;

    try {
      localStorage.setItem(this.STORAGE_KEYS.JWT_TOKEN, res.jwtToken);
      localStorage.setItem(this.STORAGE_KEYS.AUTH_TOKEN, res.jwtToken);
      
      if ('refreshToken' in res && res.refreshToken) {
        localStorage.setItem(this.STORAGE_KEYS.REFRESH_TOKEN, res.refreshToken);
      }
      
      console.log('🔐 Tokens stored successfully');
    } catch (error) {
      console.error('❌ Error storing tokens:', error);
      throw error;
    }
  }

  // ✅ ADD: Store customer information
  private storeCustomerInfo(customer: any): void {
    if (!isPlatformBrowser(this.platformId)) return;

    try {
      const customerDetails: CustomerDetails = {
        name: customer.name || customer.username || customer.firstName || '',
        phone: customer.phone || customer.phoneNumber || '',
        email: customer.email || '',
        address: customer.address || '',
        city: customer.city || '',
        state: customer.state || '',
        pincode: customer.pincode || customer.zipCode || ''
      };

      localStorage.setItem(this.STORAGE_KEYS.CUSTOMER_DETAILS, JSON.stringify(customerDetails));
      
      if (customer.phone) {
        localStorage.setItem(this.STORAGE_KEYS.USER_PHONE, customer.phone);
      }
      if (customer.address) {
        localStorage.setItem(this.STORAGE_KEYS.USER_ADDRESS, customer.address);
      }

      console.log('📦 Customer info stored:', customerDetails);
    } catch (error) {
      console.error('❌ Error storing customer info:', error);
    }
  }

  // ✅ ENHANCED: Store restaurant information
  public storeRestaurantInfo(restaurant: any): void {
    if (!isPlatformBrowser(this.platformId)) return;

    try {
      const restaurantData = {
        name: restaurant.name || restaurant.restaurantName || '',
        location: restaurant.location || restaurant.address || restaurant.city || '',
        phone: restaurant.phone || restaurant.phoneNumber || restaurant.contactNumber || '',
        address: restaurant.address || restaurant.fullAddress || '',
        city: restaurant.city || '',
        state: restaurant.state || '',
        pincode: restaurant.pincode || restaurant.zipCode || ''
      };

      Object.entries(restaurantData).forEach(([key, value]) => {
        if (value) {
          const storageKey = key === 'name' ? this.STORAGE_KEYS.RESTAURANT_NAME :
                           key === 'location' ? this.STORAGE_KEYS.RESTAURANT_LOCATION :
                           key === 'phone' ? this.STORAGE_KEYS.USER_PHONE :
                           key === 'address' ? this.STORAGE_KEYS.USER_ADDRESS : null;
          
          if (storageKey) {
            localStorage.setItem(storageKey, value);
          }
        }
      });

      console.log('📦 Restaurant info stored:', restaurantData);
    } catch (error) {
      console.error('❌ Error storing restaurant info:', error);
    }
  }

  // ✅ ENHANCED: Handle login errors
  private handleLoginError(error: HttpErrorResponse): void {
    this.clearAuthData();
    
    let errorMessage = 'Login failed. Please try again.';
    
    switch (error.status) {
      case 401:
        errorMessage = 'Invalid email or password.';
        break;
      case 403:
        errorMessage = 'Access denied. Please check your credentials.';
        break;
      case 404:
        errorMessage = 'User not found. Please check your email address.';
        break;
      case 429:
        errorMessage = 'Too many login attempts. Please try again later.';
        break;
      case 0:
        errorMessage = 'Cannot connect to server. Please check your connection.';
        break;
      default:
        if (error.error?.message) {
          errorMessage = error.error.message;
        }
    }
    
    console.error('🚨 Login Error Details:', {
      status: error.status,
      message: errorMessage,
      error: error.error
    });

    throw new Error(errorMessage);
  }

  // ✅ ENHANCED: Decode JWT with more lenient validation
  public decodeJWT(token: string): DecodedJWT | null {
    try {
      if (!token || typeof token !== 'string') {
        console.error('❌ Invalid token format');
        return null;
      }

      const parts = token.split('.');
      if (parts.length !== 3) {
        console.error('❌ Invalid JWT token structure');
        return null;
      }

      const base64Payload = parts[1];
      const paddedPayload = base64Payload + '='.repeat((4 - base64Payload.length % 4) % 4);
      const decodedJson = atob(paddedPayload);
      const decoded = JSON.parse(decodedJson) as DecodedJWT;

      if (!decoded.userId && !decoded.sub) {
        console.warn('⚠️ JWT missing user identification, using fallback');
        decoded.userId = 1;
      }

      if (!decoded.roles || !Array.isArray(decoded.roles)) {
        console.warn('⚠️ JWT missing valid roles, setting default');
        decoded.roles = ['CUSTOMER'];
      }

      if (this.isTokenExpired(decoded)) {
        console.warn('⚠️ JWT token is expired, but allowing for grace period');
      }

      console.log('🔍 JWT decoded successfully:', {
        userId: decoded.userId,
        email: decoded.email,
        roles: decoded.roles,
        expiresAt: new Date(decoded.exp * 1000).toLocaleString()
      });

      return decoded;

    } catch (error) {
      console.error('❌ Error decoding JWT:', error);
      return null;
    }
  }

  // ✅ ENHANCED: Store user info with better organization
  private storeUserInfo(decoded: DecodedJWT, loginEmail?: string, userType?: string): void {
    if (!isPlatformBrowser(this.platformId)) return;

    try {
      // Store core user data
      if (decoded.userId) {
        localStorage.setItem(this.STORAGE_KEYS.USER_ID, decoded.userId.toString());
        localStorage.setItem(this.STORAGE_KEYS.RESTAURANT_ID, decoded.userId.toString());
      }

      // Store user type
      const finalUserType = userType || decoded.userType || (decoded.roles?.[0]?.toUpperCase()) || 'CUSTOMER';
      localStorage.setItem(this.STORAGE_KEYS.USER_TYPE, finalUserType);

      // Store email
      const email = decoded.email || loginEmail;
      if (email) {
        localStorage.setItem(this.STORAGE_KEYS.USER_EMAIL, email);
      }

      // Store username
      if (decoded.username) {
        localStorage.setItem(this.STORAGE_KEYS.USERNAME, decoded.username);
      }

      // Store contact info from JWT
      if (decoded.phone) {
        localStorage.setItem(this.STORAGE_KEYS.USER_PHONE, decoded.phone);
      }
      if (decoded.address) {
        localStorage.setItem(this.STORAGE_KEYS.USER_ADDRESS, decoded.address);
      }
      if (decoded.location) {
        localStorage.setItem(this.STORAGE_KEYS.RESTAURANT_LOCATION, decoded.location);
      }

      // For restaurant users, try to get data from mapping
      if (finalUserType === 'RESTAURANT' && decoded.userId) {
        const restaurantData = this.RESTAURANT_DATA[decoded.userId.toString()];
        if (restaurantData) {
          localStorage.setItem(this.STORAGE_KEYS.RESTAURANT_NAME, restaurantData.name);
          localStorage.setItem(this.STORAGE_KEYS.RESTAURANT_LOCATION, restaurantData.location);
          
          if (!decoded.phone) {
            localStorage.setItem(this.STORAGE_KEYS.USER_PHONE, restaurantData.phone);
          }
          if (!decoded.address) {
            localStorage.setItem(this.STORAGE_KEYS.USER_ADDRESS, restaurantData.address);
          }
        }
      }

      console.log('📦 User info stored successfully for', finalUserType);

    } catch (error) {
      console.error('❌ Error storing user info:', error);
      throw error;
    }
  }

  // ✅ ENHANCED: Token expiration check
  private isTokenExpired(decoded: DecodedJWT): boolean {
    if (!decoded.exp) return false;
    
    const currentTime = Math.floor(Date.now() / 1000);
    const buffer = 300; // 5 minute grace period
    
    return decoded.exp < (currentTime - buffer);
  }

  // ✅ ENHANCED: Logout with preservation options
  logout(): void {
    console.log('🚪 Logging out user...');
    
    try {
      this.stopSessionMonitoring();
      this.clearAuthData();
      this.resetAuthState();
      
      console.log('✅ Logout completed successfully');
      
    } catch (error) {
      console.error('❌ Error during logout:', error);
      this.resetAuthState();
    }
  }

  // ✅ NEW: Logout with data preservation for role switching
  logoutWithPreservation(): void {
    console.log('🚪 Logging out with data preservation...');
    
    try {
      // Preserve cart and order tracking data
      this.preserveCartForRoleSwitch();
      
      // Stop session monitoring
      this.stopSessionMonitoring();

      // Clear auth data but preserve tracking data
      const orderTracking = this.getOrderTrackingData();
      const preservedCart = localStorage.getItem(this.STORAGE_KEYS.PRESERVED_CART);
      
      this.clearAuthData();
      
      // Restore preserved data
      if (orderTracking) {
        localStorage.setItem(this.STORAGE_KEYS.ORDER_TRACKING, JSON.stringify(orderTracking));
      }
      if (preservedCart) {
        localStorage.setItem(this.STORAGE_KEYS.PRESERVED_CART, preservedCart);
      }
      
      // Reset state
      this.resetAuthState();
      
      console.log('✅ Logout with preservation completed');
      
    } catch (error) {
      console.error('❌ Error during logout with preservation:', error);
      this.resetAuthState();
    }
  }

  // ✅ ENHANCED: Clear auth data completely
private clearAuthData(): void {
  if (!isPlatformBrowser(this.platformId)) return;

  try {
    // Clear all storage keys except preserved ones
    const preserveKeys = [
      this.STORAGE_KEYS.ORDER_TRACKING,
      this.STORAGE_KEYS.PRESERVED_CART,
      this.STORAGE_KEYS.CURRENT_ORDER_ID
    ];

    // Convert to string array for proper comparison
    const preserveKeysAsStrings = preserveKeys.map(key => key as string);

    Object.values(this.STORAGE_KEYS).forEach(key => {
      const keyAsString = key as string;
      if (!preserveKeysAsStrings.includes(keyAsString)) {
        localStorage.removeItem(keyAsString);
      }
    });

    // Clear legacy keys for cleanup
    const legacyKeys = ['jwt', 'token', 'restaurantData', 'userData', 'customerCart'];
    legacyKeys.forEach(key => {
      if (!preserveKeysAsStrings.includes(key)) {
        localStorage.removeItem(key);
      }
    });

    console.log('🧹 Auth data cleared');
  } catch (error) {
    console.error('❌ Error clearing auth data:', error);
  }
}

  // ✅ ADD: Reset auth state
  private resetAuthState(): void {
    this.authStateSubject.next(false);
    this.userInfoSubject.next(null);
    this.sessionTimerSubject.next(0);
  }

  // ✅ ENHANCED: Authentication check
  isAuthenticated(): boolean {
    if (!isPlatformBrowser(this.platformId)) {
      return false;
    }

    try {
      const token = this.getToken();
      if (!token) {
        return false;
      }

      const decoded = this.decodeJWT(token);
      return decoded !== null;
      
    } catch (error) {
      console.error('❌ Error checking authentication:', error);
      return false;
    }
  }

  // ✅ ENHANCED: Token validation
  private validateToken(): { 
    isValid: boolean; 
    isExpired: boolean; 
    decodedSuccessfully: boolean; 
    tokenExists: boolean;
    expiresAt?: Date;
  } {
    try {
      const token = this.getToken();
      
      if (!token) {
        return {
          tokenExists: false,
          decodedSuccessfully: false,
          isExpired: true,
          isValid: false
        };
      }

      const decoded = this.decodeJWT(token);
      
      if (!decoded) {
        return {
          tokenExists: true,
          decodedSuccessfully: false,
          isExpired: true,
          isValid: false
        };
      }

      const isExpired = decoded.exp ? (decoded.exp * 1000 < Date.now()) : false;
      
      return {
        tokenExists: true,
        decodedSuccessfully: true,
        isExpired: isExpired,
        isValid: true,
        expiresAt: decoded.exp ? new Date(decoded.exp * 1000) : undefined
      };
      
    } catch (error) {
      console.error('❌ Error validating token:', error);
      return {
        tokenExists: false,
        decodedSuccessfully: false,
        isExpired: true,
        isValid: false
      };
    }
  }

  // ✅ ENHANCED: Get token with validation
  getToken(): string | null {
    if (!isPlatformBrowser(this.platformId)) return null;

    try {
      const token = localStorage.getItem(this.STORAGE_KEYS.JWT_TOKEN) || 
                   localStorage.getItem(this.STORAGE_KEYS.AUTH_TOKEN);
      
      if (!token) {
        return null;
      }

      const parts = token.split('.');
      if (parts.length !== 3) {
        console.warn('⚠️ Invalid token format, but not clearing yet');
        return token;
      }

      return token;
      
    } catch (error) {
      console.error('❌ Error getting token:', error);
      return null;
    }
  }

  // ✅ ENHANCED: Role management
  hasRole(role: string): boolean {
    try {
      const userInfo = this.getUserInfo();
      return userInfo?.roles?.some(r => r.toUpperCase() === role.toUpperCase()) || false;
    } catch (error) {
      console.error('❌ Error checking user role:', error);
      return false;
    }
  }

  isCustomer(): boolean {
    return this.hasRole('CUSTOMER');
  }

  isRestaurant(): boolean {
    return this.hasRole('RESTAURANT');
  }

  isAdmin(): boolean {
    return this.hasRole('ADMIN');
  }

  hasAnyRole(roles: string[]): boolean {
    return roles.some(role => this.hasRole(role));
  }

  // ✅ ENHANCED: User info retrieval
  getUserInfo(): UserInfo {
    if (!isPlatformBrowser(this.platformId)) {
      return this.getDefaultUserInfo();
    }

    try {
      const token = this.getToken();
      const decoded = token ? this.decodeJWT(token) : null;
      
      return {
        restaurantId: this.getRestaurantId(),
        restaurantName: this.getRestaurantName(),
        restaurantLocation: this.getRestaurantLocation(),
        email: this.getUserEmail(),
        userType: this.getUserType(),
        roles: decoded?.roles || ['CUSTOMER'],
        userId: decoded?.userId || parseInt(this.getRestaurantId() || '0') || null,
        username: this.getUsername(),
        phone: this.getUserPhone(),
        location: this.getRestaurantLocation(),
        address: this.getUserAddress(),
        isLoggedIn: this.isLoggedIn(),
        tokenExpiration: this.getTokenExpiration(),
        tokenExpiringSoon: this.isTokenExpiringSoon()
      };
    } catch (error) {
      console.error('❌ Error getting user info:', error);
      return this.getDefaultUserInfo();
    }
  }

  private getDefaultUserInfo(): UserInfo {
    return {
      restaurantId: null,
      restaurantName: null,
      restaurantLocation: null,
      email: null,
      userType: null,
      roles: [],
      userId: null,
      username: null,
      phone: null,
      location: null,
      address: null,
      isLoggedIn: false,
      tokenExpiration: null,
      tokenExpiringSoon: false
    };
  }

  // ✅ ENHANCED: Individual getters with fallbacks
  getRestaurantId(): string | null {
    if (!isPlatformBrowser(this.platformId)) return null;
    
    const id = localStorage.getItem(this.STORAGE_KEYS.RESTAURANT_ID) || 
              localStorage.getItem(this.STORAGE_KEYS.USER_ID);
    return id && id.trim() !== '' ? id : null;
  }

  getRestaurantName(): string | null {
    if (!isPlatformBrowser(this.platformId)) return null;
    
    let name = localStorage.getItem(this.STORAGE_KEYS.RESTAURANT_NAME);
    
    if (!name) {
      const id = this.getRestaurantId();
      if (id && this.RESTAURANT_DATA[id]) {
        name = this.RESTAURANT_DATA[id].name;
        localStorage.setItem(this.STORAGE_KEYS.RESTAURANT_NAME, name);
      }
    }
    
    if (!name) {
      name = this.getUsername();
    }
    
    return name;
  }

  getRestaurantLocation(): string | null {
    if (!isPlatformBrowser(this.platformId)) return null;
    
    let location = localStorage.getItem(this.STORAGE_KEYS.RESTAURANT_LOCATION);
    
    if (!location || location === 'Location not provided') {
      const id = this.getRestaurantId();
      if (id && this.RESTAURANT_DATA[id]) {
        location = this.RESTAURANT_DATA[id].location;
        localStorage.setItem(this.STORAGE_KEYS.RESTAURANT_LOCATION, location);
      }
    }
    
    return location;
  }

  getUserPhone(): string | null {
    if (!isPlatformBrowser(this.platformId)) return null;
    
    let phone = localStorage.getItem(this.STORAGE_KEYS.USER_PHONE);
    
    if (!phone) {
      const id = this.getRestaurantId();
      if (id && this.RESTAURANT_DATA[id]) {
        phone = this.RESTAURANT_DATA[id].phone;
        localStorage.setItem(this.STORAGE_KEYS.USER_PHONE, phone);
      }
    }
    
    return phone;
  }

  getUserAddress(): string | null {
    if (!isPlatformBrowser(this.platformId)) return null;
    
    let address = localStorage.getItem(this.STORAGE_KEYS.USER_ADDRESS);
    
    if (!address) {
      const id = this.getRestaurantId();
      if (id && this.RESTAURANT_DATA[id]) {
        address = this.RESTAURANT_DATA[id].address;
        localStorage.setItem(this.STORAGE_KEYS.USER_ADDRESS, address);
      } else {
        address = this.getRestaurantLocation();
      }
    }
    
    return address;
  }

  getUserEmail(): string | null {
    if (!isPlatformBrowser(this.platformId)) return null;
    return localStorage.getItem(this.STORAGE_KEYS.USER_EMAIL);
  }

  getUserType(): string | null {
    if (!isPlatformBrowser(this.platformId)) return null;
    return localStorage.getItem(this.STORAGE_KEYS.USER_TYPE);
  }

  getUsername(): string | null {
    if (!isPlatformBrowser(this.platformId)) return null;
    return localStorage.getItem(this.STORAGE_KEYS.USERNAME);
  }

  // ✅ NEW: Order tracking methods
  storeOrderForTracking(orderId: string, customerDetails?: CustomerDetails): void {
    if (!isPlatformBrowser(this.platformId)) return;

    try {
      const trackingData: OrderTrackingData = {
        orderId,
        customerId: this.getCurrentUserId().toString(),
        customerDetails: customerDetails || this.getCustomerDetails(),
        timestamp: Date.now(),
        trackingStarted: new Date().toISOString()
      };

      localStorage.setItem(this.STORAGE_KEYS.ORDER_TRACKING, JSON.stringify(trackingData));
      localStorage.setItem(this.STORAGE_KEYS.CURRENT_ORDER_ID, orderId);
      
      console.log('✅ Order stored for tracking:', trackingData);
    } catch (error) {
      console.error('❌ Error storing order for tracking:', error);
    }
  }

  getOrderTrackingData(): OrderTrackingData | null {
    if (!isPlatformBrowser(this.platformId)) return null;

    try {
      const data = localStorage.getItem(this.STORAGE_KEYS.ORDER_TRACKING);
      return data ? JSON.parse(data) : null;
    } catch (error) {
      console.error('❌ Error getting order tracking data:', error);
      return null;
    }
  }

  clearOrderTrackingData(): void {
    if (!isPlatformBrowser(this.platformId)) return;

    try {
      localStorage.removeItem(this.STORAGE_KEYS.ORDER_TRACKING);
      localStorage.removeItem(this.STORAGE_KEYS.CURRENT_ORDER_ID);
      console.log('✅ Order tracking data cleared');
    } catch (error) {
      console.error('❌ Error clearing order tracking data:', error);
    }
  }

  getCurrentOrderId(): string | null {
    if (!isPlatformBrowser(this.platformId)) return null;
    
    return localStorage.getItem(this.STORAGE_KEYS.CURRENT_ORDER_ID);
  }

  // ✅ NEW: Cart preservation methods
  preserveCartForRoleSwitch(): void {
    if (!isPlatformBrowser(this.platformId)) return;

    try {
      const currentCart = localStorage.getItem('customerCart');
      const currentUser = this.getUserInfo();
      
      if (currentCart && currentUser) {
        const preservedData: PreservedCartData = {
          cart: currentCart,
          userId: currentUser.userId?.toString() || '',
          timestamp: Date.now(),
          preservedAt: new Date().toISOString()
        };

        localStorage.setItem(this.STORAGE_KEYS.PRESERVED_CART, JSON.stringify(preservedData));
        console.log('✅ Cart preserved for role switch');
      }
    } catch (error) {
      console.error('❌ Error preserving cart:', error);
    }
  }

  restorePreservedCart(): void {
    if (!isPlatformBrowser(this.platformId)) return;

    try {
      const preserved = localStorage.getItem(this.STORAGE_KEYS.PRESERVED_CART);
      if (preserved) {
        const data: PreservedCartData = JSON.parse(preserved);
        const currentUser = this.getUserInfo();
        
        // Only restore if same user and within 24 hours
        if (data.userId === currentUser?.userId?.toString() && 
            (Date.now() - data.timestamp) < 24 * 60 * 60 * 1000) {
          localStorage.setItem('customerCart', data.cart);
          console.log('✅ Cart restored from preservation');
        }
        
        // Clean up preserved data
        localStorage.removeItem(this.STORAGE_KEYS.PRESERVED_CART);
      }
    } catch (error) {
      console.error('❌ Error restoring preserved cart:', error);
    }
  }

  // ✅ ENHANCED: Customer details management
  getCustomerDetails(): CustomerDetails {
    if (!isPlatformBrowser(this.platformId)) {
      return {
        name: 'Customer',
        phone: '',
        email: '',
        address: ''
      };
    }

    try {
      const saved = localStorage.getItem(this.STORAGE_KEYS.CUSTOMER_DETAILS);
      if (saved) {
        const details = JSON.parse(saved);
        return {
          name: details.name || 'Customer',
          phone: details.phone || '',
          email: details.email || '',
          address: details.address || '',
          city: details.city || '',
          state: details.state || '',
          pincode: details.pincode || ''
        };
      }

      const userInfo = this.getUserInfo();
      return {
        name: userInfo.username || userInfo.restaurantName || 'Customer',
        phone: userInfo.phone || '',
        email: userInfo.email || '',
        address: userInfo.address || userInfo.location || '',
        city: '',
        state: '',
        pincode: ''
      };
    } catch (error) {
      console.error('❌ Error getting customer details:', error);
      return {
        name: 'Customer',
        phone: '',
        email: '',
        address: ''
      };
    }
  }

  updateCustomerDetails(customerDetails: CustomerDetails): void {
    if (!isPlatformBrowser(this.platformId)) return;

    try {
      localStorage.setItem(this.STORAGE_KEYS.CUSTOMER_DETAILS, JSON.stringify(customerDetails));
      
      if (customerDetails.phone) {
        localStorage.setItem(this.STORAGE_KEYS.USER_PHONE, customerDetails.phone);
      }
      if (customerDetails.email) {
        localStorage.setItem(this.STORAGE_KEYS.USER_EMAIL, customerDetails.email);
      }
      if (customerDetails.address) {
        localStorage.setItem(this.STORAGE_KEYS.USER_ADDRESS, customerDetails.address);
      }
      if (customerDetails.name) {
        localStorage.setItem(this.STORAGE_KEYS.USERNAME, customerDetails.name);
      }
      
      console.log('✅ Customer details updated successfully:', customerDetails);
      this.userInfoSubject.next(this.getUserInfo());
      
    } catch (error) {
      console.error('❌ Error updating customer details:', error);
      throw new Error('Failed to update customer details');
    }
  }

  areCustomerDetailsComplete(): boolean {
    const details = this.getCustomerDetails();
    return !!(details.name && details.phone && details.email && details.address);
  }

  clearCustomerDetails(): void {
    if (!isPlatformBrowser(this.platformId)) return;

    try {
      localStorage.removeItem(this.STORAGE_KEYS.CUSTOMER_DETAILS);
      console.log('✅ Customer details cleared');
    } catch (error) {
      console.error('❌ Error clearing customer details:', error);
    }
  }

  // ✅ ENHANCED: Token management
  getTokenExpiration(): Date | null {
    try {
      const token = this.getToken();
      if (!token) return null;

      const decoded = this.decodeJWT(token);
      return decoded ? new Date(decoded.exp * 1000) : null;
      
    } catch (error) {
      console.error('❌ Error getting token expiration:', error);
      return null;
    }
  }

  isTokenExpiringSoon(): boolean {
    const expiration = this.getTokenExpiration();
    if (!expiration) return false;

    const fiveMinutesFromNow = new Date(Date.now() + 5 * 60 * 1000);
    return expiration <= fiveMinutesFromNow;
  }

  // ✅ ENHANCED: Session management
  getRemainingSessionTime(): number {
    if (!isPlatformBrowser(this.platformId)) return 0;

    try {
      const lastActivity = localStorage.getItem(this.STORAGE_KEYS.LAST_ACTIVITY);
      if (!lastActivity) return 0;

      const lastActivityTime = new Date(lastActivity).getTime();
      const now = Date.now();
      const timeSinceActivity = now - lastActivityTime;

      return Math.max(0, this.MAX_IDLE_TIME - timeSinceActivity);
    } catch (error) {
      console.error('❌ Error getting remaining session time:', error);
      return 0;
    }
  }

  extendSession(): void {
    this.updateLastActivity();
    console.log('✅ Session extended');
  }

  // ✅ ENHANCED: Token refresh
  refreshToken(): Observable<LoginResponse> {
    if (!isPlatformBrowser(this.platformId)) {
      return throwError(() => new Error('Not in browser environment'));
    }

    const refreshToken = localStorage.getItem(this.STORAGE_KEYS.REFRESH_TOKEN);
    
    if (!refreshToken) {
      return throwError(() => new Error('No refresh token available'));
    }

    return this.http.post<LoginResponse>(`${this.API_BASE_URL}/refresh`, {
      refreshToken: refreshToken
    }, {
      headers: this.getDefaultHeaders()
    }).pipe(
      timeout(10000),
      tap(response => {
        if (response.jwtToken) {
          this.storeTokens(response);
          console.log('✅ Token refreshed successfully');
        }
      }),
      catchError(error => {
        console.error('❌ Token refresh failed:', error);
        this.forceLogout('Token refresh failed');
        return throwError(() => error);
      })
    );
  }

  autoRefreshToken(): void {
    if (this.isTokenExpiringSoon() && this.isAuthenticated()) {
      if (!this.refreshInProgress) {
        this.log('🔄 Auto-refreshing token...');
        this.refreshInProgress = true;
        
        this.refreshToken().subscribe({
          next: () => {
            this.log('✅ Auto token refresh successful');
            this.refreshInProgress = false;
          },
          error: (error) => {
            console.error('❌ Auto token refresh failed:', error);
            this.refreshInProgress = false;
          }
        });
      }
    }
  }

  isLoggedIn(): boolean {
    return this.isAuthenticated();
  }

  isCurrentTokenValid(): boolean {
    const validation = this.validateToken();
    return validation.isValid && validation.decodedSuccessfully;
  }

  // ✅ ENHANCED: Utility methods
  canAccess(requiredRole?: string): boolean {
    if (!this.isAuthenticated()) {
      return false;
    }

    if (!requiredRole) {
      return true;
    }

    return this.hasRole(requiredRole);
  }

  getCurrentUserId(): number {
    const id = this.getRestaurantId();
    return id ? parseInt(id) : 0;
  }

  getUserContext(): {
    userId: number;
    email: string;
    roles: string[];
    restaurantId?: string;
  } {
    const userInfo = this.getUserInfo();
    return {
      userId: userInfo.userId || 0,
      email: userInfo.email || '',
      roles: userInfo.roles || [],
      restaurantId: userInfo.restaurantId || undefined
    };
  }

  getUserDisplayName(): string {
    const userInfo = this.getUserInfo();
    return userInfo.username || userInfo.restaurantName || userInfo.email || 'User';
  }

  getUserRoles(): string[] {
    const userInfo = this.getUserInfo();
    return userInfo.roles || [];
  }

  forceLogout(reason?: string): void {
    console.log('🚨 Force logout triggered:', reason);
    this.logout();
    this.authStateSubject.next(false);
    this.userInfoSubject.next(null);
  }

  getAuthStatus(): {
    isAuthenticated: boolean;
    user: UserInfo | null;
    roles: string[];
    isCustomer: boolean;
    isRestaurant: boolean;
    sessionTimeRemaining: number;
  } {
    const isAuth = this.isAuthenticated();
    const userInfo = isAuth ? this.getUserInfo() : null;
    
    return {
      isAuthenticated: isAuth,
      user: userInfo,
      roles: userInfo?.roles || [],
      isCustomer: this.isCustomer(),
      isRestaurant: this.isRestaurant(),
      sessionTimeRemaining: this.getRemainingSessionTime()
    };
  }

  private getDefaultHeaders(): HttpHeaders {
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    });
  }

  // ✅ ENHANCED: Debug methods
  debugAuthState(): void {
    console.log('🔍 Current Auth State:', this.getUserInfo());
    console.log('🔍 Auth Status:', this.getAuthStatus());
    console.log('🔍 Order Tracking Data:', this.getOrderTrackingData());
    console.log('🔍 Current Order ID:', this.getCurrentOrderId());
    
    if (isPlatformBrowser(this.platformId)) {
      console.log('🔍 Raw localStorage:', {
        ...Object.fromEntries(
          Object.entries(this.STORAGE_KEYS).map(([key, storageKey]) => [
            key,
            localStorage.getItem(storageKey) || '[NOT_SET]'
          ])
        )
      });
    }
  }

  // 🔥 NEW: Get restaurant data by email
  getRestaurantDataByEmail(email: string): { 
    name: string; 
    location: string; 
    email: string; 
    phone: string;
    address: string;
    city: string;
    state: string;
    pincode: string;
  } | null {
    console.log('🔍 Looking up restaurant data for email:', email);
    
    // First try exact email match
    const exactMatch = this.RESTAURANT_DATA[email];
    if (exactMatch) {
      console.log('✅ Found exact email match:', exactMatch.name);
      return exactMatch;
    }
    
    // Try to find by email in the values
    for (const [id, data] of Object.entries(this.RESTAURANT_DATA)) {
      if (data.email === email) {
        console.log('✅ Found restaurant by email in data:', data.name);
        return data;
      }
    }
    
    console.warn('⚠️ No restaurant data found for email:', email);
    return null;
  }

  // ✅ ENHANCED: Get restaurant data by ID (matching database structure)
  getRestaurantDataById(id: string): { 
    name: string; 
    location: string; 
    email: string; 
    phone: string;
    address: string;
    city: string;
    state: string;
    pincode: string;
  } | null {
    // Map database IDs to email keys
    const idToEmailMap: { [key: string]: string } = {
      '1': 'dp@gmail.com',
      '2': 'new@gmail.com', 
      '3': 'any@gmail.com'
    };
    
    const email = idToEmailMap[id];
    if (email && this.RESTAURANT_DATA[email]) {
      console.log(`✅ Found restaurant data for ID ${id} via email mapping:`, email);
      return this.RESTAURANT_DATA[email];
    }
    
    // Fallback: search by ID directly in case of direct mapping
    if (this.RESTAURANT_DATA[id]) {
      console.log(`✅ Found restaurant data for ID ${id} via direct mapping`);
      return this.RESTAURANT_DATA[id];
    }
    
    console.warn(`⚠️ No restaurant data found for ID: ${id}`);
    return null;
  }

  // 🔥 NEW: Clear stale restaurant data
  clearStaleRestaurantData(): void {
    console.log('🧹 Clearing stale restaurant data...');
    
    // Clear restaurant-specific data from localStorage
    if (isPlatformBrowser(this.platformId)) {
      localStorage.removeItem(this.STORAGE_KEYS.RESTAURANT_NAME);
      localStorage.removeItem(this.STORAGE_KEYS.RESTAURANT_LOCATION);
      localStorage.removeItem(this.STORAGE_KEYS.RESTAURANT_ID);
    }
    
    // Reset user info restaurant data
    const currentUserInfo = this.getUserInfo();
    if (currentUserInfo) {
      currentUserInfo.restaurantName = null;
      currentUserInfo.restaurantLocation = null;
      currentUserInfo.restaurantId = null;
      this.userInfoSubject.next(currentUserInfo);
    }
    
    console.log('✅ Stale restaurant data cleared');
  }

  // 🔥 ENHANCED: Refresh restaurant data with validation
  refreshRestaurantData(): void {
    console.log('🔄 Refreshing restaurant data...');
    
    // Clear any stale data first
    this.clearStaleRestaurantData();
    
    // Get fresh data from token
    const token = this.getToken();
    if (token) {
      try {
        const decoded = this.decodeJWT(token);
        if (decoded && decoded.restaurantId) {
          console.log('✅ Found restaurant ID in token:', decoded.restaurantId);
          
          // Get restaurant data from our predefined data
          const restaurantData = this.getRestaurantDataById(decoded.restaurantId.toString());
          if (restaurantData) {
            console.log('✅ Found restaurant data:', restaurantData);
            
            // Store restaurant ID separately
            if (isPlatformBrowser(this.platformId)) {
              localStorage.setItem(this.STORAGE_KEYS.RESTAURANT_ID, decoded.restaurantId.toString());
            }
            
            // Store fresh restaurant data
            this.storeRestaurantInfo({
              name: restaurantData.name,
              location: restaurantData.location,
              email: restaurantData.email,
              phone: restaurantData.phone,
              address: restaurantData.address,
              city: restaurantData.city,
              state: restaurantData.state,
              pincode: restaurantData.pincode
            });
          } else {
            console.warn('⚠️ No predefined data found for restaurant ID:', decoded.restaurantId);
          }
        }
      } catch (error) {
        console.error('❌ Error refreshing restaurant data:', error);
      }
    }
  }

  isValidRestaurant(email: string): boolean {
    return Object.values(this.RESTAURANT_DATA).some(restaurant => restaurant.email === email);
  }

  ngOnDestroy(): void {
    console.log('🧹 AuthService destroying...');
    this.stopSessionMonitoring();
    
    this.authStateSubject.complete();
    this.userInfoSubject.complete();
    this.sessionTimerSubject.complete();
  }
}


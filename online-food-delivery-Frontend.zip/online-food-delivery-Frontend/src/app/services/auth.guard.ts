

// src/app/services/auth.guard.ts
import { Injectable, inject } from '@angular/core';
import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  private authService = inject(AuthService);
  private router = inject(Router);

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    console.log('🔍 AuthGuard: Checking authentication for route:', state.url);

    try {
      // Debug current auth state to help trace issues
      this.authService.debugAuthState();

      // Check if user has a valid logged-in session
      const hasValidToken = this.authService.isLoggedIn() || !!this.authService.getToken();
      if (!hasValidToken) {
        console.log('🚫 AuthGuard: No valid token - redirecting to appropriate login');
        this.redirectToLogin(state.url);
        return false;
      }

      // Get roles from userInfo, fallback to decoding token
      let userRoles = this.authService.getUserInfo()?.roles || [];

      if (userRoles.length === 0) {
        // Try decoding token roles if userInfo roles missing
        const token = this.authService.getToken();
        if (token) {
          try {
            const payload = token.split('.')[1];
            const decodedPayload = JSON.parse(atob(payload));
            userRoles = decodedPayload.roles || [];
          } catch (decodeError) {
            console.error('❌ Error decoding token roles:', decodeError);
          }
        }
      }

      // Normalize role names to uppercase for consistent matching
      userRoles = userRoles.map(role => role.toUpperCase());

      const isCustomer = userRoles.includes('CUSTOMER');
      const isRestaurant = userRoles.includes('RESTAURANT');

      console.log('🔍 AuthGuard user roles:', { userRoles, isCustomer, isRestaurant });

      // Route-based authorization logic

      // Customer routes
      if (this.isCustomerRoute(state.url)) {
        if (isCustomer) {
          console.log('✅ AuthGuard: Customer access granted for:', state.url);
          return true;
        } else {
          console.log('🚫 AuthGuard: Customer route access denied - redirecting to customer login');
          this.router.navigate(['/customer-login']);
          return false;
        }
      }

      // Restaurant routes
      if (this.isRestaurantRoute(state.url)) {
        if (isRestaurant) {
          console.log('✅ AuthGuard: Restaurant access granted for:', state.url);
          return true;
        } else {
          console.log('🚫 AuthGuard: Restaurant route access denied - redirecting to restaurant login');
          this.router.navigate(['/restaurant-login']);
          return false;
        }
      }

      // Default: allow access if user is authenticated for all other routes
      console.log('✅ AuthGuard: General access granted for:', state.url);
      return true;

    } catch (error) {
      console.error('❌ AuthGuard error:', error);
      this.redirectToLogin(state.url);
      return false;
    }
  }

  private hasToken(): boolean {
    return !!this.authService.getToken();
  }

  private isCustomerRoute(url: string): boolean {
    const customerRoutes = [
      '/customer-main',
      '/restaurant/',   // Restaurant detail/menu viewing by customers
      '/cart'
    ];

    return customerRoutes.some(route => url.startsWith(route));
  }

  private isRestaurantRoute(url: string): boolean {
    const restaurantRoutes = [
      '/restaurant-dashboard',
      '/add-menu'
    ];

    return restaurantRoutes.some(route => url.startsWith(route));
  }

  private redirectToLogin(url: string): void {
    if (this.isRestaurantRoute(url)) {
      console.log('🔄 Redirecting to restaurant login for route:', url);
      this.router.navigate(['/restaurant-login']);
    } else {
      console.log('🔄 Redirecting to customer login for route:', url);
      this.router.navigate(['/customer-login']);
    }
  }
}

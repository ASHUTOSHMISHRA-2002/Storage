

import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    console.log('🚀 INTERCEPTOR CALLED for URL:', req.url);
    
    // ✅ ENHANCED: Skip auth headers for specific endpoints
    const isAuthEndpoint = req.url.includes('/login') || 
                          req.url.includes('/register') || 
                          req.url.includes('/api/auth/') ||
                          req.url.includes('/health'); // ✅ ADDED: Skip health check
    
    if (isAuthEndpoint) {
      console.log('🔓 AUTH ENDPOINT - Skipping token for:', req.url);
      // ✅ STILL ADD CONTENT-TYPE for consistency
      const modifiedReq = req.clone({
        setHeaders: {
          'Content-Type': 'application/json'
        }
      });
      return next.handle(modifiedReq);
    }
    
    // Get token from localStorage
    const jwtToken = localStorage.getItem('jwtToken');
    const authToken = localStorage.getItem('authToken');
    const token = jwtToken || authToken;
    
    console.log('🔍 Token check:', {
      hasJwtToken: !!jwtToken,
      hasAuthToken: !!authToken,
      finalToken: !!token,
      url: req.url
    });
    
    if (token) {
      console.log('🔑 TOKEN FOUND - Adding Authorization header to:', req.url);
      
      const authReq = req.clone({
        setHeaders: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      
      return next.handle(authReq);
    }
    
    console.log('🔓 NO TOKEN - Sending request without auth header:', req.url);
    
    // ✅ STILL ADD CONTENT-TYPE even without token
    const modifiedReq = req.clone({
      setHeaders: {
        'Content-Type': 'application/json'
      }
    });
    
    return next.handle(modifiedReq);
  }
}

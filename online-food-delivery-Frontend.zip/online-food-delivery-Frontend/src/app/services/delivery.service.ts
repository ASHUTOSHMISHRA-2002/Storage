

import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';
import { AuthService } from './auth.service';

interface Delivery {
  deliveryId: number;
  orderId: number;
  agentId: number;
  agentName: string;
  agentPhone: string;
  status: string; // 'assigned', 'picked_up', 'in_transit', 'delivered', 'failed'
  estimatedDeliveryTime: string;
  actualDeliveryTime?: string;
  createdAt?: string;
  updatedAt?: string;
}

// Add delivery status enum for better management
export enum DeliveryStatus {
  ASSIGNED = 'assigned',
  PICKED_UP = 'picked_up', 
  IN_TRANSIT = 'in_transit',
  OUT_FOR_DELIVERY = 'out_for_delivery',
  DELIVERED = 'delivered',
  FAILED = 'failed',
  CANCELLED = 'cancelled'
}

@Injectable({
  providedIn: 'root'
})
export class DeliveryService {
  private readonly DELIVERY_API = 'http://localhost:8081/api/delivery';
  
  // Add BehaviorSubject for real-time delivery tracking
  private deliveriesSubject = new BehaviorSubject<Delivery[]>([]);
  public deliveries$ = this.deliveriesSubject.asObservable();
  
  private currentDeliverySubject = new BehaviorSubject<Delivery | null>(null);
  public currentDelivery$ = this.currentDeliverySubject.asObservable();

  constructor(private http: HttpClient, private auth: AuthService) {}

  private getHeaders(): HttpHeaders {
    const token = this.auth.getToken();
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token || ''}`
    });
  }

  // Assign agent to order
  assignAgent(orderId: number): Observable<Delivery> {
    return this.http.post<Delivery>(`${this.DELIVERY_API}/assign`, 
      { orderId }, 
      { headers: this.getHeaders() }
    ).pipe(
      tap(delivery => {
        console.log('✅ Agent assigned to delivery:', delivery);
        this.currentDeliverySubject.next(delivery);
      }),
      catchError(this.handleError.bind(this))
    );
  }

  // ✅ FIXED: Enhanced status update with order service integration
  updateStatus(deliveryId: number, status: string): Observable<Delivery> {
    return this.http.patch<Delivery>(`${this.DELIVERY_API}/${deliveryId}/status`,
      { 
        status,
        timestamp: new Date().toISOString()
      },
      { headers: this.getHeaders() }
    ).pipe(
      tap(delivery => {
        console.log('✅ Delivery status updated:', delivery);
        this.currentDeliverySubject.next(delivery);
        
        // ✅ KEY FIX: Update order status when delivery status changes
        this.updateOrderStatusBasedOnDelivery(delivery);
        
        // Update deliveries list
        this.updateDeliveryInList(delivery);
      }),
      catchError(this.handleError.bind(this))
    );
  }

  completeDelivery(deliveryId: number, orderId: number): Observable<Delivery> {
    const completionData = {
      status: DeliveryStatus.DELIVERED,
      actualDeliveryTime: new Date().toISOString(),
      timestamp: new Date().toISOString()
    };
  
    return this.http.patch<Delivery>(`${this.DELIVERY_API}/${deliveryId}/complete`,
      completionData,
      { headers: this.getHeaders() }
    ).pipe(
      tap(delivery => {
        console.log('✅ Delivery completed successfully:', delivery);
        
        // ✅ CRITICAL: Update order status to COMPLETED
        this.updateOrderStatus(orderId, 'COMPLETED');
      }),
      catchError(this.handleError.bind(this))
    );
  }
  private updateOrderStatus(orderId: number, status: string): void {
    // Call order service to update status
    this.http.put(`http://localhost:9097/api/orders/${orderId}/status`, {
      status: status,
      deliveryCompletedAt: new Date().toISOString()
    }, { headers: this.getHeaders() }).subscribe({
      next: (response) => {
        console.log('✅ Order status updated to COMPLETED:', response);
      },
      error: (error) => {
        console.error('❌ Error updating order status:', error);
      }
    });
  }

  // ✅ NEW: Mark as picked up
  markAsPickedUp(deliveryId: number): Observable<Delivery> {
    return this.updateStatus(deliveryId, DeliveryStatus.PICKED_UP);
  }

  // ✅ NEW: Mark as in transit
  markAsInTransit(deliveryId: number): Observable<Delivery> {
    return this.updateStatus(deliveryId, DeliveryStatus.IN_TRANSIT);
  }

  // ✅ NEW: Mark as out for delivery
  markAsOutForDelivery(deliveryId: number): Observable<Delivery> {
    return this.updateStatus(deliveryId, DeliveryStatus.OUT_FOR_DELIVERY);
  }

  // Get delivery by order ID
  getDeliveryByOrderId(orderId: number): Observable<Delivery> {
    return this.http.get<Delivery>(`${this.DELIVERY_API}/order/${orderId}`,
      { headers: this.getHeaders() }
    ).pipe(
      tap(delivery => {
        this.currentDeliverySubject.next(delivery);
      }),
      catchError(this.handleError.bind(this))
    );
  }

  // Get all deliveries
  getAllDeliveries(): Observable<Delivery[]> {
    return this.http.get<Delivery[]>(`${this.DELIVERY_API}/all`,
      { headers: this.getHeaders() }
    ).pipe(
      tap(deliveries => {
        this.deliveriesSubject.next(deliveries);
      }),
      catchError(this.handleError.bind(this))
    );
  }

  // ✅ NEW: Get deliveries for specific agent
  getDeliveriesForAgent(agentId: number): Observable<Delivery[]> {
    return this.http.get<Delivery[]>(`${this.DELIVERY_API}/agent/${agentId}`,
      { headers: this.getHeaders() }
    ).pipe(
      tap(deliveries => {
        this.deliveriesSubject.next(deliveries);
      }),
      catchError(this.handleError.bind(this))
    );
  }

  // ✅ CRITICAL FIX: Update order status based on delivery status
  private updateOrderStatusBasedOnDelivery(delivery: Delivery): void {
    // Import OrderService dynamically to avoid circular dependency
    import('./order.service').then(({ OrderService }) => {
      // Get OrderService instance (you might need to inject this properly)
      const orderService = new OrderService(this.http, this.auth);
      
      let orderStatus: string;
      
      switch (delivery.status) {
        case DeliveryStatus.ASSIGNED:
          orderStatus = 'READY_FOR_PICKUP';
          break;
        case DeliveryStatus.PICKED_UP:
          orderStatus = 'OUT_FOR_DELIVERY';
          break;
        case DeliveryStatus.IN_TRANSIT:
        case DeliveryStatus.OUT_FOR_DELIVERY:
          orderStatus = 'OUT_FOR_DELIVERY';
          break;
        case DeliveryStatus.DELIVERED:
          orderStatus = 'COMPLETED'; // ✅ THIS IS THE KEY FIX
          break;
        case DeliveryStatus.FAILED:
          orderStatus = 'DELIVERY_FAILED';
          break;
        default:
          return; // No order status update needed
      }

      // Update order status
      orderService.updateOrderStatus(delivery.orderId, orderStatus).subscribe({
        next: (updatedOrder) => {
          console.log('✅ Order status updated based on delivery:', updatedOrder);
        },
        error: (error) => {
          console.error('❌ Error updating order status:', error);
        }
      });
    });
  }

  // ✅ NEW: Finalize order delivery
  private finalizeOrderDelivery(orderId: number, delivery: Delivery): void {
    // Send completion notification to order service
    this.http.post(`http://localhost:9097/api/orders/${orderId}/delivery-completed`, {
      deliveryId: delivery.deliveryId,
      completedAt: new Date().toISOString(),
      agentId: delivery.agentId,
      agentName: delivery.agentName
    }, { headers: this.getHeaders() }).subscribe({
      next: (response) => {
        console.log('✅ Order delivery finalized:', response);
      },
      error: (error) => {
        console.error('❌ Error finalizing order delivery:', error);
      }
    });
  }

  // ✅ NEW: Update delivery in list
  private updateDeliveryInList(updatedDelivery: Delivery): void {
    const currentDeliveries = this.deliveriesSubject.value;
    const updatedDeliveries = currentDeliveries.map(delivery => 
      delivery.deliveryId === updatedDelivery.deliveryId ? updatedDelivery : delivery
    );
    this.deliveriesSubject.next(updatedDeliveries);
  }

  // ✅ NEW: Error handling
  private handleError(error: any): Observable<never> {
    console.error('❌ DeliveryService Error:', error);
    throw error;
  }

  // ✅ NEW: Utility methods
  getDeliveryStatusDisplay(status: string): string {
    const statusMap: { [key: string]: string } = {
      'assigned': 'Agent Assigned',
      'picked_up': 'Order Picked Up',
      'in_transit': 'In Transit',
      'out_for_delivery': 'Out for Delivery',
      'delivered': 'Delivered',
      'failed': 'Delivery Failed',
      'cancelled': 'Delivery Cancelled'
    };
    return statusMap[status] || status;
  }

  isDeliveryCompleted(status: string): boolean {
    return status === DeliveryStatus.DELIVERED;
  }

  canUpdateDeliveryStatus(status: string): boolean {
    return ![DeliveryStatus.DELIVERED, DeliveryStatus.FAILED, DeliveryStatus.CANCELLED].includes(status as DeliveryStatus);
  }
}

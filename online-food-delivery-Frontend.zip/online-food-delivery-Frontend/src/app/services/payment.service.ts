

// src/app/services/payment.service.ts
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError, BehaviorSubject, of } from 'rxjs';
import { catchError, tap, retry, timeout, finalize, switchMap, map } from 'rxjs/operators';
import { AuthService } from './auth.service';

// ✅ FIXED: CustomerDetails interface matching backend exactly
export interface CustomerDetails {
  name: string;
  phone: string;
  email: string;
  address: string;
  city?: string;
  state?: string;
  pincode?: string;
  // ✅ REMOVED: Backend doesn't have these fields
  // firstName?: string;
  // lastName?: string;
  // alternatePhone?: string;
  // landmark?: string;
  // addressType?: 'HOME' | 'WORK' | 'OTHER';
  // isDefault?: boolean;
}

// ✅ FIXED: PaymentRequestDTO matching backend exactly
export interface PaymentRequestDTO {
  orderId: number;
  paymentMethod: string; // ✅ FIXED: Backend expects PaymentMethod enum but we send as string
  paymentAmount: number;
  createdBy: string;
  customerDetails?: CustomerDetails;
  notes?: string;
  currency?: string;
  paymentDetails?: any; // ✅ FIXED: Backend expects JsonNode, we send as any
  returnUrl?: string;
  cancelUrl?: string;
  description?: string;
  merchantTransactionId?: string;
  callbackUrl?: string;
}

// ✅ FIXED: PaymentResponseDTO matching backend exactly
export interface PaymentResponseDTO {
  paymentId: number;
  orderId: number;
  paymentMethod: string; // ✅ Backend sends PaymentMethod enum as string
  paymentAmount: number;
  paymentStatus: string;
  transactionId?: string; // ✅ FIXED: Now properly typed
  createdBy?: string;
  createdOn?: string; // ✅ Backend sends LocalDateTime as string
  updatedOn?: string;
  customerDetails?: CustomerDetails;
  currency?: string;
  notes?: string;
  paymentGatewayResponse?: string;
}

// ✅ FIXED: PaymentConfirmationDTO matching backend PaymentConfirmDTO
export interface PaymentConfirmationDTO {
  orderId: number;
  transactionId: string;
  status: string;
  updatedBy: string;
  confirmationDetails?: string;
  paymentMethod?: string;
  gatewayResponse?: string;
  notes?: string;
}

// ✅ ADD: Payment validation result
interface PaymentValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
}

// ✅ ADD: Payment service state
interface PaymentServiceState {
  isOnline: boolean;
  lastRequestTime: Date | null;
  requestInProgress: boolean;
  retryAttempts: number;
}

@Injectable({
  providedIn: 'root'
})
export class PaymentService {
  // ✅ FIXED: Correct API endpoint - use direct payment service
  private readonly PAYMENT_API = 'http://localhost:8085/api/payments';
  private readonly MAX_RETRY_ATTEMPTS = 3;
  private readonly DEFAULT_TIMEOUT = 30000; // 30 seconds for payments
  
  // ✅ ENHANCED: Service state management  
  private serviceState: PaymentServiceState = {
    isOnline: true,
    lastRequestTime: null,
    requestInProgress: false,
    retryAttempts: 0
  };

  private stateSubject = new BehaviorSubject<PaymentServiceState>(this.serviceState);
  public state$ = this.stateSubject.asObservable();

  // ✅ ENHANCED: Loading states for different operations
  private loadingStates = {
    initiating: false,
    confirming: false,
    checking: false,
    cancelling: false,
    refunding: false
  };

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) {
    console.log('🔧 PaymentService initialized with endpoint:', this.PAYMENT_API);
    this.initializeService();
  }

  // ✅ ADD: Initialize service with network monitoring
  private initializeService(): void {
    // Monitor network status
    if (typeof window !== 'undefined' && 'navigator' in window) {
      window.addEventListener('online', () => {
        console.log('📶 Network online, payment service available');
        this.updateServiceState({ isOnline: true });
      });

      window.addEventListener('offline', () => {
        console.log('📵 Network offline, payment service unavailable');
        this.updateServiceState({ isOnline: false });
      });
    }
  }

  // ✅ ADD: Update service state
  private updateServiceState(updates: Partial<PaymentServiceState>): void {
    this.serviceState = { ...this.serviceState, ...updates };
    this.stateSubject.next(this.serviceState);
  }

  // ✅ ENHANCED: Get headers with comprehensive authentication
  private getHeaders(): HttpHeaders {
    try {
      const token = this.authService.getToken();
      const userInfo = this.authService.getUserInfo();
      
      const headers = new HttpHeaders({
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Cache-Control': 'no-cache',
        'X-Requested-With': 'XMLHttpRequest',
        'Authorization': `Bearer ${token || ''}`,
        'X-Internal-User-Id': userInfo?.userId?.toString() || userInfo?.restaurantId || '1',
        'X-Internal-User-Roles': userInfo?.roles?.[0] || 'CUSTOMER'
      });

      console.log('📤 Payment headers created:', {
        hasAuth: !!token,
        userId: userInfo?.userId || userInfo?.restaurantId,
        roles: userInfo?.roles
      });

      return headers;
    } catch (error) {
      console.error('❌ Error creating payment headers:', error);
      return new HttpHeaders({
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      });
    }
  }

  // ✅ ENHANCED: Initiate payment with backend-compatible data transformation
  initiatePayment(paymentRequest: PaymentRequestDTO): Observable<PaymentResponseDTO> {
    console.log('🚀 Initiating payment with comprehensive details:', paymentRequest);
    
    if (this.loadingStates.initiating) {
      console.warn('⚠️ Payment initiation already in progress');
      return throwError(() => new Error('Payment initiation already in progress'));
    }

    this.loadingStates.initiating = true;
    this.updateServiceState({ requestInProgress: true, lastRequestTime: new Date() });

    // Comprehensive validation
    const validation = this.validatePaymentRequest(paymentRequest);
    if (!validation.isValid) {
      console.error('❌ Payment request validation failed:', validation.errors);
      this.loadingStates.initiating = false;
      this.updateServiceState({ requestInProgress: false });
      return throwError(() => new Error(`Payment validation failed: ${validation.errors.join(', ')}`));
    }

    // Log warnings if any
    if (validation.warnings.length > 0) {
      console.warn('⚠️ Payment validation warnings:', validation.warnings);
    }

    // ✅ FIXED: Transform frontend request to match backend exactly
    const backendRequest = this.transformToBackendRequest(paymentRequest);

    console.log('📤 Sending backend-compatible payment request:', backendRequest);
    console.log('🔗 Payment API endpoint:', `${this.PAYMENT_API}/initiate`);

    return this.http.post<PaymentResponseDTO>(
      `${this.PAYMENT_API}/initiate`,
      backendRequest,
      { 
        headers: this.getHeaders(),
        reportProgress: true
      }
    ).pipe(
      timeout(this.DEFAULT_TIMEOUT),
      retry({
        count: this.MAX_RETRY_ATTEMPTS,
        delay: (error, retryCount) => {
          console.log(`🔄 Retrying payment initiation (attempt ${retryCount}/${this.MAX_RETRY_ATTEMPTS}):`, error.message);
          this.serviceState.retryAttempts = retryCount;
          return of(null).pipe(
            tap(() => {
              // Exponential backoff: 1s, 2s, 4s
              const delay = Math.pow(2, retryCount - 1) * 1000;
              setTimeout(() => {}, delay);
            })
          );
        }
      }),
      tap(response => {
        console.log('✅ Payment initiated successfully:', response);
        this.updateServiceState({ 
          isOnline: true, 
          retryAttempts: 0,
          lastRequestTime: new Date()
        });
      }),
      catchError(this.handleError.bind(this)),
      finalize(() => {
        this.loadingStates.initiating = false;
        this.updateServiceState({ requestInProgress: false });
      })
    );
  }

  // ✅ NEW: Transform frontend request to backend-compatible format
  private transformToBackendRequest(frontendRequest: PaymentRequestDTO): any {
    // ✅ FIXED: Clean customerDetails to match backend interface
    const cleanCustomerDetails = frontendRequest.customerDetails ? {
      name: frontendRequest.customerDetails.name,
      phone: frontendRequest.customerDetails.phone,
      email: frontendRequest.customerDetails.email,
      address: frontendRequest.customerDetails.address,
      city: frontendRequest.customerDetails.city || '',
      state: frontendRequest.customerDetails.state || '',
      pincode: frontendRequest.customerDetails.pincode || ''
      // ✅ REMOVED: Fields not in backend DTO
    } : null;

    // ✅ FIXED: Map frontend payment method string to backend enum format
    const backendPaymentMethod = this.mapPaymentMethodToBackend(frontendRequest.paymentMethod);

    return {
      orderId: frontendRequest.orderId,
      paymentMethod: backendPaymentMethod, // ✅ Now sends enum-compatible string
      paymentAmount: frontendRequest.paymentAmount,
      createdBy: frontendRequest.createdBy,
      customerDetails: cleanCustomerDetails,
      notes: frontendRequest.notes || `Payment for order #${frontendRequest.orderId}`,
      currency: frontendRequest.currency || 'INR',
      paymentDetails: frontendRequest.paymentDetails || {}, // ✅ Backend expects JsonNode
      returnUrl: frontendRequest.returnUrl,
      cancelUrl: frontendRequest.cancelUrl,
      description: frontendRequest.description,
      merchantTransactionId: frontendRequest.merchantTransactionId,
      callbackUrl: frontendRequest.callbackUrl
    };
  }

  // ✅ NEW: Map frontend payment method to backend enum
  private mapPaymentMethodToBackend(frontendMethod: string): string {
    const methodMapping: { [key: string]: string } = {
      'CARD': 'CREDIT_CARD', // ✅ Map to backend enum value
      'UPI': 'UPI',
      'NET_BANKING': 'NET_BANKING', 
      'WALLET': 'WALLET',
      'COD': 'CASH_ON_DELIVERY', // ✅ Map to backend enum value
      'CREDIT_CARD': 'CREDIT_CARD',
      'DEBIT_CARD': 'DEBIT_CARD',
      'CASH_ON_DELIVERY': 'CASH_ON_DELIVERY'
    };

    const backendMethod = methodMapping[frontendMethod.toUpperCase()];
    if (!backendMethod) {
      console.warn(`⚠️ Unknown payment method: ${frontendMethod}, using as-is`);
      return frontendMethod.toUpperCase();
    }

    console.log(`🔄 Mapped payment method: ${frontendMethod} -> ${backendMethod}`);
    return backendMethod;
  }

  // ✅ ENHANCED: Confirm payment with backend-compatible format
  confirmPayment(paymentRequest: PaymentRequestDTO): Observable<PaymentConfirmationDTO> {
    console.log('🔄 Confirming payment with enhanced details:', paymentRequest);

    if (this.loadingStates.confirming) {
      return throwError(() => new Error('Payment confirmation already in progress'));
    }

    this.loadingStates.confirming = true;

    // ✅ FIXED: Create PaymentConfirmDTO compatible request
    const confirmationData = {
      orderId: paymentRequest.orderId,
      transactionId: paymentRequest.merchantTransactionId || `TXN_${Date.now()}_${paymentRequest.orderId}`,
      status: 'COMPLETED', // ✅ Assuming success confirmation
      updatedBy: paymentRequest.createdBy,
      confirmationDetails: JSON.stringify(paymentRequest.paymentDetails || {}),
      paymentMethod: this.mapPaymentMethodToBackend(paymentRequest.paymentMethod),
      notes: paymentRequest.notes || `Payment confirmation for order #${paymentRequest.orderId}`
    };

    console.log('📤 Sending payment confirmation request:', confirmationData);

    return this.http.put<PaymentConfirmationDTO>(
      `${this.PAYMENT_API}/confirm`,
      confirmationData,
      { headers: this.getHeaders() }
    ).pipe(
      timeout(this.DEFAULT_TIMEOUT),
      retry(2),
      tap(response => {
        console.log('✅ Payment confirmed successfully:', response);
      }),
      catchError(this.handleError.bind(this)),
      finalize(() => {
        this.loadingStates.confirming = false;
      })
    );
  }

  // ✅ ENHANCED: Comprehensive payment request validation
  private validatePaymentRequest(request: PaymentRequestDTO): PaymentValidationResult {
    const errors: string[] = [];
    const warnings: string[] = [];

    // Validate required fields
    if (!request.orderId || request.orderId <= 0) {
      errors.push('Valid order ID is required');
    }

    if (!request.paymentMethod || request.paymentMethod.trim() === '') {
      errors.push('Payment method is required');
    } else if (!this.isValidPaymentMethod(request.paymentMethod)) {
      errors.push(`Invalid payment method: ${request.paymentMethod}`);
    }

    if (!request.paymentAmount || request.paymentAmount <= 0) {
      errors.push('Valid payment amount is required');
    } else if (request.paymentAmount > 500000) {
      errors.push('Payment amount exceeds maximum limit of ₹5,00,000');
    } else if (request.paymentAmount < 1) {
      errors.push('Payment amount must be at least ₹1');
    }

    if (!request.createdBy || request.createdBy.trim() === '') {
      errors.push('Creator information is required');
    }

    // Validate payment method availability for amount
    if (request.paymentMethod && request.paymentAmount) {
      if (!this.isPaymentMethodAvailable(request.paymentMethod, request.paymentAmount)) {
        errors.push(`${request.paymentMethod} is not available for amount ₹${request.paymentAmount}`);
      }
    }

    // Validate customer details if provided
    if (request.customerDetails) {
      const customerErrors = this.validateCustomerDetails(request.customerDetails);
      errors.push(...customerErrors);
    } else {
      warnings.push('Customer details not provided - may be required for some payment methods');
    }

    // Validate currency
    if (request.currency && !['INR', 'USD', 'EUR'].includes(request.currency)) {
      warnings.push(`Unusual currency: ${request.currency}`);
    }

    return {
      isValid: errors.length === 0,
      errors,
      warnings
    };
  }

  // ✅ FIXED: Validate customer details matching backend validation
  private validateCustomerDetails(customerDetails: CustomerDetails): string[] {
    const errors: string[] = [];

    // ✅ Match backend @NotBlank and @Size validations
    if (!customerDetails.name || customerDetails.name.trim().length < 2 || customerDetails.name.trim().length > 100) {
      errors.push('Customer name must be between 2 and 100 characters');
    }

    // ✅ Match backend @Pattern validation for Indian mobile
    if (!customerDetails.phone) {
      errors.push('Customer phone is required');
    } else {
      const cleanPhone = customerDetails.phone.replace(/\D/g, '');
      if (!/^[6-9]\d{9}$/.test(cleanPhone)) {
        errors.push('Phone number must be a valid 10-digit Indian mobile number');
      }
    }

    // ✅ Match backend @Email validation
    if (!customerDetails.email) {
      errors.push('Customer email is required');
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(customerDetails.email)) {
      errors.push('Email address must be valid');
    }

    // ✅ Match backend @Size validation for address
    if (!customerDetails.address || customerDetails.address.trim().length < 10 || customerDetails.address.trim().length > 500) {
      errors.push('Address must be between 10 and 500 characters');
    }

    // ✅ Optional field validations matching backend
    if (customerDetails.city && customerDetails.city.length > 100) {
      errors.push('City name cannot exceed 100 characters');
    }

    if (customerDetails.state && customerDetails.state.length > 100) {
      errors.push('State name cannot exceed 100 characters');
    }

    if (customerDetails.pincode && !/^\d{6}$/.test(customerDetails.pincode)) {
      errors.push('Pincode must be a valid 6-digit number');
    }

    return errors;
  }

  // ✅ ENHANCED: Check valid payment methods matching backend enum
  private isValidPaymentMethod(method: string): boolean {
    const validMethods = [
      'CARD', 'CREDIT_CARD', 'DEBIT_CARD', 
      'UPI', 'NET_BANKING', 'WALLET', 
      'COD', 'CASH_ON_DELIVERY'
    ];
    return validMethods.includes(method.toUpperCase());
  }

  // ✅ ADD: Validate URL format
  private isValidUrl(url: string): boolean {
    try {
      new URL(url);
      return true;
    } catch {
      return false;
    }
  }

  // ✅ ENHANCED: Get payment status with better error handling
  getPaymentStatus(paymentId: number): Observable<PaymentResponseDTO> {
    console.log('🔍 Getting payment status for ID:', paymentId);
    
    if (this.loadingStates.checking) {
      return throwError(() => new Error('Payment status check already in progress'));
    }

    this.loadingStates.checking = true;
    
    return this.http.get<PaymentResponseDTO>(
      `${this.PAYMENT_API}/${paymentId}/status`,
      { headers: this.getHeaders() }
    ).pipe(
      timeout(10000),
      retry(2),
      tap(response => {
        console.log('✅ Payment status retrieved:', response);
      }),
      catchError(this.handleError.bind(this)),
      finalize(() => {
        this.loadingStates.checking = false;
      })
    );
  }

  // ✅ ENHANCED: Get payment by order ID with validation
  getPaymentByOrderId(orderId: number): Observable<PaymentResponseDTO> {
    console.log('🔍 Getting payment for order ID:', orderId);
    
    if (!orderId || orderId <= 0) {
      return throwError(() => new Error('Valid order ID is required'));
    }

    this.loadingStates.checking = true;
    
    return this.http.get<PaymentResponseDTO>(
      `${this.PAYMENT_API}/order/${orderId}`,
      { headers: this.getHeaders() }
    ).pipe(
      timeout(10000),
      retry(2),
      tap(response => {
        console.log('✅ Payment retrieved for order:', response);
      }),
      catchError(this.handleError.bind(this)),
      finalize(() => {
        this.loadingStates.checking = false;
      })
    );
  }

  // ✅ ENHANCED: Cancel payment with backend-compatible format
  cancelPayment(paymentId: number, reason?: string): Observable<any> {
    console.log('🗑️ Cancelling payment:', paymentId, 'Reason:', reason);
    
    if (!paymentId || paymentId <= 0) {
      return throwError(() => new Error('Valid payment ID is required'));
    }

    if (this.loadingStates.cancelling) {
      return throwError(() => new Error('Payment cancellation already in progress'));
    }

    this.loadingStates.cancelling = true;
    
    const cancelData = {
      paymentId: paymentId,
      reason: reason || 'Cancelled by user',
      cancelledBy: this.authService.getUserDisplayName?.() || 'Customer',
      cancelledAt: new Date().toISOString(),
      requestSource: 'WEB_APP'
    };

    return this.http.post<any>(
      `${this.PAYMENT_API}/${paymentId}/cancel`,
      cancelData,
      { headers: this.getHeaders() }
    ).pipe(
      timeout(15000),
      retry(1),
      tap(response => {
        console.log('✅ Payment cancelled successfully:', response);
      }),
      catchError(this.handleError.bind(this)),
      finalize(() => {
        this.loadingStates.cancelling = false;
      })
    );
  }

  // ✅ ENHANCED: Comprehensive error handling
  private handleError(error: HttpErrorResponse): Observable<never> {
    let errorMessage = 'Payment service error occurred';
    let errorCode = 'PAYMENT_ERROR';
    
    console.error('🚨 Payment Service Error Details:', {
      status: error.status,
      statusText: error.statusText,
      url: error.url,
      error: error.error,
      message: error.message,
      timestamp: new Date().toISOString()
    });
    
    // Update service state
    this.updateServiceState({ 
      isOnline: error.status !== 0,
      lastRequestTime: new Date()
    });
    
    if (error.error instanceof ErrorEvent) {
      // Client-side error
      errorMessage = `Network Error: ${error.error.message}`;
      errorCode = 'NETWORK_ERROR';
    } else {
      // Server-side error
      switch (error.status) {
        case 0:
          errorMessage = 'Cannot connect to payment service. Please check your internet connection.';
          errorCode = 'CONNECTION_ERROR';
          this.updateServiceState({ isOnline: false });
          break;
        case 400:
          errorMessage = 'Invalid payment request. Please check your details.';
          errorCode = 'INVALID_REQUEST';
          if (error.error?.message) {
            errorMessage += ` Details: ${error.error.message}`;
          }
          break;
        case 401:
          errorMessage = 'Authentication required. Please login again.';
          errorCode = 'AUTH_ERROR';
          break;
        case 409:
          errorMessage = 'Payment already processed for this order.';
          errorCode = 'DUPLICATE_PAYMENT';
          break;
        case 422:
          errorMessage = 'Payment validation failed. Please check your details.';
          errorCode = 'VALIDATION_ERROR';
          if (error.error?.validationErrors) {
            errorMessage += ` Errors: ${error.error.validationErrors.join(', ')}`;
          }
          break;
        case 500:
          errorMessage = 'Payment server error. Please try again later.';
          errorCode = 'SERVER_ERROR';
          break;
        default:
          errorMessage = `Payment Error ${error.status}: ${error.message}`;
          if (error.error?.message) {
            errorMessage += ` - ${error.error.message}`;
          }
          errorCode = `HTTP_${error.status}`;
      }
    }
    
    console.error('🚨 Final payment error:', {
      message: errorMessage,
      code: errorCode,
      originalError: error
    });
    
    // Create enhanced error object
    const enhancedError = new Error(errorMessage);
    (enhancedError as any).code = errorCode;
    (enhancedError as any).status = error.status;
    (enhancedError as any).originalError = error;
    
    return throwError(() => enhancedError);
  }

  // ✅ ENHANCED: Utility methods
  formatPaymentAmount(amount: number): string {
    try {
      return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        maximumFractionDigits: 0,
        minimumFractionDigits: 0
      }).format(amount);
    } catch (error) {
      return `₹${amount.toFixed(0)}`;
    }
  }

  formatPaymentMethod(method: string): string {
    const methodNames: { [key: string]: string } = {
      'CARD': 'Credit/Debit Card',
      'CREDIT_CARD': 'Credit Card',
      'DEBIT_CARD': 'Debit Card', 
      'UPI': 'UPI Payment',
      'NET_BANKING': 'Net Banking',
      'WALLET': 'Digital Wallet',
      'COD': 'Cash on Delivery',
      'CASH_ON_DELIVERY': 'Cash on Delivery'
    };
    
    return methodNames[method.toUpperCase()] || method.replace(/_/g, ' ');
  }

  formatPaymentStatus(status: string): string {
    const statusNames: { [key: string]: string } = {
      'PENDING': '⏳ Payment Pending',
      'PROCESSING': '🔄 Processing Payment',
      'COMPLETED': '✅ Payment Successful',
      'SUCCESS': '✅ Payment Successful',
      'FAILED': '❌ Payment Failed',
      'CANCELLED': '🚫 Payment Cancelled',
      'REFUNDED': '💰 Payment Refunded'
    };
    
    return statusNames[status.toUpperCase()] || status.replace(/_/g, ' ');
  }

  // ✅ ENHANCED: Check if payment method is available for amount
  isPaymentMethodAvailable(method: string, amount: number): boolean {
    const methodLimits: { [key: string]: { min: number; max: number; enabled: boolean } } = {
      'UPI': { min: 1, max: 100000, enabled: true },
      'CARD': { min: 1, max: 500000, enabled: true },
      'CREDIT_CARD': { min: 1, max: 500000, enabled: true },
      'DEBIT_CARD': { min: 1, max: 500000, enabled: true },
      'NET_BANKING': { min: 10, max: 1000000, enabled: true },
      'WALLET': { min: 1, max: 50000, enabled: true },
      'COD': { min: 100, max: 2000, enabled: true },
      'CASH_ON_DELIVERY': { min: 100, max: 2000, enabled: true }
    };

    const limits = methodLimits[method.toUpperCase()];
    if (!limits || !limits.enabled) return false;

    return amount >= limits.min && amount <= limits.max;
  }

  // ✅ ENHANCED: Get processing fee for payment method
  getProcessingFee(method: string, amount: number): number {
    const fees: { [key: string]: number | ((amount: number) => number) } = {
      'UPI': 0,
      'CARD': 0,
      'CREDIT_CARD': 0,
      'DEBIT_CARD': 0,
      'NET_BANKING': 5,
      'WALLET': 0,
      'COD': (amount: number) => amount > 1000 ? 25 : 15,
      'CASH_ON_DELIVERY': (amount: number) => amount > 1000 ? 25 : 15
    };

    const fee = fees[method.toUpperCase()];
    if (typeof fee === 'function') {
      return fee(amount);
    }
    
    return fee || 0;
  }

  // ✅ ENHANCED: Test payment service connectivity
  testPaymentService(): Observable<boolean> {
    console.log('🔍 Testing payment service connectivity...');
    
    return this.http.get(`${this.PAYMENT_API}/health`, {
      headers: this.getHeaders().delete('Authorization')
    }).pipe(
      timeout(5000),
      tap(() => {
        console.log('✅ Payment service is healthy');
        this.updateServiceState({ isOnline: true });
      }),
      catchError((error) => {
        console.error('❌ Payment service is not responding:', error);
        this.updateServiceState({ isOnline: false });
        return of(false);
      }),
      map(() => true)
    );
  }

  // ✅ ENHANCED: Get loading states
  getLoadingStates() {
    return { ...this.loadingStates };
  }

  // ✅ ADD: Check if any operation is in progress
  isAnyOperationInProgress(): boolean {
    return Object.values(this.loadingStates).some(state => state);
  }

  // ✅ ADD: Get service status
  getServiceStatus(): PaymentServiceState {
    return { ...this.serviceState };
  }

  // ✅ ADD: Reset service state
  resetServiceState(): void {
    this.serviceState = {
      isOnline: true,
      lastRequestTime: null,
      requestInProgress: false,
      retryAttempts: 0
    };
    
    this.loadingStates = {
      initiating: false,
      confirming: false,
      checking: false,
      cancelling: false,
      refunding: false
    };
    
    this.stateSubject.next(this.serviceState);
    console.log('🔄 Payment service state reset');
  }

  // ✅ ADD: Cleanup method
  ngOnDestroy(): void {
    this.stateSubject.complete();
  }
}





import { Injectable, Inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

interface CartItem {
  id: number;
  name: string;
  price: number;
  quantity: number;
  restaurantId: number;
  restaurantName: string;
  image?: string;
  description?: string;
  isVegetarian?: boolean;
  menuItemId?: number;
  itemName?: string;
}

interface CartSummary {
  items: CartItem[];
  totalItems: number;
  totalAmount: number;
  subtotal: number;
  taxes: number;
  deliveryFee: number;
  discount: number;
  restaurants: { id: number; name: string; itemCount: number; subtotal: number }[];
  isEmpty: boolean;
  itemCount: number;
  restaurantId?: number;
  restaurantName?: string;
}

interface CartValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
  fixedItems: CartItem[];
}

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private readonly CART_KEY = 'customerCart';
  private readonly USER_CART_PREFIX = 'cart_user_';
  
  private cartSubject = new BehaviorSubject<CartItem[]>([]);
  
  // ✅ FIX: Provide both naming conventions for compatibility
  public cart$ = this.cartSubject.asObservable();
  public cartItems$ = this.cartSubject.asObservable();
  
  // ✅ ADD: Additional observables for easier access
  public cartCount$ = this.cartSubject.asObservable().pipe(
    map((items: CartItem[]) => items.reduce((count, item) => count + item.quantity, 0))
  );
  
  public cartTotal$ = this.cartSubject.asObservable().pipe(
    map((items: CartItem[]) => items.reduce((total, item) => total + (item.price * item.quantity), 0))
  );

  // ✅ ADD: Cart summary observable
  public cartSummary$ = this.cartSubject.asObservable().pipe(
    map((items: CartItem[]) => this.calculateCartSummary(items))
  );

  constructor(@Inject(PLATFORM_ID) private platformId: Object) {
    this.loadCart();
  }

  // Load cart with user-specific storage
  loadCart(userId?: string): void {
    if (!isPlatformBrowser(this.platformId)) return;

    try {
      let cartData: CartItem[] = [];
      
      if (userId) {
        const userCart = localStorage.getItem(this.USER_CART_PREFIX + userId);
        if (userCart) {
          cartData = JSON.parse(userCart);
        }
      } else {
        const generalCart = localStorage.getItem(this.CART_KEY);
        if (generalCart) {
          cartData = JSON.parse(generalCart);
        }
      }

      // ✅ FIX: Validate and fix cart data before setting
      const validationResult = this.validateCart(cartData);
      if (!validationResult.isValid) {
        console.warn('⚠️ Cart data validation issues:', validationResult.errors);
        cartData = validationResult.fixedItems;
      }

      this.cartSubject.next(cartData);
      console.log('🛒 Cart loaded:', cartData.length, 'items');
    } catch (error) {
      console.error('❌ Error loading cart:', error);
      this.cartSubject.next([]);
    }
  }

  // Save cart with user-specific storage
  saveCart(userId?: string): void {
    if (!isPlatformBrowser(this.platformId)) return;

    try {
      const cartData = this.cartSubject.value;
      const cartJson = JSON.stringify(cartData);

      localStorage.setItem(this.CART_KEY, cartJson);

      if (userId) {
        localStorage.setItem(this.USER_CART_PREFIX + userId, cartJson);
      }

      console.log('💾 Cart saved:', cartData.length, 'items');
    } catch (error) {
      console.error('❌ Error saving cart:', error);
    }
  }

  // ✅ ADD: Get cart summary
  getCartSummary(): CartSummary {
    const items = this.cartSubject.value;
    return this.calculateCartSummary(items);
  }

  // ✅ ADD: Calculate cart summary
  // ✅ ENHANCED: Calculate cart summary
private calculateCartSummary(items: CartItem[]): CartSummary {
    const subtotal = items.reduce((total, item) => total + (item.price * item.quantity), 0);
    const taxes = subtotal * 0.18; // 18% GST
    const deliveryFee = subtotal > 500 ? 0 : 30; // Free delivery above ₹500
    const discount = 0; // Can be calculated based on offers
    const totalAmount = subtotal + taxes + deliveryFee - discount;
    const totalItems = items.reduce((count, item) => count + item.quantity, 0);
  
    // Group by restaurants
    const restaurantMap = new Map<number, { name: string; itemCount: number; subtotal: number }>();
    
    items.forEach(item => {
      if (!restaurantMap.has(item.restaurantId)) {
        restaurantMap.set(item.restaurantId, {
          name: item.restaurantName,
          itemCount: 0,
          subtotal: 0
        });
      }
      
      const restaurant = restaurantMap.get(item.restaurantId)!;
      restaurant.itemCount += item.quantity;
      restaurant.subtotal += item.price * item.quantity;
    });
  
    const restaurants = Array.from(restaurantMap.entries()).map(([id, data]) => ({
      id,
      ...data
    }));
  
    // ✅ FIX: Get primary restaurant info (first restaurant if items exist)
    const primaryRestaurant = restaurants.length > 0 ? restaurants[0] : null;
  
    return {
      items,
      totalItems,
      totalAmount,
      subtotal,
      taxes,
      deliveryFee,
      discount,
      restaurants,
      isEmpty: items.length === 0,
      // ✅ ADD: Missing properties
      itemCount: totalItems,
      restaurantId: primaryRestaurant?.id,
      restaurantName: primaryRestaurant?.name
    };
  }
  
 // ✅ ADD: Overloaded method - can be called with or without parameters
validateCart(): CartValidationResult;
validateCart(items: CartItem[]): CartValidationResult;
validateCart(items?: CartItem[]): CartValidationResult {
  const cartItems = items || this.cartSubject.value;
  const errors: string[] = [];
  const warnings: string[] = [];
  const fixedItems: CartItem[] = [];

  if (!Array.isArray(cartItems)) {
    errors.push('Cart data is not an array');
    return {
      isValid: false,
      errors,
      warnings,
      fixedItems: []
    };
  }

  cartItems.forEach((item: any, index: number) => {
    try {
      // Validate required fields
      if (!item.id || typeof item.id !== 'number') {
        errors.push(`Item at index ${index}: Invalid or missing ID`);
        return;
      }

      if (!item.name || typeof item.name !== 'string') {
        errors.push(`Item at index ${index}: Invalid or missing name`);
        return;
      }

      if (!item.price || typeof item.price !== 'number' || item.price <= 0) {
        errors.push(`Item at index ${index}: Invalid or missing price`);
        return;
      }

      if (!item.quantity || typeof item.quantity !== 'number' || item.quantity <= 0) {
        errors.push(`Item at index ${index}: Invalid or missing quantity`);
        return;
      }

      if (!item.restaurantId || typeof item.restaurantId !== 'number') {
        errors.push(`Item at index ${index}: Invalid or missing restaurant ID`);
        return;
      }

      if (!item.restaurantName || typeof item.restaurantName !== 'string') {
        warnings.push(`Item at index ${index}: Missing restaurant name`);
        item.restaurantName = `Restaurant ${item.restaurantId}`;
      }

      // ✅ FIX: Fix any data issues with proper property mapping
      const fixedItem: CartItem = {
        id: Number(item.id),
        name: String(item.name).trim(),
        price: Number(item.price),
        quantity: Math.max(1, Math.floor(Number(item.quantity))),
        restaurantId: Number(item.restaurantId),
        restaurantName: String(item.restaurantName || `Restaurant ${item.restaurantId}`).trim(),
        image: item.image || undefined,
        description: item.description || undefined,
        isVegetarian: Boolean(item.isVegetarian),
        // ✅ ADD: Map additional properties
        menuItemId: item.menuItemId || item.id,
        itemName: item.itemName || item.name
      };

      fixedItems.push(fixedItem);

    } catch (error) {
      errors.push(`Item at index ${index}: Parsing error - ${error}`);
    }
  });

  return {
    isValid: errors.length === 0,
    errors,
    warnings,
    fixedItems
  };
}


  // ✅ ADD: Fix cart data
  fixCartData(): Observable<CartValidationResult> {
    return new Observable(observer => {
      try {
        const currentItems = this.cartSubject.value;
        const validationResult = this.validateCart(currentItems);
        
        if (validationResult.fixedItems.length !== currentItems.length || 
            !validationResult.isValid) {
          
          this.cartSubject.next(validationResult.fixedItems);
          this.saveCart();
          
          console.log('🔧 Cart data fixed:', {
            originalCount: currentItems.length,
            fixedCount: validationResult.fixedItems.length,
            errors: validationResult.errors,
            warnings: validationResult.warnings
          });
        }
        
        observer.next(validationResult);
        observer.complete();
        
      } catch (error: any) {
        console.error('❌ Error fixing cart data:', error);
        observer.error(error);
      }
    });
  }

  // Preserve cart for role switching
  preserveCartForUser(userId: string): void {
    if (!isPlatformBrowser(this.platformId)) return;

    try {
      const currentCart = this.cartSubject.value;
      const preserveData = {
        cart: currentCart,
        timestamp: Date.now(),
        userId: userId
      };

      localStorage.setItem(`preserved_cart_${userId}`, JSON.stringify(preserveData));
      console.log('🔐 Cart preserved for user:', userId);
    } catch (error) {
      console.error('❌ Error preserving cart:', error);
    }
  }

  // Restore preserved cart
  restorePreservedCart(userId: string): boolean {
    if (!isPlatformBrowser(this.platformId)) return false;

    try {
      const preserved = localStorage.getItem(`preserved_cart_${userId}`);
      if (preserved) {
        const data = JSON.parse(preserved);
        
        if (Date.now() - data.timestamp < 24 * 60 * 60 * 1000) {
          const validationResult = this.validateCart(data.cart);
          this.cartSubject.next(validationResult.fixedItems);
          this.saveCart(userId);
          
          localStorage.removeItem(`preserved_cart_${userId}`);
          
          console.log('♻️ Cart restored from preservation:', validationResult.fixedItems.length, 'items');
          return true;
        } else {
          localStorage.removeItem(`preserved_cart_${userId}`);
        }
      }
    } catch (error) {
      console.error('❌ Error restoring preserved cart:', error);
    }
    
    return false;
  }

  // Get current cart items
  getCartItems(): CartItem[] {
    return this.cartSubject.value;
  }

  // Get current cart
  getCart(): CartItem[] {
    return this.cartSubject.value;
  }

  // ✅ ENHANCED: Add to cart with proper typing and property mapping
addToCart(item: CartItem, userId?: string): void {
    try {
      // ✅ FIX: Ensure all required properties are set
      const normalizedItem: CartItem = {
        id: item.id,
        name: item.name,
        price: item.price,
        quantity: item.quantity,
        restaurantId: item.restaurantId,
        restaurantName: item.restaurantName,
        image: item.image,
        description: item.description,
        isVegetarian: item.isVegetarian,
        // ✅ ADD: Set additional properties with fallbacks
        menuItemId: item.menuItemId || item.id,
        itemName: item.itemName || item.name
      };
  
      // Validate item before adding
      const validationResult = this.validateCart([normalizedItem]);
      if (!validationResult.isValid) {
        console.error('❌ Cannot add invalid item to cart:', validationResult.errors);
        throw new Error('Invalid item data: ' + validationResult.errors.join(', '));
      }
  
      const validItem = validationResult.fixedItems[0];
      const currentCart = [...this.cartSubject.value];
      const existingIndex = currentCart.findIndex(
        cartItem => cartItem.id === validItem.id && cartItem.restaurantId === validItem.restaurantId
      );
  
      if (existingIndex >= 0) {
        currentCart[existingIndex].quantity += validItem.quantity;
      } else {
        currentCart.push(validItem);
      }
  
      this.cartSubject.next(currentCart);
      this.saveCart(userId);
      
      console.log('✅ Item added to cart:', validItem.name);
    } catch (error: any) {
      console.error('❌ Error adding item to cart:', error);
      throw error;
    }
  }
  

  // Remove item from cart
  removeFromCart(itemId: number, restaurantId: number, userId?: string): void {
    const currentCart = this.cartSubject.value.filter(
      item => !(item.id === itemId && item.restaurantId === restaurantId)
    );
    
    this.cartSubject.next(currentCart);
    this.saveCart(userId);
  }

  // Update item quantity
  updateQuantity(itemId: number, restaurantId: number, quantity: number, userId?: string): void {
    const currentCart = [...this.cartSubject.value];
    const itemIndex = currentCart.findIndex(
      item => item.id === itemId && item.restaurantId === restaurantId
    );

    if (itemIndex >= 0) {
      if (quantity <= 0) {
        currentCart.splice(itemIndex, 1);
      } else {
        currentCart[itemIndex].quantity = Math.max(1, Math.floor(quantity));
      }
      
      this.cartSubject.next(currentCart);
      this.saveCart(userId);
    }
  }

  // Clear cart
  // ✅ FIX: Make clearCart return an Observable
clearCart(userId?: string): Observable<boolean> {
    return new Observable(observer => {
      try {
        this.cartSubject.next([]);
        this.saveCart(userId);
        
        console.log('🗑️ Cart cleared successfully');
        observer.next(true);
        observer.complete();
      } catch (error: any) {
        console.error('❌ Error clearing cart:', error);
        observer.error(error);
      }
    });
  }
  
  // ✅ ADD: Synchronous version if needed elsewhere
  clearCartSync(userId?: string): void {
    this.cartSubject.next([]);
    this.saveCart(userId);
  }
  

  // Get cart totals
  getCartTotal(): number {
    return this.cartSubject.value.reduce((total, item) => total + (item.price * item.quantity), 0);
  }

  getCartItemCount(): number {
    return this.cartSubject.value.reduce((count, item) => count + item.quantity, 0);
  }

  // Additional utility methods
  isCartEmpty(): boolean {
    return this.cartSubject.value.length === 0;
  }

  getCartItemById(itemId: number, restaurantId: number): CartItem | undefined {
    return this.cartSubject.value.find(
      item => item.id === itemId && item.restaurantId === restaurantId
    );
  }

  getCartItemsByRestaurant(restaurantId: number): CartItem[] {
    return this.cartSubject.value.filter(item => item.restaurantId === restaurantId);
  }

  hasItemsFromMultipleRestaurants(): boolean {
    const restaurantIds = new Set(this.cartSubject.value.map(item => item.restaurantId));
    return restaurantIds.size > 1;
  }

  getTotalByRestaurant(restaurantId: number): number {
    return this.cartSubject.value
      .filter(item => item.restaurantId === restaurantId)
      .reduce((total, item) => total + (item.price * item.quantity), 0);
  }

  // ✅ ADD: Auto-fix cart on initialization
  autoFixCart(): void {
    this.fixCartData().subscribe({
      next: (result: CartValidationResult) => {
        if (!result.isValid) {
          console.log('🔧 Cart automatically fixed:', result.warnings);
        }
      },
      error: (error: any) => {
        console.error('❌ Error auto-fixing cart:', error);
      }
    });
  }

  // Debug method
  debugCart(): void {
    const summary = this.getCartSummary();
    console.log('🔍 Cart Debug Info:', {
      summary,
      rawItems: this.cartSubject.value,
      validation: this.validateCart(this.cartSubject.value)
    });
  }
}

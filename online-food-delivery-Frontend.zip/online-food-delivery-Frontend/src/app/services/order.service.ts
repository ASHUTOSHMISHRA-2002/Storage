

// src/app/services/order.service.ts
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, BehaviorSubject, throwError, of } from 'rxjs';
import { tap, catchError, retry, switchMap, map } from 'rxjs/operators';
import { AuthService } from './auth.service';

export interface OrderItemDTO {
  menuItemId: number;
  itemName: string;
  quantity: number;
  price: number;
  restaurantId?: number;
  isVegetarian?: boolean;
  description?: string;
  image?: string;
}

export interface OrderDTO {
  orderId: number;
  userId: number;
  restaurantId: number;
  restaurantName?: string;
  status: string;
  totalAmount: number;
  orderTime: string;
  deliveryTime?: string;
  estimatedDeliveryTime?: string;
  deliveryAddress: string;
  items: OrderItemDTO[];
  paymentId?: number;
  paymentMethod?: string;
  paymentStatus?: string;
  deliveryAgentId?: number;
  deliveryAgentName?: string;
  deliveryAgentPhone?: string;
  idempotencyKey?: string;
  customerName?: string;
  customerPhone?: string;
  customerEmail?: string;
  notes?: string;
  createdAt?: string;
  updatedAt?: string;
}

// ✅ FIXED: Updated interface to include customerDetails
export interface OrderRequestDTO {
  userId: number;
  restaurantId: number;
  restaurantName?: string;
  deliveryAddress: string;
  customerName?: string;
  customerPhone?: string;
  customerEmail?: string;
  totalAmount?: number;
  items?: OrderItemDTO[];
  notes?: string;
  paymentMethod?: string;
  customerDetails?: CustomerDetails; // ✅ ADD THIS
}

export interface OrderStatusUpdateDTO {
  orderId: number;
  status: string;
  estimatedDeliveryTime?: string;
  deliveryAgentId?: number;
  notes?: string;
}

export interface CustomerDetails {
  name: string;
  phone: string;
  email: string;
  address?: string;
  city?: string;
  state?: string;
  pincode?: string;
}

// ✅ ADD: Order creation request interface for place order
export interface OrderCreationRequest {
  items: OrderItemDTO[];
  restaurantId: number;
  restaurantName: string;
  totalAmount: number;
  customerDetails?: CustomerDetails;
  deliveryAddress?: string;
  notes?: string;
  paymentMethod?: string;
  customerName?: string;
  customerPhone?: string;
  customerEmail?: string;
}

export interface OrderSummary {
  items: any[];
  restaurantId: number;
  restaurantName: string;
  totalAmount: number;
  itemCount: number;
  customerDetails: CustomerDetails;
  deliveryAddress: string;
  notes?: string;
}

@Injectable({
  providedIn: 'root'
})
export class OrderService {
  private readonly ORDER_API = 'http://localhost:9097/api/orders';
  private readonly PAYMENT_API = 'http://localhost:8085/api/payments';
  
  private ordersSubject = new BehaviorSubject<OrderDTO[]>([]);
  public orders$ = this.ordersSubject.asObservable();
  
  private currentOrderSubject = new BehaviorSubject<OrderDTO | null>(null);
  public currentOrder$ = this.currentOrderSubject.asObservable();

  // Order status mapping
//   private readonly ORDER_STATUSES = {
//     PENDING: 'Order Placed',
//     ACCEPTED: 'Confirmed by Restaurant',
//     IN_COOKING: 'Being Prepared',
//     READY_FOR_PICKUP: 'Ready for Pickup',
//     OUT_FOR_DELIVERY: 'Out for Delivery',
//     COMPLETED: 'Delivered',
//     CANCELLED: 'Cancelled',
//     REJECTED: 'Rejected'
//   };

// In OrderService
private readonly ORDER_STATUSES = {
    PENDING: 'Order Placed',
    ACCEPTED: 'Confirmed by Restaurant',
    IN_COOKING: 'Being Prepared', 
    READY_FOR_PICKUP: 'Ready for Pickup',
    OUT_FOR_DELIVERY: 'Out for Delivery',
    COMPLETED: 'Delivered Successfully', // ✅ This should show instead of "in_progress"
    DELIVERED: 'Delivered Successfully', // ✅ Alternative status
    CANCELLED: 'Cancelled',
    REJECTED: 'Rejected'
  };
  

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) {
    console.log('🔧 OrderService initialized');
    this.loadUserOrders();
  }

  private getHeaders(): HttpHeaders {
    const token = this.authService.getToken();
    const userInfo = this.authService.getUserInfo();
    
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token || ''}`,
      'X-Internal-User-Id': userInfo?.restaurantId || '1',
      'X-Internal-User-Roles': userInfo?.roles?.[0] || 'CUSTOMER'
    });
  }

  private getUserId(): number {
    const userInfo = this.authService.getUserInfo();
    return userInfo?.restaurantId ? parseInt(userInfo.restaurantId) : 
           userInfo?.userId ? parseInt(userInfo.userId.toString()) : 1;
  }

  private getUserDetails(): CustomerDetails {
    const userInfo = this.authService.getUserInfo();
    return {
      name: userInfo?.username || 'Customer',
      email: userInfo?.email || '',
      phone: userInfo?.phone || '',
      address: userInfo?.location || userInfo?.address || ''
    };
  }

  // ✅ FIXED: Updated placeOrder method with correct interface
  placeOrder(orderData: OrderCreationRequest): Observable<OrderDTO> {
    console.log('🚀 Placing order with comprehensive details:', orderData);

    // Validate order data
    const validation = this.validateOrderData(orderData);
    if (!validation.isValid) {
      console.error('❌ Order validation failed:', validation.errors);
      return throwError(() => new Error(`Order validation failed: ${validation.errors.join(', ')}`));
    }

    const idempotencyKey = this.generateIdempotencyKey();
    
    // Transform cart items to order items
    const orderItems: OrderItemDTO[] = orderData.items.map(item => ({
      menuItemId: item.menuItemId || (item as any).id,
      itemName: item.itemName || (item as any).name,
      quantity: item.quantity,
      price: item.price,
      restaurantId: orderData.restaurantId,
      isVegetarian: item.isVegetarian || (item as any).isVegetarian,
      description: item.description,
      image: item.image
    }));

    // ✅ COMPREHENSIVE ORDER REQUEST WITH ALL DETAILS
    const orderRequest: OrderRequestDTO = {
      userId: this.getUserId(),
      restaurantId: orderData.restaurantId,
      restaurantName: orderData.restaurantName,
      deliveryAddress: orderData.deliveryAddress || orderData.customerDetails?.address || '',
      customerName: orderData.customerDetails?.name || orderData.customerName || 'Customer',
      customerPhone: orderData.customerDetails?.phone || orderData.customerPhone || '',
      customerEmail: orderData.customerDetails?.email || orderData.customerEmail || '',
      totalAmount: orderData.totalAmount,
      items: orderItems,
      notes: orderData.notes,
      paymentMethod: orderData.paymentMethod || 'CARD',
      customerDetails: orderData.customerDetails // ✅ NOW THIS WORKS
    };

    const headers = this.getHeaders().set('X-Idempotency-Key', idempotencyKey);
    
    console.log('📤 Sending comprehensive order request:', orderRequest);
    
    return this.http.post<OrderDTO>(this.ORDER_API, orderRequest, { headers })
      .pipe(
        retry(2), // Retry failed requests
        tap(order => {
          console.log('✅ Order placed successfully:', order);
          
          // Save order summary for tracking
          this.saveOrderSummary(order, orderData);
          
          // Update current order
          this.currentOrderSubject.next(order);
          
          // Update orders list
          const currentOrders = this.ordersSubject.value;
          this.ordersSubject.next([order, ...currentOrders]);
          
          // Clear order summary from localStorage after successful placement
          this.clearOrderSummary();
        }),
        catchError(this.handleError.bind(this))
      );
  }

  // 📋 Create order summary for checkout process
  createOrderSummary(orderData: {
    items: any[];
    restaurantId: number;
    restaurantName: string;
    totalAmount: number;
    deliveryAddress?: string;
    notes?: string;
    customerDetails?: CustomerDetails;
  }): OrderSummary {
    
    const customerDetails = orderData.customerDetails || this.getUserDetails();
    
    const orderSummary: OrderSummary = {
      items: orderData.items,
      restaurantId: orderData.restaurantId,
      restaurantName: orderData.restaurantName,
      totalAmount: orderData.totalAmount,
      itemCount: orderData.items.reduce((count, item) => count + item.quantity, 0),
      customerDetails: customerDetails,
      deliveryAddress: orderData.deliveryAddress || customerDetails.address || '',
      notes: orderData.notes
    };

    // Save to localStorage for payment process
    this.saveOrderSummary(null, orderSummary);
    
    console.log('📋 Order summary created:', orderSummary);
    return orderSummary;
  }

  // 💾 Save order summary to localStorage
  private saveOrderSummary(order: OrderDTO | null, orderData: any): void {
    try {
      const summaryData = {
        order: order,
        orderData: orderData,
        timestamp: new Date().toISOString()
      };
      localStorage.setItem('orderSummary', JSON.stringify(summaryData));
      console.log('💾 Order summary saved to localStorage');
    } catch (error) {
      console.error('❌ Error saving order summary:', error);
    }
  }

  // 📖 Get order summary from localStorage
  getOrderSummary(): any {
    try {
      const saved = localStorage.getItem('orderSummary');
      if (saved) {
        const summaryData = JSON.parse(saved);
        console.log('📖 Order summary loaded from localStorage');
        return summaryData;
      }
    } catch (error) {
      console.error('❌ Error loading order summary:', error);
    }
    return null;
  }

  // 🧹 Clear order summary
  clearOrderSummary(): void {
    try {
      localStorage.removeItem('orderSummary');
      console.log('🧹 Order summary cleared');
    } catch (error) {
      console.error('❌ Error clearing order summary:', error);
    }
  }

  // 🔍 Get order by ID with enhanced error handling
  getOrderById(orderId: number): Observable<OrderDTO> {
    console.log('🔍 Fetching order by ID:', orderId);
    
    return this.http.get<OrderDTO>(`${this.ORDER_API}/${orderId}`, {
      headers: this.getHeaders()
    }).pipe(
      tap(order => {
        console.log('✅ Order fetched successfully:', order);
        this.currentOrderSubject.next(order);
      }),
      catchError(this.handleError.bind(this))
    );
  }

  // 📋 Get user orders with pagination
  getUserOrders(page: number = 0, size: number = 20): Observable<OrderDTO[]> {
    console.log('📋 Fetching user orders, page:', page, 'size:', size);
    
    const params = `?page=${page}&size=${size}`;
    
    return this.http.get<OrderDTO[]>(`${this.ORDER_API}/user${params}`, {
      headers: this.getHeaders()
    }).pipe(
      tap(orders => {
        console.log('✅ User orders fetched:', orders.length, 'orders');
        this.ordersSubject.next(orders);
      }),
      catchError(this.handleError.bind(this))
    );
  }

  // ✅ ADD: Get orders for restaurant (for restaurant dashboard)
  getOrdersForRestaurant(restaurantId?: number): Observable<OrderDTO[]> {
    const id = restaurantId || this.getUserId();
    console.log('📋 Fetching orders for restaurant:', id);
    
    return this.http.get<OrderDTO[]>(`${this.ORDER_API}/restaurant/${id}`, {
      headers: this.getHeaders()
    }).pipe(
      tap(orders => {
        console.log('✅ Restaurant orders fetched:', orders.length, 'orders');
        this.ordersSubject.next(orders);
      }),
      catchError(this.handleError.bind(this))
    );
  }

  // ✅ FIXED: Update order status method with restaurant ID
  updateOrderStatus(orderId: number, status: string, restaurantId?: number, notes?: string): Observable<OrderDTO> {
    const updateData: OrderStatusUpdateDTO = {
      orderId: orderId,
      status: status,
      notes: notes
    };

    const endpoint = restaurantId 
      ? `${this.ORDER_API}/restaurant/${restaurantId}/order/${orderId}/status`
      : `${this.ORDER_API}/${orderId}/status`;

    return this.http.put<OrderDTO>(endpoint, updateData, {
      headers: this.getHeaders()
    }).pipe(
      tap(order => {
        console.log('✅ Order status updated:', order);
        this.currentOrderSubject.next(order);
        
        // Update in orders list
        const currentOrders = this.ordersSubject.value;
        const updatedOrders = currentOrders.map(o => 
          o.orderId === orderId ? order : o
        );
        this.ordersSubject.next(updatedOrders);
      }),
      catchError(this.handleError.bind(this))
    );
  }

  // ❌ Cancel order
  cancelOrder(orderId: number, reason?: string): Observable<OrderDTO> {
    const cancelData = {
      reason: reason || 'Cancelled by customer'
    };

    return this.http.put<OrderDTO>(`${this.ORDER_API}/${orderId}/cancel`, cancelData, {
      headers: this.getHeaders()
    }).pipe(
      tap(order => {
        console.log('✅ Order cancelled:', order);
        this.currentOrderSubject.next(order);
      }),
      catchError(this.handleError.bind(this))
    );
  }

  // 🔄 Reorder (duplicate previous order)
  reorder(orderId: number): Observable<OrderSummary> {
    return this.getOrderById(orderId).pipe(
      map(order => {
        const orderSummary: OrderSummary = {
          items: order.items,
          restaurantId: order.restaurantId,
          restaurantName: order.restaurantName || 'Restaurant',
          totalAmount: order.totalAmount,
          itemCount: order.items.reduce((count, item) => count + item.quantity, 0),
          customerDetails: {
            name: order.customerName || '',
            phone: order.customerPhone || '',
            email: order.customerEmail || '',
            address: order.deliveryAddress
          },
          deliveryAddress: order.deliveryAddress
        };
        
        this.saveOrderSummary(null, orderSummary);
        return orderSummary;
      })
    );
  }

  // 📊 Get order statistics
  getOrderStats(): Observable<any> {
    return this.http.get<any>(`${this.ORDER_API}/user/stats`, {
      headers: this.getHeaders()
    }).pipe(
      catchError(this.handleError.bind(this))
    );
  }

  // 🔍 Search orders
  searchOrders(query: string): Observable<OrderDTO[]> {
    return this.http.get<OrderDTO[]>(`${this.ORDER_API}/user/search?q=${encodeURIComponent(query)}`, {
      headers: this.getHeaders()
    }).pipe(
      catchError(this.handleError.bind(this))
    );
  }

  // 📱 Load user orders on service initialization
  private loadUserOrders(): void {
    if (this.authService.isAuthenticated()) {
      this.getUserOrders().subscribe({
        next: (orders) => {
          console.log('🔄 Initial orders loaded:', orders.length);
        },
        error: (error) => {
          console.error('❌ Error loading initial orders:', error);
        }
      });
    }
  }

  // ✅ FIXED: Validate order data with proper interface
  private validateOrderData(orderData: OrderCreationRequest): { isValid: boolean; errors: string[] } {
    const errors: string[] = [];

    if (!orderData.items || orderData.items.length === 0) {
      errors.push('Order must contain at least one item');
    }

    if (!orderData.restaurantId) {
      errors.push('Restaurant ID is required');
    }

    if (!orderData.restaurantName) {
      errors.push('Restaurant name is required');
    }

    if (!orderData.totalAmount || orderData.totalAmount <= 0) {
      errors.push('Total amount must be greater than zero');
    }

    if (!orderData.customerDetails?.name && !orderData.customerName) {
      errors.push('Customer name is required');
    }

    if (!orderData.customerDetails?.phone && !orderData.customerPhone) {
      errors.push('Customer phone is required');
    }

    if (!orderData.customerDetails?.email && !orderData.customerEmail) {
      errors.push('Customer email is required');
    }

    if (!orderData.deliveryAddress && !orderData.customerDetails?.address) {
      errors.push('Delivery address is required');
    }

    // Validate items
    orderData.items?.forEach((item: any, index: number) => {
      if (!item.menuItemId && !item.id) {
        errors.push(`Item ${index + 1}: Menu item ID is required`);
      }
      
      if (!item.itemName && !item.name) {
        errors.push(`Item ${index + 1}: Item name is required`);
      }
      
      if (!item.price || item.price <= 0) {
        errors.push(`Item ${index + 1}: Valid price is required`);
      }
      
      if (!item.quantity || item.quantity <= 0) {
        errors.push(`Item ${index + 1}: Valid quantity is required`);
      }
    });

    return {
      isValid: errors.length === 0,
      errors: errors
    };
  }

  // 🔑 Generate unique idempotency key
  private generateIdempotencyKey(): string {
    const timestamp = Date.now();
    const random = Math.random().toString(36).substr(2, 9);
    const userId = this.getUserId();
    return `order_${userId}_${timestamp}_${random}`;
  }

  // ❌ Enhanced error handling
  private handleError(error: HttpErrorResponse): Observable<never> {
    let errorMessage = 'An error occurred';
    
    if (error.error instanceof ErrorEvent) {
      // Client-side error
      errorMessage = `Client Error: ${error.error.message}`;
    } else {
      // Server-side error
      errorMessage = `Server Error: ${error.status} - ${error.message}`;
      
      if (error.error?.message) {
        errorMessage += ` - ${error.error.message}`;
      }
    }
    
    console.error('🚨 OrderService Error:', errorMessage);
    console.error('🚨 Full error object:', error);
    
    return throwError(() => new Error(errorMessage));
  }

  // 🎯 Helper methods for UI components
  getOrderStatusDisplay(status: string): string {
    return this.ORDER_STATUSES[status as keyof typeof this.ORDER_STATUSES] || status;
  }

  isOrderCancellable(order: OrderDTO): boolean {
    return ['PENDING', 'ACCEPTED'].includes(order.status);
  }

  isOrderTrackable(order: OrderDTO): boolean {
    return !['CANCELLED', 'REJECTED'].includes(order.status);
  }

  formatOrderTime(orderTime: string): string {
    return new Date(orderTime).toLocaleString();
  }

  formatPrice(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  }

  // 🔄 Refresh current order (for real-time updates)
  refreshCurrentOrder(): void {
    const currentOrder = this.currentOrderSubject.value;
    if (currentOrder) {
      this.getOrderById(currentOrder.orderId).subscribe();
    }
  }

  // 📞 Emergency contact methods
  getRestaurantContact(restaurantId: number): Observable<any> {
    return this.http.get<any>(`${this.ORDER_API}/restaurant/${restaurantId}/contact`, {
      headers: this.getHeaders()
    }).pipe(
      catchError(this.handleError.bind(this))
    );
  }

  getDeliveryAgentContact(agentId: number): Observable<any> {
    return this.http.get<any>(`${this.ORDER_API}/agent/${agentId}/contact`, {
      headers: this.getHeaders()
    }).pipe(
      catchError(this.handleError.bind(this))
    );
  }
}

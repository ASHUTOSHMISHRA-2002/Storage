
// S-5

import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError, BehaviorSubject, of, forkJoin, from, EMPTY } from 'rxjs';
import { AuthService } from './auth.service';
import { catchError, tap, retry, timeout, map, switchMap, finalize, mergeMap, take } from 'rxjs/operators';

export interface MenuItem {
  itemId: number;
  restaurantId: number;
  itemName: string;
  description: string;
  price: number;
  isVegetarian: boolean;
  createdAt?: string;
  updatedAt?: string;
  createdBy?: string;
  updatedBy?: string;
  imageUrl?: string;
  isAvailable?: boolean;
  category?: string;
}

export interface MenuItemRequest {
  itemName: string;
  description: string;
  price: number;
  isVegetarian: boolean;
  imageUrl?: string;
  category?: string;
  isAvailable?: boolean;
}

export interface MenuCache {
  data: MenuItem[];
  timestamp: number;
  restaurantId: number;
}

export interface MenuStats {
  total: number;
  veg: number;
  nonVeg: number;
  avgPrice: number;
  categories: string[];
  priceRange: { min: number; max: number };
}

export interface BatchMenuResponse {
  [restaurantId: number]: MenuItem[];
}

// 🔥 NEW: Additional interfaces for customer functionality
export interface Restaurant {
  id: string;
  name: string;
  location: string;
  email: string;
  rating?: number;
  deliveryTime?: string;
  deliveryFee?: number;
  minOrder?: number;
  cuisineType?: string;
  isOpen?: boolean;
}

export interface RestaurantWithMenu {
  restaurant: Restaurant;
  menu: MenuItem[];
  stats: MenuStats;
}

@Injectable({
  providedIn: 'root'
})
export class MenuService {
  private readonly menuBaseUrl = 'http://localhost:9096/api/menu';
  private readonly retryCount = 2;
  private readonly timeoutDuration = 10000; // 10 seconds
  
  // 🔥 NEW: Restaurant service base URL for customer functionality
  private readonly restaurantBaseUrl = 'http://localhost:8082/api/restaurants';
  
  // Cache management for customer main performance
  private menuCache = new Map<number, MenuCache>();
  private readonly CACHE_DURATION = 5 * 60 * 1000; // 5 minutes
  
  // 🔥 NEW: Restaurant cache for customer functionality
  private restaurantCache = new Map<string, { data: Restaurant; timestamp: number }>();
  
  // Loading state management
  private loadingStates = new Map<number, boolean>();
  private menuLoading$ = new BehaviorSubject<{restaurantId: number, loading: boolean} | null>(null);
  
  // Error tracking
  private errorStates = new Map<number, HttpErrorResponse>();
  private retryAttempts = new Map<number, number>();

  constructor(private http: HttpClient, private auth: AuthService) {
    console.log('🔧 MenuService initialized with baseUrl:', this.menuBaseUrl);
    console.log('🔧 Restaurant service baseUrl:', this.restaurantBaseUrl);
    this.initializeService();
  }

  private initializeService(): void {
    // Clear expired cache entries periodically
    setInterval(() => this.clearExpiredCache(), 60000);
    
    // Clear old error states periodically
    setInterval(() => this.clearOldErrors(), 5 * 60000); // 5 minutes
  }

  private clearExpiredCache(): void {
    const now = Date.now();
    let cleared = 0;
    
    for (const [restaurantId, cache] of this.menuCache.entries()) {
      if (now - cache.timestamp > this.CACHE_DURATION) {
        this.menuCache.delete(restaurantId);
        cleared++;
      }
    }
    
    // 🔥 NEW: Clear restaurant cache as well
    for (const [restaurantId, cache] of this.restaurantCache.entries()) {
      if (now - cache.timestamp > this.CACHE_DURATION) {
        this.restaurantCache.delete(restaurantId);
        cleared++;
      }
    }
    
    if (cleared > 0) {
      console.log(`🗑️ Cleared ${cleared} expired cache entries`);
    }
  }

  private clearOldErrors(): void {
    this.errorStates.clear();
    this.retryAttempts.clear();
  }

  // 🔥 ENHANCED: Main method with better error handling and performance
  getMenuItemsByRestaurant(restaurantId: number, useCache: boolean = true): Observable<MenuItem[]> {
    if (!restaurantId || restaurantId <= 0) {
      console.error('❌ Invalid restaurantId provided:', restaurantId);
      return throwError(() => new Error('Invalid restaurantId provided'));
    }

    // Check if already loading
    if (this.loadingStates.get(restaurantId)) {
      console.log('⏳ Already loading menu for restaurant:', restaurantId);
      return of([]);
    }

    // Check cache first
    if (useCache) {
      const cached = this.menuCache.get(restaurantId);
      if (cached && (Date.now() - cached.timestamp) < this.CACHE_DURATION) {
        console.log('📦 Returning cached menu for restaurant:', restaurantId);
        return of(cached.data);
      }
    }

    // Check if we should retry after previous errors
    const retryCount = this.retryAttempts.get(restaurantId) || 0;
    if (retryCount >= 3) {
      console.log(`🚫 Max retry attempts reached for restaurant ${restaurantId}`);
      return of([]);
    }

    console.log('🔍 Fetching menu for restaurant (public access):', restaurantId);
    
    // Set loading state
    this.loadingStates.set(restaurantId, true);
    this.menuLoading$.next({ restaurantId, loading: true });
    
    const url = `${this.menuBaseUrl}/restaurant/${restaurantId}`;
    console.log('🌐 Request URL:', url);
    
    return this.http.get<MenuItem[]>(url, {
      withCredentials: false,
      headers: this.getPublicHeaders()
    }).pipe(
      retry(this.retryCount),
      timeout(this.timeoutDuration),
      tap((menuItems: MenuItem[]) => {
        console.log(`✅ Successfully fetched ${menuItems.length} menu items for restaurant ${restaurantId}`);
        
        // Cache the results
        this.menuCache.set(restaurantId, {
          data: menuItems,
          timestamp: Date.now(),
          restaurantId
        });
        
        // Clear error states on success
        this.errorStates.delete(restaurantId);
        this.retryAttempts.delete(restaurantId);
        
        // Enhanced logging
        if (menuItems.length > 0) {
          const stats = this.getMenuStats(menuItems);
          console.log(`📋 Menu stats for restaurant ${restaurantId}:`, 
            `${stats.total} items (${stats.veg} veg, ${stats.nonVeg} non-veg), avg price: ₹${stats.avgPrice}`);
        } else {
          console.log(`📋 No menu items found for restaurant ${restaurantId}`);
        }
      }),
      catchError((error: HttpErrorResponse) => {
        console.error(`❌ Error fetching menu for restaurant ${restaurantId}:`, error);
        
        // Track error and retry attempts
        this.errorStates.set(restaurantId, error);
        this.retryAttempts.set(restaurantId, retryCount + 1);
        
        this.logDetailedError(error, `getMenuItemsByRestaurant(${restaurantId})`);
        
        // Return empty array instead of error to prevent UI breaks
        return of([]);
      }),
      finalize(() => {
        // Always clear loading state
        this.loadingStates.set(restaurantId, false);
        this.menuLoading$.next({ restaurantId, loading: false });
      })
    );
  }

  // 🔥 ENHANCED: Optimized batch loading with better performance
  getMenusForRestaurants(restaurantIds: number[]): Observable<BatchMenuResponse> {
    console.log('📦 Batch loading menus for restaurants:', restaurantIds);
    
    if (!restaurantIds || restaurantIds.length === 0) {
      return of({});
    }

    // Filter out invalid IDs
    const validIds = restaurantIds.filter(id => id && id > 0);
    
    if (validIds.length === 0) {
      console.warn('⚠️ No valid restaurant IDs provided');
      return of({});
    }

    // Use forkJoin for parallel requests
    const requests = validIds.map(id => 
      this.getMenuItemsByRestaurant(id, true).pipe(
        map(menu => ({ restaurantId: id, menu })),
        catchError(error => {
          console.error(`❌ Error loading menu for restaurant ${id}:`, error);
          return of({ restaurantId: id, menu: [] });
        })
      )
    );

    return forkJoin(requests).pipe(
      map(results => {
        const menuMap: BatchMenuResponse = {};
        results.forEach(result => {
          menuMap[result.restaurantId] = result.menu;
        });
        
        console.log(`✅ Batch loaded menus for ${Object.keys(menuMap).length} restaurants`);
        return menuMap;
      }),
      catchError(error => {
        console.error('❌ Error in batch menu loading:', error);
        return of({});
      })
    );
  }

  // 🔥 NEW: Get restaurant menu with stats
  getRestaurantMenuWithStats(restaurantId: number): Observable<{menu: MenuItem[], stats: MenuStats}> {
    return this.getMenuItemsByRestaurant(restaurantId).pipe(
      map(menu => ({
        menu,
        stats: this.getMenuStats(menu)
      }))
    );
  }

  // 🔥 NEW: Search across all cached menus
  searchAllCachedMenus(searchTerm: string): MenuItem[] {
    const allItems: MenuItem[] = [];
    
    for (const cache of this.menuCache.values()) {
      const filteredItems = this.filterMenuItems(cache.data, searchTerm);
      allItems.push(...filteredItems);
    }
    
    return allItems;
  }

  // 🔥 NEW: Get menu availability status
  getMenuAvailability(restaurantId: number): Observable<{available: boolean, itemCount: number, lastUpdated: Date | null}> {
    return this.getMenuItemsByRestaurant(restaurantId).pipe(
      map(menu => {
        const cached = this.menuCache.get(restaurantId);
        return {
          available: menu.length > 0,
          itemCount: menu.length,
          lastUpdated: cached ? new Date(cached.timestamp) : null
        };
      })
    );
  }

  // 🔥 ENHANCED: Get loading states observable
  getMenuLoadingStates(): Observable<{restaurantId: number, loading: boolean} | null> {
    return this.menuLoading$.asObservable();
  }

  // 🔥 NEW: Check if menu is loading
  isMenuLoading(restaurantId: number): boolean {
    return this.loadingStates.get(restaurantId) || false;
  }

  // 🔥 NEW: Get cached menu count for a restaurant
  getCachedMenuCount(restaurantId: number): number {
    const cached = this.menuCache.get(restaurantId);
    return cached ? cached.data.length : 0;
  }

  // 🔥 NEW: Get last error for a restaurant
  getLastError(restaurantId: number): HttpErrorResponse | null {
    return this.errorStates.get(restaurantId) || null;
  }

  // 🔥 NEW: Force refresh menu (bypass cache)
  refreshMenu(restaurantId: number): Observable<MenuItem[]> {
    console.log('🔄 Force refreshing menu for restaurant:', restaurantId);
    this.menuCache.delete(restaurantId);
    this.errorStates.delete(restaurantId);
    this.retryAttempts.delete(restaurantId);
    return this.getMenuItemsByRestaurant(restaurantId, false);
  }

  // 🔥 ENHANCED: Filter menu items with better performance
  filterMenuItems(menuItems: MenuItem[], searchTerm: string): MenuItem[] {
    if (!searchTerm || !searchTerm.trim()) {
      return menuItems;
    }

    const term = searchTerm.toLowerCase().trim();
    return menuItems.filter(item => {
      const nameMatch = item.itemName.toLowerCase().includes(term);
      const descMatch = item.description.toLowerCase().includes(term);
      const categoryMatch = item.category?.toLowerCase().includes(term) || false;
      
      return nameMatch || descMatch || categoryMatch;
    });
  }

  // 🔥 NEW: Advanced filtering with multiple criteria
  advancedFilterMenuItems(menuItems: MenuItem[], filters: {
    searchTerm?: string;
    isVegetarian?: boolean;
    category?: string;
    priceRange?: { min: number; max: number };
    isAvailable?: boolean;
  }): MenuItem[] {
    let filtered = [...menuItems];

    // Search term filter
    if (filters.searchTerm) {
      filtered = this.filterMenuItems(filtered, filters.searchTerm);
    }

    // Vegetarian filter
    if (filters.isVegetarian !== undefined) {
      filtered = filtered.filter(item => item.isVegetarian === filters.isVegetarian);
    }

    // Category filter
    if (filters.category) {
      filtered = filtered.filter(item => 
        item.category?.toLowerCase() === filters.category?.toLowerCase()
      );
    }

    // Price range filter
    if (filters.priceRange) {
      filtered = filtered.filter(item => 
        item.price >= filters.priceRange!.min && item.price <= filters.priceRange!.max
      );
    }

    // Availability filter
    if (filters.isAvailable !== undefined) {
      filtered = filtered.filter(item => 
        item.isAvailable === undefined || item.isAvailable === filters.isAvailable
      );
    }

    return filtered;
  }

  // 🔥 NEW: Get vegetarian menu items
  getVegMenuItems(menuItems: MenuItem[]): MenuItem[] {
    return menuItems.filter(item => item.isVegetarian);
  }

  // 🔥 NEW: Get non-vegetarian menu items  
  getNonVegMenuItems(menuItems: MenuItem[]): MenuItem[] {
    return menuItems.filter(item => !item.isVegetarian);
  }

  // 🔥 NEW: Get menu items by category
  getMenuItemsByCategory(menuItems: MenuItem[], category: string): MenuItem[] {
    return menuItems.filter(item => 
      item.category && item.category.toLowerCase() === category.toLowerCase()
    );
  }

  // 🔥 NEW: Get menu price range
  getMenuPriceRange(menuItems: MenuItem[]): { min: number; max: number } {
    if (menuItems.length === 0) {
      return { min: 0, max: 0 };
    }
    
    const prices = menuItems.map(item => item.price);
    return {
      min: Math.min(...prices),
      max: Math.max(...prices)
    };
  }

  // 🔥 ENHANCED: Get comprehensive menu statistics
  getMenuStats(menuItems: MenuItem[]): MenuStats {
    const vegCount = menuItems.filter(item => item.isVegetarian).length;
    const nonVegCount = menuItems.length - vegCount;
    const avgPrice = menuItems.length > 0 ? 
      menuItems.reduce((sum, item) => sum + item.price, 0) / menuItems.length : 0;
    
    const categories = [...new Set(
      menuItems
        .map(item => item.category)
        .filter((category): category is string => 
          category !== undefined && category !== null && category.trim() !== ''
        )
    )];

    const priceRange = this.getMenuPriceRange(menuItems);

    return {
      total: menuItems.length,
      veg: vegCount,
      nonVeg: nonVegCount,
      avgPrice: Math.round(avgPrice),
      categories,
      priceRange
    };
  }

  // 🔥 NEW: Get popular menu items (by category count or other criteria)
  getPopularMenuItems(menuItems: MenuItem[], limit: number = 5): MenuItem[] {
    // Sort by price (could be enhanced with actual popularity metrics)
    return menuItems
      .sort((a, b) => b.price - a.price)
      .slice(0, limit);
  }

  // 🔥 NEW: Get menu categories with item counts
  getMenuCategoriesWithCounts(menuItems: MenuItem[]): {category: string, count: number}[] {
    const categoryMap = new Map<string, number>();
    
    menuItems.forEach(item => {
      if (item.category) {
        const count = categoryMap.get(item.category) || 0;
        categoryMap.set(item.category, count + 1);
      }
    });

    return Array.from(categoryMap.entries())
      .map(([category, count]) => ({ category, count }))
      .sort((a, b) => b.count - a.count);
  }

  // 🔥 NEW: Customer functionality - Get all restaurants
  getAllRestaurants(): Observable<Restaurant[]> {
    console.log('🏪 Fetching all restaurants for customer');
    
    return this.http.get<Restaurant[]>(`${this.restaurantBaseUrl}`, {
      withCredentials: false,
      headers: this.getPublicHeaders()
    }).pipe(
      retry(this.retryCount),
      timeout(this.timeoutDuration),
      tap((restaurants: Restaurant[]) => {
        console.log(`✅ Successfully fetched ${restaurants.length} restaurants`);
        
        // Cache restaurants
        restaurants.forEach(restaurant => {
          this.restaurantCache.set(restaurant.id, {
            data: restaurant,
            timestamp: Date.now()
          });
        });
      }),
      catchError((error: HttpErrorResponse) => {
        console.error('❌ Error fetching restaurants:', error);
        this.logDetailedError(error, 'getAllRestaurants');
        return throwError(() => error);
      })
    );
  }

  // 🔥 NEW: Customer functionality - Get restaurant by ID
  getRestaurantById(id: string): Observable<Restaurant> {
    console.log(`🔍 Fetching restaurant ${id} from database...`);
    
    // Clear any cached data to ensure fresh fetch
    this.restaurantCache.delete(id);
    
    return this.http.get<Restaurant>(`${this.restaurantBaseUrl}/restaurants/${id}`, {
      headers: this.getAuthHeaders()
    }).pipe(
      tap(restaurant => {
        console.log(`✅ Restaurant ${id} fetched from database:`, restaurant);
        // Cache the fresh data
        this.restaurantCache.set(id, {
          data: restaurant,
          timestamp: Date.now()
        });
      }),
      catchError(error => {
        console.error(`❌ Error fetching restaurant ${id} from database:`, error);
        
        if (error.status === 404) {
          throw new Error(`Restaurant with ID ${id} not found in database`);
        } else if (error.status === 401) {
          throw new Error('Authentication required to access restaurant data');
        } else if (error.status >= 500) {
          throw new Error('Database service is temporarily unavailable');
        } else {
          throw new Error(`Failed to fetch restaurant data: ${error.message || 'Unknown error'}`);
        }
      }),
      timeout(this.timeoutDuration)
    );
  }

  // 🔥 NEW: Try alternative restaurant endpoint
  private tryAlternativeRestaurantEndpoint(id: string): Observable<Restaurant> {
    console.log('🔄 Trying alternative restaurant endpoint for ID:', id);
    
    // Try different endpoint patterns
    const alternativeEndpoints = [
      `${this.restaurantBaseUrl}/details/${id}`,
      `${this.restaurantBaseUrl}/info/${id}`,
      `${this.restaurantBaseUrl}/get/${id}`
    ];

    return from(alternativeEndpoints).pipe(
      mergeMap(endpoint => 
        this.http.get<Restaurant>(endpoint, {
          withCredentials: false,
          headers: this.getPublicHeaders()
        }).pipe(
          timeout(5000), // Shorter timeout for fallback attempts
          tap((restaurant: Restaurant) => {
            console.log('✅ Successfully fetched restaurant from alternative endpoint:', endpoint);
            this.restaurantCache.set(id, {
              data: restaurant,
              timestamp: Date.now()
            });
          }),
          catchError(err => {
            console.log(`❌ Alternative endpoint failed: ${endpoint}`, err);
            return EMPTY;
          })
        )
      ),
      take(1), // Take the first successful response
      catchError(() => {
        // If all endpoints fail, return fallback data
        console.log('🛠️ All endpoints failed, returning fallback restaurant data');
        return of(this.createFallbackRestaurant(id));
      })
    );
  }

  // 🔥 NEW: Create fallback restaurant data
  private createFallbackRestaurant(id: string): Restaurant {
    const fallbackRestaurant: Restaurant = {
      id: id,
      name: `Restaurant ${id}`,
      location: 'Location not available',
      email: `restaurant${id}@example.com`,
      rating: 4.0,
      deliveryTime: '30-45 mins',
      deliveryFee: 30,
      minOrder: 100,
      cuisineType: 'Multi-cuisine',
      isOpen: true
    };

    // Cache the fallback data
    this.restaurantCache.set(id, {
      data: fallbackRestaurant,
      timestamp: Date.now()
    });

    return fallbackRestaurant;
  }

  // 🔥 NEW: Get restaurant with menu and stats
  getRestaurantWithMenu(restaurantId: string): Observable<RestaurantWithMenu> {
    console.log('🍽️ Fetching restaurant with menu:', restaurantId);
    
    const restaurantId_num = parseInt(restaurantId);
    
    return forkJoin({
      restaurant: this.getRestaurantById(restaurantId),
      menu: this.getMenuItemsByRestaurant(restaurantId_num)
    }).pipe(
      map(({ restaurant, menu }) => ({
        restaurant,
        menu,
        stats: this.getMenuStats(menu)
      })),
      catchError((error: HttpErrorResponse) => {
        console.error(`❌ Error fetching restaurant with menu ${restaurantId}:`, error);
        this.logDetailedError(error, `getRestaurantWithMenu(${restaurantId})`);
        return throwError(() => error);
      })
    );
  }

  // 🔥 NEW: Search restaurants
  searchRestaurants(query: string): Observable<Restaurant[]> {
    console.log('🔍 Searching restaurants with query:', query);
    
    return this.getAllRestaurants().pipe(
      map(restaurants => {
        if (!query || !query.trim()) {
          return restaurants;
        }
        
        const searchTerm = query.toLowerCase().trim();
        return restaurants.filter(restaurant => 
          restaurant.name.toLowerCase().includes(searchTerm) ||
          restaurant.location.toLowerCase().includes(searchTerm) ||
          restaurant.cuisineType?.toLowerCase().includes(searchTerm) ||
          restaurant.email.toLowerCase().includes(searchTerm)
        );
      })
    );
  }

  // 🔥 NEW: Get restaurants by category
  getRestaurantsByCategory(category: string): Observable<Restaurant[]> {
    console.log('🏷️ Fetching restaurants by category:', category);
    
    return this.getAllRestaurants().pipe(
      map(restaurants => 
        restaurants.filter(restaurant => 
          restaurant.cuisineType?.toLowerCase() === category.toLowerCase()
        )
      )
    );
  }

  // 🔥 NEW: Get menu item by ID (for customer use)
  getMenuItemForCustomer(restaurantId: number, itemId: number): Observable<MenuItem | null> {
    console.log('🍽️ Fetching menu item for customer:', { restaurantId, itemId });
    
    return this.getMenuItemsByRestaurant(restaurantId).pipe(
      map(menuItems => {
        const item = menuItems.find(item => item.itemId === itemId);
        return item || null;
      }),
      catchError((error: HttpErrorResponse) => {
        console.error(`❌ Error fetching menu item ${itemId} for restaurant ${restaurantId}:`, error);
        return of(null);
      })
    );
  }

  // 🔥 NEW: Format menu item for cart compatibility
  formatMenuItemForCart(menuItem: MenuItem): any {
    return {
      id: menuItem.itemId.toString(),
      name: menuItem.itemName,
      description: menuItem.description,
      price: menuItem.price,
      image: menuItem.imageUrl,
      category: menuItem.category,
      isVegetarian: menuItem.isVegetarian,
      isAvailable: menuItem.isAvailable !== false
    };
  }

  // 🔥 NEW: Get restaurant menu formatted for customer
  getMenuByRestaurant(restaurantId: string): Observable<any[]> {
    const restaurantId_num = parseInt(restaurantId);
    
    return this.getMenuItemsByRestaurant(restaurantId_num).pipe(
      map(menuItems => 
        menuItems.map(item => this.formatMenuItemForCart(item))
      )
    );
  }

  // Restaurant-only endpoints (existing methods with minor enhancements)
  getMyRestaurantMenu(): Observable<MenuItem[]> {
    console.log('🔍 Fetching my restaurant menu');
    
    const restaurantId = this.auth.getRestaurantId();
    if (!restaurantId) {
      const error = new Error('Restaurant ID not found. Please login again.');
      console.error('❌ No restaurant ID available');
      return throwError(() => error);
    }
    
    const headers = this.getAuthHeaders();
    
    return this.http.get<MenuItem[]>(`${this.menuBaseUrl}/restaurant`, {
      headers,
      withCredentials: true
    }).pipe(
      retry(this.retryCount),
      timeout(this.timeoutDuration),
      tap((menuItems: MenuItem[]) => {
        console.log(`✅ Retrieved ${menuItems.length} menu items for restaurant ${restaurantId}`);
        
        // Update cache
        this.menuCache.set(parseInt(restaurantId), {
          data: menuItems,
          timestamp: Date.now(),
          restaurantId: parseInt(restaurantId)
        });
      }),
      catchError((error: HttpErrorResponse) => {
        console.error('❌ Error fetching my restaurant menu:', error);
        this.logDetailedError(error, 'getMyRestaurantMenu');
        return throwError(() => error);
      })
    );
  }

  addMenuItem(menuItem: MenuItemRequest): Observable<any> {
    console.log('➕ Adding new menu item:', menuItem);
    
    const headers = this.getAuthHeaders();
    const restaurantId = this.auth.getRestaurantId();
    
    return this.http.post(`${this.menuBaseUrl}/restaurant`, menuItem, {
      headers,
      withCredentials: true
    }).pipe(
      tap((response: any) => {
        console.log('✅ Menu item added successfully:', response);
        
        // Invalidate cache for this restaurant
        if (restaurantId) {
          this.menuCache.delete(parseInt(restaurantId));
        }
      }),
      catchError((error: HttpErrorResponse) => {
        console.error('❌ Error adding menu item:', error);
        this.logDetailedError(error, 'addMenuItem');
        return throwError(() => error);
      })
    );
  }

  updateMenuItem(itemId: number, menuItem: MenuItemRequest): Observable<any> {
    console.log('✏️ Updating menu item:', itemId, menuItem);
    
    if (!itemId || itemId <= 0) {
      return throwError(() => new Error('Invalid item ID provided'));
    }
    
    const headers = this.getAuthHeaders();
    const restaurantId = this.auth.getRestaurantId();
    
    return this.http.put(`${this.menuBaseUrl}/${itemId}`, menuItem, {
      headers,
      withCredentials: true
    }).pipe(
      tap((response: any) => {
        console.log('✅ Menu item updated successfully:', response);
        
        // Invalidate cache for this restaurant
        if (restaurantId) {
          this.menuCache.delete(parseInt(restaurantId));
        }
      }),
      catchError((error: HttpErrorResponse) => {
        console.error(`❌ Error updating menu item ${itemId}:`, error);
        this.logDetailedError(error, `updateMenuItem(${itemId})`);
        return throwError(() => error);
      })
    );
  }

  deleteMenuItem(itemId: number): Observable<any> {
    console.log('🗑️ Deleting menu item:', itemId);
    
    if (!itemId || itemId <= 0) {
      return throwError(() => new Error('Invalid item ID provided'));
    }
    
    const headers = this.getAuthHeaders();
    const restaurantId = this.auth.getRestaurantId();
    
    return this.http.delete(`${this.menuBaseUrl}/${itemId}`, {
      headers,
      withCredentials: true,
      responseType: 'text'
    }).pipe(
      tap((response: any) => {
        console.log('✅ Menu item deleted successfully:', response);
        
        // Invalidate cache for this restaurant
        if (restaurantId) {
          this.menuCache.delete(parseInt(restaurantId));
        }
      }),
      catchError((error: HttpErrorResponse) => {
        console.error(`❌ Error deleting menu item ${itemId}:`, error);
        this.logDetailedError(error, `deleteMenuItem(${itemId})`);
        return throwError(() => error);
      })
    );
  }

  getMenuItemById(itemId: number): Observable<MenuItem> {
    console.log('🔍 Fetching menu item by ID:', itemId);
    
    if (!itemId || itemId <= 0) {
      return throwError(() => new Error('Invalid item ID provided'));
    }
    
    return this.http.get<MenuItem>(`${this.menuBaseUrl}/${itemId}`, {
      headers: this.getPublicHeaders()
    }).pipe(
      retry(this.retryCount),
      timeout(this.timeoutDuration),
      tap((menuItem: MenuItem) => {
        console.log('✅ Retrieved menu item:', menuItem);
      }),
      catchError((error: HttpErrorResponse) => {
        console.error(`❌ Error fetching menu item ${itemId}:`, error);
        this.logDetailedError(error, `getMenuItemById(${itemId})`);
        return throwError(() => error);
      })
    );
  }

  // 🔥 ENHANCED: Cache management methods
  clearMenuCache(restaurantId?: number): void {
    if (restaurantId) {
      this.menuCache.delete(restaurantId);
      this.errorStates.delete(restaurantId);
      this.retryAttempts.delete(restaurantId);
      console.log('🗑️ Cleared cache for restaurant:', restaurantId);
    } else {
      this.menuCache.clear();
      this.restaurantCache.clear(); // 🔥 NEW: Clear restaurant cache too
      this.errorStates.clear();
      this.retryAttempts.clear();
      console.log('🗑️ Cleared all menu and restaurant cache');
    }
  }

  // 🔥 ENHANCED: Get comprehensive cache info
  getCacheInfo(): { 
    size: number; 
    restaurants: number[]; 
    totalItems: number;
    oldestCache: Date | null;
    newestCache: Date | null;
    errorCount: number;
    restaurantCacheSize: number; // 🔥 NEW
  } {
    const restaurants = Array.from(this.menuCache.keys());
    const totalItems = Array.from(this.menuCache.values())
      .reduce((sum, cache) => sum + cache.data.length, 0);
    
    const timestamps = Array.from(this.menuCache.values()).map(cache => cache.timestamp);
    const oldestCache = timestamps.length > 0 ? new Date(Math.min(...timestamps)) : null;
    const newestCache = timestamps.length > 0 ? new Date(Math.max(...timestamps)) : null;
    
    return {
      size: this.menuCache.size,
      restaurants,
      totalItems,
      oldestCache,
      newestCache,
      errorCount: this.errorStates.size,
      restaurantCacheSize: this.restaurantCache.size // 🔥 NEW
    };
  }

  // 🔥 NEW: Service health check
  checkServiceHealth(): Observable<{restaurantService: boolean, menuService: boolean}> {
    console.log('🏥 Checking service health...');
    
    const restaurantHealth = this.http.get(`${this.restaurantBaseUrl}/health`, {
      headers: this.getPublicHeaders()
    }).pipe(
      timeout(5000),
      map(() => true),
      catchError(() => of(false))
    );

    const menuHealth = this.http.get(`${this.menuBaseUrl}/health`, {
      headers: this.getPublicHeaders()
    }).pipe(
      timeout(5000),
      map(() => true),
      catchError(() => of(false))
    );

    return forkJoin({
      restaurantService: restaurantHealth,
      menuService: menuHealth
    }).pipe(
      tap(health => {
        console.log('🏥 Service health check results:', health);
        if (!health.restaurantService) {
          console.warn('⚠️ Restaurant service is not responding');
        }
        if (!health.menuService) {
          console.warn('⚠️ Menu service is not responding');
        }
      })
    );
  }

  // 🔥 NEW: Get service status
  getServiceStatus(): {restaurantService: string, menuService: string} {
    return {
      restaurantService: this.restaurantBaseUrl,
      menuService: this.menuBaseUrl
    };
  }

  // Private helper methods (enhanced)
  private getAuthHeaders(): HttpHeaders {
    const token = this.auth.getToken();
    
    if (token) {
      console.log('🔑 Adding Authorization header with token');
      return new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
        'X-Requested-With': 'XMLHttpRequest'
      });
    } else {
      console.log('⚠️ No token found, sending request without Authorization header');
      return new HttpHeaders({
        'Content-Type': 'application/json',
        'X-Requested-With': 'XMLHttpRequest'
      });
    }
  }

  private getPublicHeaders(): HttpHeaders {
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'X-Requested-With': 'XMLHttpRequest'
    });
  }

  private logDetailedError(error: HttpErrorResponse, method: string): void {
    console.error(`🔍 Detailed error for ${method}:`, {
      status: error.status,
      statusText: error.statusText,
      url: error.url,
      message: error.message,
      error: error.error,
      timestamp: new Date().toISOString()
    });

    if (error.status === 0) {
      console.error('🌐 Network error: Cannot connect to service. Check if the service is running.');
    } else if (error.status === 403) {
      console.error('🔒 Authentication error: Token may be invalid or expired');
    } else if (error.status === 404) {
      console.error('🔍 Not found: Resource does not exist');
    } else if (error.status === 500) {
      console.error('🔥 Server error: Internal server problem - likely no menu items for this restaurant');
    }
  }

  // 🔥 ENHANCED: Public utility methods
  canModifyMenu(): boolean {
    const userType = this.auth.getUserType();
    const isLoggedIn = this.auth.isLoggedIn();
    return isLoggedIn && userType === 'restaurant';
  }

  // 🔥 ENHANCED: Debug service config
  debugServiceConfig(): void {
    console.log('🔍 MenuService Debug Info:', {
      baseUrl: this.menuBaseUrl,
      restaurantBaseUrl: this.restaurantBaseUrl, // 🔥 NEW
      isLoggedIn: this.auth.isLoggedIn(),
      restaurantId: this.auth.getRestaurantId(),
      userType: this.auth.getUserType(),
      hasToken: !!this.auth.getToken(),
      canModifyMenu: this.canModifyMenu(),
      retryCount: this.retryCount,
      timeoutDuration: this.timeoutDuration,
      cacheInfo: this.getCacheInfo(),
      loadingStates: Array.from(this.loadingStates.entries()),
      errorStates: Array.from(this.errorStates.keys())
    });
  }

  // 🔥 ENHANCED: Test connection method
  testConnection(): Observable<any> {
    console.log('🧪 Testing connection to menu service');
    
    const testUrl = `${this.menuBaseUrl}/restaurant/1`;
    const startTime = Date.now();
    
    return this.http.get(testUrl, {
      withCredentials: false,
      headers: this.getPublicHeaders()
    }).pipe(
      timeout(5000),
      tap(() => {
        const responseTime = Date.now() - startTime;
        console.log(`✅ Menu service connection successful (${responseTime}ms)`);
      }),
      catchError((error: HttpErrorResponse) => {
        const responseTime = Date.now() - startTime;
        console.error(`❌ Menu service connection test failed (${responseTime}ms):`, error);
        this.logDetailedError(error, 'testConnection');
        return throwError(() => error);
      })
    );
  }

  // 🔥 NEW: Test restaurant service connection
  testRestaurantConnection(): Observable<any> {
    console.log('🧪 Testing connection to restaurant service');
    
    const testUrl = `${this.restaurantBaseUrl}`;
    const startTime = Date.now();
    
    return this.http.get(testUrl, {
      withCredentials: false,
      headers: this.getPublicHeaders()
    }).pipe(
      timeout(5000),
      tap(() => {
        const responseTime = Date.now() - startTime;
        console.log(`✅ Restaurant service connection successful (${responseTime}ms)`);
      }),
      catchError((error: HttpErrorResponse) => {
        const responseTime = Date.now() - startTime;
        console.error(`❌ Restaurant service connection test failed (${responseTime}ms):`, error);
        this.logDetailedError(error, 'testRestaurantConnection');
        return throwError(() => error);
      })
    );
  }
}

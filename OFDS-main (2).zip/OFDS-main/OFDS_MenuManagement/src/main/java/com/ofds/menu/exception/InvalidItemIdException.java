package com.ofds.menu.exception;

public class InvalidItemIdException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidItemIdException(String message) {
	       super(message);
	   }

}

//package com.ofds.menu.controller;
//
//import java.util.List;
//
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.validation.annotation.Validated;
//import org.springframework.web.bind.annotation.*;
//import jakarta.validation.Valid;
//import jakarta.validation.constraints.NotBlank;
//import jakarta.validation.constraints.NotNull;
//
//import com.ofds.menu.dto.MenuItemRequestDto;
//import com.ofds.menu.dto.MenuItemResponseDto;
//import com.ofds.menu.dto.ResponseMessageDto;
//import com.ofds.menu.service.MenuItemService;
//
//
//
///**
// * Controller for handling menu related operations.
// * Provides REST API endpoints for adding, deleting, updating, viewing the menu.
// *
// */
//@CrossOrigin(origins = "http://localhost:4200")  // Enable CORS for frontend
//@RestController
//@RequestMapping("/api/menu")
//@Validated
//public class MenuItemController {
//
//	private final MenuItemService menuItemService;
//
//	public MenuItemController(MenuItemService menuItemService) {
//		this.menuItemService = menuItemService;
//	}
//
//	@PostMapping("/restaurant")
//	public ResponseEntity<ResponseMessageDto> createMenuItem(
//			@Valid @RequestBody MenuItemRequestDto menuItemRequestDto,
//			@RequestHeader("X-Internal-User-Id") String requestId,
//			@RequestHeader("X-Internal-User-Roles") String roles) {
//
//		if (roles == null || !roles.contains("RESTAURANT")) {
//			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
//		}
//
//		ResponseMessageDto response = menuItemService.createMenuItem(Long.valueOf(requestId), menuItemRequestDto);
//		return new ResponseEntity<>(response, HttpStatus.CREATED);
//	}
//
//	@PutMapping("/{itemId}")
//	public ResponseEntity<ResponseMessageDto> updateMenuItem(
//			@PathVariable Long itemId,
//			@Valid @RequestBody MenuItemRequestDto menuItemRequestDto,
//			@RequestHeader("X-Internal-User-Roles") String roles) {
//
//		if (roles == null || !roles.contains("RESTAURANT")) {
//			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
//		}
//
//		ResponseMessageDto response = menuItemService.updateMenuItem(itemId, menuItemRequestDto);
//		return new ResponseEntity<>(response, HttpStatus.OK);
//	}
//
//	@DeleteMapping("/{itemId}")
//	public ResponseEntity<String> deleteMenuItem(
//			@PathVariable Long itemId,
//			@RequestHeader("X-Internal-User-Roles") String roles) {
//
//		if (roles == null || !roles.contains("RESTAURANT")) {
//			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
//		}
//
//		menuItemService.deleteMenuItem(itemId);
//		return new ResponseEntity<>("Item deleted", HttpStatus.OK);
//	}
//
//	@GetMapping("/{itemId}")
//	public ResponseEntity<MenuItemResponseDto> getMenuItemById(@PathVariable Long itemId) {
//		return new ResponseEntity<>(menuItemService.getMenuItemById(itemId), HttpStatus.OK);
//	}
//
//	@GetMapping("/restaurant/{restaurantId}")
//	public ResponseEntity<List<MenuItemResponseDto>> getMenuItemsByRestaurant(@PathVariable Long restaurantId) {
//		return new ResponseEntity<>(menuItemService.getAllMenuItemsByResturant(restaurantId), HttpStatus.OK);
//	}
//}


//
//package com.ofds.menu.controller;
//
//import java.util.Base64;
//import java.util.List;
//
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.validation.annotation.Validated;
//import org.springframework.web.bind.annotation.*;
//import jakarta.validation.Valid;
//
//import com.ofds.menu.dto.MenuItemRequestDto;
//import com.ofds.menu.dto.MenuItemResponseDto;
//import com.ofds.menu.dto.ResponseMessageDto;
//import com.ofds.menu.service.MenuItemService;
//
//import lombok.extern.slf4j.Slf4j;
//
///**
// * Controller for handling menu related operations.
// * Provides REST API endpoints for adding, deleting, updating, viewing the menu.
// */
//@CrossOrigin(origins = "http://localhost:4200")
//@RestController
//@RequestMapping("/api/menu")
//@Validated
//@Slf4j
//public class MenuItemController {
//
//	private final MenuItemService menuItemService;
//
//	public MenuItemController(MenuItemService menuItemService) {
//		this.menuItemService = menuItemService;
//	}
//
//	@PostMapping("/restaurant")
//	public ResponseEntity<ResponseMessageDto> createMenuItem(
//			@Valid @RequestBody MenuItemRequestDto menuItemRequestDto,
//			@RequestHeader(value = "Authorization", required = false) String authHeader) {
//
//		log.info("Create menu item request received");
//
//		// Extract userId and role from JWT token
//		String userId = extractUserIdFromToken(authHeader);
//		String userRole = extractUserRoleFromToken(authHeader);
//
//		log.info("Extracted from token - userId: {}, role: {}", userId, userRole);
//
//		if (userId == null || userRole == null || !userRole.contains("RESTAURANT")) {
//			log.warn("Unauthorized menu item creation attempt - userId: {}, role: {}", userId, userRole);
//			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
//		}
//
//		try {
//			log.info("Creating menu item for restaurant: {}", userId);
//			ResponseMessageDto response = menuItemService.createMenuItem(Long.valueOf(userId), menuItemRequestDto);
//			log.info("Menu item created successfully for restaurant: {}", userId);
//			return new ResponseEntity<>(response, HttpStatus.CREATED);
//		} catch (Exception e) {
//			log.error("Error creating menu item for restaurant {}: {}", userId, e.getMessage());
//			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
//		}
//	}
//
//	@PutMapping("/{itemId}")
//	public ResponseEntity<ResponseMessageDto> updateMenuItem(
//			@PathVariable Long itemId,
//			@Valid @RequestBody MenuItemRequestDto menuItemRequestDto,
//			@RequestHeader(value = "Authorization", required = false) String authHeader) {
//
//		log.info("Update menu item request received for item: {}", itemId);
//
//		String userId = extractUserIdFromToken(authHeader);
//		String userRole = extractUserRoleFromToken(authHeader);
//
//		if (userId == null || userRole == null || !userRole.contains("RESTAURANT")) {
//			log.warn("Unauthorized menu item update attempt for item: {} - userId: {}, role: {}", itemId, userId, userRole);
//			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
//		}
//
//		try {
//			log.info("Updating menu item: {} by restaurant: {}", itemId, userId);
//			ResponseMessageDto response = menuItemService.updateMenuItem(itemId, menuItemRequestDto);
//			log.info("Menu item updated successfully: {}", itemId);
//			return new ResponseEntity<>(response, HttpStatus.OK);
//		} catch (Exception e) {
//			log.error("Error updating menu item {}: {}", itemId, e.getMessage());
//			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
//		}
//	}
//
//	@DeleteMapping("/{itemId}")
//	public ResponseEntity<String> deleteMenuItem(
//			@PathVariable Long itemId,
//			@RequestHeader(value = "Authorization", required = false) String authHeader) {
//
//		log.info("Delete menu item request received for item: {}", itemId);
//
//		String userId = extractUserIdFromToken(authHeader);
//		String userRole = extractUserRoleFromToken(authHeader);
//
//		if (userId == null || userRole == null || !userRole.contains("RESTAURANT")) {
//			log.warn("Unauthorized menu item deletion attempt for item: {} - userId: {}, role: {}", itemId, userId, userRole);
//			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
//		}
//
//		try {
//			log.info("Deleting menu item: {} by restaurant: {}", itemId, userId);
//			menuItemService.deleteMenuItem(itemId);
//			log.info("Menu item deleted successfully: {}", itemId);
//			return new ResponseEntity<>("Item deleted", HttpStatus.OK);
//		} catch (Exception e) {
//			log.error("Error deleting menu item {}: {}", itemId, e.getMessage());
//			return new ResponseEntity<>("Error deleting item", HttpStatus.INTERNAL_SERVER_ERROR);
//		}
//	}
//
//	@GetMapping("/{itemId}")
//	public ResponseEntity<MenuItemResponseDto> getMenuItemById(@PathVariable Long itemId) {
//		log.info("Get menu item request received for item: {}", itemId);
//
//		try {
//			MenuItemResponseDto menuItem = menuItemService.getMenuItemById(itemId);
//			log.info("Menu item retrieved successfully: {}", itemId);
//			return new ResponseEntity<>(menuItem, HttpStatus.OK);
//		} catch (Exception e) {
//			log.error("Error retrieving menu item {}: {}", itemId, e.getMessage());
//			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
//		}
//	}
//
//	@GetMapping("/restaurant/{restaurantId}")
//	public ResponseEntity<List<MenuItemResponseDto>> getMenuItemsByRestaurant(@PathVariable Long restaurantId) {
//		log.info("Get menu items request received for restaurant: {}", restaurantId);
//
//		try {
//			List<MenuItemResponseDto> menuItems = menuItemService.getAllMenuItemsByResturant(restaurantId);
//			log.info("Menu items retrieved successfully for restaurant: {} - Found {} items", restaurantId, menuItems.size());
//			return new ResponseEntity<>(menuItems, HttpStatus.OK);
//		} catch (Exception e) {
//			log.error("Error retrieving menu items for restaurant {}: {}", restaurantId, e.getMessage());
//			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
//		}
//	}
//
//	// ✅ Enhanced endpoint for restaurant to get their own menu
//	@GetMapping("/restaurant")
//	public ResponseEntity<List<MenuItemResponseDto>> getMyRestaurantMenu(
//			@RequestHeader(value = "Authorization", required = false) String authHeader) {
//
//		log.info("Get my restaurant menu request received");
//
//		String userId = extractUserIdFromToken(authHeader);
//		String userRole = extractUserRoleFromToken(authHeader);
//
//		if (userId == null || userRole == null || !userRole.contains("RESTAURANT")) {
//			log.warn("Unauthorized restaurant menu access attempt - userId: {}, role: {}", userId, userRole);
//			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
//		}
//
//		try {
//			List<MenuItemResponseDto> menuItems = menuItemService.getAllMenuItemsByResturant(Long.valueOf(userId));
//			log.info("Restaurant menu retrieved successfully for restaurant: {} - Found {} items", userId, menuItems.size());
//			return new ResponseEntity<>(menuItems, HttpStatus.OK);
//		} catch (Exception e) {
//			log.error("Error retrieving menu items for restaurant {}: {}", userId, e.getMessage());
//			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
//		}
//	}
//
//	// ✅ Helper method to extract userId from JWT token
//	private String extractUserIdFromToken(String authHeader) {
//		if (authHeader == null || !authHeader.startsWith("Bearer ")) {
//			log.debug("No Bearer token found in Authorization header");
//			return null;
//		}
//
//		try {
//			String token = authHeader.substring(7);
//			String[] parts = token.split("\\.");
//			if (parts.length != 3) {
//				log.warn("Invalid JWT token format - expected 3 parts, got {}", parts.length);
//				return null;
//			}
//
//			String payload = new String(Base64.getUrlDecoder().decode(parts[1]));
//
//			if (payload.contains("\"userId\":")) {
//				String userIdPart = payload.substring(payload.indexOf("\"userId\":") + 9);
//
//				if (userIdPart.startsWith("\"")) {
//					int endIndex = userIdPart.indexOf("\"", 1);
//					if (endIndex > 0) {
//						String extractedUserId = userIdPart.substring(1, endIndex);
//						log.debug("Extracted string userId: {}", extractedUserId);
//						return extractedUserId;
//					}
//				} else {
//					int endIndex = Math.min(
//							userIdPart.indexOf(",") != -1 ? userIdPart.indexOf(",") : Integer.MAX_VALUE,
//							userIdPart.indexOf("}") != -1 ? userIdPart.indexOf("}") : Integer.MAX_VALUE
//					);
//					if (endIndex > 0 && endIndex != Integer.MAX_VALUE) {
//						String extractedUserId = userIdPart.substring(0, endIndex).trim();
//						log.debug("Extracted numeric userId: {}", extractedUserId);
//						return extractedUserId;
//					}
//				}
//			}
//
//			log.warn("userId not found in JWT token payload");
//			return null;
//
//		} catch (Exception e) {
//			log.error("Error extracting userId from token: {}", e.getMessage());
//			return null;
//		}
//	}
//
//	// ✅ Helper method to extract user role from JWT token
//	private String extractUserRoleFromToken(String authHeader) {
//		if (authHeader == null || !authHeader.startsWith("Bearer ")) {
//			log.debug("No Bearer token found in Authorization header for role extraction");
//			return null;
//		}
//
//		try {
//			String token = authHeader.substring(7);
//			String[] parts = token.split("\\.");
//			if (parts.length != 3) {
//				log.warn("Invalid JWT token format for role extraction");
//				return null;
//			}
//
//			String payload = new String(Base64.getUrlDecoder().decode(parts[1]));
//
//			if (payload.contains("\"roles\":[")) {
//				String rolesPart = payload.substring(payload.indexOf("\"roles\":[") + 9);
//				int endIndex = rolesPart.indexOf("]");
//				if (endIndex > 0) {
//					String extractedRoles = rolesPart.substring(0, endIndex + 1);
//					log.debug("Extracted roles: {}", extractedRoles);
//					return extractedRoles;
//				}
//			}
//
//			log.warn("roles not found in JWT token payload");
//			return null;
//
//		} catch (Exception e) {
//			log.error("Error extracting roles from token: {}", e.getMessage());
//			return null;
//		}
//	}
//}
//
//package com.ofds.menu.controller;
//
//import java.util.Base64;
//import java.util.List;
//
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.validation.annotation.Validated;
//import org.springframework.web.bind.annotation.*;
//import jakarta.validation.Valid;
//
//import com.ofds.menu.dto.MenuItemRequestDto;
//import com.ofds.menu.dto.MenuItemResponseDto;
//import com.ofds.menu.dto.ResponseMessageDto;
//import com.ofds.menu.service.MenuItemService;
//
//import lombok.extern.slf4j.Slf4j;
//
///**
// * Controller for handling menu related operations.
// * Provides REST API endpoints for adding, deleting, updating, viewing the menu.
// */
//@CrossOrigin(origins = "http://localhost:4200")
//@RestController
//@RequestMapping("/api/menu")
//@Validated
//@Slf4j
//public class MenuItemController {
//
//	private final MenuItemService menuItemService;
//
//	public MenuItemController(MenuItemService menuItemService) {
//		this.menuItemService = menuItemService;
//	}
//
//	@PostMapping("/restaurant")
//	public ResponseEntity<ResponseMessageDto> createMenuItem(
//			@Valid @RequestBody MenuItemRequestDto menuItemRequestDto,
//			@RequestHeader(value = "Authorization", required = false) String authHeader) {
//
//		log.info("Create menu item request received");
//
//		// Extract userId and role from JWT token
//		String userId = extractUserIdFromToken(authHeader);
//		String userRole = extractUserRoleFromToken(authHeader);
//
//		log.info("Extracted from token - userId: {}, role: {}", userId, userRole);
//
//		if (userId == null || userRole == null || !userRole.contains("RESTAURANT")) {
//			log.warn("Unauthorized menu item creation attempt - userId: {}, role: {}", userId, userRole);
//			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
//		}
//
//		try {
//			log.info("Creating menu item for restaurant: {}", userId);
//			ResponseMessageDto response = menuItemService.createMenuItem(Long.valueOf(userId), menuItemRequestDto);
//			log.info("Menu item created successfully for restaurant: {}", userId);
//			return new ResponseEntity<>(response, HttpStatus.CREATED);
//		} catch (Exception e) {
//			log.error("Error creating menu item for restaurant {}: {}", userId, e.getMessage());
//			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
//		}
//	}
//
//	@PutMapping("/{itemId}")
//	public ResponseEntity<ResponseMessageDto> updateMenuItem(
//			@PathVariable Long itemId,
//			@Valid @RequestBody MenuItemRequestDto menuItemRequestDto,
//			@RequestHeader(value = "Authorization", required = false) String authHeader) {
//
//		log.info("Update menu item request received for item: {}", itemId);
//
//		String userId = extractUserIdFromToken(authHeader);
//		String userRole = extractUserRoleFromToken(authHeader);
//
//		if (userId == null || userRole == null || !userRole.contains("RESTAURANT")) {
//			log.warn("Unauthorized menu item update attempt for item: {} - userId: {}, role: {}", itemId, userId, userRole);
//			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
//		}
//
//		try {
//			log.info("Updating menu item: {} by restaurant: {}", itemId, userId);
//			ResponseMessageDto response = menuItemService.updateMenuItem(itemId, menuItemRequestDto);
//			log.info("Menu item updated successfully: {}", itemId);
//			return new ResponseEntity<>(response, HttpStatus.OK);
//		} catch (Exception e) {
//			log.error("Error updating menu item {}: {}", itemId, e.getMessage());
//			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
//		}
//	}
//
//	@DeleteMapping("/{itemId}")
//	public ResponseEntity<String> deleteMenuItem(
//			@PathVariable Long itemId,
//			@RequestHeader(value = "Authorization", required = false) String authHeader) {
//
//		log.info("Delete menu item request received for item: {}", itemId);
//
//		String userId = extractUserIdFromToken(authHeader);
//		String userRole = extractUserRoleFromToken(authHeader);
//
//		if (userId == null || userRole == null || !userRole.contains("RESTAURANT")) {
//			log.warn("Unauthorized menu item deletion attempt for item: {} - userId: {}, role: {}", itemId, userId, userRole);
//			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
//		}
//
//		try {
//			log.info("Deleting menu item: {} by restaurant: {}", itemId, userId);
//			menuItemService.deleteMenuItem(itemId);
//			log.info("Menu item deleted successfully: {}", itemId);
//			return new ResponseEntity<>("Item deleted", HttpStatus.OK);
//		} catch (Exception e) {
//			log.error("Error deleting menu item {}: {}", itemId, e.getMessage());
//			return new ResponseEntity<>("Error deleting item", HttpStatus.INTERNAL_SERVER_ERROR);
//		}
//	}
//
//	@GetMapping("/{itemId}")
//	public ResponseEntity<MenuItemResponseDto> getMenuItemById(@PathVariable Long itemId) {
//		log.info("Get menu item request received for item: {}", itemId);
//
//		try {
//			MenuItemResponseDto menuItem = menuItemService.getMenuItemById(itemId);
//			log.info("Menu item retrieved successfully: {}", itemId);
//			return new ResponseEntity<>(menuItem, HttpStatus.OK);
//		} catch (Exception e) {
//			log.error("Error retrieving menu item {}: {}", itemId, e.getMessage());
//			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
//		}
//	}
//
//	// 🔥 FIXED: Allow customers to view restaurant menus
//	@GetMapping("/restaurant/{restaurantId}")
//	public ResponseEntity<List<MenuItemResponseDto>> getMenuItemsByRestaurant(
//			@PathVariable Long restaurantId,
//			@RequestHeader(value = "Authorization", required = false) String authHeader) {
//
//		log.info("Get menu items request received for restaurant: {}", restaurantId);
//
//		// Allow both CUSTOMER and RESTAURANT roles to view menus
//		String userRole = extractUserRoleFromToken(authHeader);
//
//		if (authHeader != null && userRole != null) {
//			if (userRole.contains("CUSTOMER") || userRole.contains("RESTAURANT")) {
//				log.info("Authorized user (role: {}) accessing menu for restaurant: {}", userRole, restaurantId);
//			} else {
//				log.warn("Unauthorized menu access attempt - role: {}", userRole);
//				return new ResponseEntity<>(HttpStatus.FORBIDDEN);
//			}
//		} else {
//			log.info("Public access to menu for restaurant: {}", restaurantId);
//			// Allow public access to view menus (no authentication required)
//		}
//
//		try {
//			List<MenuItemResponseDto> menuItems = menuItemService.getAllMenuItemsByResturant(restaurantId);
//			log.info("Menu items retrieved successfully for restaurant: {} - Found {} items", restaurantId, menuItems.size());
//			return new ResponseEntity<>(menuItems, HttpStatus.OK);
//		} catch (Exception e) {
//			log.error("Error retrieving menu items for restaurant {}: {}", restaurantId, e.getMessage());
//			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
//		}
//	}
//
//	// ✅ Enhanced endpoint for restaurant to get their own menu
//	@GetMapping("/restaurant")
//	public ResponseEntity<List<MenuItemResponseDto>> getMyRestaurantMenu(
//			@RequestHeader(value = "Authorization", required = false) String authHeader) {
//
//		log.info("Get my restaurant menu request received");
//
//		String userId = extractUserIdFromToken(authHeader);
//		String userRole = extractUserRoleFromToken(authHeader);
//
//		if (userId == null || userRole == null || !userRole.contains("RESTAURANT")) {
//			log.warn("Unauthorized restaurant menu access attempt - userId: {}, role: {}", userId, userRole);
//			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
//		}
//
//		try {
//			List<MenuItemResponseDto> menuItems = menuItemService.getAllMenuItemsByResturant(Long.valueOf(userId));
//			log.info("Restaurant menu retrieved successfully for restaurant: {} - Found {} items", userId, menuItems.size());
//			return new ResponseEntity<>(menuItems, HttpStatus.OK);
//		} catch (Exception e) {
//			log.error("Error retrieving menu items for restaurant {}: {}", userId, e.getMessage());
//			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
//		}
//	}
//
//	// ✅ Helper method to extract userId from JWT token
//	private String extractUserIdFromToken(String authHeader) {
//		if (authHeader == null || !authHeader.startsWith("Bearer ")) {
//			log.debug("No Bearer token found in Authorization header");
//			return null;
//		}
//
//		try {
//			String token = authHeader.substring(7);
//			String[] parts = token.split("\\.");
//			if (parts.length != 3) {
//				log.warn("Invalid JWT token format - expected 3 parts, got {}", parts.length);
//				return null;
//			}
//
//			String payload = new String(Base64.getUrlDecoder().decode(parts[1]));
//
//			if (payload.contains("\"userId\":")) {
//				String userIdPart = payload.substring(payload.indexOf("\"userId\":") + 9);
//
//				if (userIdPart.startsWith("\"")) {
//					int endIndex = userIdPart.indexOf("\"", 1);
//					if (endIndex > 0) {
//						String extractedUserId = userIdPart.substring(1, endIndex);
//						log.debug("Extracted string userId: {}", extractedUserId);
//						return extractedUserId;
//					}
//				} else {
//					int endIndex = Math.min(
//							userIdPart.indexOf(",") != -1 ? userIdPart.indexOf(",") : Integer.MAX_VALUE,
//							userIdPart.indexOf("}") != -1 ? userIdPart.indexOf("}") : Integer.MAX_VALUE
//					);
//					if (endIndex > 0 && endIndex != Integer.MAX_VALUE) {
//						String extractedUserId = userIdPart.substring(0, endIndex).trim();
//						log.debug("Extracted numeric userId: {}", extractedUserId);
//						return extractedUserId;
//					}
//				}
//			}
//
//			log.warn("userId not found in JWT token payload");
//			return null;
//
//		} catch (Exception e) {
//			log.error("Error extracting userId from token: {}", e.getMessage());
//			return null;
//		}
//	}
//
//	// ✅ Helper method to extract user role from JWT token
//	private String extractUserRoleFromToken(String authHeader) {
//		if (authHeader == null || !authHeader.startsWith("Bearer ")) {
//			log.debug("No Bearer token found in Authorization header for role extraction");
//			return null;
//		}
//
//		try {
//			String token = authHeader.substring(7);
//			String[] parts = token.split("\\.");
//			if (parts.length != 3) {
//				log.warn("Invalid JWT token format for role extraction");
//				return null;
//			}
//
//			String payload = new String(Base64.getUrlDecoder().decode(parts[1]));
//
//			if (payload.contains("\"roles\":[")) {
//				String rolesPart = payload.substring(payload.indexOf("\"roles\":[") + 9);
//				int endIndex = rolesPart.indexOf("]");
//				if (endIndex > 0) {
//					String extractedRoles = rolesPart.substring(0, endIndex + 1);
//					log.debug("Extracted roles: {}", extractedRoles);
//					return extractedRoles;
//				}
//			}
//
//			log.warn("roles not found in JWT token payload");
//			return null;
//
//		} catch (Exception e) {
//			log.error("Error extracting roles from token: {}", e.getMessage());
//			return null;
//		}
//	}
//}
//


package com.ofds.menu.controller;

import java.util.Base64;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

import com.ofds.menu.dto.MenuItemRequestDto;
import com.ofds.menu.dto.MenuItemResponseDto;
import com.ofds.menu.dto.ResponseMessageDto;
import com.ofds.menu.service.MenuItemService;

import lombok.extern.slf4j.Slf4j;

@CrossOrigin(origins = {"http://localhost:4200", "http://127.0.0.1:4200"})
@RestController
@RequestMapping("/api/menu")
@Validated
@Slf4j
public class MenuItemController {

	private final MenuItemService menuItemService;

	public MenuItemController(MenuItemService menuItemService) {
		this.menuItemService = menuItemService;
	}

	// 🔥 FIXED: Completely public endpoint for viewing restaurant menus
	@GetMapping("/restaurant/{restaurantId}")
	public ResponseEntity<List<MenuItemResponseDto>> getMenuItemsByRestaurant(
			@PathVariable Long restaurantId) {

		log.info("🌐 PUBLIC ACCESS: Get menu items for restaurant: {}", restaurantId);

		try {
			List<MenuItemResponseDto> menuItems = menuItemService.getAllMenuItemsByResturant(restaurantId);
			log.info("✅ Menu items retrieved successfully for restaurant: {} - Found {} items",
					restaurantId, menuItems.size());

			// Debug log each menu item
			menuItems.forEach(item ->
					log.info("📋 Menu item: ID={}, Name={}, Price=₹{}, Veg={}",
							item.getItemId(), item.getItemName(), item.getPrice(), item.getIsVegetarian()));

			return new ResponseEntity<>(menuItems, HttpStatus.OK);
		} catch (Exception e) {
			log.error("❌ Error retrieving menu items for restaurant {}: {}", restaurantId, e.getMessage(), e);
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	// Restaurant authentication required endpoints below

	@PostMapping("/restaurant")
	public ResponseEntity<ResponseMessageDto> createMenuItem(
			@Valid @RequestBody MenuItemRequestDto menuItemRequestDto,
			@RequestHeader(value = "Authorization", required = false) String authHeader) {

		log.info("➕ Create menu item request received");

		String userId = extractUserIdFromToken(authHeader);
		String userRole = extractUserRoleFromToken(authHeader);

		if (userId == null || userRole == null || !userRole.contains("RESTAURANT")) {
			log.warn("⛔ Unauthorized menu item creation - userId: {}, role: {}", userId, userRole);
			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
		}

		try {
			ResponseMessageDto response = menuItemService.createMenuItem(Long.valueOf(userId), menuItemRequestDto);
			log.info("✅ Menu item created successfully for restaurant: {}", userId);
			return new ResponseEntity<>(response, HttpStatus.CREATED);
		} catch (Exception e) {
			log.error("❌ Error creating menu item: {}", e.getMessage(), e);
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("/restaurant")
	public ResponseEntity<List<MenuItemResponseDto>> getMyRestaurantMenu(
			@RequestHeader(value = "Authorization", required = false) String authHeader) {

		log.info("📋 Get my restaurant menu request received");

		String userId = extractUserIdFromToken(authHeader);
		String userRole = extractUserRoleFromToken(authHeader);

		if (userId == null || userRole == null || !userRole.contains("RESTAURANT")) {
			log.warn("⛔ Unauthorized restaurant menu access - userId: {}, role: {}", userId, userRole);
			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
		}

		try {
			List<MenuItemResponseDto> menuItems = menuItemService.getAllMenuItemsByResturant(Long.valueOf(userId));
			log.info("✅ Restaurant menu retrieved for restaurant: {} - Found {} items", userId, menuItems.size());
			return new ResponseEntity<>(menuItems, HttpStatus.OK);
		} catch (Exception e) {
			log.error("❌ Error retrieving menu for restaurant {}: {}", userId, e.getMessage(), e);
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PutMapping("/{itemId}")
	public ResponseEntity<ResponseMessageDto> updateMenuItem(
			@PathVariable Long itemId,
			@Valid @RequestBody MenuItemRequestDto menuItemRequestDto,
			@RequestHeader(value = "Authorization", required = false) String authHeader) {

		String userId = extractUserIdFromToken(authHeader);
		String userRole = extractUserRoleFromToken(authHeader);

		if (userId == null || userRole == null || !userRole.contains("RESTAURANT")) {
			log.warn("⛔ Unauthorized menu update - item: {}, userId: {}, role: {}", itemId, userId, userRole);
			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
		}

		try {
			ResponseMessageDto response = menuItemService.updateMenuItem(itemId, menuItemRequestDto);
			log.info("✅ Menu item updated successfully: {}", itemId);
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (Exception e) {
			log.error("❌ Error updating menu item {}: {}", itemId, e.getMessage(), e);
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@DeleteMapping("/{itemId}")
	public ResponseEntity<String> deleteMenuItem(
			@PathVariable Long itemId,
			@RequestHeader(value = "Authorization", required = false) String authHeader) {

		String userId = extractUserIdFromToken(authHeader);
		String userRole = extractUserRoleFromToken(authHeader);

		if (userId == null || userRole == null || !userRole.contains("RESTAURANT")) {
			log.warn("⛔ Unauthorized menu deletion - item: {}, userId: {}, role: {}", itemId, userId, userRole);
			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
		}

		try {
			menuItemService.deleteMenuItem(itemId);
			log.info("✅ Menu item deleted successfully: {}", itemId);
			return new ResponseEntity<>("Item deleted", HttpStatus.OK);
		} catch (Exception e) {
			log.error("❌ Error deleting menu item {}: {}", itemId, e.getMessage(), e);
			return new ResponseEntity<>("Error deleting item", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("/{itemId}")
	public ResponseEntity<MenuItemResponseDto> getMenuItemById(@PathVariable Long itemId) {
		try {
			MenuItemResponseDto menuItem = menuItemService.getMenuItemById(itemId);
			return new ResponseEntity<>(menuItem, HttpStatus.OK);
		} catch (Exception e) {
			log.error("❌ Error retrieving menu item {}: {}", itemId, e.getMessage());
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	// JWT token parsing helper methods
	private String extractUserIdFromToken(String authHeader) {
		if (authHeader == null || !authHeader.startsWith("Bearer ")) {
			return null;
		}

		try {
			String token = authHeader.substring(7);
			String[] parts = token.split("\\.");
			if (parts.length != 3) return null;

			String payload = new String(Base64.getUrlDecoder().decode(parts[1]));

			if (payload.contains("\"userId\":")) {
				String userIdPart = payload.substring(payload.indexOf("\"userId\":") + 9);
				if (userIdPart.startsWith("\"")) {
					int endIndex = userIdPart.indexOf("\"", 1);
					return endIndex > 0 ? userIdPart.substring(1, endIndex) : null;
				} else {
					int endIndex = Math.min(
							userIdPart.indexOf(",") != -1 ? userIdPart.indexOf(",") : Integer.MAX_VALUE,
							userIdPart.indexOf("}") != -1 ? userIdPart.indexOf("}") : Integer.MAX_VALUE
					);
					return endIndex > 0 && endIndex != Integer.MAX_VALUE ?
							userIdPart.substring(0, endIndex).trim() : null;
				}
			}
			return null;
		} catch (Exception e) {
			log.error("❌ Error extracting userId from token: {}", e.getMessage());
			return null;
		}
	}

	private String extractUserRoleFromToken(String authHeader) {
		if (authHeader == null || !authHeader.startsWith("Bearer ")) {
			return null;
		}

		try {
			String token = authHeader.substring(7);
			String[] parts = token.split("\\.");
			if (parts.length != 3) return null;

			String payload = new String(Base64.getUrlDecoder().decode(parts[1]));

			if (payload.contains("\"roles\":[")) {
				String rolesPart = payload.substring(payload.indexOf("\"roles\":[") + 9);
				int endIndex = rolesPart.indexOf("]");
				return endIndex > 0 ? rolesPart.substring(0, endIndex + 1) : null;
			}
			return null;
		} catch (Exception e) {
			log.error("❌ Error extracting roles from token: {}", e.getMessage());
			return null;
		}
	}
}


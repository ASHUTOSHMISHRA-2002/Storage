//package com.fooddelivery.orderservicef.dto;
//
//import java.util.UUID;
//
//import jakarta.validation.constraints.NotBlank;
//import jakarta.validation.constraints.NotNull;
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//@Data
//@NoArgsConstructor
//@AllArgsConstructor
//public class OrderRequestDTO {
//    private Long userId;
//    @NotNull(message = "Restaurant ID is required")
//    private Long restaurantId;
//    @NotBlank(message = "Delivery address is required")
//    private String deliveryAddress;
//}

//package com.fooddelivery.orderservicef.dto;
//
//import jakarta.validation.Valid;
//import jakarta.validation.constraints.*;
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//import java.util.List;
//
//@Data
//@NoArgsConstructor
//@AllArgsConstructor
//public class OrderRequestDTO {
//    private Long userId;
//
//    @NotNull(message = "Restaurant ID is required")
//    private Long restaurantId;
//
//    @NotBlank(message = "Delivery address is required")
//    private String deliveryAddress;
//
//    // ✅ ADD: Missing fields that frontend sends
//    @NotNull(message = "Items are required")
//    @NotEmpty(message = "Order must contain at least one item")
//    @Valid
//    private List<OrderItemDTO> items;
//
//    @NotNull(message = "Total amount is required")
//    @DecimalMin(value = "0.01", message = "Total amount must be greater than 0")
//    private Double totalAmount;
//
//    // Customer details
//    private String customerName;
//    private String customerPhone;
//    private String customerEmail;
//
//    // Optional fields
//    private String restaurantName;
//    private String notes;
//    private String paymentMethod;
//}


package com.fooddelivery.orderservicef.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrderRequestDTO {

    private Long userId; // Will be set from JWT token

    @NotNull(message = "Restaurant ID is required")
    private Long restaurantId;

    @NotBlank(message = "Delivery address is required")
    @Size(min = 10, max = 500, message = "Delivery address must be between 10 and 500 characters")
    private String deliveryAddress;

    // ✅ ENHANCED: Added missing fields that frontend sends
    @NotNull(message = "Items are required")
    @NotEmpty(message = "Order must contain at least one item")
    @Valid
    private List<OrderItemDTO> items;

    @NotNull(message = "Total amount is required")
    @DecimalMin(value = "0.01", message = "Total amount must be greater than 0")
    private Double totalAmount;

    // ✅ Customer information
    @NotBlank(message = "Customer name is required")
    @Size(min = 2, max = 100, message = "Customer name must be between 2 and 100 characters")
    private String customerName;

    @NotBlank(message = "Customer phone is required")
    @Pattern(regexp = "^[6-9]\\d{9}$", message = "Phone number must be a valid 10-digit Indian mobile number")
    private String customerPhone;

    @NotBlank(message = "Customer email is required")
    @Email(message = "Email must be valid")
    private String customerEmail;

    // ✅ Optional fields
    private String restaurantName;
    private String notes;
    private String paymentMethod;
    private String deliveryInstructions;

    // ✅ Address details
    private String city;
    private String state;
    private String pincode;

    // ✅ Timing preferences
    private LocalDateTime preferredDeliveryTime;
    private String deliverySlot;
}

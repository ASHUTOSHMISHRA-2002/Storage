//package com.fooddelivery.orderservicef.repository;
//
//import java.util.List;
//import java.util.Optional;
//import java.util.UUID;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Lock;
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.stereotype.Repository;
//
//import com.fooddelivery.orderservicef.model.Order;
//import com.fooddelivery.orderservicef.model.OrderStatus;
//
//import jakarta.persistence.LockModeType;
//
//@Repository
//public interface OrderRepository extends JpaRepository<Order, Long> {
//	List<Order> findByUserId(Long userId);
//
//	List<Order> findByRestaurantId(Long restaurantId);
//
//	@Lock(LockModeType.PESSIMISTIC_WRITE)
//	@Query("SELECT o FROM Order o WHERE o.orderId = :orderId")
//	Optional<Order> findByIdWithLock(Long orderId);
//
//	boolean existsByIdempotencyKey(String idempotencyKey);
//
//	Optional<Order> findByIdempotencyKey(String idempotencyKey);
//}

package com.fooddelivery.orderservicef.repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.fooddelivery.orderservicef.model.Order;
import com.fooddelivery.orderservicef.model.OrderStatus;

import jakarta.persistence.LockModeType;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {

	// ✅ EXISTING: Keep all your current methods
	List<Order> findByUserId(Long userId);

	List<Order> findByRestaurantId(Long restaurantId);

	@Lock(LockModeType.PESSIMISTIC_WRITE)
	@Query("SELECT o FROM Order o WHERE o.orderId = :orderId")
	Optional<Order> findByIdWithLock(Long orderId);

	boolean existsByIdempotencyKey(String idempotencyKey);

	Optional<Order> findByIdempotencyKey(String idempotencyKey);

	// ✅ NEW: Added methods for restaurant dashboard functionality

	/**
	 * Find orders by restaurant ID and specific statuses (for active orders)
	 */
	List<Order> findByRestaurantIdAndStatusIn(Long restaurantId, List<OrderStatus> statuses);

	/**
	 * Find all orders by restaurant ID ordered by most recent first
	 */
	List<Order> findByRestaurantIdOrderByOrderTimeDesc(Long restaurantId);

	/**
	 * Find orders by restaurant ID with pagination support
	 */
	Page<Order> findByRestaurantIdOrderByOrderTimeDesc(Long restaurantId, Pageable pageable);

	/**
	 * Find orders by user ID ordered by most recent first
	 */
	List<Order> findByUserIdOrderByOrderTimeDesc(Long userId);

	/**
	 * Find orders by user ID with pagination support
	 */
	Page<Order> findByUserIdOrderByOrderTimeDesc(Long userId, Pageable pageable);

	/**
	 * Custom query for active orders only with specific statuses
	 */
	@Query("SELECT o FROM Order o WHERE o.restaurantId = :restaurantId AND o.status IN :statuses ORDER BY o.orderTime DESC")
	List<Order> findActiveOrdersByRestaurantId(@Param("restaurantId") Long restaurantId, @Param("statuses") List<OrderStatus> statuses);

	/**
	 * Find orders by status
	 */
	List<Order> findByStatus(OrderStatus status);

	/**
	 * Find orders by restaurant ID and status
	 */
	List<Order> findByRestaurantIdAndStatus(Long restaurantId, OrderStatus status);

	/**
	 * Find orders by user ID and status
	 */
	List<Order> findByUserIdAndStatus(Long userId, OrderStatus status);

	/**
	 * Count active orders for a restaurant
	 */
	@Query("SELECT COUNT(o) FROM Order o WHERE o.restaurantId = :restaurantId AND o.status IN :statuses")
	long countActiveOrdersByRestaurantId(@Param("restaurantId") Long restaurantId, @Param("statuses") List<OrderStatus> statuses);

	/**
	 * Find recent orders for a restaurant (last N orders)
	 */
	@Query("SELECT o FROM Order o WHERE o.restaurantId = :restaurantId ORDER BY o.orderTime DESC")
	Page<Order> findRecentOrdersByRestaurantId(@Param("restaurantId") Long restaurantId, Pageable pageable);

	/**
	 * Find orders by restaurant ID within date range
	 */
	@Query("SELECT o FROM Order o WHERE o.restaurantId = :restaurantId AND o.orderTime BETWEEN :startDate AND :endDate ORDER BY o.orderTime DESC")
	List<Order> findByRestaurantIdAndOrderTimeBetween(
			@Param("restaurantId") Long restaurantId,
			@Param("startDate") java.time.LocalDateTime startDate,
			@Param("endDate") java.time.LocalDateTime endDate
	);

	/**
	 * Find orders by multiple restaurant IDs (useful for chain restaurants)
	 */
	List<Order> findByRestaurantIdInOrderByOrderTimeDesc(List<Long> restaurantIds);

	/**
	 * Check if any active orders exist for a restaurant
	 */
	@Query("SELECT CASE WHEN COUNT(o) > 0 THEN true ELSE false END FROM Order o WHERE o.restaurantId = :restaurantId AND o.status IN :statuses")
	boolean hasActiveOrders(@Param("restaurantId") Long restaurantId, @Param("statuses") List<OrderStatus> statuses);
}

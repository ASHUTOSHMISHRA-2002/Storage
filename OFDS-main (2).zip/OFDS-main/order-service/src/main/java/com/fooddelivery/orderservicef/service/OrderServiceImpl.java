//package com.fooddelivery.orderservicef.service;
//import java.math.BigDecimal;
//import java.time.Duration;
//import java.time.LocalDateTime;
//import java.util.Collections;
//import java.util.List;
//import java.util.Random;
//import java.util.concurrent.CompletableFuture;
//import java.util.stream.Collectors;
//
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Isolation;
//import org.springframework.transaction.annotation.Transactional;
//
//import com.fooddelivery.orderservicef.dto.AgentAssignmentDTO;
//import com.fooddelivery.orderservicef.dto.AgentResponseDTO;
//// New import
//import com.fooddelivery.orderservicef.dto.CartDTO;
//import com.fooddelivery.orderservicef.dto.DeliveryStatus;
//import com.fooddelivery.orderservicef.dto.DeliveryStatusUpdateRequestDTO;
//import com.fooddelivery.orderservicef.dto.OrderDTO;
//import com.fooddelivery.orderservicef.dto.OrderItemDTO;
//import com.fooddelivery.orderservicef.dto.OrderRequestDTO;
//import com.fooddelivery.orderservicef.dto.OrderStatusUpdateDTO;
//import com.fooddelivery.orderservicef.dto.PaymentMethod;
//import com.fooddelivery.orderservicef.dto.PaymentRequestDTO;
//import com.fooddelivery.orderservicef.dto.PaymentResponseDTO;
//import com.fooddelivery.orderservicef.exception.InvalidOperationException;
//import com.fooddelivery.orderservicef.exception.ResourceNotFoundException;
//import com.fooddelivery.orderservicef.model.Order;
//import com.fooddelivery.orderservicef.model.OrderItem;
//import com.fooddelivery.orderservicef.model.OrderStatus;
//import com.fooddelivery.orderservicef.repository.OrderItemRepository;
//import com.fooddelivery.orderservicef.repository.OrderRepository;
//
//import lombok.extern.slf4j.Slf4j;
//
//@Slf4j
//@Service
//public class OrderServiceImpl implements OrderService {
//
//    private final OrderRepository orderRepository;
//    private final OrderItemRepository orderItemRepository;
//    private final CartServiceImpl cartServiceImpl;
//    private final PaymentServiceClient paymentServiceClient;
//    private final RestaurantServiceClient restaurantServiceClient;
//    private final AgentServiceClient agentServiceClient; // Changed type
//
//    public OrderServiceImpl(OrderRepository orderRepository,
//                            OrderItemRepository orderItemRepository,
//                            CartServiceImpl cartServiceImpl,
//                            PaymentServiceClient paymentServiceClient,
//                            RestaurantServiceClient restaurantServiceClient,
//                            AgentServiceClient agentServiceClient) { // Changed parameter type
//        this.orderRepository = orderRepository;
//        this.orderItemRepository = orderItemRepository;
//        this.cartServiceImpl = cartServiceImpl;
//        this.paymentServiceClient = paymentServiceClient;
//        this.restaurantServiceClient = restaurantServiceClient;
//        this.agentServiceClient = agentServiceClient; // Changed assignment
//    }
//
//    @Transactional(isolation = Isolation.SERIALIZABLE, timeout = 30)
//    public OrderDTO placeOrder(OrderRequestDTO request, String idempotencyKey) {
//        log.info("Received place order request: userId={}, restaurantId={}, idempotencyKey={}",
//                request.getUserId(), request.getRestaurantId(), idempotencyKey);
//
//        try {
//            // Idempotency check
//            if (orderRepository.existsByIdempotencyKey(idempotencyKey)) {
//                log.warn("Duplicate order for idempotencyKey={}", idempotencyKey);
//                return orderRepository.findByidempotencyKey(idempotencyKey)
//                        .map(this::convertToDTO)
//                        .orElseThrow(() -> {
//                            log.error("Idempotency key exists but order not found. Key={}", idempotencyKey);
//                            return new IllegalStateException("Inconsistent idempotency state");
//                        });
//            }
//
//            Long userId = request.getUserId();
//            Long restaurantId = request.getRestaurantId();
//
//            if (userId == null || restaurantId == null) {
//                log.error("Missing required fields: userId or restaurantId is null");
//                throw new InvalidOperationException("User ID and Restaurant ID are required");
//            }
//            CartDTO cart = cartServiceImpl.getCartByUserId(request.getUserId());
//
//            if (cart == null || cart.getItems() == null || cart.getItems().isEmpty()) {
//                log.warn("Attempt to place order with empty cart for userId={}", request.getUserId());
//                throw new InvalidOperationException("Cannot place order with empty cart");
//            }
//
//            double totalAmount = (double) calculateTotalAmount(cart);
//            log.info("Total order amount: {}", totalAmount);
//
//            // 1. Create Order object without paymentId
//            Order order = createOrder(request, idempotencyKey, totalAmount);
//            List<OrderItem> orderItems = convertCartItemsToOrderItems(cart, order);
//            order.setItems(orderItems);
//
//            // 2. Save the order and items first to generate orderId
//            Order savedOrder = orderRepository.save(order);
//            orderItemRepository.saveAll(orderItems);
//
//            // 3. Process payment using orderId
//            PaymentResponseDTO paymentResponse;
//            try {
//                paymentResponse = processPayment(savedOrder);
//                savedOrder.setPaymentId(paymentResponse.getPaymentId());
//                orderRepository.save(savedOrder); // update with paymentId
//            } catch (Exception ex) {
//                log.error("Payment failed for orderId={}, userId={}", savedOrder.getOrderId(), userId, ex);
//                throw new InvalidOperationException("Payment processing failed");
//            }
//
//            cartServiceImpl.clearCart(userId);
//            log.info("Order placed with ID={} and paymentId={}", savedOrder.getOrderId(), savedOrder.getPaymentId());
//            return convertToDTO(savedOrder);
//
//        } catch (InvalidOperationException | ResourceNotFoundException ex) {
//            log.error("Business validation failed during order placement", ex);
//            throw ex;
//        } catch (Exception ex) {
//            log.error("Unexpected error while placing order", ex);
//            throw new RuntimeException("Failed to place order", ex);
//        }
//    }
//
//    @Transactional(isolation = Isolation.REPEATABLE_READ, timeout = 10)
//    public OrderDTO updateOrderStatus(OrderStatusUpdateDTO statusUpdateDTO) {
//        log.info("Updating order status: orderId={}, newStatus={}, restaurantId={}",
//                statusUpdateDTO.getOrderId(), statusUpdateDTO.getStatus(), statusUpdateDTO.getRestaurantId());
//
//        try {
//            Order order = orderRepository.findByIdWithLock(statusUpdateDTO.getOrderId())
//                    .orElseThrow(() -> {
//                        log.error("Order not found for ID={}", statusUpdateDTO.getOrderId());
//                        return new ResourceNotFoundException("Order not found");
//                    });
//
//            if (!order.getRestaurantId().equals(statusUpdateDTO.getRestaurantId())) {
//                log.warn("Unauthorized update attempt by restaurantId={} for orderId={}",
//                        statusUpdateDTO.getRestaurantId(), order.getOrderId());
//                throw new InvalidOperationException("Restaurant is not authorized to update this order");
//            }
//
//            if (!order.getStatus().canTransitionTo(statusUpdateDTO.getStatus())) {
//                log.warn("Invalid status transition from {} to {}",
//                        order.getStatus(), statusUpdateDTO.getStatus());
//                throw new InvalidOperationException(String.format("Invalid status transition from %s to %s",
//                        order.getStatus(), statusUpdateDTO.getStatus()));
//            }
//
//            OrderStatus oldStatus = order.getStatus();
//            order.setStatus(statusUpdateDTO.getStatus());
//
//            handleStatusUpdatesAfterTransition(order);
//
//            Order updatedOrder = orderRepository.save(order);
//
//            log.info("Order status updated successfully for orderId={} to status={}",
//                    updatedOrder.getOrderId(), updatedOrder.getStatus());
//
//            return convertToDTO(updatedOrder);
//
//        } catch (InvalidOperationException | ResourceNotFoundException ex) {
//            log.error("Order status update failed due to validation", ex);
//            throw ex;
//        } catch (Exception ex) {
//            log.error("Unexpected error while updating order status", ex);
//            throw new RuntimeException("Failed to update order status", ex);
//        }
//    }
//
//    @Transactional(readOnly = true)
//    public List<OrderDTO> getUserOrders(Long userId) {
//        log.info("user orders retrieved !");
//        return orderRepository.findByUserId(userId).stream()
//                .map(this::convertToDTO)
//                .collect(Collectors.toList());
//    }
//
//    @Transactional(readOnly = true)
//    public List<OrderDTO> getRestaurantOrders(Long restaurantId) {
//        log.info("restaurant orders retrieved !");
//        return orderRepository.findByRestaurantId(restaurantId).stream()
//                .map(this::convertToDTO)
//                .collect(Collectors.toList());
//    }
//
//    @Transactional(readOnly = true)
//    public OrderDTO getOrderDetails(Long orderId) {
//        log.info(" order "+orderId+ " details retrieved !");
//        return orderRepository.findById(orderId)
//                .map(this::convertToDTO)
//                .orElseThrow(() -> new ResourceNotFoundException("Order not found"));
//    }
//
//    @Transactional(readOnly = true)
//    public boolean orderExists(String idempotencyKey) {
//        return orderRepository.existsByIdempotencyKey(idempotencyKey);
//    }
//
//    private double calculateTotalAmount(CartDTO cartDTO) {
//        return cartDTO.getItems().stream()
//                .mapToDouble(item -> item.getPrice() * item.getQuantity())
//                .sum();
//    }
//
//    private Order createOrder(OrderRequestDTO request, String idempotencyKey, double totalAmount) {
//        Order order = new Order();
//        order.setIdempotencyKey(idempotencyKey);
//        order.setUserId(request.getUserId());
//        order.setRestaurantId(request.getRestaurantId());
//        order.setStatus(OrderStatus.PENDING);
//        order.setTotalAmount(totalAmount);
//        order.setOrderTime(LocalDateTime.now());
//        order.setDeliveryAddress(request.getDeliveryAddress());
//        return order;
//    }
//
//    private List<OrderItem> convertCartItemsToOrderItems(CartDTO cartDTO, Order order) {
//        return cartDTO.getItems().stream()
//                .map(cartItem -> {
//                    OrderItem orderItem = new OrderItem();
//                    orderItem.setOrder(order);
//                    orderItem.setMenuItemId(cartItem.getMenuItemId());
//                    orderItem.setItemName(cartItem.getItemName());
//                    orderItem.setQuantity(cartItem.getQuantity());
//                    orderItem.setPrice(cartItem.getPrice());
//                    return orderItem;
//                })
//                .collect(Collectors.toList());
//    }
//
//    private PaymentResponseDTO processPayment(Order order) {
//            PaymentRequestDTO paymentRequest = new PaymentRequestDTO();
//            paymentRequest.setOrderId(order.getOrderId());
//            paymentRequest.setPaymentAmount(order.getTotalAmount());
//            paymentRequest.setPaymentMethod(PaymentMethod.Card);
//            paymentRequest.setCreatedBy(order.getUserId().toString());
//            return paymentServiceClient.processPayment(paymentRequest);
//        }
//
//    private void handleStatusUpdatesAfterTransition(Order order) {
//        if (order.getStatus() == OrderStatus.OUT_FOR_DELIVERY) {
//            assignDeliveryAgent(order);
//            CompletableFuture.runAsync(() -> {
//                try {
//                    Thread.sleep(Duration.ofSeconds(30 + new Random().nextInt(16)).toMillis());
//                    completeOrderAsync(order.getOrderId());
//                } catch (InterruptedException ignored) {
//                    Thread.currentThread().interrupt(); // Restore interrupt status
//                    log.warn("Order auto-completion interrupted for orderId={}", order.getOrderId());
//                }
//            });
//        } else if (order.getStatus() == OrderStatus.COMPLETED) {
//            order.setDeliveryTime(LocalDateTime.now());
//            // New: Update delivery status in delivery-service when order is completed
//            if (order.getDeliveryId() != null) {
//                try {
//                    DeliveryStatusUpdateRequestDTO statusUpdate = DeliveryStatusUpdateRequestDTO.builder()
//                            .status(DeliveryStatus.DELIVERED) // Matches DeliveryStatus.DELIVERED enum name
//                            .estimatedDeliveryTime(LocalDateTime.now()) // Set actual delivery time
//                            .build();
//                    agentServiceClient.updateDeliveryStatus(order.getDeliveryId(), statusUpdate);
//                    log.info("Delivery status updated to DELIVERED in delivery-service for deliveryId={}", order.getDeliveryId());
//                } catch (Exception e) {
//                    log.error("Failed to update delivery status in delivery-service for orderId={}: {}", order.getOrderId(), e.getMessage());
//                    // Consider retry mechanism or alerting if this is critical
//                }
//            } else {
//                log.warn("Order {} completed but no deliveryId found. Cannot update delivery-service status.", order.getOrderId());
//            }
//        }
//    }
//
//    @Transactional
//    protected void completeOrderAsync(Long orderId) {
//        Order o = orderRepository.findByIdWithLock(orderId)
//            .orElseThrow(() -> new ResourceNotFoundException("Order not found in async complete"));
//
//        if (o.getStatus() == OrderStatus.OUT_FOR_DELIVERY && o.getStatus().canTransitionTo(OrderStatus.COMPLETED)) {
//            o.setStatus(OrderStatus.COMPLETED);
//            o.setDeliveryTime(LocalDateTime.now());
//            orderRepository.save(o);
//            log.info("Order auto-completed via async flow, orderId={}", orderId);
//            // After auto-completion, call handleStatusUpdatesAfterTransition to propagate status
//            handleStatusUpdatesAfterTransition(o);
//        }
//    }
//
//    private void assignDeliveryAgent(Order order) {
//        AgentAssignmentDTO assignmentDTO = new AgentAssignmentDTO();
//        assignmentDTO.setOrderId(order.getOrderId());
//        assignmentDTO.setRestaurantId(order.getRestaurantId());
//        assignmentDTO.setDeliveryAddress(order.getDeliveryAddress());
//        AgentResponseDTO agentResponse = agentServiceClient.assignDeliveryAgent(assignmentDTO);
//        order.setDeliveryAgentId(agentResponse.getAgentId());
//        order.setDeliveryId(agentResponse.getDeliveryId()); // Set deliveryId from response
//        orderRepository.save(order); // Persist the updated order with deliveryId
//    }
//
//    public OrderDTO convertToDTO(Order order) {
//        log.info("Converting Order to DTO: {}", order.getOrderId());
//        if (order == null) return null;
//
//        OrderDTO dto = new OrderDTO();
//        dto.setOrderId(order.getOrderId());
//        dto.setUserId(order.getUserId());
//        dto.setRestaurantId(order.getRestaurantId());
//        dto.setDeliveryAddress(order.getDeliveryAddress());
//        dto.setOrderTime(order.getOrderTime());
//        dto.setDeliveryTime(order.getDeliveryTime());
//        dto.setStatus(order.getStatus());
//        dto.setTotalAmount(order.getTotalAmount());
//        dto.setPaymentId(order.getPaymentId());
//        dto.setIdempotencyKey(order.getIdempotencyKey());
//        dto.setDeliveryAgentId(order.getDeliveryAgentId());
//        dto.setDeliveryId(order.getDeliveryId()); // Map the new deliveryId field
//
//        if (order.getItems() != null) {
//            List<OrderItemDTO> items = order.getItems().stream()
//                .map(item -> {
//                    OrderItemDTO itemDTO = new OrderItemDTO();
//                    itemDTO.setMenuItemId(item.getMenuItemId());
//                    itemDTO.setItemName(item.getItemName());
//                    itemDTO.setQuantity(item.getQuantity());
//                    itemDTO.setPrice(item.getPrice());
//                    return itemDTO;
//                })
//                .collect(Collectors.toList());
//            dto.setItems(items);
//        } else {
//            dto.setItems(Collections.emptyList());
//        }
//        return dto;
//    }
//
//    private OrderItemDTO convertToDTO(OrderItem orderItem) {
//        OrderItemDTO dto = new OrderItemDTO();
//        dto.setMenuItemId(orderItem.getMenuItemId());
//        dto.setItemName(orderItem.getItemName());
//        dto.setQuantity(orderItem.getQuantity());
//        dto.setPrice(orderItem.getPrice());
//        return dto;
//    }
//}
//package com.fooddelivery.orderservicef.service;
//
//import java.time.Duration;
//import java.time.LocalDateTime;
//import java.util.Collections;
//import java.util.List;
//import java.util.Random;
//import java.util.concurrent.CompletableFuture;
//import java.util.stream.Collectors;
//
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Isolation;
//import org.springframework.transaction.annotation.Transactional;
//
//import com.fooddelivery.orderservicef.dto.AgentAssignmentDTO;
//import com.fooddelivery.orderservicef.dto.AgentResponseDTO;
//import com.fooddelivery.orderservicef.dto.CartDTO;
//import com.fooddelivery.orderservicef.dto.DeliveryStatus;
//import com.fooddelivery.orderservicef.dto.DeliveryStatusUpdateRequestDTO;
//import com.fooddelivery.orderservicef.dto.OrderDTO;
//import com.fooddelivery.orderservicef.dto.OrderItemDTO;
//import com.fooddelivery.orderservicef.dto.OrderRequestDTO;
//import com.fooddelivery.orderservicef.dto.OrderStatusUpdateDTO;
//import com.fooddelivery.orderservicef.dto.PaymentMethod;
//import com.fooddelivery.orderservicef.dto.PaymentRequestDTO;
//import com.fooddelivery.orderservicef.dto.PaymentResponseDTO;
//import com.fooddelivery.orderservicef.exception.InvalidOperationException;
//import com.fooddelivery.orderservicef.exception.ResourceNotFoundException;
//import com.fooddelivery.orderservicef.model.Order;
//import com.fooddelivery.orderservicef.model.OrderItem;
//import com.fooddelivery.orderservicef.model.OrderStatus;
//import com.fooddelivery.orderservicef.repository.OrderItemRepository;
//import com.fooddelivery.orderservicef.repository.OrderRepository;
//
//import lombok.extern.slf4j.Slf4j;
//
//@Slf4j
//@Service
//public class OrderServiceImpl implements OrderService {
//
//    private final OrderRepository orderRepository;
//    private final OrderItemRepository orderItemRepository;
//    private final CartServiceImpl cartServiceImpl;
//    private final PaymentServiceClient paymentServiceClient;
//    private final RestaurantServiceClient restaurantServiceClient;
//    private final AgentServiceClient agentServiceClient;
//
//    public OrderServiceImpl(OrderRepository orderRepository,
//                            OrderItemRepository orderItemRepository,
//                            CartServiceImpl cartServiceImpl,
//                            PaymentServiceClient paymentServiceClient,
//                            RestaurantServiceClient restaurantServiceClient,
//                            AgentServiceClient agentServiceClient) {
//        this.orderRepository = orderRepository;
//        this.orderItemRepository = orderItemRepository;
//        this.cartServiceImpl = cartServiceImpl;
//        this.paymentServiceClient = paymentServiceClient;
//        this.restaurantServiceClient = restaurantServiceClient;
//        this.agentServiceClient = agentServiceClient;
//    }
//
//    @Override
//    @Transactional(isolation = Isolation.SERIALIZABLE, timeout = 30)
//    public OrderDTO placeOrder(OrderRequestDTO request, String idempotencyKey) {
//        log.info("Received place order request: userId={}, restaurantId={}, idempotencyKey={}",
//                request.getUserId(), request.getRestaurantId(), idempotencyKey);
//
//        try {
//            // Idempotency check
//            if (orderRepository.existsByIdempotencyKey(idempotencyKey)) {
//                log.warn("Duplicate order for idempotencyKey={}", idempotencyKey);
//                return orderRepository.findByIdempotencyKey(idempotencyKey)
//                        .map(this::convertToDTO)
//                        .orElseThrow(() -> {
//                            log.error("Idempotency key exists but order not found. Key={}", idempotencyKey);
//                            return new IllegalStateException("Inconsistent idempotency state");
//                        });
//            }
//
//            Long userId = request.getUserId();
//            Long restaurantId = request.getRestaurantId();
//
//            if (userId == null || restaurantId == null) {
//                log.error("Missing required fields: userId or restaurantId is null");
//                throw new InvalidOperationException("User ID and Restaurant ID are required");
//            }
//
//            CartDTO cart = cartServiceImpl.getCartByUserId(request.getUserId());
//
//            if (cart == null || cart.getItems() == null || cart.getItems().isEmpty()) {
//                log.warn("Attempt to place order with empty cart for userId={}", request.getUserId());
//                throw new InvalidOperationException("Cannot place order with empty cart");
//            }
//
//            // FIXED: Use double calculation instead of BigDecimal
//            double totalAmount = calculateTotalAmount(cart);
//            log.info("Total order amount: {}", totalAmount);
//
//            // 1. Create Order object without paymentId
//            Order order = createOrder(request, idempotencyKey, totalAmount);
//            List<OrderItem> orderItems = convertCartItemsToOrderItems(cart, order);
//            order.setItems(orderItems);
//
//            // 2. Save the order and items first to generate orderId
//            Order savedOrder = orderRepository.save(order);
//            orderItemRepository.saveAll(orderItems);
//
//            // 3. Process payment using orderId
//            PaymentResponseDTO paymentResponse;
//            try {
//                paymentResponse = processPayment(savedOrder);
//                savedOrder.setPaymentId(paymentResponse.getPaymentId());
//                orderRepository.save(savedOrder); // update with paymentId
//            } catch (Exception ex) {
//                log.error("Payment failed for orderId={}, userId={}", savedOrder.getOrderId(), userId, ex);
//                throw new InvalidOperationException("Payment processing failed");
//            }
//
//            cartServiceImpl.clearCart(userId);
//            log.info("Order placed with ID={} and paymentId={}", savedOrder.getOrderId(), savedOrder.getPaymentId());
//            return convertToDTO(savedOrder);
//
//        } catch (InvalidOperationException | ResourceNotFoundException ex) {
//            log.error("Business validation failed during order placement", ex);
//            throw ex;
//        } catch (Exception ex) {
//            log.error("Unexpected error while placing order", ex);
//            throw new RuntimeException("Failed to place order", ex);
//        }
//    }
//
//    @Override
//    @Transactional(isolation = Isolation.REPEATABLE_READ, timeout = 10)
//    public OrderDTO updateOrderStatus(OrderStatusUpdateDTO statusUpdateDTO) {
//        log.info("Updating order status: orderId={}, newStatus={}, restaurantId={}",
//                statusUpdateDTO.getOrderId(), statusUpdateDTO.getStatus(), statusUpdateDTO.getRestaurantId());
//
//        try {
//            Order order = orderRepository.findByIdWithLock(statusUpdateDTO.getOrderId())
//                    .orElseThrow(() -> {
//                        log.error("Order not found for ID={}", statusUpdateDTO.getOrderId());
//                        return new ResourceNotFoundException("Order not found");
//                    });
//
//            if (!order.getRestaurantId().equals(statusUpdateDTO.getRestaurantId())) {
//                log.warn("Unauthorized update attempt by restaurantId={} for orderId={}",
//                        statusUpdateDTO.getRestaurantId(), order.getOrderId());
//                throw new InvalidOperationException("Restaurant is not authorized to update this order");
//            }
//
//            if (!order.getStatus().canTransitionTo(statusUpdateDTO.getStatus())) {
//                log.warn("Invalid status transition from {} to {}",
//                        order.getStatus(), statusUpdateDTO.getStatus());
//                throw new InvalidOperationException(String.format("Invalid status transition from %s to %s",
//                        order.getStatus(), statusUpdateDTO.getStatus()));
//            }
//
//            order.setStatus(statusUpdateDTO.getStatus());
//            handleStatusUpdatesAfterTransition(order);
//            Order updatedOrder = orderRepository.save(order);
//
//            log.info("Order status updated successfully for orderId={} to status={}",
//                    updatedOrder.getOrderId(), updatedOrder.getStatus());
//
//            return convertToDTO(updatedOrder);
//
//        } catch (InvalidOperationException | ResourceNotFoundException ex) {
//            log.error("Order status update failed due to validation", ex);
//            throw ex;
//        } catch (Exception ex) {
//            log.error("Unexpected error while updating order status", ex);
//            throw new RuntimeException("Failed to update order status", ex);
//        }
//    }
//
//    @Override
//    @Transactional(readOnly = true)
//    public List<OrderDTO> getUserOrders(Long userId) {
//        log.info("Retrieving orders for userId={}", userId);
//        return orderRepository.findByUserId(userId).stream()
//                .map(this::convertToDTO)
//                .collect(Collectors.toList());
//    }
//
//    @Override
//    @Transactional(readOnly = true)
//    public List<OrderDTO> getRestaurantOrders(Long restaurantId) {
//        log.info("Retrieving orders for restaurantId={}", restaurantId);
//        return orderRepository.findByRestaurantId(restaurantId).stream()
//                .map(this::convertToDTO)
//                .collect(Collectors.toList());
//    }
//
//    @Override
//    @Transactional(readOnly = true)
//    public OrderDTO getOrderDetails(Long orderId) {
//        log.info("Retrieving order details for orderId={}", orderId);
//        return orderRepository.findById(orderId)
//                .map(this::convertToDTO)
//                .orElseThrow(() -> new ResourceNotFoundException("Order not found"));
//    }
//
//    @Override
//    public boolean orderExists(String idempotencyKey) {
//        return orderRepository.existsByIdempotencyKey(idempotencyKey);
//    }
//
//    // FIXED: Use double calculation instead of BigDecimal
//    private double calculateTotalAmount(CartDTO cartDTO) {
//        return cartDTO.getItems().stream()
//                .mapToDouble(item -> item.getPrice() * item.getQuantity())
//                .sum();
//    }
//
//    private Order createOrder(OrderRequestDTO request, String idempotencyKey, double totalAmount) {
//        Order order = new Order();
//        order.setIdempotencyKey(idempotencyKey);
//        order.setUserId(request.getUserId());
//        order.setRestaurantId(request.getRestaurantId());
//        order.setStatus(OrderStatus.PENDING);
//        order.setTotalAmount(totalAmount); // Both are double - no conversion needed
//        order.setOrderTime(LocalDateTime.now());
//        order.setDeliveryAddress(request.getDeliveryAddress());
//        return order;
//    }
//
//    // FIXED: Use double for OrderItem price if your OrderItem entity uses double
//    private List<OrderItem> convertCartItemsToOrderItems(CartDTO cartDTO, Order order) {
//        return cartDTO.getItems().stream()
//                .map(cartItem -> {
//                    OrderItem orderItem = new OrderItem();
//                    orderItem.setOrder(order);
//                    orderItem.setMenuItemId(cartItem.getMenuItemId());
//                    orderItem.setItemName(cartItem.getItemName());
//                    orderItem.setQuantity(cartItem.getQuantity());
//                    orderItem.setPrice(cartItem.getPrice()); // Direct double assignment
//                    return orderItem;
//                })
//                .collect(Collectors.toList());
//    }
//
//    // FIXED: Use double directly for payment amount
//    private PaymentResponseDTO processPayment(Order order) {
//        PaymentRequestDTO paymentRequest = new PaymentRequestDTO();
//        paymentRequest.setOrderId(order.getOrderId());
//        paymentRequest.setPaymentAmount(order.getTotalAmount()); // Both are double - no conversion needed
//        paymentRequest.setPaymentMethod(PaymentMethod.Card);
//        paymentRequest.setCreatedBy(order.getUserId().toString());
//        return paymentServiceClient.processPayment(paymentRequest);
//    }
//
//    private void handleStatusUpdatesAfterTransition(Order order) {
//        if (order.getStatus() == OrderStatus.OUT_FOR_DELIVERY) {
//            assignDeliveryAgent(order);
//            CompletableFuture.runAsync(() -> {
//                try {
//                    Thread.sleep(Duration.ofSeconds(30 + new Random().nextInt(16)).toMillis());
//                    completeOrderAsync(order.getOrderId());
//                } catch (InterruptedException ignored) {
//                    Thread.currentThread().interrupt();
//                    log.warn("Order auto-completion interrupted for orderId={}", order.getOrderId());
//                }
//            });
//        } else if (order.getStatus() == OrderStatus.COMPLETED) {
//            order.setDeliveryTime(LocalDateTime.now());
//            if (order.getDeliveryId() != null) {
//                try {
//                    DeliveryStatusUpdateRequestDTO statusUpdate = DeliveryStatusUpdateRequestDTO.builder()
//                            .status(DeliveryStatus.DELIVERED)
//                            .estimatedDeliveryTime(LocalDateTime.now())
//                            .build();
//                    agentServiceClient.updateDeliveryStatus(order.getDeliveryId(), statusUpdate);
//                    log.info("Delivery status updated to DELIVERED in delivery-service for deliveryId={}",
//                            order.getDeliveryId());
//                } catch (Exception e) {
//                    log.error("Failed to update delivery status in delivery-service for orderId={}: {}",
//                            order.getOrderId(), e.getMessage());
//                }
//            } else {
//                log.warn("Order {} completed but no deliveryId found. Cannot update delivery-service status.",
//                        order.getOrderId());
//            }
//        }
//    }
//
//    @Transactional
//    protected void completeOrderAsync(Long orderId) {
//        try {
//            Order order = orderRepository.findByIdWithLock(orderId)
//                    .orElseThrow(() -> new ResourceNotFoundException("Order not found in async complete"));
//
//            if (order.getStatus() == OrderStatus.OUT_FOR_DELIVERY &&
//                    order.getStatus().canTransitionTo(OrderStatus.COMPLETED)) {
//                order.setStatus(OrderStatus.COMPLETED);
//                order.setDeliveryTime(LocalDateTime.now());
//                orderRepository.save(order);
//                log.info("Order auto-completed via async flow, orderId={}", orderId);
//                handleStatusUpdatesAfterTransition(order);
//            }
//        } catch (Exception e) {
//            log.error("Error in async order completion for orderId={}: {}", orderId, e.getMessage());
//        }
//    }
//
//    private void assignDeliveryAgent(Order order) {
//        try {
//            AgentAssignmentDTO assignmentDTO = new AgentAssignmentDTO();
//            assignmentDTO.setOrderId(order.getOrderId());
//            assignmentDTO.setRestaurantId(order.getRestaurantId());
//            assignmentDTO.setDeliveryAddress(order.getDeliveryAddress());
//
//            AgentResponseDTO agentResponse = agentServiceClient.assignDeliveryAgent(assignmentDTO);
//            order.setDeliveryAgentId(agentResponse.getAgentId());
//            order.setDeliveryId(agentResponse.getDeliveryId());
//            orderRepository.save(order);
//
//            log.info("Delivery agent assigned for orderId={}, agentId={}, deliveryId={}",
//                    order.getOrderId(), agentResponse.getAgentId(), agentResponse.getDeliveryId());
//        } catch (Exception e) {
//            log.error("Failed to assign delivery agent for orderId={}: {}", order.getOrderId(), e.getMessage());
//            throw new InvalidOperationException("Failed to assign delivery agent");
//        }
//    }
//
//    // FIXED: No conversion needed - both Order and OrderDTO use double
//    private OrderDTO convertToDTO(Order order) {
//        log.debug("Converting Order to DTO: {}", order.getOrderId());
//        if (order == null) return null;
//
//        OrderDTO dto = new OrderDTO();
//        dto.setOrderId(order.getOrderId());
//        dto.setUserId(order.getUserId());
//        dto.setRestaurantId(order.getRestaurantId());
//        dto.setDeliveryAddress(order.getDeliveryAddress());
//        dto.setOrderTime(order.getOrderTime());
//        dto.setDeliveryTime(order.getDeliveryTime());
//        dto.setStatus(order.getStatus());
//        dto.setTotalAmount(order.getTotalAmount()); // Both are double - no conversion needed
//        dto.setPaymentId(order.getPaymentId());
//        dto.setIdempotencyKey(order.getIdempotencyKey());
//        dto.setDeliveryAgentId(order.getDeliveryAgentId());
//        dto.setDeliveryId(order.getDeliveryId());
//
//        if (order.getItems() != null && !order.getItems().isEmpty()) {
//            List<OrderItemDTO> items = order.getItems().stream()
//                    .map(this::convertOrderItemToDTO)
//                    .collect(Collectors.toList());
//            dto.setItems(items);
//        } else {
//            dto.setItems(Collections.emptyList());
//        }
//        return dto;
//    }
//
//    // FIXED: Direct double assignment if OrderItem uses double
//    private OrderItemDTO convertOrderItemToDTO(OrderItem orderItem) {
//        OrderItemDTO dto = new OrderItemDTO();
//        dto.setMenuItemId(orderItem.getMenuItemId());
//        dto.setItemName(orderItem.getItemName());
//        dto.setQuantity(orderItem.getQuantity());
//        dto.setPrice(orderItem.getPrice()); // Direct assignment if both are double
//        return dto;
//    }
//}

//
//package com.fooddelivery.orderservicef.service;
//
//import java.time.Duration;
//import java.time.LocalDateTime;
//import java.util.Arrays;
//import java.util.Collections;
//import java.util.List;
//import java.util.Random;
//import java.util.concurrent.CompletableFuture;
//import java.util.stream.Collectors;
//
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Isolation;
//import org.springframework.transaction.annotation.Transactional;
//
//import com.fooddelivery.orderservicef.dto.AgentAssignmentDTO;
//import com.fooddelivery.orderservicef.dto.AgentResponseDTO;
//import com.fooddelivery.orderservicef.dto.CartDTO;
//import com.fooddelivery.orderservicef.dto.DeliveryStatus;
//import com.fooddelivery.orderservicef.dto.DeliveryStatusUpdateRequestDTO;
//import com.fooddelivery.orderservicef.dto.OrderDTO;
//import com.fooddelivery.orderservicef.dto.OrderItemDTO;
//import com.fooddelivery.orderservicef.dto.OrderRequestDTO;
//import com.fooddelivery.orderservicef.dto.OrderStatusUpdateDTO;
//import com.fooddelivery.orderservicef.dto.PaymentMethod;
//import com.fooddelivery.orderservicef.dto.PaymentRequestDTO;
//import com.fooddelivery.orderservicef.dto.PaymentResponseDTO;
//import com.fooddelivery.orderservicef.exception.InvalidOperationException;
//import com.fooddelivery.orderservicef.exception.ResourceNotFoundException;
//import com.fooddelivery.orderservicef.model.Order;
//import com.fooddelivery.orderservicef.model.OrderItem;
//import com.fooddelivery.orderservicef.model.OrderStatus;
//import com.fooddelivery.orderservicef.repository.OrderItemRepository;
//import com.fooddelivery.orderservicef.repository.OrderRepository;
//
//import lombok.extern.slf4j.Slf4j;
//
//@Slf4j
//@Service
//public class OrderServiceImpl implements OrderService {
//
//    private final OrderRepository orderRepository;
//    private final OrderItemRepository orderItemRepository;
//    private final CartServiceImpl cartServiceImpl;
//    private final PaymentServiceClient paymentServiceClient;
//    private final RestaurantServiceClient restaurantServiceClient;
//    private final AgentServiceClient agentServiceClient;
//
//    public OrderServiceImpl(OrderRepository orderRepository,
//                            OrderItemRepository orderItemRepository,
//                            CartServiceImpl cartServiceImpl,
//                            PaymentServiceClient paymentServiceClient,
//                            RestaurantServiceClient restaurantServiceClient,
//                            AgentServiceClient agentServiceClient) {
//        this.orderRepository = orderRepository;
//        this.orderItemRepository = orderItemRepository;
//        this.cartServiceImpl = cartServiceImpl;
//        this.paymentServiceClient = paymentServiceClient;
//        this.restaurantServiceClient = restaurantServiceClient;
//        this.agentServiceClient = agentServiceClient;
//    }
//
//    @Override
//    @Transactional(isolation = Isolation.SERIALIZABLE, timeout = 30)
//    public OrderDTO placeOrder(OrderRequestDTO request, String idempotencyKey) {
//        log.info("Received place order request: userId={}, restaurantId={}, idempotencyKey={}",
//                request.getUserId(), request.getRestaurantId(), idempotencyKey);
//
//        try {
//            // Idempotency check
//            if (orderRepository.existsByIdempotencyKey(idempotencyKey)) {
//                log.warn("Duplicate order for idempotencyKey={}", idempotencyKey);
//                return orderRepository.findByIdempotencyKey(idempotencyKey)
//                        .map(this::convertToDTO)
//                        .orElseThrow(() -> {
//                            log.error("Idempotency key exists but order not found. Key={}", idempotencyKey);
//                            return new IllegalStateException("Inconsistent idempotency state");
//                        });
//            }
//
//            Long userId = request.getUserId();
//            Long restaurantId = request.getRestaurantId();
//
//            if (userId == null || restaurantId == null) {
//                log.error("Missing required fields: userId or restaurantId is null");
//                throw new InvalidOperationException("User ID and Restaurant ID are required");
//            }
//
//            // ✅ FIXED: Use items from request FIRST, then fallback to cart
//            List<OrderItemDTO> orderItems = request.getItems();
//            double totalAmount;
//
//            log.info("=== ORDER PLACEMENT DEBUG ===");
//            log.info("Request items: {}", orderItems != null ? orderItems.size() : "null");
//            log.info("Request total amount: {}", request.getTotalAmount());
//
//            if (orderItems != null && !orderItems.isEmpty()) {
//                // ✅ Use items from request (preferred method)
//                log.info("✅ Using items from request: {} items", orderItems.size());
//                totalAmount = request.getTotalAmount() != null ? request.getTotalAmount() : calculateTotalAmountFromRequestItems(orderItems);
//                log.info("Total amount from request: {}", totalAmount);
//            } else {
//                // Fallback to cart (existing logic)
//                log.info("⚠️ No items in request, checking cart for userId: {}", userId);
//                CartDTO cart = cartServiceImpl.getCartByUserId(userId);
//
//                if (cart == null || cart.getItems() == null || cart.getItems().isEmpty()) {
//                    log.error("❌ Cannot place order: No items in request and cart is empty");
//                    throw new InvalidOperationException("Cannot place order without items. Please add items to cart or include them in the request.");
//                }
//
//                log.info("📋 Using cart items: {} items", cart.getItems().size());
//                totalAmount = calculateTotalAmount(cart);
//                orderItems = convertCartItemsToOrderItemDTOs(cart);
//            }
//
//            log.info("Final total amount: {}", totalAmount);
//            log.info("=== END DEBUG ===");
//
//            // Validate order items
//            if (orderItems.isEmpty()) {
//                throw new InvalidOperationException("Order must contain at least one item");
//            }
//
//            // Create and save order
//            Order order = createOrder(request, idempotencyKey, totalAmount);
//            List<OrderItem> orderItemEntities = convertOrderItemDTOsToOrderItems(orderItems, order);
//            order.setItems(orderItemEntities);
//
//            Order savedOrder = orderRepository.save(order);
//            orderItemRepository.saveAll(orderItemEntities);
//
//            // Process payment
//            PaymentResponseDTO paymentResponse;
//            try {
//                paymentResponse = processPayment(savedOrder);
//                savedOrder.setPaymentId(paymentResponse.getPaymentId());
//                orderRepository.save(savedOrder);
//            } catch (Exception ex) {
//                log.error("Payment failed for orderId={}, userId={}", savedOrder.getOrderId(), userId, ex);
//                throw new InvalidOperationException("Payment processing failed: " + ex.getMessage());
//            }
//
//            // Clear cart only if we used cart items (not request items)
//            if (request.getItems() == null || request.getItems().isEmpty()) {
//                try {
//                    cartServiceImpl.clearCart(userId);
//                    log.info("Cart cleared for userId: {}", userId);
//                } catch (Exception ex) {
//                    log.warn("Failed to clear cart for userId: {}", userId, ex);
//                    // Don't fail the order if cart clearing fails
//                }
//            }
//
//            log.info("✅ Order placed successfully with ID={} and paymentId={}",
//                    savedOrder.getOrderId(), savedOrder.getPaymentId());
//            return convertToDTO(savedOrder);
//
//        } catch (InvalidOperationException | ResourceNotFoundException ex) {
//            log.error("Business validation failed during order placement", ex);
//            throw ex;
//        } catch (Exception ex) {
//            log.error("Unexpected error while placing order", ex);
//            throw new RuntimeException("Failed to place order: " + ex.getMessage(), ex);
//        }
//    }
//
//    @Override
//    @Transactional(isolation = Isolation.REPEATABLE_READ, timeout = 10)
//    public OrderDTO updateOrderStatus(OrderStatusUpdateDTO statusUpdateDTO) {
//        log.info("Updating order status: orderId={}, newStatus={}, restaurantId={}",
//                statusUpdateDTO.getOrderId(), statusUpdateDTO.getStatus(), statusUpdateDTO.getRestaurantId());
//
//        try {
//            Order order = orderRepository.findByIdWithLock(statusUpdateDTO.getOrderId())
//                    .orElseThrow(() -> {
//                        log.error("Order not found for ID={}", statusUpdateDTO.getOrderId());
//                        return new ResourceNotFoundException("Order not found");
//                    });
//
//            if (!order.getRestaurantId().equals(statusUpdateDTO.getRestaurantId())) {
//                log.warn("Unauthorized update attempt by restaurantId={} for orderId={}",
//                        statusUpdateDTO.getRestaurantId(), order.getOrderId());
//                throw new InvalidOperationException("Restaurant is not authorized to update this order");
//            }
//
//            if (!order.getStatus().canTransitionTo(statusUpdateDTO.getStatus())) {
//                log.warn("Invalid status transition from {} to {}",
//                        order.getStatus(), statusUpdateDTO.getStatus());
//                throw new InvalidOperationException(String.format("Invalid status transition from %s to %s",
//                        order.getStatus(), statusUpdateDTO.getStatus()));
//            }
//
//            order.setStatus(statusUpdateDTO.getStatus());
//            handleStatusUpdatesAfterTransition(order);
//            Order updatedOrder = orderRepository.save(order);
//
//            log.info("Order status updated successfully for orderId={} to status={}",
//                    updatedOrder.getOrderId(), updatedOrder.getStatus());
//
//            return convertToDTO(updatedOrder);
//
//        } catch (InvalidOperationException | ResourceNotFoundException ex) {
//            log.error("Order status update failed due to validation", ex);
//            throw ex;
//        } catch (Exception ex) {
//            log.error("Unexpected error while updating order status", ex);
//            throw new RuntimeException("Failed to update order status", ex);
//        }
//    }
//
//    @Override
//    @Transactional(readOnly = true)
//    public List<OrderDTO> getUserOrders(Long userId) {
//        log.info("Retrieving orders for userId={}", userId);
//        return orderRepository.findByUserId(userId).stream()
//                .map(this::convertToDTO)
//                .collect(Collectors.toList());
//    }
//
////    @Override
////    @Transactional(readOnly = true)
////    public List<OrderDTO> getRestaurantOrders(Long restaurantId) {
////        log.info("Retrieving orders for restaurantId={}", restaurantId);
////        return orderRepository.findByRestaurantId(restaurantId).stream()
////                .map(this::convertToDTO)
////                .collect(Collectors.toList());
////    }
//
//    @Override
//    @Transactional(readOnly = true)
//    public OrderDTO getOrderDetails(Long orderId) {
//        log.info("Retrieving order details for orderId={}", orderId);
//        return orderRepository.findById(orderId)
//                .map(this::convertToDTO)
//                .orElseThrow(() -> new ResourceNotFoundException("Order not found"));
//    }
//
//    @Override
//    public boolean orderExists(String idempotencyKey) {
//        return orderRepository.existsByIdempotencyKey(idempotencyKey);
//    }
//
//    // ✅ NEW: Calculate total amount from request items
//    private double calculateTotalAmountFromRequestItems(List<OrderItemDTO> items) {
//        return items.stream()
//                .mapToDouble(item -> item.getPrice() * item.getQuantity())
//                .sum();
//    }
//
//    // ✅ EXISTING: Calculate total amount from cart (fallback)
//    private double calculateTotalAmount(CartDTO cartDTO) {
//        return cartDTO.getItems().stream()
//                .mapToDouble(item -> item.getPrice() * item.getQuantity())
//                .sum();
//    }
//
//    // ✅ NEW: Convert cart items to OrderItemDTO (for fallback scenario)
//    private List<OrderItemDTO> convertCartItemsToOrderItemDTOs(CartDTO cart) {
//        return cart.getItems().stream()
//                .map(cartItem -> {
//                    OrderItemDTO dto = new OrderItemDTO();
//                    dto.setMenuItemId(cartItem.getMenuItemId());
//                    dto.setItemName(cartItem.getItemName());
//                    dto.setQuantity(cartItem.getQuantity());
//                    dto.setPrice(cartItem.getPrice());
//                    return dto;
//                })
//                .collect(Collectors.toList());
//    }
//
//    // ✅ NEW: Convert OrderItemDTO to OrderItem entities
//    private List<OrderItem> convertOrderItemDTOsToOrderItems(List<OrderItemDTO> orderItems, Order order) {
//        return orderItems.stream()
//                .map(dto -> {
//                    OrderItem orderItem = new OrderItem();
//                    orderItem.setOrder(order);
//                    orderItem.setMenuItemId(dto.getMenuItemId());
//                    orderItem.setItemName(dto.getItemName());
//                    orderItem.setQuantity(dto.getQuantity());
//                    orderItem.setPrice(dto.getPrice());
//                    return orderItem;
//                })
//                .collect(Collectors.toList());
//    }
//
//    // ✅ EXISTING: Convert cart items to OrderItem entities (fallback)
//    private List<OrderItem> convertCartItemsToOrderItems(CartDTO cartDTO, Order order) {
//        return cartDTO.getItems().stream()
//                .map(cartItem -> {
//                    OrderItem orderItem = new OrderItem();
//                    orderItem.setOrder(order);
//                    orderItem.setMenuItemId(cartItem.getMenuItemId());
//                    orderItem.setItemName(cartItem.getItemName());
//                    orderItem.setQuantity(cartItem.getQuantity());
//                    orderItem.setPrice(cartItem.getPrice());
//                    return orderItem;
//                })
//                .collect(Collectors.toList());
//    }
//
//    private Order createOrder(OrderRequestDTO request, String idempotencyKey, double totalAmount) {
//        Order order = new Order();
//        order.setIdempotencyKey(idempotencyKey);
//        order.setUserId(request.getUserId());
//        order.setRestaurantId(request.getRestaurantId());
//        order.setStatus(OrderStatus.PENDING);
//        order.setTotalAmount(totalAmount);
//        order.setOrderTime(LocalDateTime.now());
//        order.setDeliveryAddress(request.getDeliveryAddress());
//        return order;
//    }
//
//    private PaymentResponseDTO processPayment(Order order) {
//        PaymentRequestDTO paymentRequest = new PaymentRequestDTO();
//        paymentRequest.setOrderId(order.getOrderId());
//        paymentRequest.setPaymentAmount(order.getTotalAmount());
//        paymentRequest.setPaymentMethod(PaymentMethod.Card);
//        paymentRequest.setCreatedBy(order.getUserId().toString());
//        return paymentServiceClient.processPayment(paymentRequest);
//    }
//
//    private void handleStatusUpdatesAfterTransition(Order order) {
//        if (order.getStatus() == OrderStatus.OUT_FOR_DELIVERY) {
//            assignDeliveryAgent(order);
//            CompletableFuture.runAsync(() -> {
//                try {
//                    Thread.sleep(Duration.ofSeconds(30 + new Random().nextInt(16)).toMillis());
//                    completeOrderAsync(order.getOrderId());
//                } catch (InterruptedException ignored) {
//                    Thread.currentThread().interrupt();
//                    log.warn("Order auto-completion interrupted for orderId={}", order.getOrderId());
//                }
//            });
//        } else if (order.getStatus() == OrderStatus.COMPLETED) {
//            order.setDeliveryTime(LocalDateTime.now());
//            if (order.getDeliveryId() != null) {
//                try {
//                    DeliveryStatusUpdateRequestDTO statusUpdate = DeliveryStatusUpdateRequestDTO.builder()
//                            .status(DeliveryStatus.DELIVERED)
//                            .estimatedDeliveryTime(LocalDateTime.now())
//                            .build();
//                    agentServiceClient.updateDeliveryStatus(order.getDeliveryId(), statusUpdate);
//                    log.info("Delivery status updated to DELIVERED in delivery-service for deliveryId={}",
//                            order.getDeliveryId());
//                } catch (Exception e) {
//                    log.error("Failed to update delivery status in delivery-service for orderId={}: {}",
//                            order.getOrderId(), e.getMessage());
//                }
//            } else {
//                log.warn("Order {} completed but no deliveryId found. Cannot update delivery-service status.",
//                        order.getOrderId());
//            }
//        }
//    }
//
//    @Transactional
//    protected void completeOrderAsync(Long orderId) {
//        try {
//            Order order = orderRepository.findByIdWithLock(orderId)
//                    .orElseThrow(() -> new ResourceNotFoundException("Order not found in async complete"));
//
//            if (order.getStatus() == OrderStatus.OUT_FOR_DELIVERY &&
//                    order.getStatus().canTransitionTo(OrderStatus.COMPLETED)) {
//                order.setStatus(OrderStatus.COMPLETED);
//                order.setDeliveryTime(LocalDateTime.now());
//                orderRepository.save(order);
//                log.info("Order auto-completed via async flow, orderId={}", orderId);
//                handleStatusUpdatesAfterTransition(order);
//            }
//        } catch (Exception e) {
//            log.error("Error in async order completion for orderId={}: {}", orderId, e.getMessage());
//        }
//    }
//
//    private void assignDeliveryAgent(Order order) {
//        try {
//            AgentAssignmentDTO assignmentDTO = new AgentAssignmentDTO();
//            assignmentDTO.setOrderId(order.getOrderId());
//            assignmentDTO.setRestaurantId(order.getRestaurantId());
//            assignmentDTO.setDeliveryAddress(order.getDeliveryAddress());
//
//            AgentResponseDTO agentResponse = agentServiceClient.assignDeliveryAgent(assignmentDTO);
//            order.setDeliveryAgentId(agentResponse.getAgentId());
//            order.setDeliveryId(agentResponse.getDeliveryId());
//            orderRepository.save(order);
//
//            log.info("Delivery agent assigned for orderId={}, agentId={}, deliveryId={}",
//                    order.getOrderId(), agentResponse.getAgentId(), agentResponse.getDeliveryId());
//        } catch (Exception e) {
//            log.error("Failed to assign delivery agent for orderId={}: {}", order.getOrderId(), e.getMessage());
//            throw new InvalidOperationException("Failed to assign delivery agent");
//        }
//    }
//
//    private OrderDTO convertToDTO(Order order) {
//        log.debug("Converting Order to DTO: {}", order.getOrderId());
//        if (order == null) return null;
//
//        OrderDTO dto = new OrderDTO();
//        dto.setOrderId(order.getOrderId());
//        dto.setUserId(order.getUserId());
//        dto.setRestaurantId(order.getRestaurantId());
//        dto.setDeliveryAddress(order.getDeliveryAddress());
//        dto.setOrderTime(order.getOrderTime());
//        dto.setDeliveryTime(order.getDeliveryTime());
//        dto.setStatus(order.getStatus());
//        dto.setTotalAmount(order.getTotalAmount());
//        dto.setPaymentId(order.getPaymentId());
//        dto.setIdempotencyKey(order.getIdempotencyKey());
//        dto.setDeliveryAgentId(order.getDeliveryAgentId());
//        dto.setDeliveryId(order.getDeliveryId());
//
//        if (order.getItems() != null && !order.getItems().isEmpty()) {
//            List<OrderItemDTO> items = order.getItems().stream()
//                    .map(this::convertOrderItemToDTO)
//                    .collect(Collectors.toList());
//            dto.setItems(items);
//        } else {
//            dto.setItems(Collections.emptyList());
//        }
//        return dto;
//    }
//
//    private OrderItemDTO convertOrderItemToDTO(OrderItem orderItem) {
//        OrderItemDTO dto = new OrderItemDTO();
//        dto.setMenuItemId(orderItem.getMenuItemId());
//        dto.setItemName(orderItem.getItemName());
//        dto.setQuantity(orderItem.getQuantity());
//        dto.setPrice(orderItem.getPrice());
//        return dto;
//    }
//
//
//    // In your OrderServiceImpl.java
//    public List<OrderDTO> getRestaurantOrders(Long restaurantId) {
//        // Get active orders only
//        List<OrderStatus> activeStatuses = Arrays.asList(
//                OrderStatus.PENDING,
//                OrderStatus.ACCEPTED,
//                OrderStatus.IN_COOKING,
//                OrderStatus.OUT_FOR_DELIVERY
//        );
//
//        List<Order> orders = orderRepository.findByRestaurantIdAndStatusIn(restaurantId, activeStatuses);
//        return orders.stream().map(this::convertToDTO).collect(Collectors.toList());
//    }
//
//    // Count active orders
//    public long getActiveOrderCount(Long restaurantId) {
//        List<OrderStatus> activeStatuses = Arrays.asList(
//                OrderStatus.PENDING, OrderStatus.ACCEPTED, OrderStatus.IN_COOKING, OrderStatus.OUT_FOR_DELIVERY
//        );
//        return orderRepository.countActiveOrdersByRestaurantId(restaurantId, activeStatuses);
//    }
//
//}


//package com.fooddelivery.orderservicef.service;
//
//import java.time.Duration;
//import java.time.LocalDateTime;
//import java.util.Arrays;
//import java.util.Collections;
//import java.util.List;
//import java.util.Random;
//import java.util.concurrent.CompletableFuture;
//import java.util.stream.Collectors;
//
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Isolation;
//import org.springframework.transaction.annotation.Transactional;
//
//import com.fooddelivery.orderservicef.dto.AgentAssignmentDTO;
//import com.fooddelivery.orderservicef.dto.AgentResponseDTO;
//import com.fooddelivery.orderservicef.dto.CartDTO;
//import com.fooddelivery.orderservicef.dto.DeliveryStatus;
//import com.fooddelivery.orderservicef.dto.DeliveryStatusUpdateRequestDTO;
//import com.fooddelivery.orderservicef.dto.OrderDTO;
//import com.fooddelivery.orderservicef.dto.OrderItemDTO;
//import com.fooddelivery.orderservicef.dto.OrderRequestDTO;
//import com.fooddelivery.orderservicef.dto.OrderStatusUpdateDTO;
//import com.fooddelivery.orderservicef.dto.PaymentMethod;
//import com.fooddelivery.orderservicef.dto.PaymentRequestDTO;
//import com.fooddelivery.orderservicef.dto.PaymentResponseDTO;
//import com.fooddelivery.orderservicef.exception.InvalidOperationException;
//import com.fooddelivery.orderservicef.exception.ResourceNotFoundException;
//import com.fooddelivery.orderservicef.model.Order;
//import com.fooddelivery.orderservicef.model.OrderItem;
//import com.fooddelivery.orderservicef.model.OrderStatus;
//import com.fooddelivery.orderservicef.repository.OrderItemRepository;
//import com.fooddelivery.orderservicef.repository.OrderRepository;
//
//import lombok.extern.slf4j.Slf4j;
//
//@Slf4j
//@Service
//public class OrderServiceImpl implements OrderService {
//
//    private final OrderRepository orderRepository;
//    private final OrderItemRepository orderItemRepository;
//    private final CartServiceImpl cartServiceImpl;
//    private final PaymentServiceClient paymentServiceClient;
//    private final RestaurantServiceClient restaurantServiceClient;
//    private final AgentServiceClient agentServiceClient;
//
//    public OrderServiceImpl(OrderRepository orderRepository,
//                            OrderItemRepository orderItemRepository,
//                            CartServiceImpl cartServiceImpl,
//                            PaymentServiceClient paymentServiceClient,
//                            RestaurantServiceClient restaurantServiceClient,
//                            AgentServiceClient agentServiceClient) {
//        this.orderRepository = orderRepository;
//        this.orderItemRepository = orderItemRepository;
//        this.cartServiceImpl = cartServiceImpl;
//        this.paymentServiceClient = paymentServiceClient;
//        this.restaurantServiceClient = restaurantServiceClient;
//        this.agentServiceClient = agentServiceClient;
//    }
//
//    @Override
//    @Transactional(isolation = Isolation.SERIALIZABLE, timeout = 30)
//    public OrderDTO placeOrder(OrderRequestDTO request, String idempotencyKey) {
//        log.info("Received place order request: userId={}, restaurantId={}, idempotencyKey={}",
//                request.getUserId(), request.getRestaurantId(), idempotencyKey);
//
//        try {
//            // Idempotency check
//            if (orderRepository.existsByIdempotencyKey(idempotencyKey)) {
//                log.warn("Duplicate order for idempotencyKey={}", idempotencyKey);
//                return orderRepository.findByIdempotencyKey(idempotencyKey)
//                        .map(this::convertToDTO)
//                        .orElseThrow(() -> {
//                            log.error("Idempotency key exists but order not found. Key={}", idempotencyKey);
//                            return new IllegalStateException("Inconsistent idempotency state");
//                        });
//            }
//
//            Long userId = request.getUserId();
//            Long restaurantId = request.getRestaurantId();
//
//            if (userId == null || restaurantId == null) {
//                log.error("Missing required fields: userId or restaurantId is null");
//                throw new InvalidOperationException("User ID and Restaurant ID are required");
//            }
//
//            // ✅ FIXED: Use items from request FIRST, then fallback to cart
//            List<OrderItemDTO> orderItems = request.getItems();
//            double totalAmount;
//
//            log.info("=== ORDER PLACEMENT DEBUG ===");
//            log.info("Request items: {}", orderItems != null ? orderItems.size() : "null");
//            log.info("Request total amount: {}", request.getTotalAmount());
//
//            if (orderItems != null && !orderItems.isEmpty()) {
//                // ✅ Use items from request (preferred method)
//                log.info("✅ Using items from request: {} items", orderItems.size());
//                totalAmount = request.getTotalAmount() != null ? request.getTotalAmount() : calculateTotalAmountFromRequestItems(orderItems);
//                log.info("Total amount from request: {}", totalAmount);
//            } else {
//                // Fallback to cart (existing logic)
//                log.info("⚠️ No items in request, checking cart for userId: {}", userId);
//                CartDTO cart = cartServiceImpl.getCartByUserId(userId);
//
//                if (cart == null || cart.getItems() == null || cart.getItems().isEmpty()) {
//                    log.error("❌ Cannot place order: No items in request and cart is empty");
//                    throw new InvalidOperationException("Cannot place order without items. Please add items to cart or include them in the request.");
//                }
//
//                log.info("📋 Using cart items: {} items", cart.getItems().size());
//                totalAmount = calculateTotalAmount(cart);
//                orderItems = convertCartItemsToOrderItemDTOs(cart);
//            }
//
//            log.info("Final total amount: {}", totalAmount);
//            log.info("=== END DEBUG ===");
//
//            // Validate order items
//            if (orderItems.isEmpty()) {
//                throw new InvalidOperationException("Order must contain at least one item");
//            }
//
//            // Create and save order
//            Order order = createOrder(request, idempotencyKey, totalAmount);
//            List<OrderItem> orderItemEntities = convertOrderItemDTOsToOrderItems(orderItems, order);
//            order.setItems(orderItemEntities);
//
//            Order savedOrder = orderRepository.save(order);
//            orderItemRepository.saveAll(orderItemEntities);
//
//            // Process payment
//            PaymentResponseDTO paymentResponse;
//            try {
//                paymentResponse = processPayment(savedOrder);
//                savedOrder.setPaymentId(paymentResponse.getPaymentId());
//                orderRepository.save(savedOrder);
//            } catch (Exception ex) {
//                log.error("Payment failed for orderId={}, userId={}", savedOrder.getOrderId(), userId, ex);
//                throw new InvalidOperationException("Payment processing failed: " + ex.getMessage());
//            }
//
//            // Clear cart only if we used cart items (not request items)
//            if (request.getItems() == null || request.getItems().isEmpty()) {
//                try {
//                    cartServiceImpl.clearCart(userId);
//                    log.info("Cart cleared for userId: {}", userId);
//                } catch (Exception ex) {
//                    log.warn("Failed to clear cart for userId: {}", userId, ex);
//                    // Don't fail the order if cart clearing fails
//                }
//            }
//
//            log.info("✅ Order placed successfully with ID={} and paymentId={}",
//                    savedOrder.getOrderId(), savedOrder.getPaymentId());
//            return convertToDTO(savedOrder);
//
//        } catch (InvalidOperationException | ResourceNotFoundException ex) {
//            log.error("Business validation failed during order placement", ex);
//            throw ex;
//        } catch (Exception ex) {
//            log.error("Unexpected error while placing order", ex);
//            throw new RuntimeException("Failed to place order: " + ex.getMessage(), ex);
//        }
//    }
//
//    @Override
//    @Transactional(isolation = Isolation.REPEATABLE_READ, timeout = 10)
//    public OrderDTO updateOrderStatus(OrderStatusUpdateDTO statusUpdateDTO) {
//        log.info("Updating order status: orderId={}, newStatus={}, restaurantId={}",
//                statusUpdateDTO.getOrderId(), statusUpdateDTO.getStatus(), statusUpdateDTO.getRestaurantId());
//
//        try {
//            Order order = orderRepository.findByIdWithLock(statusUpdateDTO.getOrderId())
//                    .orElseThrow(() -> {
//                        log.error("Order not found for ID={}", statusUpdateDTO.getOrderId());
//                        return new ResourceNotFoundException("Order not found");
//                    });
//
//            if (!order.getRestaurantId().equals(statusUpdateDTO.getRestaurantId())) {
//                log.warn("Unauthorized update attempt by restaurantId={} for orderId={}",
//                        statusUpdateDTO.getRestaurantId(), order.getOrderId());
//                throw new InvalidOperationException("Restaurant is not authorized to update this order");
//            }
//
//            if (!order.getStatus().canTransitionTo(statusUpdateDTO.getStatus())) {
//                log.warn("Invalid status transition from {} to {}",
//                        order.getStatus(), statusUpdateDTO.getStatus());
//                throw new InvalidOperationException(String.format("Invalid status transition from %s to %s",
//                        order.getStatus(), statusUpdateDTO.getStatus()));
//            }
//
//            order.setStatus(statusUpdateDTO.getStatus());
//            handleStatusUpdatesAfterTransition(order);
//            Order updatedOrder = orderRepository.save(order);
//
//            log.info("Order status updated successfully for orderId={} to status={}",
//                    updatedOrder.getOrderId(), updatedOrder.getStatus());
//
//            return convertToDTO(updatedOrder);
//
//        } catch (InvalidOperationException | ResourceNotFoundException ex) {
//            log.error("Order status update failed due to validation", ex);
//            throw ex;
//        } catch (Exception ex) {
//            log.error("Unexpected error while updating order status", ex);
//            throw new RuntimeException("Failed to update order status", ex);
//        }
//    }
//
//    @Override
//    @Transactional(readOnly = true)
//    public List<OrderDTO> getUserOrders(Long userId) {
//        log.info("Retrieving orders for userId={}", userId);
//        return orderRepository.findByUserId(userId).stream()
//                .map(this::convertToDTO)
//                .collect(Collectors.toList());
//    }
//
//    // ✅ FIXED: Added @Override and proper error handling
//    @Override
//    @Transactional(readOnly = true)
//    public List<OrderDTO> getRestaurantOrders(Long restaurantId) {
//        log.info("🔍 Fetching orders for restaurant ID: {}", restaurantId);
//
//        try {
//            // Validate input
//            if (restaurantId == null || restaurantId <= 0) {
//                log.error("❌ Invalid restaurant ID: {}", restaurantId);
//                throw new InvalidOperationException("Invalid restaurant ID");
//            }
//
//            // Get active orders only
//            List<OrderStatus> activeStatuses = Arrays.asList(
//                    OrderStatus.PENDING,
//                    OrderStatus.ACCEPTED,
//                    OrderStatus.IN_COOKING,
//                    OrderStatus.OUT_FOR_DELIVERY
//            );
//
//            List<Order> orders = orderRepository.findByRestaurantIdAndStatusIn(restaurantId, activeStatuses);
//
//            log.info("✅ Found {} active orders for restaurant {}", orders.size(), restaurantId);
//
//            return orders.stream().map(this::convertToDTO).collect(Collectors.toList());
//
//        } catch (InvalidOperationException ex) {
//            log.error("❌ Validation error: {}", ex.getMessage());
//            throw ex;
//        } catch (Exception ex) {
//            log.error("❌ Error fetching restaurant orders for ID {}: {}", restaurantId, ex.getMessage(), ex);
//            throw new RuntimeException("Failed to fetch restaurant orders: " + ex.getMessage(), ex);
//        }
//    }
//
//    // ✅ FIXED: Added @Override and proper error handling
//
//    @Transactional(readOnly = true)
//    public long getActiveOrderCount(Long restaurantId) {
//        log.info("🔍 Counting active orders for restaurant ID: {}", restaurantId);
//
//        try {
//            if (restaurantId == null || restaurantId <= 0) {
//                log.error("❌ Invalid restaurant ID: {}", restaurantId);
//                return 0;
//            }
//
//            List<OrderStatus> activeStatuses = Arrays.asList(
//                    OrderStatus.PENDING, OrderStatus.ACCEPTED, OrderStatus.IN_COOKING, OrderStatus.OUT_FOR_DELIVERY
//            );
//
//            long count = orderRepository.countActiveOrdersByRestaurantId(restaurantId, activeStatuses);
//            log.info("✅ Found {} active orders for restaurant {}", count, restaurantId);
//            return count;
//
//        } catch (Exception e) {
//            log.error("❌ Error counting restaurant orders: {}", e.getMessage(), e);
//            return 0;
//        }
//    }
//
//    @Override
//    @Transactional(readOnly = true)
//    public OrderDTO getOrderDetails(Long orderId) {
//        log.info("Retrieving order details for orderId={}", orderId);
//        return orderRepository.findById(orderId)
//                .map(this::convertToDTO)
//                .orElseThrow(() -> new ResourceNotFoundException("Order not found"));
//    }
//
//    @Override
//    public boolean orderExists(String idempotencyKey) {
//        return orderRepository.existsByIdempotencyKey(idempotencyKey);
//    }
//
//    // ✅ NEW: Calculate total amount from request items
//    private double calculateTotalAmountFromRequestItems(List<OrderItemDTO> items) {
//        return items.stream()
//                .mapToDouble(item -> item.getPrice() * item.getQuantity())
//                .sum();
//    }
//
//    // ✅ EXISTING: Calculate total amount from cart (fallback)
//    private double calculateTotalAmount(CartDTO cartDTO) {
//        return cartDTO.getItems().stream()
//                .mapToDouble(item -> item.getPrice() * item.getQuantity())
//                .sum();
//    }
//
//    // ✅ NEW: Convert cart items to OrderItemDTO (for fallback scenario)
//    private List<OrderItemDTO> convertCartItemsToOrderItemDTOs(CartDTO cart) {
//        return cart.getItems().stream()
//                .map(cartItem -> {
//                    OrderItemDTO dto = new OrderItemDTO();
//                    dto.setMenuItemId(cartItem.getMenuItemId());
//                    dto.setItemName(cartItem.getItemName());
//                    dto.setQuantity(cartItem.getQuantity());
//                    dto.setPrice(cartItem.getPrice());
//                    return dto;
//                })
//                .collect(Collectors.toList());
//    }
//
//    // ✅ NEW: Convert OrderItemDTO to OrderItem entities
//    private List<OrderItem> convertOrderItemDTOsToOrderItems(List<OrderItemDTO> orderItems, Order order) {
//        return orderItems.stream()
//                .map(dto -> {
//                    OrderItem orderItem = new OrderItem();
//                    orderItem.setOrder(order);
//                    orderItem.setMenuItemId(dto.getMenuItemId());
//                    orderItem.setItemName(dto.getItemName());
//                    orderItem.setQuantity(dto.getQuantity());
//                    orderItem.setPrice(dto.getPrice());
//                    return orderItem;
//                })
//                .collect(Collectors.toList());
//    }
//
//    // ✅ EXISTING: Convert cart items to OrderItem entities (fallback)
//    private List<OrderItem> convertCartItemsToOrderItems(CartDTO cartDTO, Order order) {
//        return cartDTO.getItems().stream()
//                .map(cartItem -> {
//                    OrderItem orderItem = new OrderItem();
//                    orderItem.setOrder(order);
//                    orderItem.setMenuItemId(cartItem.getMenuItemId());
//                    orderItem.setItemName(cartItem.getItemName());
//                    orderItem.setQuantity(cartItem.getQuantity());
//                    orderItem.setPrice(cartItem.getPrice());
//                    return orderItem;
//                })
//                .collect(Collectors.toList());
//    }
//
//    private Order createOrder(OrderRequestDTO request, String idempotencyKey, double totalAmount) {
//        Order order = new Order();
//        order.setIdempotencyKey(idempotencyKey);
//        order.setUserId(request.getUserId());
//        order.setRestaurantId(request.getRestaurantId());
//        order.setStatus(OrderStatus.PENDING);
//        order.setTotalAmount(totalAmount);
//        order.setOrderTime(LocalDateTime.now());
//        order.setDeliveryAddress(request.getDeliveryAddress());
//        return order;
//    }
//
//    private PaymentResponseDTO processPayment(Order order) {
//        PaymentRequestDTO paymentRequest = new PaymentRequestDTO();
//        paymentRequest.setOrderId(order.getOrderId());
//        paymentRequest.setPaymentAmount(order.getTotalAmount());
//        paymentRequest.setPaymentMethod(PaymentMethod.Card);
//        paymentRequest.setCreatedBy(order.getUserId().toString());
//        return paymentServiceClient.processPayment(paymentRequest);
//    }
//
//    private void handleStatusUpdatesAfterTransition(Order order) {
//        if (order.getStatus() == OrderStatus.OUT_FOR_DELIVERY) {
//            assignDeliveryAgent(order);
//            CompletableFuture.runAsync(() -> {
//                try {
//                    Thread.sleep(Duration.ofSeconds(30 + new Random().nextInt(16)).toMillis());
//                    completeOrderAsync(order.getOrderId());
//                } catch (InterruptedException ignored) {
//                    Thread.currentThread().interrupt();
//                    log.warn("Order auto-completion interrupted for orderId={}", order.getOrderId());
//                }
//            });
//        } else if (order.getStatus() == OrderStatus.COMPLETED) {
//            order.setDeliveryTime(LocalDateTime.now());
//            if (order.getDeliveryId() != null) {
//                try {
//                    DeliveryStatusUpdateRequestDTO statusUpdate = DeliveryStatusUpdateRequestDTO.builder()
//                            .status(DeliveryStatus.DELIVERED)
//                            .estimatedDeliveryTime(LocalDateTime.now())
//                            .build();
//                    agentServiceClient.updateDeliveryStatus(order.getDeliveryId(), statusUpdate);
//                    log.info("Delivery status updated to DELIVERED in delivery-service for deliveryId={}",
//                            order.getDeliveryId());
//                } catch (Exception e) {
//                    log.error("Failed to update delivery status in delivery-service for orderId={}: {}",
//                            order.getOrderId(), e.getMessage());
//                }
//            } else {
//                log.warn("Order {} completed but no deliveryId found. Cannot update delivery-service status.",
//                        order.getOrderId());
//            }
//        }
//    }
//
//    @Transactional
//    protected void completeOrderAsync(Long orderId) {
//        try {
//            Order order = orderRepository.findByIdWithLock(orderId)
//                    .orElseThrow(() -> new ResourceNotFoundException("Order not found in async complete"));
//
//            if (order.getStatus() == OrderStatus.OUT_FOR_DELIVERY &&
//                    order.getStatus().canTransitionTo(OrderStatus.COMPLETED)) {
//                order.setStatus(OrderStatus.COMPLETED);
//                order.setDeliveryTime(LocalDateTime.now());
//                orderRepository.save(order);
//                log.info("Order auto-completed via async flow, orderId={}", orderId);
//                handleStatusUpdatesAfterTransition(order);
//            }
//        } catch (Exception e) {
//            log.error("Error in async order completion for orderId={}: {}", orderId, e.getMessage());
//        }
//    }
//
//    private void assignDeliveryAgent(Order order) {
//        try {
//            AgentAssignmentDTO assignmentDTO = new AgentAssignmentDTO();
//            assignmentDTO.setOrderId(order.getOrderId());
//            assignmentDTO.setRestaurantId(order.getRestaurantId());
//            assignmentDTO.setDeliveryAddress(order.getDeliveryAddress());
//
//            AgentResponseDTO agentResponse = agentServiceClient.assignDeliveryAgent(assignmentDTO);
//            order.setDeliveryAgentId(agentResponse.getAgentId());
//            order.setDeliveryId(agentResponse.getDeliveryId());
//            orderRepository.save(order);
//
//            log.info("Delivery agent assigned for orderId={}, agentId={}, deliveryId={}",
//                    order.getOrderId(), agentResponse.getAgentId(), agentResponse.getDeliveryId());
//        } catch (Exception e) {
//            log.error("Failed to assign delivery agent for orderId={}: {}", order.getOrderId(), e.getMessage());
//            throw new InvalidOperationException("Failed to assign delivery agent");
//        }
//    }
//
//    private OrderDTO convertToDTO(Order order) {
//        log.debug("Converting Order to DTO: {}", order.getOrderId());
//        if (order == null) return null;
//
//        OrderDTO dto = new OrderDTO();
//        dto.setOrderId(order.getOrderId());
//        dto.setUserId(order.getUserId());
//        dto.setRestaurantId(order.getRestaurantId());
//        dto.setDeliveryAddress(order.getDeliveryAddress());
//        dto.setOrderTime(order.getOrderTime());
//        dto.setDeliveryTime(order.getDeliveryTime());
//        dto.setStatus(order.getStatus());
//        dto.setTotalAmount(order.getTotalAmount());
//        dto.setPaymentId(order.getPaymentId());
//        dto.setIdempotencyKey(order.getIdempotencyKey());
//        dto.setDeliveryAgentId(order.getDeliveryAgentId());
//        dto.setDeliveryId(order.getDeliveryId());
//
//        if (order.getItems() != null && !order.getItems().isEmpty()) {
//            List<OrderItemDTO> items = order.getItems().stream()
//                    .map(this::convertOrderItemToDTO)
//                    .collect(Collectors.toList());
//            dto.setItems(items);
//        } else {
//            dto.setItems(Collections.emptyList());
//        }
//        return dto;
//    }
//
//    private OrderItemDTO convertOrderItemToDTO(OrderItem orderItem) {
//        OrderItemDTO dto = new OrderItemDTO();
//        dto.setMenuItemId(orderItem.getMenuItemId());
//        dto.setItemName(orderItem.getItemName());
//        dto.setQuantity(orderItem.getQuantity());
//        dto.setPrice(orderItem.getPrice());
//        return dto;
//    }
//}

//
//package com.fooddelivery.orderservicef.service;
//
//import java.time.Duration;
//import java.time.LocalDateTime;
//import java.util.Arrays;
//import java.util.Collections;
//import java.util.List;
//import java.util.Random;
//import java.util.concurrent.CompletableFuture;
//import java.util.stream.Collectors;
//
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Isolation;
//import org.springframework.transaction.annotation.Transactional;
//
//import com.fooddelivery.orderservicef.dto.AgentAssignmentDTO;
//import com.fooddelivery.orderservicef.dto.AgentResponseDTO;
//import com.fooddelivery.orderservicef.dto.CartDTO;
//import com.fooddelivery.orderservicef.dto.DeliveryStatus;
//import com.fooddelivery.orderservicef.dto.DeliveryStatusUpdateRequestDTO;
//import com.fooddelivery.orderservicef.dto.OrderDTO;
//import com.fooddelivery.orderservicef.dto.OrderItemDTO;
//import com.fooddelivery.orderservicef.dto.OrderRequestDTO;
//import com.fooddelivery.orderservicef.dto.OrderStatusUpdateDTO;
//import com.fooddelivery.orderservicef.dto.PaymentMethod;
//import com.fooddelivery.orderservicef.dto.PaymentRequestDTO;
//import com.fooddelivery.orderservicef.dto.PaymentResponseDTO;
//import com.fooddelivery.orderservicef.exception.InvalidOperationException;
//import com.fooddelivery.orderservicef.exception.ResourceNotFoundException;
//import com.fooddelivery.orderservicef.model.Order;
//import com.fooddelivery.orderservicef.model.OrderItem;
//import com.fooddelivery.orderservicef.model.OrderStatus;
//import com.fooddelivery.orderservicef.repository.OrderItemRepository;
//import com.fooddelivery.orderservicef.repository.OrderRepository;
//
//import lombok.extern.slf4j.Slf4j;
//
//@Slf4j
//@Service
//public class OrderServiceImpl implements OrderService {
//
//    private final OrderRepository orderRepository;
//    private final OrderItemRepository orderItemRepository;
//    private final CartServiceImpl cartServiceImpl;
//    private final PaymentServiceClient paymentServiceClient;
//    private final RestaurantServiceClient restaurantServiceClient;
//    private final AgentServiceClient agentServiceClient;
//
//    // ✅ ADD: Constants for retry mechanism
//    private static final int MAX_RETRIES = 3;
//    private static final long RETRY_DELAY_MS = 1000;
//
//    public OrderServiceImpl(OrderRepository orderRepository,
//                            OrderItemRepository orderItemRepository,
//                            CartServiceImpl cartServiceImpl,
//                            PaymentServiceClient paymentServiceClient,
//                            RestaurantServiceClient restaurantServiceClient,
//                            AgentServiceClient agentServiceClient) {
//        this.orderRepository = orderRepository;
//        this.orderItemRepository = orderItemRepository;
//        this.cartServiceImpl = cartServiceImpl;
//        this.paymentServiceClient = paymentServiceClient;
//        this.restaurantServiceClient = restaurantServiceClient;
//        this.agentServiceClient = agentServiceClient;
//    }
//
//    @Override
//    @Transactional(isolation = Isolation.SERIALIZABLE, timeout = 30)
//    public OrderDTO placeOrder(OrderRequestDTO request, String idempotencyKey) {
//        log.info("Received place order request: userId={}, restaurantId={}, idempotencyKey={}",
//                request.getUserId(), request.getRestaurantId(), idempotencyKey);
//
//        try {
//            // ✅ ENHANCED: Validate request first
//            validateOrderRequest(request);
//
//            // Idempotency check
//            if (orderRepository.existsByIdempotencyKey(idempotencyKey)) {
//                log.warn("Duplicate order for idempotencyKey={}", idempotencyKey);
//                return orderRepository.findByIdempotencyKey(idempotencyKey)
//                        .map(this::convertToDTO)
//                        .orElseThrow(() -> {
//                            log.error("Idempotency key exists but order not found. Key={}", idempotencyKey);
//                            return new IllegalStateException("Inconsistent idempotency state");
//                        });
//            }
//
//            Long userId = request.getUserId();
//            Long restaurantId = request.getRestaurantId();
//
//            // ✅ FIXED: Use items from request FIRST, then fallback to cart
//            List<OrderItemDTO> orderItems = request.getItems();
//            double totalAmount;
//
//            log.info("=== ORDER PLACEMENT DEBUG ===");
//            log.info("Request items: {}", orderItems != null ? orderItems.size() : "null");
//            log.info("Request total amount: {}", request.getTotalAmount());
//
//            if (orderItems != null && !orderItems.isEmpty()) {
//                // ✅ Use items from request (preferred method)
//                log.info("✅ Using items from request: {} items", orderItems.size());
//
//                // ✅ ENHANCED: Validate each item has required fields
//                validateOrderItems(orderItems);
//
//                totalAmount = request.getTotalAmount() != null ? request.getTotalAmount() : calculateTotalAmountFromRequestItems(orderItems);
//                log.info("Total amount from request: {}", totalAmount);
//            } else {
//                // Fallback to cart (existing logic)
//                log.info("⚠️ No items in request, checking cart for userId: {}", userId);
//                CartDTO cart = cartServiceImpl.getCartByUserId(userId);
//
//                if (cart == null || cart.getItems() == null || cart.getItems().isEmpty()) {
//                    log.error("❌ Cannot place order: No items in request and cart is empty");
//                    throw new InvalidOperationException("Cannot place order without items. Please add items to cart or include them in the request.");
//                }
//
//                log.info("📋 Using cart items: {} items", cart.getItems().size());
//                totalAmount = calculateTotalAmount(cart);
//                orderItems = convertCartItemsToOrderItemDTOs(cart);
//            }
//
//            log.info("Final total amount: {}", totalAmount);
//            log.info("=== END DEBUG ===");
//
//            // Validate order items
//            if (orderItems.isEmpty()) {
//                throw new InvalidOperationException("Order must contain at least one item");
//            }
//
//            // Create and save order
//            Order order = createOrder(request, idempotencyKey, totalAmount);
//            List<OrderItem> orderItemEntities = convertOrderItemDTOsToOrderItems(orderItems, order);
//            order.setItems(orderItemEntities);
//
//            Order savedOrder = orderRepository.save(order);
//            orderItemRepository.saveAll(orderItemEntities);
//
//            // ✅ ENHANCED: Process payment with retry mechanism
//            PaymentResponseDTO paymentResponse;
//            try {
//                paymentResponse = processPaymentWithRetry(savedOrder);
//                savedOrder.setPaymentId(paymentResponse.getPaymentId());
//                orderRepository.save(savedOrder);
//            } catch (Exception ex) {
//                log.error("Payment failed for orderId={}, userId={}", savedOrder.getOrderId(), userId, ex);
//                throw new InvalidOperationException("Payment processing failed: " + ex.getMessage());
//            }
//
//            // Clear cart only if we used cart items (not request items)
//            if (request.getItems() == null || request.getItems().isEmpty()) {
//                try {
//                    cartServiceImpl.clearCart(userId);
//                    log.info("Cart cleared for userId: {}", userId);
//                } catch (Exception ex) {
//                    log.warn("Failed to clear cart for userId: {}", userId, ex);
//                    // Don't fail the order if cart clearing fails
//                }
//            }
//
//            log.info("✅ Order placed successfully with ID={} and paymentId={}",
//                    savedOrder.getOrderId(), savedOrder.getPaymentId());
//            return convertToDTO(savedOrder);
//
//        } catch (InvalidOperationException | ResourceNotFoundException ex) {
//            log.error("Business validation failed during order placement", ex);
//            throw ex;
//        } catch (Exception ex) {
//            log.error("Unexpected error while placing order", ex);
//            throw new RuntimeException("Failed to place order: " + ex.getMessage(), ex);
//        }
//    }
//
//    @Override
//    @Transactional(isolation = Isolation.REPEATABLE_READ, timeout = 10)
//    public OrderDTO updateOrderStatus(OrderStatusUpdateDTO statusUpdateDTO) {
//        log.info("Updating order status: orderId={}, newStatus={}, restaurantId={}",
//                statusUpdateDTO.getOrderId(), statusUpdateDTO.getStatus(), statusUpdateDTO.getRestaurantId());
//
//        try {
//            Order order = orderRepository.findByIdWithLock(statusUpdateDTO.getOrderId())
//                    .orElseThrow(() -> {
//                        log.error("Order not found for ID={}", statusUpdateDTO.getOrderId());
//                        return new ResourceNotFoundException("Order not found");
//                    });
//
//            if (!order.getRestaurantId().equals(statusUpdateDTO.getRestaurantId())) {
//                log.warn("Unauthorized update attempt by restaurantId={} for orderId={}",
//                        statusUpdateDTO.getRestaurantId(), order.getOrderId());
//                throw new InvalidOperationException("Restaurant is not authorized to update this order");
//            }
//
//            if (!order.getStatus().canTransitionTo(statusUpdateDTO.getStatus())) {
//                log.warn("Invalid status transition from {} to {}",
//                        order.getStatus(), statusUpdateDTO.getStatus());
//                throw new InvalidOperationException(String.format("Invalid status transition from %s to %s",
//                        order.getStatus(), statusUpdateDTO.getStatus()));
//            }
//
//            order.setStatus(statusUpdateDTO.getStatus());
//            handleStatusUpdatesAfterTransition(order);
//            Order updatedOrder = orderRepository.save(order);
//
//            log.info("Order status updated successfully for orderId={} to status={}",
//                    updatedOrder.getOrderId(), updatedOrder.getStatus());
//
//            return convertToDTO(updatedOrder);
//
//        } catch (InvalidOperationException | ResourceNotFoundException ex) {
//            log.error("Order status update failed due to validation", ex);
//            throw ex;
//        } catch (Exception ex) {
//            log.error("Unexpected error while updating order status", ex);
//            throw new RuntimeException("Failed to update order status", ex);
//        }
//    }
//
//    @Override
//    @Transactional(readOnly = true)
//    public List<OrderDTO> getUserOrders(Long userId) {
//        log.info("Retrieving orders for userId={}", userId);
//        return orderRepository.findByUserId(userId).stream()
//                .map(this::convertToDTO)
//                .collect(Collectors.toList());
//    }
//
//    @Override
//    @Transactional(readOnly = true)
//    public List<OrderDTO> getRestaurantOrders(Long restaurantId) {
//        log.info("🔍 Fetching orders for restaurant ID: {}", restaurantId);
//
//        try {
//            // Validate input
//            if (restaurantId == null || restaurantId <= 0) {
//                log.error("❌ Invalid restaurant ID: {}", restaurantId);
//                throw new InvalidOperationException("Invalid restaurant ID");
//            }
//
//            // Get active orders only
//            List<OrderStatus> activeStatuses = Arrays.asList(
//                    OrderStatus.PENDING,
//                    OrderStatus.ACCEPTED,
//                    OrderStatus.IN_COOKING,
//                    OrderStatus.OUT_FOR_DELIVERY
//            );
//
//            List<Order> orders = orderRepository.findByRestaurantIdAndStatusIn(restaurantId, activeStatuses);
//
//            log.info("✅ Found {} active orders for restaurant {}", orders.size(), restaurantId);
//
//            return orders.stream().map(this::convertToDTO).collect(Collectors.toList());
//
//        } catch (InvalidOperationException ex) {
//            log.error("❌ Validation error: {}", ex.getMessage());
//            throw ex;
//        } catch (Exception ex) {
//            log.error("❌ Error fetching restaurant orders for ID {}: {}", restaurantId, ex.getMessage(), ex);
//            throw new RuntimeException("Failed to fetch restaurant orders: " + ex.getMessage(), ex);
//        }
//    }
//
//    @Transactional(readOnly = true)
//    public long getActiveOrderCount(Long restaurantId) {
//        log.info("🔍 Counting active orders for restaurant ID: {}", restaurantId);
//
//        try {
//            if (restaurantId == null || restaurantId <= 0) {
//                log.error("❌ Invalid restaurant ID: {}", restaurantId);
//                return 0;
//            }
//
//            List<OrderStatus> activeStatuses = Arrays.asList(
//                    OrderStatus.PENDING, OrderStatus.ACCEPTED, OrderStatus.IN_COOKING, OrderStatus.OUT_FOR_DELIVERY
//            );
//
//            long count = orderRepository.countActiveOrdersByRestaurantId(restaurantId, activeStatuses);
//            log.info("✅ Found {} active orders for restaurant {}", count, restaurantId);
//            return count;
//
//        } catch (Exception e) {
//            log.error("❌ Error counting restaurant orders: {}", e.getMessage(), e);
//            return 0;
//        }
//    }
//
//    @Override
//    @Transactional(readOnly = true)
//    public OrderDTO getOrderDetails(Long orderId) {
//        log.info("Retrieving order details for orderId={}", orderId);
//        return orderRepository.findById(orderId)
//                .map(this::convertToDTO)
//                .orElseThrow(() -> new ResourceNotFoundException("Order not found"));
//    }
//
//    @Override
//    public boolean orderExists(String idempotencyKey) {
//        return orderRepository.existsByIdempotencyKey(idempotencyKey);
//    }
//
//    // ✅ ENHANCED: Comprehensive request validation
//    private void validateOrderRequest(OrderRequestDTO request) {
//        if (request == null) {
//            throw new InvalidOperationException("Order request cannot be null");
//        }
//
//        if (request.getUserId() == null || request.getUserId() <= 0) {
//            throw new InvalidOperationException("Valid user ID is required");
//        }
//
//        if (request.getRestaurantId() == null || request.getRestaurantId() <= 0) {
//            throw new InvalidOperationException("Valid restaurant ID is required");
//        }
//
//        if (request.getDeliveryAddress() == null || request.getDeliveryAddress().trim().isEmpty()) {
//            throw new InvalidOperationException("Delivery address is required");
//        }
//    }
//
//    // ✅ FIXED: Updated validation for primitive double
//    private void validateOrderItems(List<OrderItemDTO> items) {
//        if (items == null || items.isEmpty()) {
//            throw new InvalidOperationException("Order must contain at least one item");
//        }
//
//        for (int i = 0; i < items.size(); i++) {
//            OrderItemDTO item = items.get(i);
//            String itemPosition = "Item " + (i + 1);
//
//            // Validate menuItemId (Long - wrapper type, can be null)
//            if (item.getMenuItemId() == null || item.getMenuItemId() <= 0) {
//                throw new InvalidOperationException(itemPosition + ": Valid menu item ID is required");
//            }
//
//            // Validate itemName (String can be null)
//            if (item.getItemName() == null || item.getItemName().trim().isEmpty()) {
//                log.warn("{}: ItemName is null/empty for menuItemId={}. Will use fallback.", itemPosition, item.getMenuItemId());
//                // Don't throw error here, let the conversion method handle it with fallback
//            }
//
//            // Validate quantity (Integer - wrapper type, can be null)
//            if (item.getQuantity() == null || item.getQuantity() <= 0) {
//                throw new InvalidOperationException(itemPosition + ": Valid quantity is required");
//            }
//
//            // ✅ FIXED: Remove null check for primitive double, only validate value
//            if (item.getPrice() <= 0.0) {
//                throw new InvalidOperationException(itemPosition + ": Valid price is required (must be greater than 0)");
//            }
//
//            // ✅ ADDITIONAL: Validate other double fields that might be used
//            if (item.getOriginalPrice() < 0.0) {
//                throw new InvalidOperationException(itemPosition + ": Original price cannot be negative");
//            }
//
//            if (item.getDiscount() < 0.0) {
//                throw new InvalidOperationException(itemPosition + ": Discount cannot be negative");
//            }
//
//            if (item.getTaxRate() < 0.0) {
//                throw new InvalidOperationException(itemPosition + ": Tax rate cannot be negative");
//            }
//        }
//    }
//
//    // ✅ CRITICAL FIX: Ensure itemName is never null
//    private String ensureValidItemName(String itemName, Long menuItemId) {
//        if (itemName == null || itemName.trim().isEmpty()) {
//            log.warn("ItemName is null/empty for menuItemId={}. Using fallback.", menuItemId);
//            return "Menu Item " + menuItemId;
//        }
//        return itemName.trim();
//    }
//
//    // ✅ ENHANCED: Payment processing with retry mechanism
//    private PaymentResponseDTO processPaymentWithRetry(Order order) {
//        Exception lastException = null;
//
//        for (int attempt = 1; attempt <= MAX_RETRIES; attempt++) {
//            try {
//                log.info("Payment attempt {}/{} for orderId={}", attempt, MAX_RETRIES, order.getOrderId());
//                return processPayment(order);
//
//            } catch (Exception ex) {
//                lastException = ex;
//                log.warn("Payment attempt {}/{} failed for orderId={}: {}",
//                        attempt, MAX_RETRIES, order.getOrderId(), ex.getMessage());
//
//                if (attempt < MAX_RETRIES) {
//                    try {
//                        Thread.sleep(RETRY_DELAY_MS * attempt); // Exponential backoff
//                    } catch (InterruptedException ie) {
//                        Thread.currentThread().interrupt();
//                        break;
//                    }
//                }
//            }
//        }
//
//        log.error("All payment attempts failed for orderId={}", order.getOrderId());
//        throw new InvalidOperationException("Payment processing failed after " + MAX_RETRIES + " attempts: " +
//                (lastException != null ? lastException.getMessage() : "Unknown error"));
//    }
//
//    // ✅ ENHANCED: Better payment error handling
//    private PaymentResponseDTO processPayment(Order order) {
//        try {
//            PaymentRequestDTO paymentRequest = new PaymentRequestDTO();
//            paymentRequest.setOrderId(order.getOrderId());
//            paymentRequest.setPaymentAmount(order.getTotalAmount());
//            paymentRequest.setPaymentMethod(PaymentMethod.Card);
//            paymentRequest.setCreatedBy(order.getUserId().toString());
//
//            log.info("Processing payment for orderId={}, amount={}",
//                    order.getOrderId(), order.getTotalAmount());
//
//            PaymentResponseDTO response = paymentServiceClient.processPayment(paymentRequest);
//
//            log.info("Payment processed successfully: orderId={}, paymentId={}",
//                    order.getOrderId(), response.getPaymentId());
//
//            return response;
//
//        } catch (Exception ex) {
//            log.error("Payment processing failed for orderId={}: {}",
//                    order.getOrderId(), ex.getMessage(), ex);
//
//            // ✅ MORE SPECIFIC ERROR MESSAGES
//            if (ex.getMessage().contains("DUPLICATE_TRANSACTION")) {
//                throw new InvalidOperationException("Payment already processed for this order");
//            } else if (ex.getMessage().contains("INSUFFICIENT_FUNDS")) {
//                throw new InvalidOperationException("Payment failed: Insufficient funds");
//            } else {
//                throw new InvalidOperationException("Payment processing failed: " + ex.getMessage());
//            }
//        }
//    }
//
//    // ✅ NEW: Calculate total amount from request items
//    private double calculateTotalAmountFromRequestItems(List<OrderItemDTO> items) {
//        return items.stream()
//                .mapToDouble(item -> item.getPrice() * item.getQuantity())
//                .sum();
//    }
//
//    // ✅ EXISTING: Calculate total amount from cart (fallback)
//    private double calculateTotalAmount(CartDTO cartDTO) {
//        return cartDTO.getItems().stream()
//                .mapToDouble(item -> item.getPrice() * item.getQuantity())
//                .sum();
//    }
//
//    // ✅ NEW: Convert cart items to OrderItemDTO (for fallback scenario)
//    private List<OrderItemDTO> convertCartItemsToOrderItemDTOs(CartDTO cart) {
//        return cart.getItems().stream()
//                .map(cartItem -> {
//                    OrderItemDTO dto = new OrderItemDTO();
//                    dto.setMenuItemId(cartItem.getMenuItemId());
//                    dto.setItemName(ensureValidItemName(cartItem.getItemName(), cartItem.getMenuItemId()));
//                    dto.setQuantity(cartItem.getQuantity());
//                    dto.setPrice(cartItem.getPrice());
//                    return dto;
//                })
//                .collect(Collectors.toList());
//    }
//
//    // ✅ CRITICAL FIX: Enhanced OrderItem conversion with null safety
//    private List<OrderItem> convertOrderItemDTOsToOrderItems(List<OrderItemDTO> orderItems, Order order) {
//        return orderItems.stream()
//                .map(dto -> {
//                    OrderItem orderItem = new OrderItem();
//                    orderItem.setOrder(order);
//                    orderItem.setMenuItemId(dto.getMenuItemId());
//
//                    // ✅ CRITICAL FIX: Ensure itemName is never null
//                    orderItem.setItemName(ensureValidItemName(dto.getItemName(), dto.getMenuItemId()));
//
//                    orderItem.setQuantity(dto.getQuantity());
//                    orderItem.setPrice(dto.getPrice());
//                    return orderItem;
//                })
//                .collect(Collectors.toList());
//    }
//
//    // ✅ EXISTING: Convert cart items to OrderItem entities (fallback) - Enhanced
//    private List<OrderItem> convertCartItemsToOrderItems(CartDTO cartDTO, Order order) {
//        return cartDTO.getItems().stream()
//                .map(cartItem -> {
//                    OrderItem orderItem = new OrderItem();
//                    orderItem.setOrder(order);
//                    orderItem.setMenuItemId(cartItem.getMenuItemId());
//                    orderItem.setItemName(ensureValidItemName(cartItem.getItemName(), cartItem.getMenuItemId()));
//                    orderItem.setQuantity(cartItem.getQuantity());
//                    orderItem.setPrice(cartItem.getPrice());
//                    return orderItem;
//                })
//                .collect(Collectors.toList());
//    }
//
//    private Order createOrder(OrderRequestDTO request, String idempotencyKey, double totalAmount) {
//        Order order = new Order();
//        order.setIdempotencyKey(idempotencyKey);
//        order.setUserId(request.getUserId());
//        order.setRestaurantId(request.getRestaurantId());
//        order.setStatus(OrderStatus.PENDING);
//        order.setTotalAmount(totalAmount);
//        order.setOrderTime(LocalDateTime.now());
//        order.setDeliveryAddress(request.getDeliveryAddress());
//        return order;
//    }
//
//    private void handleStatusUpdatesAfterTransition(Order order) {
//        if (order.getStatus() == OrderStatus.OUT_FOR_DELIVERY) {
//            assignDeliveryAgent(order);
//            CompletableFuture.runAsync(() -> {
//                try {
//                    Thread.sleep(Duration.ofSeconds(30 + new Random().nextInt(16)).toMillis());
//                    completeOrderAsync(order.getOrderId());
//                } catch (InterruptedException ignored) {
//                    Thread.currentThread().interrupt();
//                    log.warn("Order auto-completion interrupted for orderId={}", order.getOrderId());
//                }
//            });
//        } else if (order.getStatus() == OrderStatus.COMPLETED) {
//            order.setDeliveryTime(LocalDateTime.now());
//            if (order.getDeliveryId() != null) {
//                try {
//                    DeliveryStatusUpdateRequestDTO statusUpdate = DeliveryStatusUpdateRequestDTO.builder()
//                            .status(DeliveryStatus.DELIVERED)
//                            .estimatedDeliveryTime(LocalDateTime.now())
//                            .build();
//                    agentServiceClient.updateDeliveryStatus(order.getDeliveryId(), statusUpdate);
//                    log.info("Delivery status updated to DELIVERED in delivery-service for deliveryId={}",
//                            order.getDeliveryId());
//                } catch (Exception e) {
//                    log.error("Failed to update delivery status in delivery-service for orderId={}: {}",
//                            order.getOrderId(), e.getMessage());
//                }
//            } else {
//                log.warn("Order {} completed but no deliveryId found. Cannot update delivery-service status.",
//                        order.getOrderId());
//            }
//        }
//    }
//
//    @Transactional
//    protected void completeOrderAsync(Long orderId) {
//        try {
//            Order order = orderRepository.findByIdWithLock(orderId)
//                    .orElseThrow(() -> new ResourceNotFoundException("Order not found in async complete"));
//
//            if (order.getStatus() == OrderStatus.OUT_FOR_DELIVERY &&
//                    order.getStatus().canTransitionTo(OrderStatus.COMPLETED)) {
//                order.setStatus(OrderStatus.COMPLETED);
//                order.setDeliveryTime(LocalDateTime.now());
//                orderRepository.save(order);
//                log.info("Order auto-completed via async flow, orderId={}", orderId);
//                handleStatusUpdatesAfterTransition(order);
//            }
//        } catch (Exception e) {
//            log.error("Error in async order completion for orderId={}: {}", orderId, e.getMessage());
//        }
//    }
//
//    // ✅ ENHANCED: More robust delivery agent assignment
//    private void assignDeliveryAgent(Order order) {
//        try {
//            log.info("Attempting to assign delivery agent for orderId={}", order.getOrderId());
//
//            AgentAssignmentDTO assignmentDTO = new AgentAssignmentDTO();
//            assignmentDTO.setOrderId(order.getOrderId());
//            assignmentDTO.setRestaurantId(order.getRestaurantId());
//            assignmentDTO.setDeliveryAddress(order.getDeliveryAddress());
//
//            AgentResponseDTO agentResponse = agentServiceClient.assignDeliveryAgent(assignmentDTO);
//
//            if (agentResponse == null) {
//                throw new InvalidOperationException("No response from delivery agent service");
//            }
//
//            if (agentResponse.getAgentId() == null || agentResponse.getDeliveryId() == null) {
//                throw new InvalidOperationException("Invalid agent assignment response");
//            }
//
//            order.setDeliveryAgentId(agentResponse.getAgentId());
//            order.setDeliveryId(agentResponse.getDeliveryId());
//            orderRepository.save(order);
//
//            log.info("✅ Delivery agent assigned successfully: orderId={}, agentId={}, deliveryId={}",
//                    order.getOrderId(), agentResponse.getAgentId(), agentResponse.getDeliveryId());
//
//        } catch (Exception e) {
//            log.error("❌ Failed to assign delivery agent for orderId={}: {}", order.getOrderId(), e.getMessage(), e);
//
//            // ✅ DON'T THROW EXCEPTION - Let order proceed without agent initially
//            // The restaurant can manually assign or retry later
//            log.warn("⚠️ Order will proceed without delivery agent assignment for orderId={}", order.getOrderId());
//        }
//    }
//
//    private OrderDTO convertToDTO(Order order) {
//        log.debug("Converting Order to DTO: {}", order.getOrderId());
//        if (order == null) return null;
//
//        OrderDTO dto = new OrderDTO();
//        dto.setOrderId(order.getOrderId());
//        dto.setUserId(order.getUserId());
//        dto.setRestaurantId(order.getRestaurantId());
//        dto.setDeliveryAddress(order.getDeliveryAddress());
//        dto.setOrderTime(order.getOrderTime());
//        dto.setDeliveryTime(order.getDeliveryTime());
//        dto.setStatus(order.getStatus());
//        dto.setTotalAmount(order.getTotalAmount());
//        dto.setPaymentId(order.getPaymentId());
//        dto.setIdempotencyKey(order.getIdempotencyKey());
//        dto.setDeliveryAgentId(order.getDeliveryAgentId());
//        dto.setDeliveryId(order.getDeliveryId());
//
//        if (order.getItems() != null && !order.getItems().isEmpty()) {
//            List<OrderItemDTO> items = order.getItems().stream()
//                    .map(this::convertOrderItemToDTO)
//                    .collect(Collectors.toList());
//            dto.setItems(items);
//        } else {
//            dto.setItems(Collections.emptyList());
//        }
//        return dto;
//    }
//
//    private OrderItemDTO convertOrderItemToDTO(OrderItem orderItem) {
//        OrderItemDTO dto = new OrderItemDTO();
//        dto.setMenuItemId(orderItem.getMenuItemId());
//        dto.setItemName(orderItem.getItemName());
//        dto.setQuantity(orderItem.getQuantity());
//        dto.setPrice(orderItem.getPrice());
//        return dto;
//    }
//}


package com.fooddelivery.orderservicef.service;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import com.fooddelivery.orderservicef.dto.AgentAssignmentDTO;
import com.fooddelivery.orderservicef.dto.AgentResponseDTO;
import com.fooddelivery.orderservicef.dto.CartDTO;
import com.fooddelivery.orderservicef.dto.DeliveryStatus;
import com.fooddelivery.orderservicef.dto.DeliveryStatusUpdateRequestDTO;
import com.fooddelivery.orderservicef.dto.OrderDTO;
import com.fooddelivery.orderservicef.dto.OrderItemDTO;
import com.fooddelivery.orderservicef.dto.OrderRequestDTO;
import com.fooddelivery.orderservicef.dto.OrderStatusUpdateDTO;
import com.fooddelivery.orderservicef.dto.PaymentMethod;
import com.fooddelivery.orderservicef.dto.PaymentRequestDTO;
import com.fooddelivery.orderservicef.dto.PaymentResponseDTO;
import com.fooddelivery.orderservicef.exception.InvalidOperationException;
import com.fooddelivery.orderservicef.exception.ResourceNotFoundException;
import com.fooddelivery.orderservicef.model.Order;
import com.fooddelivery.orderservicef.model.OrderItem;
import com.fooddelivery.orderservicef.model.OrderStatus;
import com.fooddelivery.orderservicef.repository.OrderItemRepository;
import com.fooddelivery.orderservicef.repository.OrderRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class OrderServiceImpl implements OrderService {

    private final OrderRepository orderRepository;
    private final OrderItemRepository orderItemRepository;
    private final CartServiceImpl cartServiceImpl;
    private final PaymentServiceClient paymentServiceClient;
    private final RestaurantServiceClient restaurantServiceClient;
    private final AgentServiceClient agentServiceClient;

    // ✅ ADD: Constants for retry mechanism
    private static final int MAX_RETRIES = 3;
    private static final long RETRY_DELAY_MS = 1000;

    public OrderServiceImpl(OrderRepository orderRepository,
                            OrderItemRepository orderItemRepository,
                            CartServiceImpl cartServiceImpl,
                            PaymentServiceClient paymentServiceClient,
                            RestaurantServiceClient restaurantServiceClient,
                            AgentServiceClient agentServiceClient) {
        this.orderRepository = orderRepository;
        this.orderItemRepository = orderItemRepository;
        this.cartServiceImpl = cartServiceImpl;
        this.paymentServiceClient = paymentServiceClient;
        this.restaurantServiceClient = restaurantServiceClient;
        this.agentServiceClient = agentServiceClient;
    }

    @Override
    @Transactional(isolation = Isolation.SERIALIZABLE, timeout = 30)
    public OrderDTO placeOrder(OrderRequestDTO request, String idempotencyKey) {
        log.info("Received place order request: userId={}, restaurantId={}, idempotencyKey={}",
                request.getUserId(), request.getRestaurantId(), idempotencyKey);

        try {
            // ✅ ENHANCED: Validate request first
            validateOrderRequest(request);

            // Idempotency check
            if (orderRepository.existsByIdempotencyKey(idempotencyKey)) {
                log.warn("Duplicate order for idempotencyKey={}", idempotencyKey);
                return orderRepository.findByIdempotencyKey(idempotencyKey)
                        .map(this::convertToDTO)
                        .orElseThrow(() -> {
                            log.error("Idempotency key exists but order not found. Key={}", idempotencyKey);
                            return new IllegalStateException("Inconsistent idempotency state");
                        });
            }

            Long userId = request.getUserId();
            Long restaurantId = request.getRestaurantId();

            // ✅ FIXED: Use items from request FIRST, then fallback to cart
            List<OrderItemDTO> orderItems = request.getItems();
            double totalAmount;

            log.info("=== ORDER PLACEMENT DEBUG ===");
            log.info("Request items: {}", orderItems != null ? orderItems.size() : "null");
            log.info("Request total amount: {}", request.getTotalAmount());

            if (orderItems != null && !orderItems.isEmpty()) {
                // ✅ Use items from request (preferred method)
                log.info("✅ Using items from request: {} items", orderItems.size());

                // ✅ ENHANCED: Validate each item has required fields
                validateOrderItems(orderItems);

                totalAmount = request.getTotalAmount() != null ? request.getTotalAmount() : calculateTotalAmountFromRequestItems(orderItems);
                log.info("Total amount from request: {}", totalAmount);
            } else {
                // Fallback to cart (existing logic)
                log.info("⚠️ No items in request, checking cart for userId: {}", userId);
                CartDTO cart = cartServiceImpl.getCartByUserId(userId);

                if (cart == null || cart.getItems() == null || cart.getItems().isEmpty()) {
                    log.error("❌ Cannot place order: No items in request and cart is empty");
                    throw new InvalidOperationException("Cannot place order without items. Please add items to cart or include them in the request.");
                }

                log.info("📋 Using cart items: {} items", cart.getItems().size());
                totalAmount = calculateTotalAmount(cart);
                orderItems = convertCartItemsToOrderItemDTOs(cart);
            }

            log.info("Final total amount: {}", totalAmount);
            log.info("=== END DEBUG ===");

            // Validate order items
            if (orderItems.isEmpty()) {
                throw new InvalidOperationException("Order must contain at least one item");
            }

            // Create and save order
            Order order = createOrder(request, idempotencyKey, totalAmount);
            List<OrderItem> orderItemEntities = convertOrderItemDTOsToOrderItems(orderItems, order);
            order.setItems(orderItemEntities);

            Order savedOrder = orderRepository.save(order);
            orderItemRepository.saveAll(orderItemEntities);

            // ✅ ENHANCED: Process payment with retry mechanism
            PaymentResponseDTO paymentResponse;
            try {
                paymentResponse = processPaymentWithRetry(savedOrder);
                savedOrder.setPaymentId(paymentResponse.getPaymentId());
                orderRepository.save(savedOrder);
            } catch (Exception ex) {
                log.error("Payment failed for orderId={}, userId={}", savedOrder.getOrderId(), userId, ex);
                throw new InvalidOperationException("Payment processing failed: " + ex.getMessage());
            }

            // Clear cart only if we used cart items (not request items)
            if (request.getItems() == null || request.getItems().isEmpty()) {
                try {
                    cartServiceImpl.clearCart(userId);
                    log.info("Cart cleared for userId: {}", userId);
                } catch (Exception ex) {
                    log.warn("Failed to clear cart for userId: {}", userId, ex);
                    // Don't fail the order if cart clearing fails
                }
            }

            log.info("✅ Order placed successfully with ID={} and paymentId={}",
                    savedOrder.getOrderId(), savedOrder.getPaymentId());
            return convertToDTO(savedOrder);

        } catch (InvalidOperationException | ResourceNotFoundException ex) {
            log.error("Business validation failed during order placement", ex);
            throw ex;
        } catch (Exception ex) {
            log.error("Unexpected error while placing order", ex);
            throw new RuntimeException("Failed to place order: " + ex.getMessage(), ex);
        }
    }

    @Override
    @Transactional(isolation = Isolation.REPEATABLE_READ, timeout = 10)
    public OrderDTO updateOrderStatus(OrderStatusUpdateDTO statusUpdateDTO) {
        log.info("🔄 Updating order status: orderId={}, newStatus={}, restaurantId={}",
                statusUpdateDTO.getOrderId(), statusUpdateDTO.getStatus(), statusUpdateDTO.getRestaurantId());

        try {
            Order order = orderRepository.findByIdWithLock(statusUpdateDTO.getOrderId())
                    .orElseThrow(() -> {
                        log.error("Order not found for ID={}", statusUpdateDTO.getOrderId());
                        return new ResourceNotFoundException("Order not found");
                    });

            if (!order.getRestaurantId().equals(statusUpdateDTO.getRestaurantId())) {
                log.warn("Unauthorized update attempt by restaurantId={} for orderId={}",
                        statusUpdateDTO.getRestaurantId(), order.getOrderId());
                throw new InvalidOperationException("Restaurant is not authorized to update this order");
            }

            if (!order.getStatus().canTransitionTo(statusUpdateDTO.getStatus())) {
                log.warn("Invalid status transition from {} to {}",
                        order.getStatus(), statusUpdateDTO.getStatus());
                throw new InvalidOperationException(String.format("Invalid status transition from %s to %s",
                        order.getStatus(), statusUpdateDTO.getStatus()));
            }

            order.setStatus(statusUpdateDTO.getStatus());
            handleStatusUpdatesAfterTransition(order);
            Order updatedOrder = orderRepository.save(order);

            log.info("✅ Order status updated successfully for orderId={} to status={}",
                    updatedOrder.getOrderId(), updatedOrder.getStatus());

            return convertToDTO(updatedOrder);

        } catch (InvalidOperationException | ResourceNotFoundException ex) {
            log.error("Order status update failed due to validation", ex);
            throw ex;
        } catch (Exception ex) {
            log.error("Unexpected error while updating order status", ex);
            throw new RuntimeException("Failed to update order status", ex);
        }
    }

    @Override
    @Transactional(readOnly = true)
    public List<OrderDTO> getUserOrders(Long userId) {
        log.info("Retrieving orders for userId={}", userId);
        return orderRepository.findByUserId(userId).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<OrderDTO> getRestaurantOrders(Long restaurantId) {
        log.info("🔍 Fetching orders for restaurant ID: {}", restaurantId);

        try {
            // Validate input
            if (restaurantId == null || restaurantId <= 0) {
                log.error("❌ Invalid restaurant ID: {}", restaurantId);
                throw new InvalidOperationException("Invalid restaurant ID");
            }

            // Get active orders only
            List<OrderStatus> activeStatuses = Arrays.asList(
                    OrderStatus.PENDING,
                    OrderStatus.ACCEPTED,
                    OrderStatus.IN_COOKING,
                    OrderStatus.OUT_FOR_DELIVERY
            );

            List<Order> orders = orderRepository.findByRestaurantIdAndStatusIn(restaurantId, activeStatuses);

            log.info("✅ Found {} active orders for restaurant {}", orders.size(), restaurantId);

            return orders.stream().map(this::convertToDTO).collect(Collectors.toList());

        } catch (InvalidOperationException ex) {
            log.error("❌ Validation error: {}", ex.getMessage());
            throw ex;
        } catch (Exception ex) {
            log.error("❌ Error fetching restaurant orders for ID {}: {}", restaurantId, ex.getMessage(), ex);
            throw new RuntimeException("Failed to fetch restaurant orders: " + ex.getMessage(), ex);
        }
    }

    @Transactional(readOnly = true)
    public long getActiveOrderCount(Long restaurantId) {
        log.info("🔍 Counting active orders for restaurant ID: {}", restaurantId);

        try {
            if (restaurantId == null || restaurantId <= 0) {
                log.error("❌ Invalid restaurant ID: {}", restaurantId);
                return 0;
            }

            List<OrderStatus> activeStatuses = Arrays.asList(
                    OrderStatus.PENDING, OrderStatus.ACCEPTED, OrderStatus.IN_COOKING, OrderStatus.OUT_FOR_DELIVERY
            );

            long count = orderRepository.countActiveOrdersByRestaurantId(restaurantId, activeStatuses);
            log.info("✅ Found {} active orders for restaurant {}", count, restaurantId);
            return count;

        } catch (Exception e) {
            log.error("❌ Error counting restaurant orders: {}", e.getMessage(), e);
            return 0;
        }
    }

    @Override
    @Transactional(readOnly = true)
    public OrderDTO getOrderDetails(Long orderId) {
        log.info("Retrieving order details for orderId={}", orderId);
        return orderRepository.findById(orderId)
                .map(this::convertToDTO)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found"));
    }

    @Override
    public boolean orderExists(String idempotencyKey) {
        return orderRepository.existsByIdempotencyKey(idempotencyKey);
    }

    // ✅ ENHANCED: Comprehensive request validation
    private void validateOrderRequest(OrderRequestDTO request) {
        if (request == null) {
            throw new InvalidOperationException("Order request cannot be null");
        }

        if (request.getUserId() == null || request.getUserId() <= 0) {
            throw new InvalidOperationException("Valid user ID is required");
        }

        if (request.getRestaurantId() == null || request.getRestaurantId() <= 0) {
            throw new InvalidOperationException("Valid restaurant ID is required");
        }

        if (request.getDeliveryAddress() == null || request.getDeliveryAddress().trim().isEmpty()) {
            throw new InvalidOperationException("Delivery address is required");
        }
    }

    // ✅ FIXED: Updated validation for primitive double
    private void validateOrderItems(List<OrderItemDTO> items) {
        if (items == null || items.isEmpty()) {
            throw new InvalidOperationException("Order must contain at least one item");
        }

        for (int i = 0; i < items.size(); i++) {
            OrderItemDTO item = items.get(i);
            String itemPosition = "Item " + (i + 1);

            // Validate menuItemId (Long - wrapper type, can be null)
            if (item.getMenuItemId() == null || item.getMenuItemId() <= 0) {
                throw new InvalidOperationException(itemPosition + ": Valid menu item ID is required");
            }

            // Validate itemName (String can be null)
            if (item.getItemName() == null || item.getItemName().trim().isEmpty()) {
                log.warn("{}: ItemName is null/empty for menuItemId={}. Will use fallback.", itemPosition, item.getMenuItemId());
                // Don't throw error here, let the conversion method handle it with fallback
            }

            // Validate quantity (Integer - wrapper type, can be null)
            if (item.getQuantity() == null || item.getQuantity() <= 0) {
                throw new InvalidOperationException(itemPosition + ": Valid quantity is required");
            }

            // ✅ FIXED: Remove null check for primitive double, only validate value
            if (item.getPrice() <= 0.0) {
                throw new InvalidOperationException(itemPosition + ": Valid price is required (must be greater than 0)");
            }

            // ✅ ADDITIONAL: Validate other double fields that might be used
            if (item.getOriginalPrice() < 0.0) {
                throw new InvalidOperationException(itemPosition + ": Original price cannot be negative");
            }

            if (item.getDiscount() < 0.0) {
                throw new InvalidOperationException(itemPosition + ": Discount cannot be negative");
            }

            if (item.getTaxRate() < 0.0) {
                throw new InvalidOperationException(itemPosition + ": Tax rate cannot be negative");
            }
        }
    }

    // ✅ CRITICAL FIX: Ensure itemName is never null
    private String ensureValidItemName(String itemName, Long menuItemId) {
        if (itemName == null || itemName.trim().isEmpty()) {
            log.warn("ItemName is null/empty for menuItemId={}. Using fallback.", menuItemId);
            return "Menu Item " + menuItemId;
        }
        return itemName.trim();
    }

    // ✅ ENHANCED: Payment processing with retry mechanism
    private PaymentResponseDTO processPaymentWithRetry(Order order) {
        Exception lastException = null;

        for (int attempt = 1; attempt <= MAX_RETRIES; attempt++) {
            try {
                log.info("Payment attempt {}/{} for orderId={}", attempt, MAX_RETRIES, order.getOrderId());
                return processPayment(order);

            } catch (Exception ex) {
                lastException = ex;
                log.warn("Payment attempt {}/{} failed for orderId={}: {}",
                        attempt, MAX_RETRIES, order.getOrderId(), ex.getMessage());

                if (attempt < MAX_RETRIES) {
                    try {
                        Thread.sleep(RETRY_DELAY_MS * attempt); // Exponential backoff
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
            }
        }

        log.error("All payment attempts failed for orderId={}", order.getOrderId());
        throw new InvalidOperationException("Payment processing failed after " + MAX_RETRIES + " attempts: " +
                (lastException != null ? lastException.getMessage() : "Unknown error"));
    }

    // ✅ ENHANCED: Better payment error handling
    private PaymentResponseDTO processPayment(Order order) {
        try {
            PaymentRequestDTO paymentRequest = new PaymentRequestDTO();
            paymentRequest.setOrderId(order.getOrderId());
            paymentRequest.setPaymentAmount(order.getTotalAmount());
            paymentRequest.setPaymentMethod(PaymentMethod.Card);
            paymentRequest.setCreatedBy(order.getUserId().toString());

            log.info("Processing payment for orderId={}, amount={}",
                    order.getOrderId(), order.getTotalAmount());

            PaymentResponseDTO response = paymentServiceClient.processPayment(paymentRequest);

            log.info("Payment processed successfully: orderId={}, paymentId={}",
                    order.getOrderId(), response.getPaymentId());

            return response;

        } catch (Exception ex) {
            log.error("Payment processing failed for orderId={}: {}",
                    order.getOrderId(), ex.getMessage(), ex);

            // ✅ MORE SPECIFIC ERROR MESSAGES
            if (ex.getMessage().contains("DUPLICATE_TRANSACTION")) {
                throw new InvalidOperationException("Payment already processed for this order");
            } else if (ex.getMessage().contains("INSUFFICIENT_FUNDS")) {
                throw new InvalidOperationException("Payment failed: Insufficient funds");
            } else {
                throw new InvalidOperationException("Payment processing failed: " + ex.getMessage());
            }
        }
    }

    // ✅ NEW: Calculate total amount from request items
    private double calculateTotalAmountFromRequestItems(List<OrderItemDTO> items) {
        return items.stream()
                .mapToDouble(item -> item.getPrice() * item.getQuantity())
                .sum();
    }

    // ✅ EXISTING: Calculate total amount from cart (fallback)
    private double calculateTotalAmount(CartDTO cartDTO) {
        return cartDTO.getItems().stream()
                .mapToDouble(item -> item.getPrice() * item.getQuantity())
                .sum();
    }

    // ✅ NEW: Convert cart items to OrderItemDTO (for fallback scenario)
    private List<OrderItemDTO> convertCartItemsToOrderItemDTOs(CartDTO cart) {
        return cart.getItems().stream()
                .map(cartItem -> {
                    OrderItemDTO dto = new OrderItemDTO();
                    dto.setMenuItemId(cartItem.getMenuItemId());
                    dto.setItemName(ensureValidItemName(cartItem.getItemName(), cartItem.getMenuItemId()));
                    dto.setQuantity(cartItem.getQuantity());
                    dto.setPrice(cartItem.getPrice());
                    return dto;
                })
                .collect(Collectors.toList());
    }

    // ✅ CRITICAL FIX: Enhanced OrderItem conversion with null safety
    private List<OrderItem> convertOrderItemDTOsToOrderItems(List<OrderItemDTO> orderItems, Order order) {
        return orderItems.stream()
                .map(dto -> {
                    OrderItem orderItem = new OrderItem();
                    orderItem.setOrder(order);
                    orderItem.setMenuItemId(dto.getMenuItemId());

                    // ✅ CRITICAL FIX: Ensure itemName is never null
                    orderItem.setItemName(ensureValidItemName(dto.getItemName(), dto.getMenuItemId()));

                    orderItem.setQuantity(dto.getQuantity());
                    orderItem.setPrice(dto.getPrice());
                    return orderItem;
                })
                .collect(Collectors.toList());
    }

    // ✅ EXISTING: Convert cart items to OrderItem entities (fallback) - Enhanced
    private List<OrderItem> convertCartItemsToOrderItems(CartDTO cartDTO, Order order) {
        return cartDTO.getItems().stream()
                .map(cartItem -> {
                    OrderItem orderItem = new OrderItem();
                    orderItem.setOrder(order);
                    orderItem.setMenuItemId(cartItem.getMenuItemId());
                    orderItem.setItemName(ensureValidItemName(cartItem.getItemName(), cartItem.getMenuItemId()));
                    orderItem.setQuantity(cartItem.getQuantity());
                    orderItem.setPrice(cartItem.getPrice());
                    return orderItem;
                })
                .collect(Collectors.toList());
    }

    private Order createOrder(OrderRequestDTO request, String idempotencyKey, double totalAmount) {
        Order order = new Order();
        order.setIdempotencyKey(idempotencyKey);
        order.setUserId(request.getUserId());
        order.setRestaurantId(request.getRestaurantId());
        order.setStatus(OrderStatus.PENDING);
        order.setTotalAmount(totalAmount);
        order.setOrderTime(LocalDateTime.now());
        order.setDeliveryAddress(request.getDeliveryAddress());
        return order;
    }

    // ✅ ENHANCED: Improved status transition handling with better random agent assignment
    private void handleStatusUpdatesAfterTransition(Order order) {
        if (order.getStatus() == OrderStatus.OUT_FOR_DELIVERY) {
            log.info("🚛 Order status changed to OUT_FOR_DELIVERY, triggering random agent assignment for orderId={}", order.getOrderId());
            assignDeliveryAgent(order);

            // ✅ ENHANCED: Auto-completion with improved timing
            CompletableFuture.runAsync(() -> {
                try {
                    // Random completion time between 30-45 seconds for testing
                    Thread.sleep(Duration.ofSeconds(30 + new Random().nextInt(16)).toMillis());
                    completeOrderAsync(order.getOrderId());
                } catch (InterruptedException ignored) {
                    Thread.currentThread().interrupt();
                    log.warn("Order auto-completion interrupted for orderId={}", order.getOrderId());
                }
            });
        } else if (order.getStatus() == OrderStatus.COMPLETED) {
            log.info("🎉 Order completed, updating delivery status and releasing agent for orderId={}", order.getOrderId());
            order.setDeliveryTime(LocalDateTime.now());

            // ✅ ENHANCED: Better delivery completion handling
            if (order.getDeliveryId() != null) {
                try {
                    DeliveryStatusUpdateRequestDTO statusUpdate = DeliveryStatusUpdateRequestDTO.builder()
                            .status(DeliveryStatus.DELIVERED)
                            .estimatedDeliveryTime(LocalDateTime.now())
                            .build();
                    agentServiceClient.updateDeliveryStatus(order.getDeliveryId(), statusUpdate);
                    log.info("✅ Delivery status updated to DELIVERED and agent released for deliveryId={}", order.getDeliveryId());
                } catch (Exception e) {
                    log.error("❌ Failed to update delivery status for orderId={}: {}", order.getOrderId(), e.getMessage());
                }
            } else {
                log.info("ℹ️ Order {} completed without delivery assignment (no agent to release)", order.getOrderId());

                // ✅ NEW: Try to release any stuck agents for this order
                try {
                    releaseStuckAgentsForOrder(order.getOrderId());
                } catch (Exception e) {
                    log.warn("⚠️ Could not release stuck agents for order {}: {}", order.getOrderId(), e.getMessage());
                }
            }
        }
    }

    @Transactional
    protected void completeOrderAsync(Long orderId) {
        try {
            Order order = orderRepository.findByIdWithLock(orderId)
                    .orElseThrow(() -> new ResourceNotFoundException("Order not found in async complete"));

            if (order.getStatus() == OrderStatus.OUT_FOR_DELIVERY &&
                    order.getStatus().canTransitionTo(OrderStatus.COMPLETED)) {
                order.setStatus(OrderStatus.COMPLETED);
                order.setDeliveryTime(LocalDateTime.now());
                orderRepository.save(order);
                log.info("🔄 Order auto-completed via async flow, orderId={}", orderId);
                handleStatusUpdatesAfterTransition(order);
            }
        } catch (Exception e) {
            log.error("❌ Error in async order completion for orderId={}: {}", orderId, e.getMessage());
        }
    }

    // ✅ ENHANCED: Random delivery agent assignment with improved error handling
    private void assignDeliveryAgent(Order order) {
        try {
            log.info("🎲 Attempting to assign random delivery agent for orderId={}", order.getOrderId());

            AgentAssignmentDTO assignmentDTO = new AgentAssignmentDTO();
            assignmentDTO.setOrderId(order.getOrderId());
            assignmentDTO.setRestaurantId(order.getRestaurantId());
            assignmentDTO.setDeliveryAddress(order.getDeliveryAddress());

            // ✅ This will trigger random agent selection in DeliveryServiceImpl
            AgentResponseDTO agentResponse = agentServiceClient.assignDeliveryAgent(assignmentDTO);

            if (agentResponse == null) {
                throw new InvalidOperationException("No response from delivery agent service");
            }

            if (agentResponse.getAgentId() == null || agentResponse.getDeliveryId() == null) {
                throw new InvalidOperationException("Invalid agent assignment response");
            }

            order.setDeliveryAgentId(agentResponse.getAgentId());
            order.setDeliveryId(agentResponse.getDeliveryId());
            orderRepository.save(order);

            log.info("🎯 Random delivery agent assigned successfully: orderId={}, agentId={}, deliveryId={}",
                    order.getOrderId(), agentResponse.getAgentId(), agentResponse.getDeliveryId());

        } catch (Exception e) {
            log.error("❌ Failed to assign random delivery agent for orderId={}: {}", order.getOrderId(), e.getMessage(), e);

            // ✅ DON'T THROW EXCEPTION - Let order proceed without agent initially
            // The restaurant can manually assign or retry later
            log.warn("⚠️ Order will proceed without delivery agent assignment. Agent can be assigned manually later for orderId={}", order.getOrderId());
        }
    }

    // ✅ NEW: Method to release stuck agents for completed orders
    private void releaseStuckAgentsForOrder(Long orderId) {
        try {
            log.info("🔧 Attempting to release any stuck agents for completed order: {}", orderId);
            // This could call a cleanup endpoint in delivery service
            // For now, just log the attempt
            log.info("ℹ️ No delivery assignment found to clean up for order: {}", orderId);
        } catch (Exception e) {
            log.warn("⚠️ Error in stuck agent cleanup for order {}: {}", orderId, e.getMessage());
        }
    }

    private OrderDTO convertToDTO(Order order) {
        log.debug("Converting Order to DTO: {}", order.getOrderId());
        if (order == null) return null;

        OrderDTO dto = new OrderDTO();
        dto.setOrderId(order.getOrderId());
        dto.setUserId(order.getUserId());
        dto.setRestaurantId(order.getRestaurantId());
        dto.setDeliveryAddress(order.getDeliveryAddress());
        dto.setOrderTime(order.getOrderTime());
        dto.setDeliveryTime(order.getDeliveryTime());
        dto.setStatus(order.getStatus());
        dto.setTotalAmount(order.getTotalAmount());
        dto.setPaymentId(order.getPaymentId());
        dto.setIdempotencyKey(order.getIdempotencyKey());
        dto.setDeliveryAgentId(order.getDeliveryAgentId());
        dto.setDeliveryId(order.getDeliveryId());

        if (order.getItems() != null && !order.getItems().isEmpty()) {
            List<OrderItemDTO> items = order.getItems().stream()
                    .map(this::convertOrderItemToDTO)
                    .collect(Collectors.toList());
            dto.setItems(items);
        } else {
            dto.setItems(Collections.emptyList());
        }
        return dto;
    }

    private OrderItemDTO convertOrderItemToDTO(OrderItem orderItem) {
        OrderItemDTO dto = new OrderItemDTO();
        dto.setMenuItemId(orderItem.getMenuItemId());
        dto.setItemName(orderItem.getItemName());
        dto.setQuantity(orderItem.getQuantity());
        dto.setPrice(orderItem.getPrice());
        return dto;
    }
}

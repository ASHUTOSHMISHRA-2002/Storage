//////package com.fooddelivery.orderservicef.dto;
//////
//////import java.util.UUID;
//////
//////import com.fooddelivery.orderservicef.model.OrderStatus;
//////
//////import lombok.AllArgsConstructor;
//////import lombok.Data;
//////import lombok.NoArgsConstructor;
//////
//////@Data
//////@NoArgsConstructor
//////@AllArgsConstructor
//////public class OrderStatusUpdateDTO {
//////    private Long orderId;
//////    private OrderStatus status;
//////    private Long restaurantId; // For validation
//////}
////
////package com.fooddelivery.orderservicef.dto;
////
////import jakarta.validation.constraints.NotBlank;
////import jakarta.validation.constraints.NotNull;
////import lombok.AllArgsConstructor;
////import lombok.Data;
////import lombok.NoArgsConstructor;
////
////import java.time.LocalDateTime;
////
////@Data
////@NoArgsConstructor
////@AllArgsConstructor
////public class OrderStatusUpdateDTO {
////
////    @NotBlank(message = "Status is required")
////    private String status;
////
////    private String notes;
////    private String updatedBy;
////    private LocalDateTime estimatedDeliveryTime;
////    private Long deliveryAgentId;
////    private String deliveryAgentName;
////    private String deliveryAgentPhone;
////    private String trackingInfo;
////}
//
//
//// src/main/java/com/fooddelivery/orderservicef/dto/OrderStatusUpdateDTO.java
//package com.fooddelivery.orderservicef.dto;
//
//import jakarta.validation.constraints.NotBlank;
//import jakarta.validation.constraints.NotNull;
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//import java.time.LocalDateTime;
//
//@Data
//@NoArgsConstructor
//@AllArgsConstructor
//public class OrderStatusUpdateDTO {
//
//    // ✅ ADD: Missing orderId field
//    @NotNull(message = "Order ID is required")
//    private Long orderId;
//
//    @NotNull(message = "Restaurant ID is required")
//    private Long restaurantId;
//
//    @NotBlank(message = "Status is required")
//    private String status;
//
//    private String notes;
//    private String updatedBy;
//    private LocalDateTime estimatedDeliveryTime;
//    private Long deliveryAgentId;
//    private String deliveryAgentName;
//    private String deliveryAgentPhone;
//    private String trackingInfo;
//}

package com.fooddelivery.orderservicef.dto;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import com.fooddelivery.orderservicef.model.OrderStatus;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrderStatusUpdateDTO {

    @NotNull(message = "Order ID is required")
    private Long orderId;

    @NotNull(message = "Restaurant ID is required")
    private Long restaurantId;

    // ✅ FIXED: Changed from String to OrderStatus enum
    @NotNull(message = "Status is required")
    private OrderStatus status;

    private String notes;
    private String updatedBy;
    private LocalDateTime estimatedDeliveryTime;
    private Long deliveryAgentId;
    private String deliveryAgentName;
    private String deliveryAgentPhone;
    private String trackingInfo;
}

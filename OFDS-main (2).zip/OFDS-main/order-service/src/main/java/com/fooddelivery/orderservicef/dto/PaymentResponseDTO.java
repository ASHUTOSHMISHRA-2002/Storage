////package com.fooddelivery.orderservicef.dto;
////
////import java.util.UUID;
////
////import lombok.AllArgsConstructor;
////import lombok.Data;
////import lombok.Getter;
////import lombok.NoArgsConstructor;
////import lombok.Setter;
////
////@Data
////@Setter
////@Getter
////@AllArgsConstructor
////@NoArgsConstructor
////public class PaymentResponseDTO {
////	private Long paymentId;
////    private Long orderId;
////    private Double paymentAmount;
////    private PaymentMethod paymentMethod;
////    private String createdOn;
////    private String paymentStatus;
////
////}
//
//package com.fooddelivery.orderservicef.dto;
//
//import lombok.Data;
//import lombok.Getter;
//import lombok.Setter;
//
//@Data
//@Setter
//@Getter
//public class PaymentResponseDTO {
//    private Long paymentId;
//    private Long orderId;
//    private double paymentAmount;
//    private String paymentStatus;
//    private Long transactionId; // ✅ ADD this field
//    private String paymentMethod;
//}


package com.fooddelivery.orderservicef.dto;

import java.time.LocalDateTime;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Data
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class PaymentResponseDTO {
    private Long paymentId;
    private Long orderId;
    private double paymentAmount;
    private String paymentStatus; // SUCCESS, FAILED, PENDING
    private Long transactionId; // Transaction reference from payment gateway
    private String paymentMethod; // CARD, UPI, NET_BANKING, etc.
    private LocalDateTime paymentTime; // When payment was processed
    private String gatewayResponse; // Response from payment gateway (optional)
}

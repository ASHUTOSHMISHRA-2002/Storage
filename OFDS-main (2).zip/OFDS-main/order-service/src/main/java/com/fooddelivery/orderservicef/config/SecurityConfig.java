//package com.fooddelivery.orderservicef.config;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//import org.springframework.security.config.http.SessionCreationPolicy;
//import org.springframework.security.web.SecurityFilterChain;
//
//@Configuration
//@EnableWebSecurity
//public class SecurityConfig {
//
//	 @Bean
//		SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
//		 http
//         .csrf(csrf -> csrf.disable())
//         .sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
//         .authorizeHttpRequests(authorize -> authorize
//             .anyRequest().permitAll()
//         );
//
//			return http.build();
//		}
//}

package com.fooddelivery.orderservicef.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.http.HttpMethod;

import java.util.Arrays;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

	@Bean
	SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
		http
				// ✅ FIXED: Enable CORS with custom configuration
				.cors(cors -> cors.configurationSource(corsConfigurationSource()))

				// Disable CSRF for stateless API
				.csrf(csrf -> csrf.disable())

				// Stateless session management
				.sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))

				// Configure authorization
				.authorizeHttpRequests(authorize -> authorize
						// ✅ FIXED: Allow OPTIONS requests for CORS preflight
						.requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()

						// ✅ FIXED: Allow all order-related endpoints
						.requestMatchers("/api/orders/**").permitAll()
						.requestMatchers("/api/orders/restaurant/**").permitAll()
						.requestMatchers("/api/orders/user/**").permitAll()

						// ✅ ADD: Health check and actuator endpoints
						.requestMatchers("/actuator/**").permitAll()
						.requestMatchers("/health/**").permitAll()

						// ✅ ADD: Error endpoints
						.requestMatchers("/error").permitAll()

						// All other requests require authentication (if needed later)
						.anyRequest().permitAll() // Change to .authenticated() when you implement auth
				);

		return http.build();
	}

	// ✅ NEW: CORS Configuration Bean
	@Bean
	public CorsConfigurationSource corsConfigurationSource() {
		CorsConfiguration configuration = new CorsConfiguration();

		// ✅ FIXED: Allow Angular development server origins
		configuration.setAllowedOrigins(Arrays.asList(
				"http://localhost:4200",
				"http://127.0.0.1:4200",
				"http://localhost:3000", // In case you use React later
				"http://127.0.0.1:3000"
		));

		// ✅ FIXED: Allow all necessary HTTP methods
		configuration.setAllowedMethods(Arrays.asList(
				"GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH", "HEAD"
		));

		// ✅ FIXED: Allow all headers including Authorization
		configuration.setAllowedHeaders(Arrays.asList(
				"*", // Allow all headers
				"Authorization",
				"Content-Type",
				"Accept",
				"X-Requested-With",
				"X-Internal-User-Id",
				"X-Internal-User-Roles",
				"X-Idempotency-Key",
				"Cache-Control"
		));

		// ✅ FIXED: Allow credentials for authentication
		configuration.setAllowCredentials(true);

		// ✅ FIXED: Cache preflight response for 1 hour
		configuration.setMaxAge(3600L);

		// ✅ FIXED: Expose headers that frontend might need
		configuration.setExposedHeaders(Arrays.asList(
				"Authorization",
				"Content-Type",
				"X-Total-Count",
				"X-Page-Count",
				"Location"
		));

		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		source.registerCorsConfiguration("/**", configuration);

		return source;
	}
}

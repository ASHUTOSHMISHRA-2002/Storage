//package com.fooddelivery.orderservicef.dto;
//
//import java.math.BigDecimal;
//import java.util.UUID;
//
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//@Data
//@NoArgsConstructor
//@AllArgsConstructor
//public class OrderItemDTO {
//    private Long menuItemId;
//    private String itemName;
//    private Integer quantity;
//    private double price;
//}

package com.fooddelivery.orderservicef.dto;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrderItemDTO {

    // ✅ EXISTING: Basic item identification
    @NotNull(message = "Menu item ID is required")
    private Long menuItemId;

    @NotBlank(message = "Item name is required")
    @Size(min = 2, max = 100, message = "Item name must be between 2 and 100 characters")
    private String itemName;

    @NotNull(message = "Quantity is required")
    @Min(value = 1, message = "Quantity must be at least 1")
    @Max(value = 50, message = "Quantity cannot exceed 50")
    private Integer quantity;

    // ✅ FIXED: Changed to double for consistency
    @NotNull(message = "Price is required")
    @DecimalMin(value = "0.01", message = "Price must be greater than 0")
    private double price;

    // ✅ ENHANCED: Additional item details for better order management
    @Size(max = 500, message = "Description cannot exceed 500 characters")
    private String description;

    private String image;

    private Boolean isVegetarian;

    @Size(max = 50, message = "Category cannot exceed 50 characters")
    private String category;

    @Size(max = 200, message = "Special instructions cannot exceed 200 characters")
    private String specialInstructions;

    // ✅ ENHANCED: Restaurant context
    private Long restaurantId;

    // ✅ FIXED: Changed BigDecimal to double
    private double originalPrice; // For discount tracking
    private double discount;      // Discount amount
    private double totalPrice;    // quantity * price

    // ✅ ENHANCED: Nutritional information (optional)
    @Min(value = 0, message = "Calories cannot be negative")
    private Integer calories;

    @Size(max = 200, message = "Allergens information cannot exceed 200 characters")
    private String allergens;

    // ✅ ENHANCED: Customization options
    @Size(max = 300, message = "Customizations cannot exceed 300 characters")
    private String customizations;

    // ✅ ENHANCED: Availability status
    private Boolean isAvailable = true;

    // ✅ ENHANCED: Item metadata
    private String sku; // Stock Keeping Unit
    private Double weight; // Item weight for delivery calculation

    // ✅ FIXED: Changed BigDecimal to double
    private double taxRate;
    private double taxAmount;

    // ✅ ENHANCED: Preparation details
    @Min(value = 0, message = "Preparation time cannot be negative")
    private Integer preparationTimeMinutes;

    private String preparationNotes;

    // ✅ ENHANCED: Order item status
    private String itemStatus; // PENDING, PREPARING, READY, etc.

    // ✅ FIXED: Helper methods updated to use double
    public double calculateTotalPrice() {
        if (quantity != null) {
            double total = price * quantity;
            if (discount > 0) {
                total = total - discount;
            }
            this.totalPrice = total;
            return total;
        }
        return 0.0;
    }

    public double calculateTaxAmount() {
        if (taxRate > 0 && totalPrice > 0) {
            this.taxAmount = totalPrice * (taxRate / 100);
            return this.taxAmount;
        }
        return 0.0;
    }

    public double getFinalPrice() {
        double total = calculateTotalPrice();
        double tax = calculateTaxAmount();
        return total + tax;
    }

    // ✅ FIXED: Validation helper updated for double
    public boolean isValid() {
        return menuItemId != null &&
                itemName != null && !itemName.trim().isEmpty() &&
                quantity != null && quantity > 0 &&
                price > 0;
    }

    // ✅ FIXED: Display helpers updated for double
    public String getFormattedPrice() {
        return String.format("₹%.2f", price);
    }

    public String getFormattedTotalPrice() {
        double total = calculateTotalPrice();
        return String.format("₹%.2f", total);
    }

    public String getVegIndicator() {
        if (isVegetarian != null) {
            return isVegetarian ? "🟢" : "🔴";
        }
        return "";
    }

    // ✅ FIXED: Item summary updated for double
    public String getItemSummary() {
        return String.format("%s x%d @ %s = %s",
                itemName,
                quantity,
                getFormattedPrice(),
                getFormattedTotalPrice());
    }

    // ✅ ENHANCED: Additional helper methods for double
    public double getSubtotal() {
        return price * (quantity != null ? quantity : 0);
    }

    public double getDiscountPercentage() {
        if (originalPrice > 0 && discount > 0) {
            return (discount / originalPrice) * 100;
        }
        return 0.0;
    }

    public boolean hasDiscount() {
        return discount > 0;
    }

    public double getSavings() {
        return hasDiscount() ? discount : 0.0;
    }
}

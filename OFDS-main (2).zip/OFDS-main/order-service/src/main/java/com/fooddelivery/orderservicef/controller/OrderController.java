////package com.fooddelivery.orderservicef.controller;
////
////import lombok.RequiredArgsConstructor;
////import lombok.extern.slf4j.Slf4j;
////
////import org.springframework.http.HttpStatus;
////import org.springframework.http.ResponseEntity;
////import org.springframework.security.oauth2.jwt.Jwt;
////import org.springframework.security.core.annotation.AuthenticationPrincipal;
////import org.springframework.web.bind.annotation.*;
////
////import com.fooddelivery.orderservicef.dto.OrderDTO;
////import com.fooddelivery.orderservicef.dto.OrderRequestDTO;
////import com.fooddelivery.orderservicef.dto.OrderStatusUpdateDTO;
////import com.fooddelivery.orderservicef.model.OrderStatus;
////import com.fooddelivery.orderservicef.service.OrderServiceImpl;
////
////import java.util.List;
////import java.util.UUID;
////@Slf4j
////@RestController
////@RequestMapping("/api/orders")
////@RequiredArgsConstructor
////public class OrderController {
////
////    private final OrderServiceImpl orderServiceImpl;
////
////    /**
////     * takes in the OrderDTO
////     * places the order and returns the OrderEntity
////     * */
////    @PostMapping
////    public ResponseEntity<OrderDTO> placeOrder(
////            @RequestHeader("Idempotency-Key") String idempotencyKey,
////            @RequestBody OrderRequestDTO orderRequest,
////            @RequestHeader("X-Internal-User-Id") String requestId,
////			@RequestHeader("X-Internal-User-Roles")String roles) {
////
////    	//long stronVal = 123456789L;
////    	if (!roles.contains("CUSTOMER")) {
////            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
////        }
////
////        orderRequest.setUserId(Long.valueOf(requestId));
////
////
////        log.info("Order placed successfully !"+idempotencyKey);
////        return ResponseEntity.ok(
////                orderServiceImpl.placeOrder(orderRequest, idempotencyKey)
////            );
////    }
////
////    /**
////     * Retrieving the orders by user
////     * gets the user id by the jwt header
////     * returns the orders of the user
////     * */
////    @GetMapping("/user")
////    public ResponseEntity<List<OrderDTO>> getUserOrders(
////    		@RequestHeader("X-Internal-User-Id") String requestId,
////			@RequestHeader("X-Internal-User-Roles")String roles) {
////
////
//////    	long stronVal = 123456789L;
////    	if (!roles.contains("CUSTOMER")) {
////            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
////        }
////
////        log.info("User "+Long.valueOf(requestId)+"Orders reteirved successfully !");
////        return ResponseEntity.ok(orderServiceImpl.getUserOrders(Long.valueOf(requestId)));
////    }
////
////    /**
////     * Retrieving the orders by restaurant
////     * gets the restaurant id by the jwt header
////     * returns the orders placed the restaurant
////     * */
////    @GetMapping("/restaurant")
////    public ResponseEntity<List<OrderDTO>> getRestaurantOrders(
////    		@RequestHeader("X-Internal-User-Id") String requestId,
////			@RequestHeader("X-Internal-User-Roles")String roles) {
////
////
////    	//long stronVal = 5965392056977236797L;
////    	if (!roles.contains("RESTAURANT")) {
////            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
////        }
////
////        log.info("Restaurant " +Long.valueOf(requestId)+"Orders reteirved successfully !");
////        return ResponseEntity.ok(orderServiceImpl.getRestaurantOrders(Long.valueOf(requestId)));
////    }
////
////    /**
////     * Updating the status of the order
////     * intakes the OrderStatusUpdateDTO
////     * returns the updated order status by the restaurant
////     * */
////    @PutMapping("/status")
////    public ResponseEntity<OrderDTO> updateOrderStatus(
////            @RequestBody OrderStatusUpdateDTO statusUpdateDTO,
////            @RequestHeader("X-Internal-User-Id") String requestId,
////			@RequestHeader("X-Internal-User-Roles")String roles) {
////
//////    	Long restId=5965392056977236797L;
////    	if (!roles.contains("RESTAURANT")) {
////            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
////        }
////
////    	statusUpdateDTO.setRestaurantId(Long.valueOf(requestId));
////        log.info("Orders status updated successfully !");
////        return ResponseEntity.ok(
////                orderServiceImpl.updateOrderStatus(statusUpdateDTO)
////            );
////    }
////
////    /**
////     * Retrieving the order by it's id
////     * uses the orderId from PathVariable !
////     * */
////    @GetMapping("/{orderId}")
////    public ResponseEntity<OrderDTO> getOrderDetails(
////            @PathVariable Long orderId) {
////    	log.info("Orders details retrieved successfully !");
////        return ResponseEntity.ok(orderServiceImpl.getOrderDetails(orderId));
////    }
////}
//
//
//
//
//package com.fooddelivery.orderservicef.controller;
//
//import lombok.RequiredArgsConstructor;
//import lombok.extern.slf4j.Slf4j;
//
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import com.fooddelivery.orderservicef.dto.OrderDTO;
//import com.fooddelivery.orderservicef.dto.OrderStatusUpdateDTO;
//import com.fooddelivery.orderservicef.service.OrderServiceImpl;
//
//import java.util.Base64;
//import java.util.List;
//
//@CrossOrigin(origins = "http://localhost:4200")
//@Slf4j
//@RestController
//@RequestMapping("/api/orders")
//@RequiredArgsConstructor
//public class OrderController {
//
//    private final OrderServiceImpl orderServiceImpl;
//
//    /**
//     * Retrieving the orders by restaurant
//     * Gets the restaurant id from JWT token
//     * Returns the orders placed at the restaurant
//     */
//    @GetMapping("/restaurant")
//    public ResponseEntity<List<OrderDTO>> getRestaurantOrders(
//            @RequestHeader(value = "Authorization", required = false) String authHeader) {
//
//        String userId = extractUserIdFromToken(authHeader);
//        String userRole = extractUserRoleFromToken(authHeader);
//
//        if (userId == null || userRole == null || !userRole.contains("RESTAURANT")) {
//            log.warn("Unauthorized restaurant orders access attempt");
//            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
//        }
//
//        log.info("Restaurant {} orders retrieved successfully!", userId);
//        return ResponseEntity.ok(orderServiceImpl.getRestaurantOrders(Long.valueOf(userId)));
//    }
//
//    /**
//     * Updating the status of the order
//     * Takes the OrderStatusUpdateDTO
//     * Returns the updated order status by the restaurant
//     */
//    @PutMapping("/status")
//    public ResponseEntity<OrderDTO> updateOrderStatus(
//            @RequestBody OrderStatusUpdateDTO statusUpdateDTO,
//            @RequestHeader(value = "Authorization", required = false) String authHeader) {
//
//        String userId = extractUserIdFromToken(authHeader);
//        String userRole = extractUserRoleFromToken(authHeader);
//
//        if (userId == null || userRole == null || !userRole.contains("RESTAURANT")) {
//            log.warn("Unauthorized order status update attempt");
//            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
//        }
//
//        statusUpdateDTO.setRestaurantId(Long.valueOf(userId));
//        log.info("Order status updated successfully by restaurant: {}", userId);
//        return ResponseEntity.ok(orderServiceImpl.updateOrderStatus(statusUpdateDTO));
//    }
//
//    /**
//     * Retrieving the order by its id
//     * Uses the orderId from PathVariable
//     */
//    @GetMapping("/{orderId}")
//    public ResponseEntity<OrderDTO> getOrderDetails(@PathVariable Long orderId) {
//        log.info("Order details retrieved successfully for order: {}", orderId);
//        return ResponseEntity.ok(orderServiceImpl.getOrderDetails(orderId));
//    }
//
//    // ✅ Helper method to extract userId from JWT token
//    private String extractUserIdFromToken(String authHeader) {
//        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
//            return null;
//        }
//
//        try {
//            String token = authHeader.substring(7);
//            String[] parts = token.split("\\.");
//            if (parts.length != 3) return null;
//
//            String payload = new String(Base64.getUrlDecoder().decode(parts[1]));
//
//            if (payload.contains("\"userId\":")) {
//                String userIdPart = payload.substring(payload.indexOf("\"userId\":") + 9);
//                if (userIdPart.startsWith("\"")) {
//                    int endIndex = userIdPart.indexOf("\"", 1);
//                    return endIndex > 0 ? userIdPart.substring(1, endIndex) : null;
//                } else {
//                    int endIndex = userIdPart.indexOf(",");
//                    if (endIndex == -1) endIndex = userIdPart.indexOf("}");
//                    return endIndex > 0 ? userIdPart.substring(0, endIndex).trim() : null;
//                }
//            }
//        } catch (Exception e) {
//            log.error("Error extracting userId from token: {}", e.getMessage());
//        }
//
//        return null;
//    }
//
//    // ✅ Helper method to extract user role from JWT token
//    private String extractUserRoleFromToken(String authHeader) {
//        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
//            return null;
//        }
//
//        try {
//            String token = authHeader.substring(7);
//            String[] parts = token.split("\\.");
//            if (parts.length != 3) return null;
//
//            String payload = new String(Base64.getUrlDecoder().decode(parts[1]));
//
//            if (payload.contains("\"roles\":[")) {
//                String rolesPart = payload.substring(payload.indexOf("\"roles\":[") + 9);
//                int endIndex = rolesPart.indexOf("]");
//                if (endIndex > 0) {
//                    return rolesPart.substring(0, endIndex + 1);
//                }
//            }
//        } catch (Exception e) {
//            log.error("Error extracting roles from token: {}", e.getMessage());
//        }
//
//        return null;
//    }
//}


//package com.fooddelivery.orderservicef.controller;
//
//import lombok.RequiredArgsConstructor;
//import lombok.extern.slf4j.Slf4j;
//
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import com.fooddelivery.orderservicef.dto.OrderDTO;
//import com.fooddelivery.orderservicef.dto.OrderRequestDTO;
//import com.fooddelivery.orderservicef.dto.OrderStatusUpdateDTO;
//import com.fooddelivery.orderservicef.service.OrderServiceImpl;
//
//import java.util.Base64;
//import java.util.List;
//
//@CrossOrigin(origins = "http://localhost:4200")
//@Slf4j
//@RestController
//@RequestMapping("/api/orders")
//@RequiredArgsConstructor
//public class OrderController {
//
//    private final OrderServiceImpl orderServiceImpl;
//
//    /**
//     * ✅ ADDED: Place a new order
//     * This is the missing POST endpoint that your frontend needs
//     */
//    @PostMapping
//    public ResponseEntity<OrderDTO> placeOrder(
//            @RequestBody OrderRequestDTO orderRequest,
//            @RequestHeader(value = "X-Idempotency-Key", required = false) String idempotencyKey,
//            @RequestHeader(value = "Authorization", required = false) String authHeader) {
//
//        log.info("Received order placement request: restaurantId={}, deliveryAddress={}",
//                orderRequest.getRestaurantId(), orderRequest.getDeliveryAddress());
//
//        try {
//            // Extract userId from token (if available) or use default for mock
//            String userId = extractUserIdFromToken(authHeader);
//            if (userId != null) {
//                orderRequest.setUserId(Long.valueOf(userId));
//                log.info("Using userId from token: {}", userId);
//            } else {
//                // For mock/demo purposes, use a default user ID
//                orderRequest.setUserId(1L);
//                log.info("Using default userId: 1 (no auth token provided)");
//            }
//
//            // Generate idempotency key if not provided
//            if (idempotencyKey == null || idempotencyKey.isEmpty()) {
//                idempotencyKey = "order_" + System.currentTimeMillis() + "_" +
//                        Math.random().toString(36).substring(2, 9);
//                log.info("Generated idempotency key: {}", idempotencyKey);
//            }
//
//            log.info("Creating order for userId: {}, restaurantId: {}, idempotencyKey: {}",
//                    orderRequest.getUserId(), orderRequest.getRestaurantId(), idempotencyKey);
//
//            OrderDTO order = orderServiceImpl.placeOrder(orderRequest, idempotencyKey);
//
//            log.info("✅ Order created successfully with ID: {}", order.getOrderId());
//            return new ResponseEntity<>(order, HttpStatus.CREATED);
//
//        } catch (Exception ex) {
//            log.error("❌ Error creating order: {}", ex.getMessage(), ex);
//            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }
//
//    /**
//     * Retrieving the orders by restaurant
//     * Gets the restaurant id from JWT token
//     * Returns the orders placed at the restaurant
//     */
//    @GetMapping("/restaurant")
//    public ResponseEntity<List<OrderDTO>> getRestaurantOrders(
//            @RequestHeader(value = "Authorization", required = false) String authHeader) {
//
//        String userId = extractUserIdFromToken(authHeader);
//        String userRole = extractUserRoleFromToken(authHeader);
//
//        if (userId == null || userRole == null || !userRole.contains("RESTAURANT")) {
//            log.warn("Unauthorized restaurant orders access attempt");
//            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
//        }
//
//        log.info("Restaurant {} orders retrieved successfully!", userId);
//        return ResponseEntity.ok(orderServiceImpl.getRestaurantOrders(Long.valueOf(userId)));
//    }
//
//    /**
//     * Updating the status of the order
//     * Takes the OrderStatusUpdateDTO
//     * Returns the updated order status by the restaurant
//     */
//    @PutMapping("/status")
//    public ResponseEntity<OrderDTO> updateOrderStatus(
//            @RequestBody OrderStatusUpdateDTO statusUpdateDTO,
//            @RequestHeader(value = "Authorization", required = false) String authHeader) {
//
//        String userId = extractUserIdFromToken(authHeader);
//        String userRole = extractUserRoleFromToken(authHeader);
//
//        if (userId == null || userRole == null || !userRole.contains("RESTAURANT")) {
//            log.warn("Unauthorized order status update attempt");
//            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
//        }
//
//        statusUpdateDTO.setRestaurantId(Long.valueOf(userId));
//        log.info("Order status updated successfully by restaurant: {}", userId);
//        return ResponseEntity.ok(orderServiceImpl.updateOrderStatus(statusUpdateDTO));
//    }
//
//    /**
//     * Retrieving the order by its id
//     * Uses the orderId from PathVariable
//     */
//    @GetMapping("/{orderId}")
//    public ResponseEntity<OrderDTO> getOrderDetails(@PathVariable Long orderId) {
//        log.info("Order details retrieved successfully for order: {}", orderId);
//        return ResponseEntity.ok(orderServiceImpl.getOrderDetails(orderId));
//    }
//
//    /**
//     * ✅ ADDED: Get user orders (for customer order history)
//     */
//    @GetMapping("/user")
//    public ResponseEntity<List<OrderDTO>> getUserOrders(
//            @RequestHeader(value = "Authorization", required = false) String authHeader) {
//
//        String userId = extractUserIdFromToken(authHeader);
//        if (userId == null) {
//            // For mock/demo, use default user ID
//            userId = "1";
//        }
//
//        log.info("User {} orders retrieved successfully!", userId);
//        return ResponseEntity.ok(orderServiceImpl.getUserOrders(Long.valueOf(userId)));
//    }
//
//    // ✅ Helper method to extract userId from JWT token
//    private String extractUserIdFromToken(String authHeader) {
//        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
//            return null;
//        }
//
//        try {
//            String token = authHeader.substring(7);
//            String[] parts = token.split("\\.");
//            if (parts.length != 3) return null;
//
//            String payload = new String(Base64.getUrlDecoder().decode(parts[1]));
//
//            if (payload.contains("\"userId\":")) {
//                String userIdPart = payload.substring(payload.indexOf("\"userId\":") + 9);
//                if (userIdPart.startsWith("\"")) {
//                    int endIndex = userIdPart.indexOf("\"", 1);
//                    return endIndex > 0 ? userIdPart.substring(1, endIndex) : null;
//                } else {
//                    int endIndex = userIdPart.indexOf(",");
//                    if (endIndex == -1) endIndex = userIdPart.indexOf("}");
//                    return endIndex > 0 ? userIdPart.substring(0, endIndex).trim() : null;
//                }
//            }
//        } catch (Exception e) {
//            log.error("Error extracting userId from token: {}", e.getMessage());
//        }
//
//        return null;
//    }
//
//    // ✅ Helper method to extract user role from JWT token
//    private String extractUserRoleFromToken(String authHeader) {
//        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
//            return null;
//        }
//
//        try {
//            String token = authHeader.substring(7);
//            String[] parts = token.split("\\.");
//            if (parts.length != 3) return null;
//
//            String payload = new String(Base64.getUrlDecoder().decode(parts[1]));
//
//            if (payload.contains("\"roles\":[")) {
//                String rolesPart = payload.substring(payload.indexOf("\"roles\":[") + 9);
//                int endIndex = rolesPart.indexOf("]");
//                if (endIndex > 0) {
//                    return rolesPart.substring(0, endIndex + 1);
//                }
//            }
//        } catch (Exception e) {
//            log.error("Error extracting roles from token: {}", e.getMessage());
//        }
//
//        return null;
//    }
//}


//package com.fooddelivery.orderservicef.controller;
//
//import lombok.RequiredArgsConstructor;
//import lombok.extern.slf4j.Slf4j;
//
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import com.fooddelivery.orderservicef.dto.OrderDTO;
//import com.fooddelivery.orderservicef.dto.OrderRequestDTO;
//import com.fooddelivery.orderservicef.dto.OrderStatusUpdateDTO;
//import com.fooddelivery.orderservicef.service.OrderServiceImpl;
//import com.fooddelivery.orderservicef.exception.InvalidOperationException;
//import com.fooddelivery.orderservicef.exception.ResourceNotFoundException;
//
//import java.util.Base64;
//import java.util.List;
//
//@CrossOrigin(origins = "http://localhost:4200")
//@Slf4j
//@RestController
//@RequestMapping("/api/orders")
//@RequiredArgsConstructor
//public class OrderController {
//
//    private final OrderServiceImpl orderServiceImpl;
//
//    /**
//     * ✅ Place a new order with proper error handling
//     */
//    @PostMapping
//    public ResponseEntity<?> placeOrder(
//            @RequestBody OrderRequestDTO orderRequest,
//            @RequestHeader(value = "X-Idempotency-Key", required = false) String idempotencyKey,
//            @RequestHeader(value = "Authorization", required = false) String authHeader) {
//
//        log.info("Received order placement request: restaurantId={}, deliveryAddress={}",
//                orderRequest.getRestaurantId(), orderRequest.getDeliveryAddress());
//
//        try {
//            // Extract userId from token (if available) or use default for mock
//            String userId = extractUserIdFromToken(authHeader);
//            if (userId != null) {
//                orderRequest.setUserId(Long.valueOf(userId));
//                log.info("Using userId from token: {}", userId);
//            } else {
//                // For mock/demo purposes, use a default user ID
//                orderRequest.setUserId(1L);
//                log.info("Using default userId: 1 (no auth token provided)");
//            }
//
//            // Generate idempotency key if not provided
//            if (idempotencyKey == null || idempotencyKey.isEmpty()) {
//                idempotencyKey = "order_" + System.currentTimeMillis() + "_" +
//                        java.util.UUID.randomUUID().toString().substring(0, 8);
//                log.info("Generated idempotency key: {}", idempotencyKey);
//            }
//
//            log.info("Creating order for userId: {}, restaurantId: {}, idempotencyKey: {}",
//                    orderRequest.getUserId(), orderRequest.getRestaurantId(), idempotencyKey);
//
//            OrderDTO order = orderServiceImpl.placeOrder(orderRequest, idempotencyKey);
//
//            log.info("✅ Order created successfully with ID: {}", order.getOrderId());
//            return new ResponseEntity<>(order, HttpStatus.CREATED);
//
//        } catch (InvalidOperationException ex) {
//            log.error("❌ Invalid operation: {}", ex.getMessage());
//            return ResponseEntity.badRequest().body(createErrorResponse(ex.getMessage()));
//        } catch (ResourceNotFoundException ex) {
//            log.error("❌ Resource not found: {}", ex.getMessage());
//            return ResponseEntity.notFound().build();
//        } catch (IllegalArgumentException ex) {
//            log.error("❌ Invalid argument: {}", ex.getMessage());
//            return ResponseEntity.badRequest().body(createErrorResponse("Invalid request data: " + ex.getMessage()));
//        } catch (Exception ex) {
//            log.error("❌ Unexpected error creating order: {}", ex.getMessage(), ex);
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                    .body(createErrorResponse("Failed to create order. Please try again."));
//        }
//    }
//
//    /**
//     * Get restaurant orders with better error handling
//     */
//    @GetMapping("/restaurant")
//    public ResponseEntity<?> getRestaurantOrders(
//            @RequestHeader(value = "Authorization", required = false) String authHeader) {
//
//        try {
//            String userId = extractUserIdFromToken(authHeader);
//            String userRole = extractUserRoleFromToken(authHeader);
//
//            if (userId == null || userRole == null || !userRole.contains("RESTAURANT")) {
//                log.warn("Unauthorized restaurant orders access attempt");
//                return ResponseEntity.status(HttpStatus.FORBIDDEN)
//                        .body(createErrorResponse("Access denied. Restaurant authorization required."));
//            }
//
//            List<OrderDTO> orders = orderServiceImpl.getRestaurantOrders(Long.valueOf(userId));
//            log.info("Restaurant {} orders retrieved successfully! Count: {}", userId, orders.size());
//            return ResponseEntity.ok(orders);
//
//        } catch (NumberFormatException ex) {
//            log.error("Invalid userId format: {}", ex.getMessage());
//            return ResponseEntity.badRequest().body(createErrorResponse("Invalid user ID format"));
//        } catch (Exception ex) {
//            log.error("Error retrieving restaurant orders: {}", ex.getMessage(), ex);
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                    .body(createErrorResponse("Failed to retrieve orders"));
//        }
//    }
//
//    /**
//     * Update order status with validation
//     */
//    @PutMapping("/status")
//    public ResponseEntity<?> updateOrderStatus(
//            @RequestBody OrderStatusUpdateDTO statusUpdateDTO,
//            @RequestHeader(value = "Authorization", required = false) String authHeader) {
//
//        try {
//            String userId = extractUserIdFromToken(authHeader);
//            String userRole = extractUserRoleFromToken(authHeader);
//
//            if (userId == null || userRole == null || !userRole.contains("RESTAURANT")) {
//                log.warn("Unauthorized order status update attempt");
//                return ResponseEntity.status(HttpStatus.FORBIDDEN)
//                        .body(createErrorResponse("Access denied. Restaurant authorization required."));
//            }
//
//            statusUpdateDTO.setRestaurantId(Long.valueOf(userId));
//            OrderDTO updatedOrder = orderServiceImpl.updateOrderStatus(statusUpdateDTO);
//
//            log.info("Order status updated successfully by restaurant: {} for order: {}",
//                    userId, statusUpdateDTO.getOrderId());
//            return ResponseEntity.ok(updatedOrder);
//
//        } catch (InvalidOperationException ex) {
//            log.error("Invalid operation: {}", ex.getMessage());
//            return ResponseEntity.badRequest().body(createErrorResponse(ex.getMessage()));
//        } catch (ResourceNotFoundException ex) {
//            log.error("Order not found: {}", ex.getMessage());
//            return ResponseEntity.notFound().build();
//        } catch (Exception ex) {
//            log.error("Error updating order status: {}", ex.getMessage(), ex);
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                    .body(createErrorResponse("Failed to update order status"));
//        }
//    }
//
//    /**
//     * Get order details with error handling
//     */
//    @GetMapping("/{orderId}")
//    public ResponseEntity<?> getOrderDetails(@PathVariable Long orderId) {
//        try {
//            OrderDTO order = orderServiceImpl.getOrderDetails(orderId);
//            log.info("Order details retrieved successfully for order: {}", orderId);
//            return ResponseEntity.ok(order);
//        } catch (ResourceNotFoundException ex) {
//            log.error("Order not found: {}", ex.getMessage());
//            return ResponseEntity.notFound().build();
//        } catch (Exception ex) {
//            log.error("Error retrieving order details: {}", ex.getMessage(), ex);
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                    .body(createErrorResponse("Failed to retrieve order details"));
//        }
//    }
//
//    /**
//     * Get user orders with error handling
//     */
//    @GetMapping("/user")
//    public ResponseEntity<?> getUserOrders(
//            @RequestHeader(value = "Authorization", required = false) String authHeader) {
//
//        try {
//            String userId = extractUserIdFromToken(authHeader);
//            if (userId == null) {
//                // For mock/demo, use default user ID
//                userId = "1";
//                log.info("Using default userId for user orders: {}", userId);
//            }
//
//            List<OrderDTO> orders = orderServiceImpl.getUserOrders(Long.valueOf(userId));
//            log.info("User {} orders retrieved successfully! Count: {}", userId, orders.size());
//            return ResponseEntity.ok(orders);
//
//        } catch (NumberFormatException ex) {
//            log.error("Invalid userId format: {}", ex.getMessage());
//            return ResponseEntity.badRequest().body(createErrorResponse("Invalid user ID format"));
//        } catch (Exception ex) {
//            log.error("Error retrieving user orders: {}", ex.getMessage(), ex);
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                    .body(createErrorResponse("Failed to retrieve user orders"));
//        }
//    }
//
//    /**
//     * Health check endpoint
//     */
//    @GetMapping("/health")
//    public ResponseEntity<String> healthCheck() {
//        return ResponseEntity.ok("Order Service is running");
//    }
//
//    // Helper method to extract userId from JWT token
//    private String extractUserIdFromToken(String authHeader) {
//        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
//            return null;
//        }
//
//        try {
//            String token = authHeader.substring(7);
//            String[] parts = token.split("\\.");
//            if (parts.length != 3) return null;
//
//            String payload = new String(Base64.getUrlDecoder().decode(parts[1]));
//
//            if (payload.contains("\"userId\":")) {
//                String userIdPart = payload.substring(payload.indexOf("\"userId\":") + 9);
//                if (userIdPart.startsWith("\"")) {
//                    int endIndex = userIdPart.indexOf("\"", 1);
//                    return endIndex > 0 ? userIdPart.substring(1, endIndex) : null;
//                } else {
//                    int endIndex = userIdPart.indexOf(",");
//                    if (endIndex == -1) endIndex = userIdPart.indexOf("}");
//                    return endIndex > 0 ? userIdPart.substring(0, endIndex).trim() : null;
//                }
//            }
//        } catch (Exception e) {
//            log.error("Error extracting userId from token: {}", e.getMessage());
//        }
//
//        return null;
//    }
//
//    // Helper method to extract user role from JWT token
//    private String extractUserRoleFromToken(String authHeader) {
//        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
//            return null;
//        }
//
//        try {
//            String token = authHeader.substring(7);
//            String[] parts = token.split("\\.");
//            if (parts.length != 3) return null;
//
//            String payload = new String(Base64.getUrlDecoder().decode(parts[1]));
//
//            if (payload.contains("\"roles\":[")) {
//                String rolesPart = payload.substring(payload.indexOf("\"roles\":[") + 9);
//                int endIndex = rolesPart.indexOf("]");
//                if (endIndex > 0) {
//                    return rolesPart.substring(0, endIndex + 1);
//                }
//            }
//        } catch (Exception e) {
//            log.error("Error extracting roles from token: {}", e.getMessage());
//        }
//
//        return null;
//    }
//
//    /**
//     * Helper method to create consistent error responses
//     */
//    private ErrorResponse createErrorResponse(String message) {
//        return new ErrorResponse(message, System.currentTimeMillis());
//    }
//
//    /**
//     * Error response DTO
//     */
//    public static class ErrorResponse {
//        private String message;
//        private long timestamp;
//
//        public ErrorResponse(String message, long timestamp) {
//            this.message = message;
//            this.timestamp = timestamp;
//        }
//
//        // Getters
//        public String getMessage() { return message; }
//        public long getTimestamp() { return timestamp; }
//
//        // Setters
//        public void setMessage(String message) { this.message = message; }
//        public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
//    }
//}

//
//package com.fooddelivery.orderservicef.controller;
//
//import com.fooddelivery.orderservicef.model.OrderStatus;
//import lombok.RequiredArgsConstructor;
//import lombok.extern.slf4j.Slf4j;
//
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import com.fooddelivery.orderservicef.dto.OrderDTO;
//import com.fooddelivery.orderservicef.dto.OrderRequestDTO;
//import com.fooddelivery.orderservicef.dto.OrderStatusUpdateDTO;
//import com.fooddelivery.orderservicef.service.OrderServiceImpl;
//import com.fooddelivery.orderservicef.exception.InvalidOperationException;
//import com.fooddelivery.orderservicef.exception.ResourceNotFoundException;
//
//import java.util.Base64;
//import java.util.List;
//import java.util.Map;
//
//@CrossOrigin(origins = "http://localhost:4200")
//@Slf4j
//@RestController
//@RequestMapping("/api/orders")
//@RequiredArgsConstructor
//public class OrderController {
//
//    private final OrderServiceImpl orderServiceImpl;
//
//    /**
//     * ✅ Place a new order with proper error handling
//     */
//    @PostMapping
//    public ResponseEntity<?> placeOrder(
//            @RequestBody OrderRequestDTO orderRequest,
//            @RequestHeader(value = "X-Idempotency-Key", required = false) String idempotencyKey,
//            @RequestHeader(value = "Authorization", required = false) String authHeader) {
//
//        log.info("Received order placement request: restaurantId={}, deliveryAddress={}",
//                orderRequest.getRestaurantId(), orderRequest.getDeliveryAddress());
//
//        try {
//            // Extract userId from token (if available) or use default for mock
//            String userId = extractUserIdFromToken(authHeader);
//            if (userId != null) {
//                orderRequest.setUserId(Long.valueOf(userId));
//                log.info("Using userId from token: {}", userId);
//            } else {
//                // For mock/demo purposes, use a default user ID
//                orderRequest.setUserId(1L);
//                log.info("Using default userId: 1 (no auth token provided)");
//            }
//
//            // Generate idempotency key if not provided
//            if (idempotencyKey == null || idempotencyKey.isEmpty()) {
//                idempotencyKey = "order_" + System.currentTimeMillis() + "_" +
//                        java.util.UUID.randomUUID().toString().substring(0, 8);
//                log.info("Generated idempotency key: {}", idempotencyKey);
//            }
//
//            log.info("Creating order for userId: {}, restaurantId: {}, idempotencyKey: {}",
//                    orderRequest.getUserId(), orderRequest.getRestaurantId(), idempotencyKey);
//
//            OrderDTO order = orderServiceImpl.placeOrder(orderRequest, idempotencyKey);
//
//            log.info("✅ Order created successfully with ID: {}", order.getOrderId());
//            return new ResponseEntity<>(order, HttpStatus.CREATED);
//
//        } catch (InvalidOperationException ex) {
//            log.error("❌ Invalid operation: {}", ex.getMessage());
//            return ResponseEntity.badRequest().body(createErrorResponse(ex.getMessage()));
//        } catch (ResourceNotFoundException ex) {
//            log.error("❌ Resource not found: {}", ex.getMessage());
//            return ResponseEntity.notFound().build();
//        } catch (IllegalArgumentException ex) {
//            log.error("❌ Invalid argument: {}", ex.getMessage());
//            return ResponseEntity.badRequest().body(createErrorResponse("Invalid request data: " + ex.getMessage()));
//        } catch (Exception ex) {
//            log.error("❌ Unexpected error creating order: {}", ex.getMessage(), ex);
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                    .body(createErrorResponse("Failed to create order. Please try again."));
//        }
//    }
//
//    /**
//     * ✅ FIXED: Get orders for a specific restaurant by ID (moved outside placeOrder method)
//     */
//    @GetMapping("/restaurant/{restaurantId}")
//    public ResponseEntity<?> getOrdersForRestaurant(
//            @PathVariable Long restaurantId,
//            @RequestHeader(value = "Authorization", required = false) String authHeader) {
//
//        log.info("Fetching orders for restaurant ID: {}", restaurantId);
//
//        try {
//            // Validate restaurant ID
//            if (restaurantId == null || restaurantId <= 0) {
//                log.error("Invalid restaurant ID: {}", restaurantId);
//                return ResponseEntity.badRequest()
//                        .body(createErrorResponse("Invalid restaurant ID"));
//            }
//
//            // Optional: Add authorization check if needed
//            // String userId = extractUserIdFromToken(authHeader);
//            // if (userId != null && !userId.equals(restaurantId.toString())) {
//            //     return ResponseEntity.status(HttpStatus.FORBIDDEN)
//            //             .body(createErrorResponse("Access denied"));
//            // }
//
//            // Fetch orders for the specific restaurant
//            List<OrderDTO> orders = orderServiceImpl.getRestaurantOrders(restaurantId);
//
//            log.info("✅ Restaurant {} orders retrieved successfully! Count: {}",
//                    restaurantId, orders.size());
//
//            return ResponseEntity.ok(orders);
//
//        } catch (NumberFormatException ex) {
//            log.error("Invalid restaurant ID format: {}", ex.getMessage());
//            return ResponseEntity.badRequest()
//                    .body(createErrorResponse("Invalid restaurant ID format"));
//        } catch (ResourceNotFoundException ex) {
//            log.error("Restaurant not found: {}", ex.getMessage());
//            return ResponseEntity.notFound().build();
//        } catch (Exception ex) {
//            log.error("❌ Error retrieving orders for restaurant {}: {}",
//                    restaurantId, ex.getMessage(), ex);
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                    .body(createErrorResponse("Failed to retrieve restaurant orders"));
//        }
//    }
//
//    /**
//     * Get restaurant orders with better error handling
//     */
//    @GetMapping("/restaurant")
//    public ResponseEntity<?> getRestaurantOrders(
//            @RequestHeader(value = "Authorization", required = false) String authHeader) {
//
//        try {
//            String userId = extractUserIdFromToken(authHeader);
//            String userRole = extractUserRoleFromToken(authHeader);
//
//            if (userId == null || userRole == null || !userRole.contains("RESTAURANT")) {
//                log.warn("Unauthorized restaurant orders access attempt");
//                return ResponseEntity.status(HttpStatus.FORBIDDEN)
//                        .body(createErrorResponse("Access denied. Restaurant authorization required."));
//            }
//
//            List<OrderDTO> orders = orderServiceImpl.getRestaurantOrders(Long.valueOf(userId));
//            log.info("Restaurant {} orders retrieved successfully! Count: {}", userId, orders.size());
//            return ResponseEntity.ok(orders);
//
//        } catch (NumberFormatException ex) {
//            log.error("Invalid userId format: {}", ex.getMessage());
//            return ResponseEntity.badRequest().body(createErrorResponse("Invalid user ID format"));
//        } catch (Exception ex) {
//            log.error("Error retrieving restaurant orders: {}", ex.getMessage(), ex);
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                    .body(createErrorResponse("Failed to retrieve orders"));
//        }
//    }
//
//    /**
//     * Update order status with validation
//     */
//    @PutMapping("/status")
//    public ResponseEntity<?> updateOrderStatus(
//            @RequestBody OrderStatusUpdateDTO statusUpdateDTO,
//            @RequestHeader(value = "Authorization", required = false) String authHeader) {
//
//        try {
//            String userId = extractUserIdFromToken(authHeader);
//            String userRole = extractUserRoleFromToken(authHeader);
//
//            if (userId == null || userRole == null || !userRole.contains("RESTAURANT")) {
//                log.warn("Unauthorized order status update attempt");
//                return ResponseEntity.status(HttpStatus.FORBIDDEN)
//                        .body(createErrorResponse("Access denied. Restaurant authorization required."));
//            }
//
//            statusUpdateDTO.setRestaurantId(Long.valueOf(userId));
//            OrderDTO updatedOrder = orderServiceImpl.updateOrderStatus(statusUpdateDTO);
//
//            log.info("Order status updated successfully by restaurant: {} for order: {}",
//                    userId, statusUpdateDTO.getOrderId());
//            return ResponseEntity.ok(updatedOrder);
//
//        } catch (InvalidOperationException ex) {
//            log.error("Invalid operation: {}", ex.getMessage());
//            return ResponseEntity.badRequest().body(createErrorResponse(ex.getMessage()));
//        } catch (ResourceNotFoundException ex) {
//            log.error("Order not found: {}", ex.getMessage());
//            return ResponseEntity.notFound().build();
//        } catch (Exception ex) {
//            log.error("Error updating order status: {}", ex.getMessage(), ex);
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                    .body(createErrorResponse("Failed to update order status"));
//        }
//    }
//
//    /**
//     * Get order details with error handling
//     */
//    @GetMapping("/{orderId}")
//    public ResponseEntity<?> getOrderDetails(@PathVariable Long orderId) {
//        try {
//            OrderDTO order = orderServiceImpl.getOrderDetails(orderId);
//            log.info("Order details retrieved successfully for order: {}", orderId);
//            return ResponseEntity.ok(order);
//        } catch (ResourceNotFoundException ex) {
//            log.error("Order not found: {}", ex.getMessage());
//            return ResponseEntity.notFound().build();
//        } catch (Exception ex) {
//            log.error("Error retrieving order details: {}", ex.getMessage(), ex);
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                    .body(createErrorResponse("Failed to retrieve order details"));
//        }
//    }
//
//    /**
//     * Get user orders with error handling
//     */
//    @GetMapping("/user")
//    public ResponseEntity<?> getUserOrders(
//            @RequestHeader(value = "Authorization", required = false) String authHeader) {
//
//        try {
//            String userId = extractUserIdFromToken(authHeader);
//            if (userId == null) {
//                // For mock/demo, use default user ID
//                userId = "1";
//                log.info("Using default userId for user orders: {}", userId);
//            }
//
//            List<OrderDTO> orders = orderServiceImpl.getUserOrders(Long.valueOf(userId));
//            log.info("User {} orders retrieved successfully! Count: {}", userId, orders.size());
//            return ResponseEntity.ok(orders);
//
//        } catch (NumberFormatException ex) {
//            log.error("Invalid userId format: {}", ex.getMessage());
//            return ResponseEntity.badRequest().body(createErrorResponse("Invalid user ID format"));
//        } catch (Exception ex) {
//            log.error("Error retrieving user orders: {}", ex.getMessage(), ex);
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                    .body(createErrorResponse("Failed to retrieve user orders"));
//        }
//    }
//
//    @PutMapping("/restaurant/{restaurantId}/order/{orderId}/status")
//    public ResponseEntity<?> updateOrderStatusForRestaurant(
//            @PathVariable Long restaurantId,
//            @PathVariable Long orderId,
//            @RequestBody Map<String, String> statusUpdate,
//            @RequestHeader(value = "Authorization", required = false) String authHeader) {
//
//        log.info("🔄 Updating order status for restaurant {} order {}: {}",
//                restaurantId, orderId, statusUpdate.get("status"));
//
//        try {
//            // Validate inputs
//            if (restaurantId == null || restaurantId <= 0) {
//                return ResponseEntity.badRequest()
//                        .body(createErrorResponse("Invalid restaurant ID"));
//            }
//
//            if (orderId == null || orderId <= 0) {
//                return ResponseEntity.badRequest()
//                        .body(createErrorResponse("Invalid order ID"));
//            }
//
//            String newStatus = statusUpdate.get("status");
//            if (newStatus == null || newStatus.trim().isEmpty()) {
//                return ResponseEntity.badRequest()
//                        .body(createErrorResponse("Status is required"));
//            }
//
//            // Create OrderStatusUpdateDTO
//            OrderStatusUpdateDTO statusUpdateDTO = new OrderStatusUpdateDTO();
//            statusUpdateDTO.setOrderId(orderId);
//            statusUpdateDTO.setRestaurantId(restaurantId);
//            statusUpdateDTO.setStatus(OrderStatus.valueOf(newStatus.toUpperCase()));
//            statusUpdateDTO.setNotes(statusUpdate.get("notes"));
//
//            // Update order status
//            OrderDTO updatedOrder = orderServiceImpl.updateOrderStatus(statusUpdateDTO);
//
//            log.info("✅ Order status updated successfully: restaurant={}, order={}, status={}",
//                    restaurantId, orderId, newStatus);
//
//            return ResponseEntity.ok(updatedOrder);
//
//        } catch (IllegalArgumentException ex) {
//            log.error("❌ Invalid status value: {}", ex.getMessage());
//            return ResponseEntity.badRequest()
//                    .body(createErrorResponse("Invalid status: " + ex.getMessage()));
//        } catch (ResourceNotFoundException ex) {
//            log.error("❌ Order not found: {}", ex.getMessage());
//            return ResponseEntity.notFound().build();
//        } catch (InvalidOperationException ex) {
//            log.error("❌ Invalid operation: {}", ex.getMessage());
//            return ResponseEntity.badRequest()
//                    .body(createErrorResponse(ex.getMessage()));
//        } catch (Exception ex) {
//            log.error("❌ Error updating order status: {}", ex.getMessage(), ex);
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                    .body(createErrorResponse("Failed to update order status: " + ex.getMessage()));
//        }
//    }
//
//    /**
//     * Health check endpoint
//     */
//    @GetMapping("/health")
//    public ResponseEntity<String> healthCheck() {
//        return ResponseEntity.ok("Order Service is running");
//    }
//
//    // Helper method to extract userId from JWT token
//    private String extractUserIdFromToken(String authHeader) {
//        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
//            return null;
//        }
//
//        try {
//            String token = authHeader.substring(7);
//            String[] parts = token.split("\\.");
//            if (parts.length != 3) return null;
//
//            String payload = new String(Base64.getUrlDecoder().decode(parts[1]));
//
//            if (payload.contains("\"userId\":")) {
//                String userIdPart = payload.substring(payload.indexOf("\"userId\":") + 9);
//                if (userIdPart.startsWith("\"")) {
//                    int endIndex = userIdPart.indexOf("\"", 1);
//                    return endIndex > 0 ? userIdPart.substring(1, endIndex) : null;
//                } else {
//                    int endIndex = userIdPart.indexOf(",");
//                    if (endIndex == -1) endIndex = userIdPart.indexOf("}");
//                    return endIndex > 0 ? userIdPart.substring(0, endIndex).trim() : null;
//                }
//            }
//        } catch (Exception e) {
//            log.error("Error extracting userId from token: {}", e.getMessage());
//        }
//
//        return null;
//    }
//
//    // Helper method to extract user role from JWT token
//    private String extractUserRoleFromToken(String authHeader) {
//        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
//            return null;
//        }
//
//        try {
//            String token = authHeader.substring(7);
//            String[] parts = token.split("\\.");
//            if (parts.length != 3) return null;
//
//            String payload = new String(Base64.getUrlDecoder().decode(parts[1]));
//
//            if (payload.contains("\"roles\":[")) {
//                String rolesPart = payload.substring(payload.indexOf("\"roles\":[") + 9);
//                int endIndex = rolesPart.indexOf("]");
//                if (endIndex > 0) {
//                    return rolesPart.substring(0, endIndex + 1);
//                }
//            }
//        } catch (Exception e) {
//            log.error("Error extracting roles from token: {}", e.getMessage());
//        }
//
//        return null;
//    }
//
//    /**
//     * Helper method to create consistent error responses
//     */
//    private ErrorResponse createErrorResponse(String message) {
//        return new ErrorResponse(message, System.currentTimeMillis());
//    }
//
//    /**
//     * Error response DTO
//     */
//    public static class ErrorResponse {
//        private String message;
//        private long timestamp;
//
//        public ErrorResponse(String message, long timestamp) {
//            this.message = message;
//            this.timestamp = timestamp;
//        }
//
//        // Getters
//        public String getMessage() { return message; }
//        public long getTimestamp() { return timestamp; }
//
//        // Setters
//        public void setMessage(String message) { this.message = message; }
//        public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
//    }
//}


package com.fooddelivery.orderservicef.controller;

import com.fooddelivery.orderservicef.model.OrderStatus;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.fooddelivery.orderservicef.dto.OrderDTO;
import com.fooddelivery.orderservicef.dto.OrderRequestDTO;
import com.fooddelivery.orderservicef.dto.OrderStatusUpdateDTO;
import com.fooddelivery.orderservicef.service.OrderServiceImpl;
import com.fooddelivery.orderservicef.exception.InvalidOperationException;
import com.fooddelivery.orderservicef.exception.ResourceNotFoundException;

import jakarta.servlet.http.HttpServletRequest;
import java.util.Base64;
import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "http://localhost:4200")
@Slf4j
@RestController
@RequestMapping("/api/orders")
@RequiredArgsConstructor
public class OrderController {

    private final OrderServiceImpl orderServiceImpl;

    /**
     * ✅ Place a new order with proper error handling
     */
    @PostMapping
    public ResponseEntity<?> placeOrder(
            @RequestBody OrderRequestDTO orderRequest,
            @RequestHeader(value = "X-Idempotency-Key", required = false) String idempotencyKey,
            @RequestHeader(value = "Authorization", required = false) String authHeader,
            HttpServletRequest request) {

        log.info("Received order placement request: restaurantId={}, deliveryAddress={}",
                orderRequest.getRestaurantId(), orderRequest.getDeliveryAddress());

        try {
            // ✅ ENHANCED: Better user ID extraction with fallbacks
            Long userId = extractUserIdFromRequest(authHeader, request);
            orderRequest.setUserId(userId);

            log.info("Using userId: {} for order placement", userId);

            // Generate idempotency key if not provided
            if (idempotencyKey == null || idempotencyKey.isEmpty()) {
                idempotencyKey = "order_" + System.currentTimeMillis() + "_" +
                        java.util.UUID.randomUUID().toString().substring(0, 8);
                log.info("Generated idempotency key: {}", idempotencyKey);
            }

            log.info("Creating order for userId: {}, restaurantId: {}, idempotencyKey: {}",
                    orderRequest.getUserId(), orderRequest.getRestaurantId(), idempotencyKey);

            OrderDTO order = orderServiceImpl.placeOrder(orderRequest, idempotencyKey);

            log.info("✅ Order created successfully with ID: {}", order.getOrderId());
            return new ResponseEntity<>(order, HttpStatus.CREATED);

        } catch (InvalidOperationException ex) {
            log.error("❌ Invalid operation: {}", ex.getMessage());
            return ResponseEntity.badRequest().body(createErrorResponse(ex.getMessage()));
        } catch (ResourceNotFoundException ex) {
            log.error("❌ Resource not found: {}", ex.getMessage());
            return ResponseEntity.notFound().build();
        } catch (IllegalArgumentException ex) {
            log.error("❌ Invalid argument: {}", ex.getMessage());
            return ResponseEntity.badRequest().body(createErrorResponse("Invalid request data: " + ex.getMessage()));
        } catch (Exception ex) {
            log.error("❌ Unexpected error creating order: {}", ex.getMessage(), ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(createErrorResponse("Failed to create order. Please try again."));
        }
    }

    /**
     * ✅ CRITICAL: Get order details by ID (for order tracking)
     */
    @GetMapping("/{orderId}")
    public ResponseEntity<?> getOrderDetails(
            @PathVariable Long orderId,
            @RequestHeader(value = "Authorization", required = false) String authHeader,
            HttpServletRequest request) {

        log.info("🔍 Fetching order details for orderId: {}", orderId);

        try {
            // Validate order ID
            if (orderId == null || orderId <= 0) {
                log.error("Invalid order ID: {}", orderId);
                return ResponseEntity.badRequest()
                        .body(createErrorResponse("Invalid order ID"));
            }

            // Get order details
            OrderDTO order = orderServiceImpl.getOrderDetails(orderId);

            // ✅ ENHANCED: Add security check (optional - remove if you want public access)
            Long requestingUserId = extractUserIdFromRequest(authHeader, request);

            // Allow access if:
            // 1. User is the customer who placed the order
            // 2. User is the restaurant that received the order
            // 3. No authentication (for demo purposes)
            boolean hasAccess = requestingUserId == null || // No auth (demo mode)
                    requestingUserId.equals(order.getUserId()) || // Customer access
                    requestingUserId.equals(order.getRestaurantId()); // Restaurant access

            if (!hasAccess) {
                log.warn("Access denied for user {} to order {}", requestingUserId, orderId);
                return ResponseEntity.status(HttpStatus.FORBIDDEN)
                        .body(createErrorResponse("Access denied to this order"));
            }

            log.info("✅ Order details retrieved successfully for order: {}", orderId);
            return ResponseEntity.ok(order);

        } catch (ResourceNotFoundException ex) {
            log.error("❌ Order not found: {}", ex.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(createErrorResponse("Order not found with ID: " + orderId));
        } catch (Exception ex) {
            log.error("❌ Error retrieving order details for orderId {}: {}", orderId, ex.getMessage(), ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(createErrorResponse("Failed to retrieve order details"));
        }
    }

    /**
     * ✅ ENHANCED: Get orders for a specific restaurant by ID
     */
    @GetMapping("/restaurant/{restaurantId}")
    public ResponseEntity<?> getOrdersForRestaurant(
            @PathVariable Long restaurantId,
            @RequestHeader(value = "Authorization", required = false) String authHeader,
            HttpServletRequest request) {

        log.info("🔍 Fetching orders for restaurant ID: {}", restaurantId);

        try {
            // Validate restaurant ID
            if (restaurantId == null || restaurantId <= 0) {
                log.error("Invalid restaurant ID: {}", restaurantId);
                return ResponseEntity.badRequest()
                        .body(createErrorResponse("Invalid restaurant ID"));
            }

            // ✅ ENHANCED: Check authorization
            Long requestingUserId = extractUserIdFromRequest(authHeader, request);
            String userRole = extractUserRoleFromToken(authHeader);

            // Allow access for restaurant owners or demo mode
            if (requestingUserId != null && !requestingUserId.equals(restaurantId) &&
                    (userRole == null || !userRole.contains("ADMIN"))) {
                log.warn("Access denied for user {} to restaurant {} orders", requestingUserId, restaurantId);
                return ResponseEntity.status(HttpStatus.FORBIDDEN)
                        .body(createErrorResponse("Access denied to restaurant orders"));
            }

            // Fetch orders for the specific restaurant
            List<OrderDTO> orders = orderServiceImpl.getRestaurantOrders(restaurantId);

            log.info("✅ Restaurant {} orders retrieved successfully! Count: {}", restaurantId, orders.size());
            return ResponseEntity.ok(orders);

        } catch (NumberFormatException ex) {
            log.error("❌ Invalid restaurant ID format: {}", ex.getMessage());
            return ResponseEntity.badRequest()
                    .body(createErrorResponse("Invalid restaurant ID format"));
        } catch (ResourceNotFoundException ex) {
            log.error("❌ Restaurant not found: {}", ex.getMessage());
            return ResponseEntity.notFound().build();
        } catch (Exception ex) {
            log.error("❌ Error retrieving orders for restaurant {}: {}", restaurantId, ex.getMessage(), ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(createErrorResponse("Failed to retrieve restaurant orders"));
        }
    }

    /**
     * ✅ ENHANCED: Update order status for restaurant with better validation
     */
    @PutMapping("/restaurant/{restaurantId}/order/{orderId}/status")
    public ResponseEntity<?> updateOrderStatusForRestaurant(
            @PathVariable Long restaurantId,
            @PathVariable Long orderId,
            @RequestBody Map<String, String> statusUpdate,
            @RequestHeader(value = "Authorization", required = false) String authHeader,
            HttpServletRequest request) {

        log.info("🔄 Updating order status for restaurant {} order {}: {}",
                restaurantId, orderId, statusUpdate.get("status"));

        try {
            // Validate inputs
            if (restaurantId == null || restaurantId <= 0) {
                return ResponseEntity.badRequest()
                        .body(createErrorResponse("Invalid restaurant ID"));
            }

            if (orderId == null || orderId <= 0) {
                return ResponseEntity.badRequest()
                        .body(createErrorResponse("Invalid order ID"));
            }

            String newStatus = statusUpdate.get("status");
            if (newStatus == null || newStatus.trim().isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(createErrorResponse("Status is required"));
            }

            // ✅ ENHANCED: Check authorization
            Long requestingUserId = extractUserIdFromRequest(authHeader, request);
            if (requestingUserId != null && !requestingUserId.equals(restaurantId)) {
                log.warn("Access denied for user {} to update restaurant {} order", requestingUserId, restaurantId);
                return ResponseEntity.status(HttpStatus.FORBIDDEN)
                        .body(createErrorResponse("Access denied to update this order"));
            }

            // Validate status
            OrderStatus orderStatus;
            try {
                orderStatus = OrderStatus.valueOf(newStatus.toUpperCase());
            } catch (IllegalArgumentException e) {
                log.error("❌ Invalid status value: {}", newStatus);
                return ResponseEntity.badRequest()
                        .body(createErrorResponse("Invalid status: " + newStatus +
                                ". Valid statuses are: " + java.util.Arrays.toString(OrderStatus.values())));
            }

            // Create OrderStatusUpdateDTO
            OrderStatusUpdateDTO statusUpdateDTO = new OrderStatusUpdateDTO();
            statusUpdateDTO.setOrderId(orderId);
            statusUpdateDTO.setRestaurantId(restaurantId);
            statusUpdateDTO.setStatus(orderStatus);
            statusUpdateDTO.setNotes(statusUpdate.get("notes"));

            // Update order status
            OrderDTO updatedOrder = orderServiceImpl.updateOrderStatus(statusUpdateDTO);

            log.info("✅ Order status updated successfully: restaurant={}, order={}, status={}",
                    restaurantId, orderId, newStatus);

            return ResponseEntity.ok(updatedOrder);

        } catch (ResourceNotFoundException ex) {
            log.error("❌ Order not found: {}", ex.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(createErrorResponse("Order not found: " + ex.getMessage()));
        } catch (InvalidOperationException ex) {
            log.error("❌ Invalid operation: {}", ex.getMessage());
            return ResponseEntity.badRequest()
                    .body(createErrorResponse(ex.getMessage()));
        } catch (Exception ex) {
            log.error("❌ Error updating order status: {}", ex.getMessage(), ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(createErrorResponse("Failed to update order status: " + ex.getMessage()));
        }
    }

    /**
     * ✅ Get user orders with error handling
     */
    @GetMapping("/user")
    public ResponseEntity<?> getUserOrders(
            @RequestHeader(value = "Authorization", required = false) String authHeader,
            HttpServletRequest request) {

        try {
            Long userId = extractUserIdFromRequest(authHeader, request);

            List<OrderDTO> orders = orderServiceImpl.getUserOrders(userId);
            log.info("✅ User {} orders retrieved successfully! Count: {}", userId, orders.size());
            return ResponseEntity.ok(orders);

        } catch (NumberFormatException ex) {
            log.error("❌ Invalid userId format: {}", ex.getMessage());
            return ResponseEntity.badRequest().body(createErrorResponse("Invalid user ID format"));
        } catch (Exception ex) {
            log.error("❌ Error retrieving user orders: {}", ex.getMessage(), ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(createErrorResponse("Failed to retrieve user orders"));
        }
    }

    /**
     * ✅ FIXED: Get order status only (lightweight endpoint for frequent polling)
     */
    @GetMapping("/{orderId}/status")
    public ResponseEntity<?> getOrderStatus(
            @PathVariable Long orderId,
            @RequestHeader(value = "Authorization", required = false) String authHeader) {

        log.debug("🔍 Fetching order status for orderId: {}", orderId);

        try {
            OrderDTO order = orderServiceImpl.getOrderDetails(orderId);

            // ✅ FIX: Convert LocalDateTime to String
            String orderTimeString = order.getOrderTime() != null ?
                    order.getOrderTime().toString() : null;
            String deliveryTimeString = order.getDeliveryTime() != null ?
                    order.getDeliveryTime().toString() : null;

            // Return lightweight status response
            OrderStatusResponse statusResponse = new OrderStatusResponse(
                    order.getOrderId(),
                    order.getStatus().toString(),
                    orderTimeString,      // ✅ Now String
                    deliveryTimeString,   // ✅ Now String
                    System.currentTimeMillis()
            );

            return ResponseEntity.ok(statusResponse);

        } catch (ResourceNotFoundException ex) {
            log.error("❌ Order not found for status check: {}", ex.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(createErrorResponse("Order not found"));
        } catch (Exception ex) {
            log.error("❌ Error getting order status: {}", ex.getMessage(), ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(createErrorResponse("Failed to get order status"));
        }
    }

    /**
     * ✅ Health check endpoint
     */
    @GetMapping("/health")
    public ResponseEntity<String> healthCheck() {
        return ResponseEntity.ok("Order Service is running");
    }

    // ✅ ENHANCED: Better user ID extraction with multiple fallbacks
    private Long extractUserIdFromRequest(String authHeader, HttpServletRequest request) {
        // Method 1: Extract from JWT token
        String userIdFromToken = extractUserIdFromToken(authHeader);
        if (userIdFromToken != null) {
            try {
                return Long.valueOf(userIdFromToken);
            } catch (NumberFormatException e) {
                log.warn("Invalid userId format in token: {}", userIdFromToken);
            }
        }

        // Method 2: Extract from custom headers (matching your AuthService)
        String userIdHeader = request.getHeader("X-Internal-User-Id");
        if (userIdHeader != null) {
            try {
                return Long.valueOf(userIdHeader);
            } catch (NumberFormatException e) {
                log.warn("Invalid userId in X-Internal-User-Id header: {}", userIdHeader);
            }
        }

        // Method 3: Default fallback for demo/testing
        log.info("No valid userId found, using default: 1");
        return 1L;
    }

    // ✅ ENHANCED: Helper method to extract userId from JWT token
    private String extractUserIdFromToken(String authHeader) {
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return null;
        }

        try {
            String token = authHeader.substring(7);
            String[] parts = token.split("\\.");
            if (parts.length != 3) return null;

            String payload = new String(Base64.getUrlDecoder().decode(parts[1]));

            // Try multiple field names that might contain user ID
            String[] userIdFields = {"userId", "user_id", "sub", "id"};

            for (String field : userIdFields) {
                String fieldPattern = "\"" + field + "\":";
                if (payload.contains(fieldPattern)) {
                    String userIdPart = payload.substring(payload.indexOf(fieldPattern) + fieldPattern.length());

                    if (userIdPart.startsWith("\"")) {
                        // String value
                        int endIndex = userIdPart.indexOf("\"", 1);
                        if (endIndex > 0) {
                            return userIdPart.substring(1, endIndex);
                        }
                    } else {
                        // Numeric value
                        int endIndex = userIdPart.indexOf(",");
                        if (endIndex == -1) endIndex = userIdPart.indexOf("}");
                        if (endIndex > 0) {
                            return userIdPart.substring(0, endIndex).trim();
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.error("❌ Error extracting userId from token: {}", e.getMessage());
        }

        return null;
    }

    // Helper method to extract user role from JWT token
    private String extractUserRoleFromToken(String authHeader) {
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return null;
        }

        try {
            String token = authHeader.substring(7);
            String[] parts = token.split("\\.");
            if (parts.length != 3) return null;

            String payload = new String(Base64.getUrlDecoder().decode(parts[1]));

            if (payload.contains("\"roles\":[")) {
                String rolesPart = payload.substring(payload.indexOf("\"roles\":[") + 9);
                int endIndex = rolesPart.indexOf("]");
                if (endIndex > 0) {
                    return rolesPart.substring(0, endIndex + 1);
                }
            }
        } catch (Exception e) {
            log.error("❌ Error extracting roles from token: {}", e.getMessage());
        }

        return null;
    }

    /**
     * ✅ Helper method to create consistent error responses
     */
    private ErrorResponse createErrorResponse(String message) {
        return new ErrorResponse(message, System.currentTimeMillis());
    }

    /**
     * ✅ Error response DTO
     */
    public static class ErrorResponse {
        private String message;
        private long timestamp;

        public ErrorResponse(String message, long timestamp) {
            this.message = message;
            this.timestamp = timestamp;
        }

        // Getters and setters
        public String getMessage() { return message; }
        public long getTimestamp() { return timestamp; }
        public void setMessage(String message) { this.message = message; }
        public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
    }

    /**
     * ✅ NEW: Lightweight order status response for polling
     */
    public static class OrderStatusResponse {
        private Long orderId;
        private String status;
        private String orderTime;
        private String deliveryTime;
        private long lastUpdated;

        public OrderStatusResponse(Long orderId, String status, String orderTime, String deliveryTime, long lastUpdated) {
            this.orderId = orderId;
            this.status = status;
            this.orderTime = orderTime;
            this.deliveryTime = deliveryTime;
            this.lastUpdated = lastUpdated;
        }

        // Getters and setters
        public Long getOrderId() { return orderId; }
        public String getStatus() { return status; }
        public String getOrderTime() { return orderTime; }
        public String getDeliveryTime() { return deliveryTime; }
        public long getLastUpdated() { return lastUpdated; }

        public void setOrderId(Long orderId) { this.orderId = orderId; }
        public void setStatus(String status) { this.status = status; }
        public void setOrderTime(String orderTime) { this.orderTime = orderTime; }
        public void setDeliveryTime(String deliveryTime) { this.deliveryTime = deliveryTime; }
        public void setLastUpdated(long lastUpdated) { this.lastUpdated = lastUpdated; }
    }
}



//package com.delivery.delivery_service.repository;
//
//import com.delivery.delivery_service.entity.DeliveryEntity;
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import java.util.Optional;
//
///**
// * Spring Data JPA repository for {@link DeliveryEntity}.
// * Provides standard CRUD operations and custom query methods for delivery data.
// */
//public interface DeliveryRepository extends JpaRepository<DeliveryEntity, Long> {
//    /**
//     * Retrieves a delivery record by its associated order ID.
//     * The result is wrapped in an {@link Optional} to handle cases where no delivery is found.
//     *
//     * @param orderId The unique identifier of the order.
//     * @return An {@link Optional} containing the {@link DeliveryEntity} if found, otherwise an empty Optional.
//     */
//    Optional<DeliveryEntity> findByOrderId(Long orderId);
//
//    /**
//     * Checks if a delivery record already exists for a given order ID.
//     * This is useful for preventing duplicate delivery assignments for the same order.
//     *
//     * @param orderId The unique identifier of the order to check.
//     * @return {@code true} if a delivery exists for the given order ID, {@code false} otherwise.
//     */
//    boolean existsByOrderId(Long orderId);
//}


package com.delivery.delivery_service.repository;

import com.delivery.delivery_service.entity.DeliveryEntity;
import com.delivery.delivery_service.entity.DeliveryStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Spring Data JPA repository for {@link DeliveryEntity}.
 * Provides standard CRUD operations and custom query methods for delivery data.
 */
@Repository
public interface DeliveryRepository extends JpaRepository<DeliveryEntity, Long> {

    /**
     * ✅ EXISTING: Finds delivery by order ID
     */
    Optional<DeliveryEntity> findByOrderId(Long orderId);

    /**
     * ✅ EXISTING: Checks if delivery exists for order
     */
    boolean existsByOrderId(Long orderId);

    /**
     * ✅ NEW: Finds all deliveries by status (REQUIRED FOR THE FIX)
     */
    List<DeliveryEntity> findByDeliveryStatus(DeliveryStatus deliveryStatus);

    /**
     * ✅ NEW: Finds all deliveries assigned to a specific agent
     */
    List<DeliveryEntity> findByAgentAgentId(Long agentId);

    /**
     * ✅ NEW: Counts deliveries by status
     */
    long countByDeliveryStatus(DeliveryStatus deliveryStatus);

    /**
     * ✅ NEW: Finds active deliveries for an agent
     */
    @Query("SELECT d FROM DeliveryEntity d WHERE d.agent.agentId = :agentId AND d.deliveryStatus = :status")
    List<DeliveryEntity> findByAgentIdAndStatus(@Param("agentId") Long agentId, @Param("status") DeliveryStatus status);

    /**
     * ✅ OPTIONAL: Find deliveries by order ID list (for batch operations)
     */
    List<DeliveryEntity> findByOrderIdIn(List<Long> orderIds);

    /**
     * ✅ OPTIONAL: Find recent deliveries (for monitoring)
     */
    @Query("SELECT d FROM DeliveryEntity d WHERE d.createdOn >= :fromDate ORDER BY d.createdOn DESC")
    List<DeliveryEntity> findRecentDeliveries(@Param("fromDate") java.time.LocalDateTime fromDate);
}

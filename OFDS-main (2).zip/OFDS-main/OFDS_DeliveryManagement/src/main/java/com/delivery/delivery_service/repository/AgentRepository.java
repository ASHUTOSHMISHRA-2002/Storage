//package com.delivery.delivery_service.repository;
//
//import com.delivery.delivery_service.entity.AgentEntity;
//import com.delivery.delivery_service.entity.AgentStatus;
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import java.util.List;
//
///**
// * Spring Data JPA repository for {@link AgentEntity}.
// * Provides standard CRUD operations and custom query methods for agent data.
// */
//public interface AgentRepository extends JpaRepository<AgentEntity, Long> {
//    /**
//     * Finds all agents that have a specific status.
//     * This allows querying for agents that are, for example, 'AVAILABLE' or 'ASSIGNED'.
//     *
//     * @param status The {@link AgentStatus} to filter agents by.
//     * @return A list of {@link AgentEntity} matching the given status.
//     */
//    List<AgentEntity> findByAgentStatus(AgentStatus status);
//
//}
//
//package com.delivery.delivery_service.repository;
//
//import com.delivery.delivery_service.entity.AgentEntity;
//import com.delivery.delivery_service.entity.AgentStatus;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.data.repository.query.Param;
//
//import java.util.List;
//import java.util.Optional;
//
///**
// * Spring Data JPA repository for {@link AgentEntity}.
// * Provides standard CRUD operations and custom query methods for agent data.
// */
//public interface AgentRepository extends JpaRepository<AgentEntity, Long> {
//
//    /**
//     * ✅ CORE: Finds all agents that have a specific status.
//     * This is essential for random agent selection.
//     *
//     * @param status The {@link AgentStatus} to filter agents by.
//     * @return A list of {@link AgentEntity} matching the given status.
//     */
//    List<AgentEntity> findByAgentStatus(AgentStatus status);
//
//    /**
//     * ✅ USEFUL: Counts agents by status for monitoring.
//     *
//     * @param status The status to count.
//     * @return Number of agents with the specified status.
//     */
//    long countByAgentStatus(AgentStatus status);
//
//    /**
//     * ✅ OPTIONAL: Find agent by phone number for validation.
//     *
//     * @param phoneNumber The phone number to search for.
//     * @return Optional containing the agent if found.
//     */
//    Optional<AgentEntity> findByAgentPhoneNumber(String phoneNumber);
//
//    /**
//     * ✅ OPTIONAL: Custom query to find available agents in a specific area/zone.
//     * Useful for future location-based assignment.
//     *
//     * @param status The agent status.
//     * @return List of available agents (can be extended with location parameters).
//     */
//    @Query("SELECT a FROM AgentEntity a WHERE a.agentStatus = :status ORDER BY a.agentId")
//    List<AgentEntity> findAvailableAgentsOrdered(@Param("status") AgentStatus status);
//}
//


package com.delivery.delivery_service.repository;

import com.delivery.delivery_service.entity.AgentEntity;
import com.delivery.delivery_service.entity.AgentStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Spring Data JPA repository for {@link AgentEntity}.
 * Provides standard CRUD operations and custom query methods for agent data.
 */
@Repository
public interface AgentRepository extends JpaRepository<AgentEntity, Long> {

    /**
     * ✅ EXISTING: Finds all agents that have a specific status.
     * This is essential for random agent selection.
     */
    List<AgentEntity> findByAgentStatus(AgentStatus status);

    /**
     * ✅ NEW: Counts agents by status for monitoring (REQUIRED FOR THE UPDATED SERVICE)
     */
    long countByAgentStatus(AgentStatus status);

    /**
     * ✅ OPTIONAL: Find agent by phone number for validation
     */
    Optional<AgentEntity> findByAgentPhoneNumber(String phoneNumber);

    /**
     * ✅ OPTIONAL: Custom query to find available agents ordered by ID
     */
    @Query("SELECT a FROM AgentEntity a WHERE a.agentStatus = :status ORDER BY a.agentId")
    List<AgentEntity> findAvailableAgentsOrdered(@Param("status") AgentStatus status);
}

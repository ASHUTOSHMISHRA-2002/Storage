//package com.delivery.delivery_service.service;
//
//import com.delivery.delivery_service.dto.DeliveryAssignmentDTO;
//import com.delivery.delivery_service.dto.DeliveryDTO;
//import com.delivery.delivery_service.dto.DeliveryStatusUpdateDTO;
//import com.delivery.delivery_service.dto.OrderDTO;
//
///**
// * Interface defining the business logic for managing delivery operations.
// * This contract specifies the core functionalities of the Delivery Service.
// */
//public interface DeliveryService {
//
//    /*
//     * Assigns a delivery agent to a specific order.
//     *
//     * @param dto Contains the order ID and the agent ID for the assignment.
//     * @return A {@link DeliveryDTO} representing the newly created delivery record.
//     * @throws IllegalArgumentException If orderId or agentId are invalid.
//     * @throws DuplicateAssignmentException If the order is already assigned or the agent is already assigned.
//     * @throws ResourceNotFoundException If the agent specified by agentId is not found.
//     */
//    DeliveryDTO assignDeliveryAgent(DeliveryAssignmentDTO dto);
//
//    /*
//     * Updates the status of an existing delivery.
//     *
//     * @param deliveryId The unique ID of the delivery to update.
//     * @param dto Contains the new status and optionally an updated estimated delivery time.
//     * @return A {@link DeliveryDTO} representing the updated delivery record.
//     * @throws ResourceNotFoundException If the delivery specified by deliveryId is not found.
//     * @throws InvalidStatusException If the provided status value is invalid or leads to an invalid transition.
//     */
//    DeliveryDTO updateDeliveryStatus(Long deliveryId, DeliveryStatusUpdateDTO dto);
//
//    /*
//     * Retrieves the delivery details for a given order ID.
//     *
//     * @param orderId The unique ID of the order to find the delivery for.
//     * @return A {@link DeliveryDTO} representing the delivery associated with the order.
//     * @throws ResourceNotFoundException If no delivery record is found for the given order ID.
//     */
//    DeliveryDTO getDeliveryByOrderId(Long orderId);
//
//    Long findAvailableAgent();
//
//    DeliveryDTO assignDelivery(OrderDTO orderDTO);
//}
//


package com.delivery.delivery_service.service;

import com.delivery.delivery_service.dto.DeliveryAssignmentDTO;
import com.delivery.delivery_service.dto.DeliveryDTO;
import com.delivery.delivery_service.dto.DeliveryStatusUpdateDTO;
import com.delivery.delivery_service.dto.OrderDTO;
import com.delivery.delivery_service.entity.AgentEntity;
import com.delivery.delivery_service.entity.DeliveryStatus;
import java.util.List;

/**
 * Interface defining the business logic for managing delivery operations.
 * This contract specifies the core functionalities of the Delivery Service.
 */
public interface DeliveryService {

    /**
     * Assigns a delivery agent to a specific order.
     *
     * @param dto Contains the order ID and the agent ID for the assignment.
     * @return A {@link DeliveryDTO} representing the newly created delivery record.
     * @throws IllegalArgumentException If orderId or agentId are invalid.
     * @throws DuplicateAssignmentException If the order is already assigned or the agent is already assigned.
     * @throws ResourceNotFoundException If the agent specified by agentId is not found.
     */
    DeliveryDTO assignDeliveryAgent(DeliveryAssignmentDTO dto);

    /**
     * Updates the status of an existing delivery.
     *
     * @param deliveryId The unique ID of the delivery to update.
     * @param dto Contains the new status and optionally an updated estimated delivery time.
     * @return A {@link DeliveryDTO} representing the updated delivery record.
     * @throws ResourceNotFoundException If the delivery specified by deliveryId is not found.
     * @throws InvalidStatusException If the provided status value is invalid or leads to an invalid transition.
     */
    DeliveryDTO updateDeliveryStatus(Long deliveryId, DeliveryStatusUpdateDTO dto);

    /**
     * Retrieves the delivery details for a given order ID.
     *
     * @param orderId The unique ID of the order to find the delivery for.
     * @return A {@link DeliveryDTO} representing the delivery associated with the order.
     * @throws ResourceNotFoundException If no delivery record is found for the given order ID.
     */
    DeliveryDTO getDeliveryByOrderId(Long orderId);

    /**
     * ✅ CORE: Finds an available agent randomly for assignment.
     * This method implements the random selection logic.
     *
     * @return The ID of a randomly selected available agent, or null if none available.
     */
    Long findAvailableAgent();

    /**
     * ✅ CORE: Assigns a randomly selected delivery agent to an order.
     * This is the main method called by the Order Service for automatic assignment.
     *
     * @param orderDTO Contains order details for delivery assignment.
     * @return A {@link DeliveryDTO} representing the newly assigned delivery with random agent.
     * @throws ResourceNotFoundException If no available agents are found.
     * @throws InvalidOrderIdException If the order ID is invalid.
     * @throws DuplicateAssignmentException If delivery already exists for the order.
     */
    DeliveryDTO assignDelivery(OrderDTO orderDTO);

    // ✅ OPTIONAL: Additional methods for enhanced functionality

    /**
     * Gets delivery details by delivery ID.
     *
     * @param deliveryId The unique ID of the delivery.
     * @return A {@link DeliveryDTO} representing the delivery record.
     * @throws ResourceNotFoundException If the delivery is not found.
     */
    DeliveryDTO getDeliveryById(Long deliveryId);

    /**
     * Gets count of available agents for monitoring.
     *
     * @return Number of agents currently available for assignment.
     */
    long getAvailableAgentsCount();

    /**
     * Releases an agent back to available status.
     *
     * @param agentId The ID of the agent to release.
     * @return true if agent was successfully released, false otherwise.
     */
    boolean releaseAgent(Long agentId);

    /**
     * Gets all deliveries with a specific status.
     *
     * @param status The delivery status to filter by.
     * @return List of deliveries with the specified status.
     */
    List<DeliveryDTO> getDeliveriesByStatus(DeliveryStatus status);

    /**
     * Gets all active deliveries (IN_PROGRESS status).
     *
     * @return List of active deliveries.
     */
    List<DeliveryDTO> getActiveDeliveries();

    /**
     * Gets all deliveries assigned to a specific agent.
     *
     * @param agentId The ID of the agent.
     * @return List of deliveries assigned to the agent.
     */
    List<DeliveryDTO> getDeliveriesForAgent(Long agentId);

    /**
     * Health check method to verify service is working correctly.
     *
     * @return true if service is healthy, false otherwise.
     */
    boolean isServiceHealthy();
}

//package com.ofds.authservice.service;
//
//import org.springframework.stereotype.Service;
//
//import java.security.Key;
//import java.util.Date;
//import java.util.HashMap;
//import java.util.Map;
//import java.util.function.Function;
//
//import org.springframework.beans.factory.annotation.Value;
//
//import io.jsonwebtoken.Claims;
//import io.jsonwebtoken.Jwts;
//import io.jsonwebtoken.SignatureAlgorithm;
//import io.jsonwebtoken.io.Decoders;
//import io.jsonwebtoken.security.Keys;
//
//@Service
//public class JwtService {
//
//	@Value("${jwt.secret}")
//	private String SECRET_KEY;
//
//	@Value("${jwt.expiration.ms}")
//	private long EXPIRATION_TIME_MS;
//
//	public String extractUsername(String token) {
//		return extractClaim(token, Claims::getSubject);
//	}
//
//	public Date extractExpiration(String token) {
//		return extractClaim(token, Claims::getExpiration);
//	}
//
//	public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
//		final Claims claims = extractAllClaims(token);
//		return claimsResolver.apply(claims);
//	}
//
//	private Claims extractAllClaims(String token) {
//		return Jwts.parser().setSigningKey(getSigningKey()).build().parseClaimsJws(token).getBody();
//	}
//
//	private Boolean isTokenExpired(String token) {
//		return extractExpiration(token).before(new Date());
//	}
//
//	public String generateToken(String username, Map<String, Object> extraClaims) {
//		return Jwts.builder().setClaims(extraClaims).setSubject(username)
//				.setIssuedAt(new Date(System.currentTimeMillis()))
//				.setExpiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME_MS))
//				.signWith(getSigningKey(), SignatureAlgorithm.HS256).compact();
//	}
//
//
//	private Key getSigningKey() {
//		byte[] keyBytes = Decoders.BASE64.decode(SECRET_KEY);
//		return Keys.hmacShaKeyFor(keyBytes);
//	}
//
//}

package com.ofds.authservice.service;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.auth0.jwt.interfaces.JWTVerifier;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.Claim;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import lombok.extern.slf4j.Slf4j;

import java.util.Date;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;

@Service
@Slf4j
public class JwtService {

	@Value("${jwt.secret}")
	private String secretKey;

	@Value("${jwt.expiration.ms}")
	private long expirationMs;

	private static final String ISSUER = "ofds-auth-service";

	// ✅ Generate JWT Token using Auth0 library
	public String generateToken(String subject, Map<String, Object> claims) {
		try {
			Algorithm algorithm = Algorithm.HMAC256(secretKey);
			Date now = new Date(System.currentTimeMillis());
			Date expiration = new Date(System.currentTimeMillis() + expirationMs);

			log.debug("🔐 Generating JWT token for subject: {} with expiration: {}", subject, expiration);

			com.auth0.jwt.JWTCreator.Builder tokenBuilder = JWT.create()
					.withSubject(subject)
					.withIssuer(ISSUER)
					.withIssuedAt(now)
					.withExpiresAt(expiration);

			// ✅ Add claims with proper type handling
			if (claims != null) {
				for (Map.Entry<String, Object> entry : claims.entrySet()) {
					String key = entry.getKey();
					Object value = entry.getValue();

					if (value instanceof String) {
						tokenBuilder.withClaim(key, (String) value);
					} else if (value instanceof Integer) {
						tokenBuilder.withClaim(key, (Integer) value);
					} else if (value instanceof Long) {
						tokenBuilder.withClaim(key, (Long) value);
					} else if (value instanceof Boolean) {
						tokenBuilder.withClaim(key, (Boolean) value);
					} else if (value instanceof Date) {
						tokenBuilder.withClaim(key, (Date) value);
					} else if (value instanceof List) {
						// Convert list to string array for JWT
						ArrayList<String> stringList = new ArrayList<>();
						for (Object obj : (List<?>) value) {
							stringList.add(obj.toString());
						}
						tokenBuilder.withArrayClaim(key, stringList.toArray(new String[0]));
					} else {
						tokenBuilder.withClaim(key, value.toString());
					}
				}
			}

			String token = tokenBuilder.sign(algorithm);
			log.debug("✅ JWT token generated successfully for: {}", subject);
			return token;

		} catch (Exception e) {
			log.error("❌ Error generating JWT token for subject {}: {}", subject, e.getMessage(), e);
			throw new RuntimeException("Failed to generate JWT token", e);
		}
	}

	// ✅ Verify and decode JWT token
	public DecodedJWT verifyToken(String token) {
		try {
			Algorithm algorithm = Algorithm.HMAC256(secretKey);
			JWTVerifier verifier = JWT.require(algorithm)
					.withIssuer(ISSUER)
					.build();
			return verifier.verify(token);
		} catch (JWTVerificationException e) {
			log.error("❌ JWT verification failed: {}", e.getMessage());
			throw new RuntimeException("JWT verification failed", e);
		}
	}

	// ✅ Extract username (subject) from token
	public String extractUsername(String token) {
		try {
			DecodedJWT decodedJWT = verifyToken(token);
			return decodedJWT.getSubject();
		} catch (Exception e) {
			log.error("❌ Error extracting username from token: {}", e.getMessage());
			return null;
		}
	}

	// ✅ Extract email from token
	public String extractEmail(String token) {
		try {
			DecodedJWT decodedJWT = verifyToken(token);
			Claim emailClaim = decodedJWT.getClaim("email");
			return emailClaim.isNull() ? null : emailClaim.asString();
		} catch (Exception e) {
			log.error("❌ Error extracting email from token: {}", e.getMessage());
			return null;
		}
	}

	// ✅ Extract user type from token
	public String extractUserType(String token) {
		try {
			DecodedJWT decodedJWT = verifyToken(token);
			Claim userTypeClaim = decodedJWT.getClaim("userType");
			return userTypeClaim.isNull() ? null : userTypeClaim.asString();
		} catch (Exception e) {
			log.error("❌ Error extracting userType from token: {}", e.getMessage());
			return null;
		}
	}

	// ✅ Extract expiration date from token
	public Date extractExpiration(String token) {
		try {
			DecodedJWT decodedJWT = verifyToken(token);
			return decodedJWT.getExpiresAt();
		} catch (Exception e) {
			log.error("❌ Error extracting expiration from token: {}", e.getMessage());
			return null;
		}
	}

	// ✅ Check if token is expired
	public Boolean isTokenExpired(String token) {
		try {
			Date expiration = extractExpiration(token);
			return expiration != null && expiration.before(new Date());
		} catch (Exception e) {
			log.error("❌ Error checking token expiration: {}", e.getMessage());
			return true; // Assume expired if we can't check
		}
	}

	// ✅ Validate token with username
	public boolean validateToken(String token, String username) {
		try {
			String extractedUsername = extractUsername(token);
			return (extractedUsername != null &&
					extractedUsername.equals(username) &&
					!isTokenExpired(token));
		} catch (Exception e) {
			log.error("❌ Error validating token for user {}: {}", username, e.getMessage());
			return false;
		}
	}

	// ✅ General token validation
	public boolean validateToken(String token) {
		try {
			verifyToken(token); // This will throw exception if invalid
			return !isTokenExpired(token);
		} catch (Exception e) {
			log.error("❌ Token validation failed: {}", e.getMessage());
			return false;
		}
	}

	// ✅ Extract any claim from token
	public String extractClaim(String token, String claimName) {
		try {
			DecodedJWT decodedJWT = verifyToken(token);
			Claim claim = decodedJWT.getClaim(claimName);
			return claim.isNull() ? null : claim.asString();
		} catch (Exception e) {
			log.error("❌ Error extracting claim '{}' from token: {}", claimName, e.getMessage());
			return null;
		}
	}

	// ✅ Extract list claim from token
	public List<String> extractListClaim(String token, String claimName) {
		try {
			DecodedJWT decodedJWT = verifyToken(token);
			Claim claim = decodedJWT.getClaim(claimName);
			return claim.isNull() ? null : claim.asList(String.class);
		} catch (Exception e) {
			log.error("❌ Error extracting list claim '{}' from token: {}", claimName, e.getMessage());
			return null;
		}
	}

	// ✅ Get expiration time in milliseconds
	public long getExpirationTime() {
		return expirationMs;
	}

	// ✅ Check if token expires soon (within 5 minutes)
	public boolean isTokenExpiringSoon(String token) {
		try {
			Date expiration = extractExpiration(token);
			if (expiration == null) return true;

			long fiveMinutesFromNow = System.currentTimeMillis() + (5 * 60 * 1000);
			return expiration.getTime() < fiveMinutesFromNow;
		} catch (Exception e) {
			log.error("❌ Error checking if token expires soon: {}", e.getMessage());
			return true;
		}
	}

	// ✅ Debug method (remove in production)
	public void debugToken(String token) {
		try {
			DecodedJWT decodedJWT = verifyToken(token);
			log.info("🔍 JWT Token Debug:");
			log.info("  - Subject: {}", decodedJWT.getSubject());
			log.info("  - Issuer: {}", decodedJWT.getIssuer());
			log.info("  - Email: {}", extractClaim(token, "email"));
			log.info("  - UserType: {}", extractClaim(token, "userType"));
			log.info("  - Roles: {}", extractListClaim(token, "roles"));
			log.info("  - Issued At: {}", decodedJWT.getIssuedAt());
			log.info("  - Expires At: {}", decodedJWT.getExpiresAt());
			log.info("  - Is Expired: {}", isTokenExpired(token));
		} catch (Exception e) {
			log.error("❌ Error debugging token: {}", e.getMessage());
		}
	}
}

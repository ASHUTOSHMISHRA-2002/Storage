//package com.ofds.authservice.service;
//
//import java.util.HashMap;
//import java.util.Map;
//
//import org.springframework.http.HttpStatus;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.stereotype.Service;
//import org.springframework.web.server.ResponseStatusException;
//
//import com.ofds.authservice.client.CustomerServiceClient;
//import com.ofds.authservice.client.RestaurantServiceClient;
//import com.ofds.authservice.dto.LoginRequest;
//import com.ofds.authservice.dto.LoginResponse;
//import com.ofds.authservice.dto.UserAuthDetailsDTO;
//
//import lombok.RequiredArgsConstructor;
//import lombok.extern.slf4j.Slf4j;
//
//@Service
//@RequiredArgsConstructor
//@Slf4j
//public class AuthService {
//
//	private final CustomerServiceClient customerServiceClient;
//	private final RestaurantServiceClient restaurantServiceClient;
//    private final JwtService jwtService;
//    private final PasswordEncoder passwordEncoder;
//
//    public LoginResponse authenticateUser(LoginRequest loginRequest) {
//        log.info("Attempting to authenticate user: {}", loginRequest.getEmail());
//
//        UserAuthDetailsDTO userDetails;
//        try {
//            userDetails = customerServiceClient.getUserByUsername(loginRequest.getEmail());
//            log.debug("User details fetched for {}: {}", loginRequest.getEmail(), userDetails != null ? userDetails.getUsername() : "null");
//
//            if (userDetails == null || userDetails.getHashedPassword() == null) {
//                log.warn("User not found or password not set for: {}", loginRequest.getEmail());
//                throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid Credentials");
//            }
//
//            if (!passwordEncoder.matches(loginRequest.getPassword(), userDetails.getHashedPassword())) {
//                log.warn("Password mismatch for user: {}", loginRequest.getEmail());
//                throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid Credentials");
//            }
//
//            Map<String, Object> claims = new HashMap<>();
//            claims.put("userId", userDetails.getId());
//            claims.put("username", userDetails.getUsername());
//            claims.put("email", userDetails.getEmail());
//            claims.put("roles", userDetails.getRoles());
//
//            String jwtToken = jwtService.generateToken(userDetails.getUsername(), claims);
//            log.info("Authentication successful for user: {}", userDetails.getUsername());
//
//            return new LoginResponse(jwtToken, "Login successful");
//
//        } catch (feign.FeignException.NotFound e) {
//            log.warn("User {} not found in Customer Service during authentication.", loginRequest.getEmail());
//            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid Credentials", e);
//        } catch (Exception e) {
//            log.error("Authentication failed for {}: {}", loginRequest.getEmail(), e.getMessage(), e);
//            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Authentication failed unexpectedly", e);
//        }
//    }
//
//    public LoginResponse authenticateRestaurant(LoginRequest loginRequest) {
//        log.info("Attempting to authenticate user: {}", loginRequest.getEmail());
//
//        UserAuthDetailsDTO userDetails;
//        try {
//
//            userDetails = restaurantServiceClient.getUserByUsername(loginRequest.getEmail());
//            log.debug("User details fetched for {}: {}", loginRequest.getEmail(), userDetails != null ? userDetails.getUsername() : "null");
//
//            if (userDetails == null || userDetails.getHashedPassword() == null) {
//                log.warn("User not found or password not set for: {}", loginRequest.getEmail());
//                throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid Credentials");
//            }
//
//            if (!passwordEncoder.matches(loginRequest.getPassword(), userDetails.getHashedPassword())) {
//                log.warn("Password mismatch for user: {}", loginRequest.getEmail());
//                throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid Credentials");
//            }
//
//            Map<String, Object> claims = new HashMap<>();
//            claims.put("userId", userDetails.getId());
//            claims.put("username", userDetails.getUsername());
//            claims.put("email", userDetails.getEmail());
//            claims.put("roles", userDetails.getRoles());
//
//            String jwtToken = jwtService.generateToken(userDetails.getUsername(), claims);
//            log.info("Authentication successful for user: {}", userDetails.getUsername());
//
//            return new LoginResponse(jwtToken, "Login successful");
//
//        } catch (feign.FeignException.NotFound e) {
//            log.warn("User {} not found in Customer Service during authentication.", loginRequest.getEmail());
//            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid Credentials", e);
//        } catch (Exception e) {
//            log.error("Authentication failed for {}: {}", loginRequest.getEmail(), e.getMessage(), e);
//            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Authentication failed unexpectedly", e);
//        }
//    }
//}


package com.ofds.authservice.service;

import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.Arrays;

import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.ofds.authservice.client.CustomerServiceClient;
import com.ofds.authservice.client.RestaurantServiceClient;
import com.ofds.authservice.dto.LoginRequest;
import com.ofds.authservice.dto.LoginResponse;
import com.ofds.authservice.dto.UserAuthDetailsDTO;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuthService {

    private final CustomerServiceClient customerServiceClient;
    private final RestaurantServiceClient restaurantServiceClient;
    private final JwtService jwtService;
    private final PasswordEncoder passwordEncoder;

    public LoginResponse authenticateUser(LoginRequest loginRequest) {
        log.info("🔐 Attempting to authenticate CUSTOMER: {}", loginRequest.getEmail());

        UserAuthDetailsDTO userDetails;
        try {
            // ✅ FIXED: Add null check and better error handling
            userDetails = customerServiceClient.getUserByUsername(loginRequest.getEmail());
            log.debug("✅ Customer details fetched for {}: {}", loginRequest.getEmail(),
                    userDetails != null ? userDetails.getUsername() : "null");

            if (userDetails == null) {
                log.warn("❌ Customer not found for: {}", loginRequest.getEmail());
                throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid email or password");
            }

            if (userDetails.getHashedPassword() == null || userDetails.getHashedPassword().trim().isEmpty()) {
                log.warn("❌ Password not set for customer: {}", loginRequest.getEmail());
                throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid email or password");
            }

            // ✅ FIXED: Better password validation
            if (!passwordEncoder.matches(loginRequest.getPassword(), userDetails.getHashedPassword())) {
                log.warn("❌ Password mismatch for customer: {}", loginRequest.getEmail());
                throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid email or password");
            }

            // ✅ FIXED: Enhanced JWT claims with proper user type
            Map<String, Object> claims = new HashMap<>();
            claims.put("userId", userDetails.getId());
            claims.put("username", userDetails.getUsername());
            claims.put("email", userDetails.getEmail());
            claims.put("userType", "CUSTOMER"); // ✅ Add user type
            claims.put("roles", userDetails.getRoles() != null ? userDetails.getRoles() : Arrays.asList("CUSTOMER"));

            String jwtToken = jwtService.generateToken(userDetails.getEmail(), claims); // ✅ Use email as subject
            log.info("✅ Customer authentication successful: {} (ID: {})", userDetails.getUsername(), userDetails.getId());

            return new LoginResponse(jwtToken, "Customer login successful");

        } catch (feign.FeignException.NotFound e) {
            log.warn("❌ Customer {} not found in Customer Service during authentication", loginRequest.getEmail());
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid email or password", e);
        } catch (feign.FeignException.ServiceUnavailable e) {
            log.error("❌ Customer Service unavailable during authentication for {}", loginRequest.getEmail());
            throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE, "Service temporarily unavailable", e);
        } catch (feign.FeignException e) {
            log.error("❌ Feign error during customer authentication for {}: Status {}, Message: {}",
                    loginRequest.getEmail(), e.status(), e.getMessage());
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Authentication service error", e);
        } catch (ResponseStatusException e) {
            // ✅ Re-throw ResponseStatusException as-is
            throw e;
        } catch (Exception e) {
            log.error("❌ Unexpected error during customer authentication for {}: {}", loginRequest.getEmail(), e.getMessage(), e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Authentication failed unexpectedly", e);
        }
    }

    public LoginResponse authenticateRestaurant(LoginRequest loginRequest) {
        log.info("🔐 Attempting to authenticate RESTAURANT: {}", loginRequest.getEmail());

        UserAuthDetailsDTO userDetails;
        try {
            // ✅ FIXED: Better error handling for restaurant service call
            userDetails = restaurantServiceClient.getUserByUsername(loginRequest.getEmail());
            log.debug("✅ Restaurant details fetched for {}: {}", loginRequest.getEmail(),
                    userDetails != null ? userDetails.getUsername() : "null");

            if (userDetails == null) {
                log.warn("❌ Restaurant not found for: {}", loginRequest.getEmail());
                throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid email or password");
            }

            if (userDetails.getHashedPassword() == null || userDetails.getHashedPassword().trim().isEmpty()) {
                log.warn("❌ Password not set for restaurant: {}", loginRequest.getEmail());
                throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid email or password");
            }

            // ✅ FIXED: Better password validation with logging
            log.debug("🔍 Validating password for restaurant: {}", loginRequest.getEmail());
            if (!passwordEncoder.matches(loginRequest.getPassword(), userDetails.getHashedPassword())) {
                log.warn("❌ Password mismatch for restaurant: {}", loginRequest.getEmail());
                throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid email or password");
            }

            // ✅ FIXED: Enhanced JWT claims with proper user type
            Map<String, Object> claims = new HashMap<>();
            claims.put("userId", userDetails.getId());
            claims.put("restaurantId", userDetails.getId()); // ✅ Add restaurant ID specifically
            claims.put("username", userDetails.getUsername());
            claims.put("email", userDetails.getEmail());
            claims.put("userType", "RESTAURANT"); // ✅ Add user type
            claims.put("roles", userDetails.getRoles() != null ? userDetails.getRoles() : Arrays.asList("RESTAURANT"));

            String jwtToken = jwtService.generateToken(userDetails.getEmail(), claims); // ✅ Use email as subject
            log.info("✅ Restaurant authentication successful: {} (ID: {})", userDetails.getUsername(), userDetails.getId());

            return new LoginResponse(jwtToken, "Restaurant login successful");

        } catch (feign.FeignException.NotFound e) {
            log.warn("❌ Restaurant {} not found in Restaurant Service during authentication", loginRequest.getEmail());
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid email or password", e);
        } catch (feign.FeignException.ServiceUnavailable e) {
            log.error("❌ Restaurant Service unavailable during authentication for {}", loginRequest.getEmail());
            throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE, "Service temporarily unavailable", e);
        } catch (feign.FeignException e) {
            log.error("❌ Feign error during restaurant authentication for {}: Status {}, Message: {}",
                    loginRequest.getEmail(), e.status(), e.getMessage());
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Authentication service error", e);
        } catch (ResponseStatusException e) {
            // ✅ Re-throw ResponseStatusException as-is
            throw e;
        } catch (Exception e) {
            log.error("❌ Unexpected error during restaurant authentication for {}: {}", loginRequest.getEmail(), e.getMessage(), e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Authentication failed unexpectedly", e);
        }
    }

    // ✅ NEW: Helper method to validate password strength (optional)
    private boolean isPasswordStrong(String password) {
        return password != null && password.length() >= 5; // Matches your frontend validation
    }

    // ✅ NEW: Helper method for debugging (remove in production)
    public void debugAuthService() {
        log.info("🔍 AuthService Debug Info:");
        log.info("  - Password Encoder: {}", passwordEncoder.getClass().getSimpleName());
        log.info("  - JWT Service: {}", jwtService.getClass().getSimpleName());
        log.info("  - Customer Client: {}", customerServiceClient.getClass().getSimpleName());
        log.info("  - Restaurant Client: {}", restaurantServiceClient.getClass().getSimpleName());
    }
}

////
////
////package com.example.payment.exception;
////
////import lombok.extern.slf4j.Slf4j; // Provides the 'log' object for logging
////import org.springframework.http.HttpStatus;
////import org.springframework.http.ResponseEntity;
////import org.springframework.web.bind.annotation.ExceptionHandler;
////import org.springframework.web.bind.annotation.RestControllerAdvice;
////
/////**
//// * Global exception handler for the payment service.
//// * This class uses Spring's {@code @RestControllerAdvice} to provide
//// * centralized exception handling across all controllers in the application,
//// * mapping specific exceptions to appropriate HTTP status codes and responses.
//// */
////@RestControllerAdvice // Combines @ControllerAdvice and @ResponseBody
////@Slf4j // Enables logging for this class
////public class GlobalExceptionHandler {
////
////    /**
////     * Handles {@link ResourceNotFoundException} and returns an HTTP 404 Not Found status.
////     * This is typically used when a requested resource (like a payment by ID) does not exist.
////     *
////     * @param e The ResourceNotFoundException instance.
////     * @return A ResponseEntity with HttpStatus.NOT_FOUND and the exception message.
////     */
////    @ExceptionHandler(ResourceNotFoundException.class)
////    public ResponseEntity<String> handleNotFound(ResourceNotFoundException e) {
////        // Log the exception at WARN level, as it's an expected business-level error.
////        log.warn("ResourceNotFoundException caught: {}", e.getMessage());
////        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
////    }
////
////    /**
////     * Handles {@link DuplicateTransactionException} and returns an HTTP 409 Conflict status.
////     * This is typically used when an operation conflicts with the current state of a resource,
////     * for example, trying to initiate a payment that already exists or confirm an already confirmed transaction.
////     *
////     * @param e The DuplicateTransactionException instance.
////     * @return A ResponseEntity with HttpStatus.CONFLICT and the exception message.
////     */
////    @ExceptionHandler(DuplicateTransactionException.class)
////    public ResponseEntity<String> handleDuplicate(DuplicateTransactionException e) {
////        // Log the exception at WARN level, as it's an expected business-level error.
////        log.warn("DuplicateTransactionException caught: {}", e.getMessage());
////        return ResponseEntity.status(HttpStatus.CONFLICT).body(e.getMessage());
////    }
////
////    /**
////     * Catches any other uncaught {@link Exception} and returns an HTTP 400 Bad Request status.
////     * This acts as a fallback for general unhandled exceptions, providing a consistent error response.
////     * It's important to log these at ERROR level as they indicate an unexpected issue.
////     *
////     * @param e The Exception instance.
////     * @return A ResponseEntity with HttpStatus.BAD_REQUEST and the exception message.
////     */
////    @ExceptionHandler(Exception.class)
////    public ResponseEntity<String> handleGeneral(Exception e) {
////        // Log the generic exception at ERROR level with stack trace for detailed debugging.
////        log.error("Unhandled exception occurred: {}", e.getMessage(), e);
////        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
////    }
////}
//package com.example.payment.exception;
//
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.ExceptionHandler;
//import org.springframework.web.bind.annotation.RestControllerAdvice;
//import org.springframework.web.bind.MethodArgumentNotValidException;
//import org.springframework.http.converter.HttpMessageNotReadableException;
//import jakarta.validation.ConstraintViolationException;
//
//@RestControllerAdvice
//@Slf4j
//public class GlobalExceptionHandler {
//
//    @ExceptionHandler(ResourceNotFoundException.class)
//    public ResponseEntity<String> handleNotFound(ResourceNotFoundException e) {
//        log.warn("ResourceNotFoundException caught: {}", e.getMessage());
//        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
//    }
//
//    @ExceptionHandler(DuplicateTransactionException.class)
//    public ResponseEntity<String> handleDuplicate(DuplicateTransactionException e) {
//        log.warn("DuplicateTransactionException caught: {}", e.getMessage());
//        return ResponseEntity.status(HttpStatus.CONFLICT).body(e.getMessage());
//    }
//
//    @ExceptionHandler(MethodArgumentNotValidException.class)
//    public ResponseEntity<String> handleValidationErrors(MethodArgumentNotValidException e) {
//        String errorMessage = e.getBindingResult().getFieldErrors().stream()
//            .map(error -> error.getField() + ": " + error.getDefaultMessage())
//            .findFirst()
//            .orElse("Invalid input");
//        log.warn("Validation error: {}", errorMessage);
//        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorMessage);
//    }
//
//    @ExceptionHandler(HttpMessageNotReadableException.class)
//    public ResponseEntity<String> handleInvalidFormat(HttpMessageNotReadableException e) {
//        log.warn("Invalid input format: {}", e.getMessage());
//        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid input format. Please check your request data.");
//    }
//
//    @ExceptionHandler(ConstraintViolationException.class)
//    public ResponseEntity<String> handleConstraintViolation(ConstraintViolationException e) {
//        log.warn("Constraint violation: {}", e.getMessage());
//        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Validation failed: " + e.getMessage());
//    }
//
//    @ExceptionHandler(InvalidInputFormatException.class)
//    public ResponseEntity<String> handleInvalidInputFormat(InvalidInputFormatException e) {
//        log.warn("InvalidInputFormatException caught: {}", e.getMessage());
//        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
//    }
//
//    @ExceptionHandler(Exception.class)
//    public ResponseEntity<String> handleGeneral(Exception e) {
//        log.error("Unhandled exception occurred: {}", e.getMessage(), e);
//        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
//    }
//}
//



// src/main/java/com/example/payment/exception/GlobalExceptionHandler.java
package com.example.payment.exception;

import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@ControllerAdvice
@Slf4j  // ✅ ADD: Logging capability
public class GlobalExceptionHandler {

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>> handleValidationExceptions(
            MethodArgumentNotValidException ex) {

        log.warn("🚨 Validation error occurred: {}", ex.getMessage());

        Map<String, String> fieldErrors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            fieldErrors.put(fieldName, errorMessage);
            log.warn("  ❌ Field '{}': {}", fieldName, errorMessage);
        });

        // ✅ ENHANCED: Structured error response
        Map<String, Object> errorResponse = new HashMap<>();
        errorResponse.put("timestamp", LocalDateTime.now().toString());
        errorResponse.put("status", HttpStatus.BAD_REQUEST.value());
        errorResponse.put("error", "Validation Failed");
        errorResponse.put("message", "Request validation failed");
        errorResponse.put("fieldErrors", fieldErrors);

        return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
    }

    // ✅ ADD: Handle JSON parsing errors specifically
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<Map<String, Object>> handleJsonParseException(HttpMessageNotReadableException ex) {
        log.error("🚨 JSON parsing error: {}", ex.getMessage());

        Map<String, Object> errorResponse = new HashMap<>();
        errorResponse.put("timestamp", LocalDateTime.now().toString());
        errorResponse.put("status", HttpStatus.BAD_REQUEST.value());
        errorResponse.put("error", "Invalid JSON");
        errorResponse.put("message", "Unable to parse request body. Please check JSON format.");

        // Check for specific JSON errors
        if (ex.getCause() instanceof InvalidFormatException) {
            InvalidFormatException formatEx = (InvalidFormatException) ex.getCause();
            errorResponse.put("details", "Invalid value for field: " + formatEx.getPath().get(0).getFieldName());
        }

        return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(DuplicateTransactionException.class)
    public ResponseEntity<Map<String, Object>> handleDuplicateTransaction(DuplicateTransactionException ex) {
        log.warn("🚨 Duplicate transaction: {}", ex.getMessage());

        Map<String, Object> errorResponse = new HashMap<>();
        errorResponse.put("timestamp", LocalDateTime.now().toString());
        errorResponse.put("status", HttpStatus.CONFLICT.value());
        errorResponse.put("error", "Duplicate Transaction");
        errorResponse.put("message", ex.getMessage());

        return new ResponseEntity<>(errorResponse, HttpStatus.CONFLICT);
    }

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleResourceNotFound(ResourceNotFoundException ex) {
        log.warn("🚨 Resource not found: {}", ex.getMessage());

        Map<String, Object> errorResponse = new HashMap<>();
        errorResponse.put("timestamp", LocalDateTime.now().toString());
        errorResponse.put("status", HttpStatus.NOT_FOUND.value());
        errorResponse.put("error", "Resource Not Found");
        errorResponse.put("message", ex.getMessage());

        return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(InvalidInputFormatException.class)
    public ResponseEntity<Map<String, Object>> handleInvalidInput(InvalidInputFormatException ex) {
        log.warn("🚨 Invalid input format: {}", ex.getMessage());

        Map<String, Object> errorResponse = new HashMap<>();
        errorResponse.put("timestamp", LocalDateTime.now().toString());
        errorResponse.put("status", HttpStatus.BAD_REQUEST.value());
        errorResponse.put("error", "Invalid Input");
        errorResponse.put("message", ex.getMessage());

        return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> handleGenericException(Exception ex) {
        log.error("🚨 Unexpected error occurred: {}", ex.getMessage(), ex);

        Map<String, Object> errorResponse = new HashMap<>();
        errorResponse.put("timestamp", LocalDateTime.now().toString());
        errorResponse.put("status", HttpStatus.INTERNAL_SERVER_ERROR.value());
        errorResponse.put("error", "Internal Server Error");
        errorResponse.put("message", "An unexpected error occurred. Please try again later.");

        // In development, include stack trace details
        if (isDebugMode()) {
            errorResponse.put("details", ex.getMessage());
        }

        return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    // ✅ ADD: Helper method to check debug mode
    private boolean isDebugMode() {
        // You can check system property or application property
        return "true".equals(System.getProperty("debug.mode")) ||
                "development".equals(System.getProperty("spring.profiles.active"));
    }
}

//
//
//package com.example.payment.model;
//
//public enum PaymentMethod {
//	Card,Cash,Online
//
//}
//
//


package com.example.payment.model;

public enum PaymentMethod {
	Card,
	Cash,
	Online,
	UPI,        // ✅ ADD: For UPI payments (Google Pay, PhonePe, etc.)
	COD,        // ✅ ADD: For Cash on Delivery
	NET_BANKING, // ✅ ADD: For Net Banking
	WALLET      // ✅ ADD: For Digital Wallets (Paytm, etc.)
}

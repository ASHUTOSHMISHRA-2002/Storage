//package com.example.payment.dto;
//
//import java.math.BigDecimal;
//
//import com.example.payment.model.PaymentMethod;
//import lombok.Data;
//
//@Data
//public class PaymentResponseDTO {
//    private Long paymentId;
//    private Long orderId;
//    private PaymentMethod paymentMethod;
//    private BigDecimal paymentAmount;
//    private String paymentStatus;
//
//
//
//	public Object getTransactionId() {
//
//		return orderId;
//	}
//
//
//}


package com.example.payment.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import com.example.payment.model.PaymentMethod;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PaymentResponseDTO {
    private Long paymentId;
    private Long orderId;
    private PaymentMethod paymentMethod;
    private BigDecimal paymentAmount;
    private String paymentStatus;

    // ✅ ADD: Proper transaction ID field
    private String transactionId;

    // ✅ ADD: Additional useful fields for frontend
    private String createdBy;
    private LocalDateTime createdOn;
    private LocalDateTime updatedOn;

    // ✅ ADD: Customer details (if needed for response)
    private CustomerDetails customerDetails;

    // ✅ ADD: Payment processing details
    private String currency = "INR";
    private String notes;
    private String paymentGatewayResponse;

    // ✅ REMOVE: The problematic getTransactionId() method
    // Now transactionId is a proper field with getter/setter from @Data
}

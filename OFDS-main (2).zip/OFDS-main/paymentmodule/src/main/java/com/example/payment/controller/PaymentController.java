//
//
//package com.example.payment.controller;
//
//import com.example.payment.dto.PaymentRequestDTO;
//import com.example.payment.dto.PaymentResponseDTO;
//import com.example.payment.exception.DuplicateTransactionException;
//import com.example.payment.exception.ResourceNotFoundException;
//import com.example.payment.service.PaymentService;
//import jakarta.validation.Valid;
//import lombok.extern.slf4j.Slf4j; // Provides the 'log' object
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
///**
// * REST Controller for managing payment operations (initiation, confirmation, retrieval, deletion).
// */
//@RestController
//@RequestMapping("/api/payments")
//@Slf4j // Enables logging for this class
//public class PaymentController {
//
//    private final PaymentService paymentService;
//
//    /**
//     * Constructs the PaymentController, injecting PaymentService.
//     */
//    public PaymentController(PaymentService paymentService) {
//        this.paymentService = paymentService;
//        log.info("PaymentController initialized."); // Logs controller startup
//    }
//
//    /**
//     * **POST /api/payments/initiate**
//     * Initiates a new payment transaction.
//     * @param requestDTO Payment initiation details.
//     * @return PaymentResponseDTO with transaction status.
//     */
//    @PostMapping("/initiate")
//    public ResponseEntity<PaymentResponseDTO> initiatePayment(@Valid @RequestBody PaymentRequestDTO requestDTO) {
//        log.info("Initiating payment for order ID: {}", requestDTO.getOrderId()); // Log request start
//        try {
//            PaymentResponseDTO responseDTO = paymentService.initiatePayment(requestDTO);
//            log.info("Payment initiated, transaction ID: {}", responseDTO.getTransactionId()); // Log success
//            return ResponseEntity.ok(responseDTO);
//        } catch (Exception e) {
//            log.error("Failed to initiate payment for order ID {}: {}", requestDTO.getOrderId(), e.getMessage(), e); // Log errors with stack trace
//            throw e;
//        }
//    }
//
//    /**
//     * **POST /api/payments/confirm**
//     * Confirms a previously initiated payment.
//     * @param requestDTO Payment confirmation details.
//     * @return Success message.
//     * @throws DuplicateTransactionException if already confirmed.
//     * @throws ResourceNotFoundException if payment not found.
//     */
//    @PostMapping("/confirm")
//    public ResponseEntity<String> confirmPayment(@Valid @RequestBody PaymentRequestDTO requestDTO)
//            throws DuplicateTransactionException, ResourceNotFoundException {
//        log.info("Confirming payment for order ID: {}", requestDTO.getOrderId()); // Log request start
//        try {
//            paymentService.confirmPayment(requestDTO);
//            log.info("Payment confirmed for order ID: {}", requestDTO.getOrderId()); // Log success
//            return ResponseEntity.ok("Payment confirmed successfully.");
//        } catch (DuplicateTransactionException e) {
//            log.warn("Duplicate confirmation for order ID {}: {}", requestDTO.getOrderId(), e.getMessage()); // Log warnings
//            throw e;
//        } catch (ResourceNotFoundException e) {
//            log.warn("Payment not found for confirmation, order ID {}: {}", requestDTO.getOrderId(), e.getMessage()); // Log warnings
//            throw e;
//        } catch (Exception e) {
//            log.error("Error confirming payment for order ID {}: {}", requestDTO.getOrderId(), e.getMessage(), e); // Log errors
//            throw e;
//        }
//    }
//
//    /**
//     * **GET /api/payments/order/{orderId}**
//     * Retrieves payment details by order ID.
//     * @param orderId The ID of the order.
//     * @return PaymentResponseDTO with details.
//     * @throws ResourceNotFoundException if payment not found.
//     */
//    @GetMapping("/order/{orderId}")
//    public ResponseEntity<PaymentResponseDTO> getPaymentDetails(@PathVariable Long orderId)
//            throws ResourceNotFoundException {
//        log.info("Fetching payment details for order ID: {}", orderId); // Log request start
//        try {
//            PaymentResponseDTO responseDTO = paymentService.getPaymentDetails(orderId);
//            log.info("Payment details found for order ID: {}", orderId); // Log success
//            return ResponseEntity.ok(responseDTO);
//        } catch (ResourceNotFoundException e) {
//            log.warn("Payment details not found for order ID {}: {}", orderId, e.getMessage()); // Log warnings
//            throw e;
//        } catch (Exception e) {
//            log.error("Error fetching payment details for order ID {}: {}", orderId, e.getMessage(), e); // Log errors
//            throw e;
//        }
//    }
//
//    /**
//     * **DELETE /api/payments/order/{orderId}**
//     * Deletes a payment record by order ID.
//     * @param orderId The ID of the order.
//     * @return Success message.
//     */
//    @DeleteMapping("/order/{orderId}")
//    public ResponseEntity<String> deletePayment(@PathVariable Long orderId) {
//        log.info("Deleting payment for order ID: {}", orderId); // Log request start
//        try {
//            paymentService.deletePaymentByOrderId(orderId);
//            log.info("Payment record deleted for order ID: {}", orderId); // Log success
//            return ResponseEntity.ok("OrderId :" + orderId + " deleted successfully.");
//        } catch (ResourceNotFoundException e) {
//            log.warn("Attempted to delete non-existent payment for order ID {}: {}", orderId, e.getMessage()); // Log warnings
//            throw e;
//        } catch (Exception e) {
//            log.error("Error deleting payment for order ID {}: {}", orderId, e.getMessage(), e); // Log errors
//            throw e;
//        }
//    }
//}

//package com.example.payment.controller;
//
//import com.example.payment.dto.PaymentRequestDTO;
//import com.example.payment.dto.PaymentResponseDTO;
//import com.example.payment.dto.PaymentConfirmDTO;
//import com.example.payment.exception.DuplicateTransactionException;
//import com.example.payment.exception.ResourceNotFoundException;
//import com.example.payment.exception.InvalidInputFormatException;
//import com.example.payment.service.PaymentService;
//import jakarta.validation.Valid;
//import lombok.extern.slf4j.Slf4j;
//
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//@RestController
//@RequestMapping("/api/payments")
//@Slf4j
//public class PaymentController {
//
//    private final PaymentService paymentService;
//
//    public PaymentController(PaymentService paymentService) {
//        this.paymentService = paymentService;
//        log.info("PaymentController initialized.");
//    }
//
//    @PostMapping("/initiate")
//    public ResponseEntity<?> initiatePayment(@Valid @RequestBody PaymentRequestDTO requestDTO) {
//        log.info("🔍 Initiating payment for order ID: {}", requestDTO.getOrderId());
//        log.info("  Payment method: {}", requestDTO.getPaymentMethod());
//        log.info("  Payment amount: {}", requestDTO.getPaymentAmount());
//        log.info("  Created by: {}", requestDTO.getCreatedBy());
//        log.info("  Customer details: {}", requestDTO.getCustomerDetails());
//        log.info("  Notes: {}", requestDTO.getNotes());
//        log.info("  Currency: {}", requestDTO.getCurrency());
//
//        try {
//            PaymentResponseDTO responseDTO = paymentService.initiatePayment(requestDTO);
//            log.info("✅ Payment initiated, transaction ID: {}", responseDTO.getTransactionId());
//            return ResponseEntity.ok(responseDTO);
//        } catch (DuplicateTransactionException e) {
//            log.error("❌ Duplicate transaction for order ID {}: {}", requestDTO.getOrderId(), e.getMessage());
//            return ResponseEntity.status(HttpStatus.CONFLICT).body(e.getMessage());
//        } catch (InvalidInputFormatException e) {
//            log.error("❌ Invalid input format for order ID {}: {}", requestDTO.getOrderId(), e.getMessage());
//            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
//        } catch (Exception e) {
//            log.error("❌ Failed to initiate payment for order ID {}: {}", requestDTO.getOrderId(), e.getMessage(), e);
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                    .body("Failed to initiate payment: " + e.getMessage());
//        }
//    }
//
//    @PutMapping("/confirm")
//    public ResponseEntity<?> confirmPayment(@Valid @RequestBody PaymentRequestDTO requestDTO,
//                                            @RequestHeader(value = "X-Internal-User-Roles", required = false) String roles) {
//
//        if (roles == null || !roles.contains("CUSTOMER")) {
//            log.warn("⚠️ Access denied for payment confirmation. Roles: {}", roles);
//            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Access denied");
//        }
//
//        log.info("🔄 Confirming payment for order ID: {}", requestDTO.getOrderId());
//        try {
//            paymentService.confirmPayment(requestDTO);
//            log.info("✅ Payment confirmed for order ID: {}", requestDTO.getOrderId());
//            return ResponseEntity.ok("Payment confirmed successfully.");
//        } catch (DuplicateTransactionException e) {
//            log.warn("⚠️ Duplicate confirmation for order ID {}: {}", requestDTO.getOrderId(), e.getMessage());
//            return ResponseEntity.status(HttpStatus.CONFLICT).body(e.getMessage());
//        } catch (ResourceNotFoundException e) {
//            log.warn("⚠️ Payment not found for confirmation, order ID {}: {}", requestDTO.getOrderId(), e.getMessage());
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
//        } catch (InvalidInputFormatException e) {
//            log.error("❌ Invalid input format for order ID {}: {}", requestDTO.getOrderId(), e.getMessage());
//            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
//        } catch (Exception e) {
//            log.error("❌ Error confirming payment for order ID {}: {}", requestDTO.getOrderId(), e.getMessage(), e);
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                    .body("Failed to confirm payment: " + e.getMessage());
//        }
//    }
//
//    @GetMapping("/order/{orderId}")
//    public ResponseEntity<?> getPaymentDetails(@PathVariable Long orderId) {
//        log.info("🔍 Fetching payment details for order ID: {}", orderId);
//        try {
//            PaymentResponseDTO responseDTO = paymentService.getPaymentDetails(orderId);
//            log.info("✅ Payment details found for order ID: {}", orderId);
//            return ResponseEntity.ok(responseDTO);
//        } catch (ResourceNotFoundException e) {
//            log.warn("⚠️ Payment details not found for order ID {}: {}", orderId, e.getMessage());
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
//        } catch (Exception e) {
//            log.error("❌ Error fetching payment details for order ID {}: {}", orderId, e.getMessage(), e);
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                    .body("Failed to fetch payment details: " + e.getMessage());
//        }
//    }
//
//    @DeleteMapping("/order/{orderId}")
//    public ResponseEntity<?> deletePayment(@PathVariable Long orderId) {
//        log.info("🗑️ Deleting payment for order ID: {}", orderId);
//        try {
//            paymentService.deletePaymentByOrderId(orderId);
//            log.info("✅ Payment record deleted for order ID: {}", orderId);
//            return ResponseEntity.ok("OrderId: " + orderId + " deleted successfully.");
//        } catch (ResourceNotFoundException e) {
//            log.warn("⚠️ Attempted to delete non-existent payment for order ID {}: {}", orderId, e.getMessage());
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
//        } catch (Exception e) {
//            log.error("❌ Error deleting payment for order ID {}: {}", orderId, e.getMessage(), e);
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                    .body("Failed to delete payment: " + e.getMessage());
//        }
//    }
//}


package com.example.payment.controller;

import com.example.payment.dto.PaymentRequestDTO;
import com.example.payment.dto.PaymentResponseDTO;
import com.example.payment.dto.PaymentConfirmDTO;
import com.example.payment.exception.DuplicateTransactionException;
import com.example.payment.exception.ResourceNotFoundException;
import com.example.payment.exception.InvalidInputFormatException;
import com.example.payment.service.PaymentService;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.HashMap;

@RestController
@RequestMapping("/api/payments")
@Slf4j
public class PaymentController {

    private final PaymentService paymentService;
    private final ObjectMapper objectMapper;

    public PaymentController(PaymentService paymentService, ObjectMapper objectMapper) {
        this.paymentService = paymentService;
        this.objectMapper = objectMapper;
        log.info("PaymentController initialized.");
    }

    @PostMapping("/initiate")
    public ResponseEntity<?> initiatePayment(@Valid @RequestBody PaymentRequestDTO requestDTO,
                                             HttpServletRequest request) {

        // ✅ ENHANCED: Comprehensive request logging for debugging
        log.info("🔍 =================================");
        log.info("🔍 PAYMENT INITIATION REQUEST DEBUG");
        log.info("🔍 =================================");
        log.info("🔍 Request URL: {}", request.getRequestURL());
        log.info("🔍 Content-Type: {}", request.getContentType());
        log.info("🔍 Content-Length: {}", request.getContentLength());
        log.info("🔍 Remote Address: {}", request.getRemoteAddr());

        try {
            log.info("🔍 Parsed PaymentRequestDTO Details:");
            log.info("  📋 Order ID: {} (Type: {})",
                    requestDTO.getOrderId(),
                    requestDTO.getOrderId() != null ? requestDTO.getOrderId().getClass().getSimpleName() : "null");

            log.info("  💳 Payment Method: {} (Type: {})",
                    requestDTO.getPaymentMethod(),
                    requestDTO.getPaymentMethod() != null ? requestDTO.getPaymentMethod().getClass().getSimpleName() : "null");

            log.info("  💰 Payment Amount: {} (Type: {})",
                    requestDTO.getPaymentAmount(),
                    requestDTO.getPaymentAmount() != null ? requestDTO.getPaymentAmount().getClass().getSimpleName() : "null");

            log.info("  👤 Created By: {}", requestDTO.getCreatedBy());

            // ✅ ENHANCED: Detailed customer details logging
            if (requestDTO.getCustomerDetails() != null) {
                log.info("  👥 Customer Details Present:");
                log.info("    Name: {}", requestDTO.getCustomerDetails().getName());
                log.info("    Phone: {}", requestDTO.getCustomerDetails().getPhone());
                log.info("    Email: {}", requestDTO.getCustomerDetails().getEmail());
                log.info("    Address: {}", requestDTO.getCustomerDetails().getAddress());
                log.info("    City: {}", requestDTO.getCustomerDetails().getCity());
                log.info("    State: {}", requestDTO.getCustomerDetails().getState());
                log.info("    Pincode: {}", requestDTO.getCustomerDetails().getPincode());
            } else {
                log.warn("  ⚠️ Customer Details: NULL");
            }

            log.info("  📝 Notes: {}", requestDTO.getNotes());
            log.info("  💱 Currency: {}", requestDTO.getCurrency());

            // ✅ ENHANCED: Payment details logging with type information
            if (requestDTO.getPaymentDetails() != null) {
                log.info("  🔧 Payment Details Present (Type: {})",
                        requestDTO.getPaymentDetails().getClass().getSimpleName());
                try {
                    String paymentDetailsJson = objectMapper.writeValueAsString(requestDTO.getPaymentDetails());
                    log.info("  🔧 Payment Details JSON: {}", paymentDetailsJson);
                } catch (Exception e) {
                    log.error("  ❌ Error serializing payment details: {}", e.getMessage());
                }
            } else {
                log.info("  🔧 Payment Details: NULL");
            }

            log.info("  🔗 Return URL: {}", requestDTO.getReturnUrl());
            log.info("  ❌ Cancel URL: {}", requestDTO.getCancelUrl());
            log.info("  📄 Description: {}", requestDTO.getDescription());
            log.info("  🆔 Merchant Transaction ID: {}", requestDTO.getMerchantTransactionId());
            log.info("  📞 Callback URL: {}", requestDTO.getCallbackUrl());

            log.info("🔍 =================================");

            // ✅ ENHANCED: Validation before service call
            validatePaymentRequest(requestDTO);

            // Call payment service
            PaymentResponseDTO responseDTO = paymentService.initiatePayment(requestDTO);

            log.info("✅ =================================");
            log.info("✅ PAYMENT INITIATED SUCCESSFULLY");
            log.info("✅ =================================");
            log.info("✅ Payment ID: {}", responseDTO.getPaymentId());
            log.info("✅ Transaction ID: {}", responseDTO.getTransactionId());
            log.info("✅ Order ID: {}", responseDTO.getOrderId());
            log.info("✅ Payment Status: {}", responseDTO.getPaymentStatus());
            log.info("✅ Payment Amount: {}", responseDTO.getPaymentAmount());
            log.info("✅ =================================");

            return ResponseEntity.ok(responseDTO);

        } catch (DuplicateTransactionException e) {
            log.error("❌ Duplicate transaction for order ID {}: {}", requestDTO.getOrderId(), e.getMessage());
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body(createErrorResponse("DUPLICATE_TRANSACTION", e.getMessage(), requestDTO.getOrderId()));

        } catch (InvalidInputFormatException e) {
            log.error("❌ Invalid input format for order ID {}: {}", requestDTO.getOrderId(), e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(createErrorResponse("INVALID_INPUT_FORMAT", e.getMessage(), requestDTO.getOrderId()));

        } catch (IllegalArgumentException e) {
            log.error("❌ Invalid payment method or data for order ID {}: {}", requestDTO.getOrderId(), e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(createErrorResponse("INVALID_PAYMENT_DATA", e.getMessage(), requestDTO.getOrderId()));

        } catch (org.springframework.http.converter.HttpMessageNotReadableException e) {
            log.error("❌ JSON parsing error for order ID {}: {}", requestDTO.getOrderId(), e.getMessage());
            log.error("❌ Root cause: {}", e.getRootCause() != null ? e.getRootCause().getMessage() : "Unknown");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(createErrorResponse("JSON_PARSE_ERROR",
                            "Invalid JSON format in request. Please check your payment details structure.",
                            requestDTO.getOrderId()));

        } catch (jakarta.validation.ConstraintViolationException e) {
            log.error("❌ Validation error for order ID {}: {}", requestDTO.getOrderId(), e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(createErrorResponse("VALIDATION_ERROR",
                            "Request validation failed: " + e.getMessage(),
                            requestDTO.getOrderId()));

        } catch (Exception e) {
            log.error("❌ ================================");
            log.error("❌ UNEXPECTED PAYMENT ERROR");
            log.error("❌ ================================");
            log.error("❌ Order ID: {}", requestDTO.getOrderId());
            log.error("❌ Error Type: {}", e.getClass().getSimpleName());
            log.error("❌ Error Message: {}", e.getMessage());
            log.error("❌ Full Stack Trace:", e);
            log.error("❌ ================================");

            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(createErrorResponse("INTERNAL_SERVER_ERROR",
                            "Failed to initiate payment: " + e.getMessage(),
                            requestDTO.getOrderId()));
        }
    }

    // ✅ ADD: Validation method
    private void validatePaymentRequest(PaymentRequestDTO requestDTO) {
        log.info("🔍 Validating payment request...");

        if (requestDTO.getOrderId() == null || requestDTO.getOrderId() <= 0) {
            throw new InvalidInputFormatException("Order ID must be a positive number");
        }

        if (requestDTO.getPaymentMethod() == null) {
            throw new InvalidInputFormatException("Payment method is required");
        }

        if (requestDTO.getPaymentAmount() == null || requestDTO.getPaymentAmount().doubleValue() <= 0) {
            throw new InvalidInputFormatException("Payment amount must be greater than 0");
        }

        if (requestDTO.getCreatedBy() == null || requestDTO.getCreatedBy().trim().isEmpty()) {
            throw new InvalidInputFormatException("Created by field is required");
        }

        // Validate customer details if present
        if (requestDTO.getCustomerDetails() != null) {
            validateCustomerDetails(requestDTO.getCustomerDetails());
        }

        log.info("✅ Payment request validation passed");
    }

    // ✅ ADD: Customer details validation
    private void validateCustomerDetails(com.example.payment.dto.CustomerDetails customerDetails) {
        if (customerDetails.getName() == null || customerDetails.getName().trim().length() < 2) {
            throw new InvalidInputFormatException("Customer name must be at least 2 characters");
        }

        if (customerDetails.getPhone() == null || !customerDetails.getPhone().matches("^[6-9]\\d{9}$")) {
            throw new InvalidInputFormatException("Invalid phone number format. Must be 10 digits starting with 6-9");
        }

        if (customerDetails.getEmail() == null || !customerDetails.getEmail().contains("@")) {
            throw new InvalidInputFormatException("Invalid email format");
        }

        if (customerDetails.getAddress() == null || customerDetails.getAddress().trim().length() < 10) {
            throw new InvalidInputFormatException("Address must be at least 10 characters");
        }
    }

    // ✅ ENHANCED: Consistent error response format
    private Map<String, Object> createErrorResponse(String errorCode, String message, Long orderId) {
        Map<String, Object> errorResponse = new HashMap<>();
        errorResponse.put("success", false);
        errorResponse.put("errorCode", errorCode);
        errorResponse.put("message", message);
        errorResponse.put("orderId", orderId);
        errorResponse.put("timestamp", System.currentTimeMillis());
        errorResponse.put("path", "/api/payments/initiate");
        return errorResponse;
    }

    @PutMapping("/confirm")
    public ResponseEntity<?> confirmPayment(@Valid @RequestBody PaymentRequestDTO requestDTO,
                                            @RequestHeader(value = "X-Internal-User-Roles", required = false) String roles) {

        if (roles == null || !roles.contains("CUSTOMER")) {
            log.warn("⚠️ Access denied for payment confirmation. Roles: {}", roles);
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body(createErrorResponse("ACCESS_DENIED", "Access denied", requestDTO.getOrderId()));
        }

        log.info("🔄 =================================");
        log.info("🔄 PAYMENT CONFIRMATION REQUEST");
        log.info("🔄 =================================");
        log.info("🔄 Order ID: {}", requestDTO.getOrderId());
        log.info("🔄 Payment Method: {}", requestDTO.getPaymentMethod());
        log.info("🔄 Payment Amount: {}", requestDTO.getPaymentAmount());
        log.info("🔄 =================================");

        try {
            paymentService.confirmPayment(requestDTO);

            log.info("✅ =================================");
            log.info("✅ PAYMENT CONFIRMED SUCCESSFULLY");
            log.info("✅ Order ID: {}", requestDTO.getOrderId());
            log.info("✅ =================================");

            Map<String, Object> successResponse = new HashMap<>();
            successResponse.put("success", true);
            successResponse.put("message", "Payment confirmed successfully.");
            successResponse.put("orderId", requestDTO.getOrderId());
            successResponse.put("timestamp", System.currentTimeMillis());

            return ResponseEntity.ok(successResponse);

        } catch (DuplicateTransactionException e) {
            log.warn("⚠️ Duplicate confirmation for order ID {}: {}", requestDTO.getOrderId(), e.getMessage());
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body(createErrorResponse("DUPLICATE_CONFIRMATION", e.getMessage(), requestDTO.getOrderId()));

        } catch (ResourceNotFoundException e) {
            log.warn("⚠️ Payment not found for confirmation, order ID {}: {}", requestDTO.getOrderId(), e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(createErrorResponse("PAYMENT_NOT_FOUND", e.getMessage(), requestDTO.getOrderId()));

        } catch (InvalidInputFormatException e) {
            log.error("❌ Invalid input format for order ID {}: {}", requestDTO.getOrderId(), e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(createErrorResponse("INVALID_INPUT_FORMAT", e.getMessage(), requestDTO.getOrderId()));

        } catch (Exception e) {
            log.error("❌ Error confirming payment for order ID {}: {}", requestDTO.getOrderId(), e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(createErrorResponse("CONFIRMATION_FAILED",
                            "Failed to confirm payment: " + e.getMessage(),
                            requestDTO.getOrderId()));
        }
    }

    @GetMapping("/order/{orderId}")
    public ResponseEntity<?> getPaymentDetails(@PathVariable Long orderId) {
        log.info("🔍 Fetching payment details for order ID: {}", orderId);

        try {
            if (orderId == null || orderId <= 0) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(createErrorResponse("INVALID_ORDER_ID", "Order ID must be a positive number", orderId));
            }

            PaymentResponseDTO responseDTO = paymentService.getPaymentDetails(orderId);

            log.info("✅ Payment details found for order ID: {}", orderId);
            log.info("✅ Payment ID: {}", responseDTO.getPaymentId());
            log.info("✅ Payment Status: {}", responseDTO.getPaymentStatus());

            return ResponseEntity.ok(responseDTO);

        } catch (ResourceNotFoundException e) {
            log.warn("⚠️ Payment details not found for order ID {}: {}", orderId, e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(createErrorResponse("PAYMENT_NOT_FOUND", e.getMessage(), orderId));

        } catch (Exception e) {
            log.error("❌ Error fetching payment details for order ID {}: {}", orderId, e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(createErrorResponse("FETCH_ERROR",
                            "Failed to fetch payment details: " + e.getMessage(),
                            orderId));
        }
    }

    @DeleteMapping("/order/{orderId}")
    public ResponseEntity<?> deletePayment(@PathVariable Long orderId) {
        log.info("🗑️ Deleting payment for order ID: {}", orderId);

        try {
            if (orderId == null || orderId <= 0) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(createErrorResponse("INVALID_ORDER_ID", "Order ID must be a positive number", orderId));
            }

            paymentService.deletePaymentByOrderId(orderId);

            log.info("✅ Payment record deleted for order ID: {}", orderId);

            Map<String, Object> successResponse = new HashMap<>();
            successResponse.put("success", true);
            successResponse.put("message", "OrderId: " + orderId + " deleted successfully.");
            successResponse.put("orderId", orderId);
            successResponse.put("timestamp", System.currentTimeMillis());

            return ResponseEntity.ok(successResponse);

        } catch (ResourceNotFoundException e) {
            log.warn("⚠️ Attempted to delete non-existent payment for order ID {}: {}", orderId, e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(createErrorResponse("PAYMENT_NOT_FOUND", e.getMessage(), orderId));

        } catch (Exception e) {
            log.error("❌ Error deleting payment for order ID {}: {}", orderId, e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(createErrorResponse("DELETE_ERROR",
                            "Failed to delete payment: " + e.getMessage(),
                            orderId));
        }
    }

    // ✅ ADD: Health check endpoint
    @GetMapping("/health")
    public ResponseEntity<?> healthCheck() {
        Map<String, Object> health = new HashMap<>();
        health.put("status", "UP");
        health.put("service", "Payment Service");
        health.put("timestamp", System.currentTimeMillis());
        health.put("version", "1.0.0");

        log.info("✅ Health check requested - Service is UP");
        return ResponseEntity.ok(health);
    }

    // ✅ ADD: Debug endpoint (for development only)
    @GetMapping("/debug/order/{orderId}")
    public ResponseEntity<?> debugPayment(@PathVariable Long orderId) {
        log.info("🔍 Debug payment request for order ID: {}", orderId);

        try {
            Map<String, Object> debugInfo = new HashMap<>();
            debugInfo.put("orderId", orderId);
            debugInfo.put("timestamp", System.currentTimeMillis());
            debugInfo.put("endpoint", "/api/payments/debug/order/" + orderId);

            // Add any debug information you need
            debugInfo.put("message", "Debug endpoint is working");

            return ResponseEntity.ok(debugInfo);

        } catch (Exception e) {
            log.error("❌ Debug endpoint error: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(createErrorResponse("DEBUG_ERROR", e.getMessage(), orderId));
        }
    }
}

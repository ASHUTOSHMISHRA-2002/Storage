//package com.example.payment.dto;
//
//import lombok.Data;
//
//@Data
//public class PaymentConfirmDTO {
//
//    private Long orderId;
//    private String transactionId;
//    private String status;
//    private String updatedBy;
//}


package com.example.payment.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PaymentConfirmDTO {

    @NotNull(message = "Order ID is required")
    private Long orderId;

    @NotBlank(message = "Transaction ID is required")
    private String transactionId;

    @NotBlank(message = "Status is required")
    private String status;

    @NotBlank(message = "Updated by is required")
    private String updatedBy;

    // ✅ ADD: Additional confirmation details
    private String confirmationDetails;
    private String paymentMethod;
    private String gatewayResponse;
    private String notes;
}

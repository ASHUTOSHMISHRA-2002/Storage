//
//
//package com.example.payment.dto;
//
//import java.math.BigDecimal;
//
//import com.example.payment.model.PaymentMethod;
//import jakarta.validation.constraints.NotNull;
//import jakarta.validation.constraints.Positive;
//import jakarta.validation.constraints.NotBlank;
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//@Data
//@NoArgsConstructor
//@AllArgsConstructor
//public class PaymentRequestDTO {
//
//    @NotNull(message = "Order ID is required")
//    private Long orderId;
//
//    @NotNull(message = "Payment method is required")
//    private PaymentMethod paymentMethod;
//
//    @NotNull(message = "Payment amount is required")
//    @Positive(message = "Payment amount must be positive")
//    private BigDecimal paymentAmount;
//
//    @NotBlank(message = "Created by is required")
//    private String createdBy;
//}
//


// src/main/java/com/example/payment/dto/PaymentRequestDTO.java
//// src/main/java/com/example/payment/dto/PaymentRequestDTO.java
//package com.example.payment.dto;
//
//import java.math.BigDecimal;
//import com.example.payment.model.PaymentMethod;
//import jakarta.validation.Valid;
//import jakarta.validation.constraints.NotNull;
//import jakarta.validation.constraints.Positive;
//import jakarta.validation.constraints.NotBlank;
//import jakarta.validation.constraints.DecimalMin;
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//@Data
//@NoArgsConstructor
//@AllArgsConstructor
//public class PaymentRequestDTO {
//
//    @NotNull(message = "Order ID is required")
//    private Long orderId;
//
//    @NotNull(message = "Payment method is required")
//    private PaymentMethod paymentMethod;
//
//    @NotNull(message = "Payment amount is required")
//    @DecimalMin(value = "0.01", message = "Payment amount must be at least 0.01")
//    private BigDecimal paymentAmount;
//
//    @NotBlank(message = "Created by is required")
//    private String createdBy;
//
//    // ✅ ADD: Customer details field (this was missing and causing the error)
//    @Valid
//    private CustomerDetails customerDetails;
//
//    // ✅ ADD: Optional fields your frontend is sending
//    private String notes;
//    private String currency;
//    private Object paymentDetails; // Using Object to handle different payment method details
//
//    // ✅ ADD: Additional fields for complete payment processing
//    private String returnUrl;
//    private String cancelUrl;
//    private String description;
//    private String merchantTransactionId;
//    private String callbackUrl;
//}

// src/main/java/com/example/payment/dto/PaymentRequestDTO.java
package com.example.payment.dto;

import java.math.BigDecimal;
import com.example.payment.model.PaymentMethod;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode; // ✅ ADD: For flexible JSON handling
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.DecimalMin;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PaymentRequestDTO {

    @NotNull(message = "Order ID is required")
    @JsonProperty("orderId")
    private Long orderId;

    @NotNull(message = "Payment method is required")
    @JsonProperty("paymentMethod")
    private PaymentMethod paymentMethod;

    @NotNull(message = "Payment amount is required")
    @DecimalMin(value = "0.01", message = "Payment amount must be at least 0.01")
    @JsonProperty("paymentAmount")
    private BigDecimal paymentAmount;

    @NotBlank(message = "Created by is required")
    @JsonProperty("createdBy")
    private String createdBy;

    @Valid
    @JsonProperty("customerDetails")
    private CustomerDetails customerDetails;

    @JsonProperty("notes")
    private String notes;

    @JsonProperty("currency")
    private String currency;

    // ✅ FIXED: Change from Object/String to JsonNode for flexible handling
    @JsonProperty("paymentDetails")
    private JsonNode paymentDetails;

    @JsonProperty("returnUrl")
    private String returnUrl;

    @JsonProperty("cancelUrl")
    private String cancelUrl;

    @JsonProperty("description")
    private String description;

    @JsonProperty("merchantTransactionId")
    private String merchantTransactionId;

    @JsonProperty("callbackUrl")
    private String callbackUrl;
}

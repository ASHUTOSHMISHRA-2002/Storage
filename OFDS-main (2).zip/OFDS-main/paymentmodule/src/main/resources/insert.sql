INSERT INTO payment (order_id_order, payment_method, payment_amount, payment_status, created_by)
VALUES (1006, 'Online', 250.00, 'Pending', 'jaswanth')
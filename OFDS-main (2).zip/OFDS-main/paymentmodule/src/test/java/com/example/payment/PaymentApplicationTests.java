package com.example.payment;


import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes=PaymentModuleApplication.class)

class PaymentApplicationTests {
	@Test
	void contextLoads(){
}
}
 




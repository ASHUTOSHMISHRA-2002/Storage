//package com.example.Restaurant.config;
//
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.web.servlet.config.annotation.CorsRegistry;
//import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
//
//@Configuration
//public class CorsConfig {
//    @Bean
//    public WebMvcConfigurer corsConfigurer() {
//        return new WebMvcConfigurer() {
//            @Override
//            public void addCorsMappings(CorsRegistry registry) {
//                registry.addMapping("/**") // Apply to all endpoints
//                        .allowedOrigins("http://localhost:4200") // ✅ Allow frontend
//                        .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS") // ✅ Common REST methods
//                        .allowedHeaders("*") // ✅ Allow all headers
//                        .allowCredentials(true); // ✅ Required if frontend sends cookies/token
//            }
//        };
//    }
//}


//package com.example.Restaurant.config;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.web.servlet.config.annotation.CorsRegistry;
//import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
//
//@Configuration
//public class CorsConfig {
//
//    @Bean
//    public WebMvcConfigurer corsConfigurer() {
//        return new WebMvcConfigurer() {
//            @Override
//            public void addCorsMappings(CorsRegistry registry) {
//                registry.addMapping("/**") // Apply to all endpoints
//                        .allowedOrigins("http://localhost:4200") // ✅ Allow frontend
//                        .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH") // ✅ All REST methods
//                        .allowedHeaders(
//                                "Content-Type",
//                                "Authorization",
//                                "X-Requested-With",
//                                "Accept",
//                                "Origin",
//                                "Access-Control-Request-Method",
//                                "Access-Control-Request-Headers"
//                        ) // ✅ Specific headers that work with Angular
//                        .exposedHeaders(
//                                "Authorization",
//                                "Content-Type",
//                                "X-Total-Count"
//                        ) // ✅ Headers that Angular can read
//                        .allowCredentials(true) // ✅ Required for cookies/token
//                        .maxAge(3600); // ✅ Cache preflight response for 1 hour
//            }
//        };
//    }
//}


//// src/main/java/com/example/Restaurant/config/CorsConfig.java
//package com.example.Restaurant.config;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.web.servlet.config.annotation.CorsRegistry;
//import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
//
//@Configuration
//public class CorsConfig {
//    @Bean
//    public WebMvcConfigurer corsConfigurer() {
//        return new WebMvcConfigurer() {
//            @Override
//            public void addCorsMappings(CorsRegistry registry) {
//                registry.addMapping("/**")
//                        .allowedOrigins("http://localhost:4200", "http://127.0.0.1:4200")
//                        .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH")
//                        .allowedHeaders("*")
//                        .allowCredentials(true)
//                        .maxAge(3600);
//            }
//        };
//    }
//}


// Apply to all three services (auth, customer, restaurant)
package com.example.Restaurant.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class CorsConfig {
    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/**")
                        .allowedOrigins("http://localhost:4200", "http://127.0.0.1:4200")
                        .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH")
                        .allowedHeaders("*")
                        .allowCredentials(true)
                        .maxAge(3600);
            }
        };
    }
}

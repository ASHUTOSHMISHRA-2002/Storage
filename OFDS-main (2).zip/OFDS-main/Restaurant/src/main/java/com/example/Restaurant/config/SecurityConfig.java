//package com.example.Restaurant.config;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.http.SessionCreationPolicy;
//import org.springframework.security.web.SecurityFilterChain;
//import org.springframework.web.cors.CorsConfiguration;
//import org.springframework.web.cors.CorsConfigurationSource;
//import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
//
//import java.util.List;
//
//@Configuration
//@EnableMethodSecurity
//public class SecurityConfig {
//
//    @Bean
//    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
//        http
//                .csrf(csrf -> csrf.disable())
//                .cors(cors -> cors.configurationSource(corsConfigurationSource())) // ✅ Use our CORS settings
//                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
//                .authorizeHttpRequests(auth -> auth
//                        .requestMatchers(
//                                "/api/restaurants/register",
//                                "/api/restaurants/login",
//                                "/internal/users/**"
//                        ).permitAll()
//                        .anyRequest().authenticated()
//                );
//
//        return http.build();
//    }
//
//    @Bean
//    public CorsConfigurationSource corsConfigurationSource() {
//        CorsConfiguration config = new CorsConfiguration();
//
//        config.setAllowedOrigins(List.of("http://localhost:4200")); // ✅ Frontend origin
//        config.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS")); // ✅ REST methods
//        config.setAllowedHeaders(List.of( // ✅ Custom + standard headers
//                "Content-Type",
//                "Authorization",
//                "X-Internal-User-Id",
//                "X-Internal-User-Roles"
//        ));
//        config.setExposedHeaders(List.of( // Optional: expose headers to frontend
//                "Authorization",
//                "X-Internal-User-Id",
//                "X-Internal-User-Roles"
//        ));
//        config.setAllowCredentials(true); // ✅ Needed for cookies/token
//
//        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
//        source.registerCorsConfiguration("/**", config);
//        return source;
//    }
//}



//package com.example.Restaurant.config;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.http.SessionCreationPolicy;
//import org.springframework.security.web.SecurityFilterChain;
//import org.springframework.web.cors.CorsConfiguration;
//import org.springframework.web.cors.CorsConfigurationSource;
//import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
//
//import java.util.List;
//
//@Configuration
//@EnableMethodSecurity
//public class SecurityConfig {
//
//    @Bean
//    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
//        http
//                .csrf(csrf -> csrf.disable())
//                .cors(cors -> cors.configurationSource(corsConfigurationSource()))
//                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
//                .authorizeHttpRequests(auth -> auth
//                        // ✅ Make all restaurant and related endpoints public
//                        .requestMatchers(
//                                "/api/restaurants/**",      // All restaurant endpoints
//                                "/api/menu/**",            // All menu endpoints
//                                "/api/orders/**",          // All order endpoints
//                                "/api/auth/**",            // All auth endpoints
//                                "/internal/users/**",
//                                "/error",
//                                "/favicon.ico"
//                        ).permitAll()
//                        .anyRequest().authenticated()  // Other endpoints still require auth
//                );
//
//        return http.build();
//    }
//
//    @Bean
//    public CorsConfigurationSource corsConfigurationSource() {
//        CorsConfiguration config = new CorsConfiguration();
//
//        config.setAllowedOrigins(List.of("http://localhost:4200"));
//        config.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
//        config.setAllowedHeaders(List.of("*"));
//        config.setExposedHeaders(List.of("Authorization", "Content-Type"));
//        config.setAllowCredentials(true);
//        config.setMaxAge(3600L); // Cache preflight requests for 1 hour
//
//        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
//        source.registerCorsConfiguration("/**", config);
//        return source;
//    }
//}



// src/main/java/com/example/Restaurant/config/SecurityConfig.java
//package com.example.Restaurant.config;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.http.HttpMethod;
//import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//import org.springframework.security.config.http.SessionCreationPolicy;
//import org.springframework.security.web.SecurityFilterChain;
//import org.springframework.web.cors.CorsConfiguration;
//import org.springframework.web.cors.CorsConfigurationSource;
//import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
//
//import java.util.Arrays;
//
//@Configuration
//@EnableWebSecurity
//@EnableMethodSecurity(prePostEnabled = true)
//public class SecurityConfig {
//
//    @Bean
//    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
//        http
//                .csrf(csrf -> csrf.disable())
//                .cors(cors -> cors.configurationSource(corsConfigurationSource()))
//                .sessionManagement(session ->
//                        session.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
//                )
//                .authorizeHttpRequests(auth -> auth
//                        // 🔥 FIXED: Public restaurant listing for customers
//                        .requestMatchers(HttpMethod.GET, "/api/restaurants").permitAll()
//                        .requestMatchers(HttpMethod.GET, "/api/restaurants/**").permitAll()
//
//                        // Authentication endpoints
//                        .requestMatchers(HttpMethod.POST, "/api/restaurants/register").permitAll()
//                        .requestMatchers(HttpMethod.POST, "/api/restaurants/login").permitAll()
//                        .requestMatchers("/api/auth/**").permitAll()
//
//                        // Menu endpoints - public access for customers
//                        .requestMatchers(HttpMethod.GET, "/api/menu/**").permitAll()
//
//                        // Internal service communication
//                        .requestMatchers("/internal/**").permitAll()
//
//                        // Health check and static resources
//                        .requestMatchers("/error", "/favicon.ico", "/actuator/health").permitAll()
//
//                        // All other requests require authentication
//                        .anyRequest().authenticated()
//                )
//                .formLogin(form -> form.disable())
//                .httpBasic(basic -> basic.disable());
//
//        return http.build();
//    }
//
//    @Bean
//    public CorsConfigurationSource corsConfigurationSource() {
//        CorsConfiguration configuration = new CorsConfiguration();
//
//        configuration.setAllowedOriginPatterns(Arrays.asList(
//                "http://localhost:4200",
//                "http://127.0.0.1:4200",
//                "http://localhost:*"
//        ));
//
//        configuration.setAllowedMethods(Arrays.asList(
//                "GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH", "HEAD"
//        ));
//
//        configuration.setAllowedHeaders(Arrays.asList("*"));
//
//        configuration.setExposedHeaders(Arrays.asList(
//                "Authorization",
//                "Content-Type",
//                "X-Total-Count",
//                "Access-Control-Allow-Origin",
//                "Access-Control-Allow-Headers"
//        ));
//
//        configuration.setAllowCredentials(true);
//        configuration.setMaxAge(3600L);
//
//        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
//        source.registerCorsConfiguration("/**", configuration);
//        return source;
//    }
//}


//
//package com.example.Restaurant.config;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.http.HttpMethod;
//import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//import org.springframework.security.config.http.SessionCreationPolicy;
//import org.springframework.security.web.SecurityFilterChain;
//import org.springframework.web.cors.CorsConfiguration;
//import org.springframework.web.cors.CorsConfigurationSource;
//import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
//import lombok.extern.slf4j.Slf4j;
//
//import java.util.Arrays;
//
//@Configuration
//@EnableWebSecurity
//@EnableMethodSecurity(prePostEnabled = true)
//@Slf4j
//public class SecurityConfig {
//
//    @Bean
//    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
//        log.info("🔒 Configuring Restaurant Service Security...");
//
//        http
//                .csrf(csrf -> {
//                    csrf.disable();
//                    log.debug("CSRF protection disabled");
//                })
//                .cors(cors -> {
//                    cors.configurationSource(corsConfigurationSource());
//                    log.debug("CORS configuration applied");
//                })
//                .sessionManagement(session -> {
//                    session.sessionCreationPolicy(SessionCreationPolicy.STATELESS);
//                    log.debug("Stateless session management configured");
//                })
//                .authorizeHttpRequests(auth -> {
//                    auth
//                            // 🔥 PUBLIC ENDPOINTS - No authentication required
//                            .requestMatchers(HttpMethod.GET, "/api/restaurants").permitAll()
//                            .requestMatchers(HttpMethod.GET, "/api/restaurants/**").permitAll()
//                            .requestMatchers(HttpMethod.POST, "/api/restaurants/register").permitAll()
//                            .requestMatchers(HttpMethod.POST, "/api/restaurants/login").permitAll()
//
//                            // Health and debug endpoints
//                            .requestMatchers("/api/restaurants/health").permitAll()
//                            .requestMatchers("/api/restaurants/status").permitAll()
//                            .requestMatchers("/api/restaurants/debug/**").permitAll()
//
//                            // Auth service endpoints
//                            .requestMatchers("/api/auth/**").permitAll()
//
//                            // Menu endpoints - public access for customers
//                            .requestMatchers(HttpMethod.GET, "/api/menu/**").permitAll()
//
//                            // Internal service communication
//                            .requestMatchers("/internal/**").permitAll()
//
//                            // Static resources and error pages
//                            .requestMatchers("/error", "/favicon.ico", "/actuator/**").permitAll()
//
//                            // 🔥 PROTECTED ENDPOINTS - Authentication required
//                            .requestMatchers(HttpMethod.PUT, "/api/restaurants/**").authenticated()
//                            .requestMatchers(HttpMethod.DELETE, "/api/restaurants/**").authenticated()
//                            .requestMatchers(HttpMethod.PATCH, "/api/restaurants/**").authenticated()
//                            .requestMatchers("/api/restaurants/profile").authenticated()
//                            .requestMatchers("/api/restaurants/details").authenticated()
//
//                            // All other requests require authentication
//                            .anyRequest().authenticated();
//
//                    log.info("✅ Security rules configured:");
//                    log.info("   📖 Public: GET /api/restaurants, POST /api/restaurants/register, POST /api/restaurants/login");
//                    log.info("   🔒 Protected: PUT/DELETE/PATCH /api/restaurants/**, /api/restaurants/profile, /api/restaurants/details");
//                })
//                .formLogin(form -> {
//                    form.disable();
//                    log.debug("Form login disabled");
//                })
//                .httpBasic(basic -> {
//                    basic.disable();
//                    log.debug("HTTP Basic auth disabled");
//                });
//
//        log.info("🔒 Restaurant Service Security configuration completed");
//        return http.build();
//    }
//
//    @Bean
//    public CorsConfigurationSource corsConfigurationSource() {
//        log.debug("🌐 Configuring CORS...");
//
//        CorsConfiguration configuration = new CorsConfiguration();
//
//        configuration.setAllowedOriginPatterns(Arrays.asList(
//                "http://localhost:4200",
//                "http://127.0.0.1:4200",
//                "http://localhost:*"
//        ));
//
//        configuration.setAllowedMethods(Arrays.asList(
//                "GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH", "HEAD"
//        ));
//
//        configuration.setAllowedHeaders(Arrays.asList("*"));
//
//        configuration.setExposedHeaders(Arrays.asList(
//                "Authorization",
//                "Content-Type",
//                "X-Total-Count",
//                "Access-Control-Allow-Origin",
//                "Access-Control-Allow-Headers"
//        ));
//
//        configuration.setAllowCredentials(true);
//        configuration.setMaxAge(3600L);
//
//        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
//        source.registerCorsConfiguration("/**", configuration);
//
//        log.info("✅ CORS configured for origins: http://localhost:4200, http://127.0.0.1:4200");
//        return source;
//    }
//}

package com.example.Restaurant.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import lombok.extern.slf4j.Slf4j;

import java.util.Arrays;

@Configuration
@EnableWebSecurity
@Slf4j
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        log.info("🔒 Configuring Restaurant Service Security for Customer Access...");

        http
                .csrf(csrf -> csrf.disable())
                .cors(cors -> cors.configurationSource(corsConfigurationSource()))
                .sessionManagement(session ->
                        session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(auth -> auth
                        // 🔥 CRITICAL: Allow public access to restaurant listing
                        .requestMatchers(HttpMethod.GET, "/api/restaurants").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/restaurants/{id}").permitAll()

                        // Authentication endpoints
                        .requestMatchers(HttpMethod.POST, "/api/restaurants/register").permitAll()
                        .requestMatchers(HttpMethod.POST, "/api/restaurants/login").permitAll()

                        // Protected restaurant management endpoints
                        .requestMatchers(HttpMethod.GET, "/api/restaurants/profile").authenticated()
                        .requestMatchers(HttpMethod.GET, "/api/restaurants/details").authenticated()
                        .requestMatchers(HttpMethod.PUT, "/api/restaurants/**").authenticated()
                        .requestMatchers(HttpMethod.DELETE, "/api/restaurants/**").authenticated()
                        .requestMatchers(HttpMethod.PATCH, "/api/restaurants/**").authenticated()

                        // Health endpoints
                        .requestMatchers("/api/restaurants/health").permitAll()
                        .requestMatchers("/error", "/favicon.ico").permitAll()

                        // All other endpoints require authentication
                        .anyRequest().authenticated()
                )
                .formLogin(form -> form.disable())
                .httpBasic(basic -> basic.disable());

        log.info("✅ Restaurant listing is now PUBLIC for customer browsing");
        return http.build();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();

        configuration.setAllowedOrigins(Arrays.asList(
                "http://localhost:4200",
                "http://127.0.0.1:4200"
        ));

        configuration.setAllowedMethods(Arrays.asList(
                "GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH", "HEAD"
        ));

        configuration.setAllowedHeaders(Arrays.asList("*"));
        configuration.setAllowCredentials(true);
        configuration.setMaxAge(3600L);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);

        return source;
    }
}


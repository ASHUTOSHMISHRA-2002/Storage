//package com.example.Restaurant.Controller;
//
//import com.example.Restaurant.Dto.*;
//import com.example.Restaurant.Exception.InvalidCredentialsException;
//import com.example.Restaurant.Service.RestaurantService;
//import jakarta.validation.Valid;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.List;
//
///**
// * Controller for managing restaurant-related operations.
// * Handles registration, login, and retrieval.
// */
//@RestController
//@RequestMapping("/api/restaurants")
//public class RestaurantController {
//
//    @Autowired
//    private RestaurantService restaurantService;
//
//    /**
//     * Registers a new restaurant.
//     */
//    @PostMapping("/register")
//    public ResponseEntity<AuthResponseDTO> register(@Valid @RequestBody RestaurantRegisterDTO dto) {
//        AuthResponseDTO response = restaurantService.register(dto);
//        return ResponseEntity.ok(response);
//    }
//
//    /**
//     * Authenticates a restaurant login.
//     */
//    @PostMapping("/login")
//    public ResponseEntity<AuthResponseDTO> login(@Valid @RequestBody RestaurantLoginDTO dto)
//            throws InvalidCredentialsException {
//        AuthResponseDTO response = restaurantService.login(dto);
//        return ResponseEntity.ok(response);
//    }
//
//    /**
//     * Retrieves restaurant details by its ID.
//     */
//    @GetMapping("/{id}")
//    public ResponseEntity<RestaurantDTO> getRestaurantById(@PathVariable Long id) {
//        RestaurantDTO restaurant = restaurantService.getRestaurantById(id);
//        if (restaurant == null) {
//            return ResponseEntity.notFound().build(); // ✅ Prevent 500 on null result
//        }
//        return ResponseEntity.ok(restaurant);
//    }
//
//    /**
//     * Retrieves all registered restaurants.
//     */
//    @GetMapping
//    public ResponseEntity<List<RestaurantDTO>> getAllRestaurants() {
//        List<RestaurantDTO> restaurants = restaurantService.getAllRestaurants();
//        return ResponseEntity.ok(restaurants);
//    }
//}


//package com.example.Restaurant.Controller;
//
//import com.example.Restaurant.Dto.*;
//import com.example.Restaurant.Exception.InvalidCredentialsException;
//import com.example.Restaurant.Service.RestaurantService;
//import jakarta.validation.Valid;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import lombok.extern.slf4j.Slf4j;
//
//import java.util.Base64;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//@CrossOrigin(origins = "http://localhost:4200")
//@RestController
//@RequestMapping("/api/restaurants")
//@Slf4j
//public class RestaurantController {
//
//    @Autowired
//    private RestaurantService restaurantService;
//
//    @PostMapping("/register")
//    public ResponseEntity<AuthResponseDTO> register(@Valid @RequestBody RestaurantRegisterDTO dto) {
//        log.info("Restaurant registration request for email: {}", dto.getEmail());
//        AuthResponseDTO response = restaurantService.register(dto);
//        log.info("Restaurant registered successfully with email: {}", dto.getEmail());
//        return ResponseEntity.ok(response);
//    }
//
//    @PostMapping("/login")
//    public ResponseEntity<RestaurantLoginResponseDTO> login(@Valid @RequestBody RestaurantLoginDTO dto)
//            throws InvalidCredentialsException {
//        log.info("Restaurant login request for email: {}", dto.getEmail());
//        RestaurantLoginResponseDTO response = restaurantService.loginWithToken(dto);
//        log.info("Restaurant logged in successfully with email: {}", dto.getEmail());
//        return ResponseEntity.ok(response);
//    }
//
//    // ✅ This is the endpoint your Angular app is calling
//    @GetMapping("/profile")
//    public ResponseEntity<?> getMyProfile(@RequestHeader(value = "Authorization", required = false) String authHeader) {
//        log.info("Restaurant profile request received");
//        log.info("Authorization header: {}", authHeader != null ? "Bearer [TOKEN_PRESENT]" : "NO_TOKEN");
//
//        // Extract userId from JWT token
//        String userId = extractUserIdFromToken(authHeader);
//        String userRole = extractUserRoleFromToken(authHeader);
//
//        log.info("Extracted from token - userId: {}, role: {}", userId, userRole);
//
//        if (userId == null) {
//            log.warn("No userId found in token");
//            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Authentication required");
//        }
//
//        if (userRole == null || !userRole.contains("RESTAURANT")) {
//            log.warn("Invalid role - userId: {}, role: {}", userId, userRole);
//            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Restaurant role required");
//        }
//
//        try {
//            Long restaurantId = Long.valueOf(userId);
//            RestaurantDTO restaurant = restaurantService.getRestaurantById(restaurantId);
//
//            if (restaurant == null) {
//                log.warn("Restaurant not found for userId: {}", userId);
//                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Restaurant not found");
//            }
//
//            // Map to Angular expected format
//            Map<String, Object> response = new HashMap<>();
//            response.put("restaurantName", restaurant.getName());
//            response.put("restaurantLocation", restaurant.getLocation());
//            response.put("email", restaurant.getEmail());
//            response.put("id", restaurant.getId());
//
//            log.info("Restaurant profile retrieved successfully for userId: {}", userId);
//            return ResponseEntity.ok(response);
//
//        } catch (Exception e) {
//            log.error("Error retrieving profile for userId {}: {}", userId, e.getMessage());
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server error");
//        }
//    }
//
//    @GetMapping("/{id}")
//    public ResponseEntity<RestaurantDTO> getRestaurantById(@PathVariable Long id) {
//        log.info("Request to get restaurant by ID: {}", id);
//        RestaurantDTO restaurant = restaurantService.getRestaurantById(id);
//        if (restaurant == null) {
//            return ResponseEntity.notFound().build();
//        }
//        return ResponseEntity.ok(restaurant);
//    }
//
//    @GetMapping
//    public ResponseEntity<List<RestaurantDTO>> getAllRestaurants() {
//        log.info("Request to get all restaurants");
//        List<RestaurantDTO> restaurants = restaurantService.getAllRestaurants();
//        return ResponseEntity.ok(restaurants);
//    }
//
//    // ✅ JWT Token extraction method
//    private String extractUserIdFromToken(String authHeader) {
//        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
//            log.debug("No Bearer token found");
//            return null;
//        }
//
//        try {
//            String token = authHeader.substring(7); // Remove "Bearer "
//            String[] parts = token.split("\\.");
//            if (parts.length != 3) {
//                log.warn("Invalid JWT format - expected 3 parts, got {}", parts.length);
//                return null;
//            }
//
//            // Decode payload
//            String payload = new String(Base64.getUrlDecoder().decode(parts[1]));
//            log.debug("JWT payload decoded successfully");
//
//            // Extract userId
//            if (payload.contains("\"userId\":")) {
//                String userIdPart = payload.substring(payload.indexOf("\"userId\":") + 9);
//
//                if (userIdPart.startsWith("\"")) {
//                    // String format: "userId":"1"
//                    int endIndex = userIdPart.indexOf("\"", 1);
//                    if (endIndex > 0) {
//                        String extractedUserId = userIdPart.substring(1, endIndex);
//                        log.debug("Extracted string userId: {}", extractedUserId);
//                        return extractedUserId;
//                    }
//                } else {
//                    // Numeric format: "userId":1
//                    int endIndex = userIdPart.indexOf(",");
//                    if (endIndex == -1) endIndex = userIdPart.indexOf("}");
//                    if (endIndex > 0) {
//                        String extractedUserId = userIdPart.substring(0, endIndex).trim();
//                        log.debug("Extracted numeric userId: {}", extractedUserId);
//                        return extractedUserId;
//                    }
//                }
//            }
//
//            log.warn("userId not found in payload");
//            return null;
//
//        } catch (Exception e) {
//            log.error("Error extracting userId: {}", e.getMessage());
//            return null;
//        }
//    }
//
//    private String extractUserRoleFromToken(String authHeader) {
//        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
//            return null;
//        }
//
//        try {
//            String token = authHeader.substring(7);
//            String[] parts = token.split("\\.");
//            if (parts.length != 3) return null;
//
//            String payload = new String(Base64.getUrlDecoder().decode(parts[1]));
//
//            if (payload.contains("\"roles\":[")) {
//                String rolesPart = payload.substring(payload.indexOf("\"roles\":[") + 9);
//                int endIndex = rolesPart.indexOf("]");
//                if (endIndex > 0) {
//                    String roles = rolesPart.substring(0, endIndex + 1);
//                    log.debug("Extracted roles: {}", roles);
//                    return roles;
//                }
//            }
//            return null;
//        } catch (Exception e) {
//            log.error("Error extracting roles: {}", e.getMessage());
//            return null;
//        }
//    }
//}


//package com.example.Restaurant.Controller;
//
//import com.example.Restaurant.Dto.*;
//import com.example.Restaurant.Exception.InvalidCredentialsException;
//import com.example.Restaurant.Service.RestaurantService;
//import jakarta.validation.Valid;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import lombok.extern.slf4j.Slf4j;
//
//import java.util.Base64;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//@CrossOrigin(origins = "http://localhost:4200")
//@RestController
//@RequestMapping("/api/restaurants")
//@Slf4j
//public class RestaurantController {
//
//    @Autowired
//    private RestaurantService restaurantService;
//
//    @PostMapping("/register")
//    public ResponseEntity<AuthResponseDTO> register(@Valid @RequestBody RestaurantRegisterDTO dto) {
//        log.info("Restaurant registration request for email: {}", dto.getEmail());
//        AuthResponseDTO response = restaurantService.register(dto);
//        log.info("Restaurant registered successfully with email: {}", dto.getEmail());
//        return ResponseEntity.ok(response);
//    }
//
//    @PostMapping("/login")
//    public ResponseEntity<RestaurantLoginResponseDTO> login(@Valid @RequestBody RestaurantLoginDTO dto)
//            throws InvalidCredentialsException {
//        log.info("Restaurant login request for email: {}", dto.getEmail());
//        RestaurantLoginResponseDTO response = restaurantService.loginWithToken(dto);
//        log.info("Restaurant logged in successfully with email: {}", dto.getEmail());
//        return ResponseEntity.ok(response);
//    }
//
//    @GetMapping("/profile")
//    public ResponseEntity<?> getMyProfile(@RequestHeader(value = "Authorization", required = false) String authHeader) {
//        log.info("Restaurant profile request received");
//        log.info("Authorization header: {}", authHeader != null ? "Bearer [TOKEN_PRESENT]" : "NO_TOKEN");
//
//        // Extract userId from JWT token
//        String userId = extractUserIdFromToken(authHeader);
//        String userRole = extractUserRoleFromToken(authHeader);
//
//        log.info("Extracted from token - userId: {}, role: {}", userId, userRole);
//
//        if (userId == null) {
//            log.warn("No userId found in token");
//            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Authentication required");
//        }
//
//        if (userRole == null || !userRole.contains("RESTAURANT")) {
//            log.warn("Invalid role - userId: {}, role: {}", userId, userRole);
//            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Restaurant role required");
//        }
//
//        try {
//            Long restaurantId = Long.valueOf(userId);
//            RestaurantDTO restaurant = restaurantService.getRestaurantById(restaurantId);
//
//            if (restaurant == null) {
//                log.warn("Restaurant not found for userId: {}", userId);
//                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Restaurant not found");
//            }
//
//            // Map to Angular expected format
//            Map<String, Object> response = new HashMap<>();
//            response.put("restaurantName", restaurant.getName());
//            response.put("restaurantLocation", restaurant.getLocation());
//            response.put("email", restaurant.getEmail());
//            response.put("id", restaurant.getId());
//
//            log.info("Restaurant profile retrieved successfully for userId: {}", userId);
//            return ResponseEntity.ok(response);
//
//        } catch (Exception e) {
//            log.error("Error retrieving profile for userId {}: {}", userId, e.getMessage());
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server error");
//        }
//    }
//
//    @GetMapping("/details")
//    public ResponseEntity<?> getRestaurantDetails(@RequestHeader(value = "Authorization", required = false) String authHeader) {
//        log.info("Restaurant details request received");
//        return getMyProfile(authHeader); // Reuse profile logic
//    }
//
//    @GetMapping("/{id}")
//    public ResponseEntity<RestaurantDTO> getRestaurantById(@PathVariable Long id) {
//        log.info("Request to get restaurant by ID: {}", id);
//        RestaurantDTO restaurant = restaurantService.getRestaurantById(id);
//        if (restaurant == null) {
//            return ResponseEntity.notFound().build();
//        }
//        return ResponseEntity.ok(restaurant);
//    }
//
//    @GetMapping
//    public ResponseEntity<List<RestaurantDTO>> getAllRestaurants() {
//        log.info("Request to get all restaurants");
//        List<RestaurantDTO> restaurants = restaurantService.getAllRestaurants();
//        return ResponseEntity.ok(restaurants);
//    }
//
//    // ✅ FIXED: Proper JWT token extraction
//    private String extractUserIdFromToken(String authHeader) {
//        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
//            log.debug("No Bearer token found");
//            return null;
//        }
//
//        try {
//            String token = authHeader.substring(7); // Remove "Bearer "
//            log.debug("Processing JWT token: {}...", token.substring(0, Math.min(20, token.length())));
//
//            // Split JWT token (header.payload.signature)
//            String[] parts = token.split("\\.");
//            if (parts.length != 3) {
//                log.warn("Invalid JWT format - expected 3 parts, got {}", parts.length);
//                return null;
//            }
//
//            // Decode JWT payload (middle part)
//            String payload = new String(Base64.getUrlDecoder().decode(parts[1]));
//            log.debug("JWT payload decoded: {}", payload);
//
//            // Extract userId from payload
//            if (payload.contains("\"userId\":")) {
//                String userIdPart = payload.substring(payload.indexOf("\"userId\":") + 9);
//
//                // Handle both string and numeric formats
//                if (userIdPart.startsWith("\"")) {
//                    // String format: "userId":"1"
//                    int endIndex = userIdPart.indexOf("\"", 1);
//                    if (endIndex > 0) {
//                        String extractedUserId = userIdPart.substring(1, endIndex);
//                        log.debug("Extracted string userId: {}", extractedUserId);
//                        return extractedUserId;
//                    }
//                } else {
//                    // Numeric format: "userId":1
//                    int commaIndex = userIdPart.indexOf(",");
//                    int braceIndex = userIdPart.indexOf("}");
//                    int endIndex = (commaIndex != -1 && braceIndex != -1) ?
//                            Math.min(commaIndex, braceIndex) :
//                            (commaIndex != -1 ? commaIndex : braceIndex);
//
//                    if (endIndex > 0) {
//                        String extractedUserId = userIdPart.substring(0, endIndex).trim();
//                        log.debug("Extracted numeric userId: {}", extractedUserId);
//                        return extractedUserId;
//                    }
//                }
//            }
//
//            // Also try 'sub' field (JWT standard)
//            if (payload.contains("\"sub\":")) {
//                String subPart = payload.substring(payload.indexOf("\"sub\":") + 6);
//                if (subPart.startsWith("\"")) {
//                    int endIndex = subPart.indexOf("\"", 1);
//                    if (endIndex > 0) {
//                        String extractedSub = subPart.substring(1, endIndex);
//                        log.debug("Extracted sub as userId: {}", extractedSub);
//                        return extractedSub;
//                    }
//                }
//            }
//
//            log.warn("userId not found in JWT payload: {}", payload);
//            return null;
//
//        } catch (Exception e) {
//            log.error("Error extracting userId from JWT token: {}", e.getMessage());
//            return null;
//        }
//    }
//
//    // ✅ FIXED: Proper JWT role extraction
//    private String extractUserRoleFromToken(String authHeader) {
//        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
//            log.debug("No Bearer token found for role extraction");
//            return null;
//        }
//
//        try {
//            String token = authHeader.substring(7);
//            String[] parts = token.split("\\.");
//            if (parts.length != 3) {
//                log.warn("Invalid JWT format for role extraction");
//                return null;
//            }
//
//            // Decode JWT payload
//            String payload = new String(Base64.getUrlDecoder().decode(parts[1]));
//            log.debug("JWT payload for roles: {}", payload);
//
//            // Extract roles array
//            if (payload.contains("\"roles\":[")) {
//                String rolesPart = payload.substring(payload.indexOf("\"roles\":[") + 9);
//                int endIndex = rolesPart.indexOf("]");
//                if (endIndex > 0) {
//                    String roles = rolesPart.substring(0, endIndex + 1);
//                    log.debug("Extracted roles: {}", roles);
//                    return roles;
//                }
//            }
//
//            // Try alternative role field names
//            if (payload.contains("\"authorities\":[")) {
//                String authPart = payload.substring(payload.indexOf("\"authorities\":[") + 15);
//                int endIndex = authPart.indexOf("]");
//                if (endIndex > 0) {
//                    String authorities = authPart.substring(0, endIndex + 1);
//                    log.debug("Extracted authorities as roles: {}", authorities);
//                    return authorities;
//                }
//            }
//
//            log.warn("roles not found in JWT payload: {}", payload);
//            return null;
//
//        } catch (Exception e) {
//            log.error("Error extracting roles from JWT token: {}", e.getMessage());
//            return null;
//        }
//    }
//}



//package com.example.Restaurant.Controller;
//
//import com.example.Restaurant.Dto.*;
//import com.example.Restaurant.Exception.InvalidCredentialsException;
//import com.example.Restaurant.Service.RestaurantService;
//import jakarta.validation.Valid;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//import lombok.extern.slf4j.Slf4j;
//
//import com.fasterxml.jackson.databind.JsonNode;
//import com.fasterxml.jackson.databind.ObjectMapper;
//
//import java.nio.charset.StandardCharsets;
//import java.util.Base64;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//@CrossOrigin(origins = {"http://localhost:4200", "http://127.0.0.1:4200"}, allowCredentials = "true")
//@RestController
//@RequestMapping("/api/restaurants")
//@Slf4j
//public class RestaurantController {
//
//    @Autowired
//    private RestaurantService restaurantService;
//
//    private final ObjectMapper objectMapper = new ObjectMapper();
//
//    // === REGISTRATION ===
//    @PostMapping("/register")
//    public ResponseEntity<AuthResponseDTO> register(@Valid @RequestBody RestaurantRegisterDTO dto) {
//        log.info("Restaurant registration request for email: {}", dto.getEmail());
//        AuthResponseDTO response = restaurantService.register(dto);
//        log.info("Restaurant registered successfully: {}", dto.getEmail());
//        return ResponseEntity.ok(response);
//    }
//
//    // === LOGIN ===
//    @PostMapping("/login")
//    public ResponseEntity<RestaurantLoginResponseDTO> login(@Valid @RequestBody RestaurantLoginDTO dto) throws InvalidCredentialsException {
//        log.info("Restaurant login for email: {}", dto.getEmail());
//        RestaurantLoginResponseDTO response = restaurantService.loginWithToken(dto);
//        log.info("Restaurant logged in successfully: {}", dto.getEmail());
//        return ResponseEntity.ok(response);
//    }
//
//    // === PROFILE via JWT ===
//    @GetMapping("/profile")
//    public ResponseEntity<?> getMyProfile(@RequestHeader(value = "Authorization", required = false) String authHeader) {
//        log.info("Restaurant profile request.");
//        log.info("Authorization header: {}", authHeader != null ? "[TOKEN_PRESENT]" : "NO_TOKEN");
//
//        String userId = extractUserIdFromToken(authHeader);
//        String userRole = extractUserRoleFromToken(authHeader);
//
//        log.info("Decoded JWT - userId: {}, role(s): {}", userId, userRole);
//
//        if (userId == null) {
//            log.warn("No userId found in JWT.");
//            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Authentication required");
//        }
//        if (userRole == null || !userRole.contains("RESTAURANT")) {
//            log.warn("No RESTAURANT role. userId: {}, roles: {}", userId, userRole);
//            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Restaurant role required");
//        }
//
//        try {
//            Long restaurantId = Long.valueOf(userId);
//            RestaurantDTO restaurant = restaurantService.getRestaurantById(restaurantId);
//
//            if (restaurant == null) {
//                log.warn("Restaurant not found for userId: {}", userId);
//                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Restaurant not found");
//            }
//
//            Map<String, Object> response = new HashMap<>();
//            response.put("restaurantName", restaurant.getName());
//            response.put("restaurantLocation", restaurant.getLocation());
//            response.put("email", restaurant.getEmail());
//            response.put("id", restaurant.getId());
//
//            log.info("Returning restaurant profile for userId: {}", userId);
//            return ResponseEntity.ok(response);
//
//        } catch (Exception e) {
//            log.error("Profile error for userId {}: {}", userId, e.getMessage());
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server error");
//        }
//    }
//
//    // RESTAURANT DETAILS (identical to /profile)
//    @GetMapping("/details")
//    public ResponseEntity<?> getRestaurantDetails(@RequestHeader(value = "Authorization", required = false) String authHeader) {
//        log.info("Restaurant details request.");
//        return getMyProfile(authHeader);
//    }
//
//    // === GET (BY ID) ===
//    @GetMapping("/{id}")
//    public ResponseEntity<RestaurantDTO> getRestaurantById(@PathVariable Long id) {
//        log.info("Request for restaurant by ID: {}", id);
//        RestaurantDTO restaurant = restaurantService.getRestaurantById(id);
//        if (restaurant == null) {
//            log.warn("Not found: restaurant id {}", id);
//            return ResponseEntity.notFound().build();
//        }
//        return ResponseEntity.ok(restaurant);
//    }
//
//    // === GET ALL RESTAURANTS ===
//    @GetMapping
//    public ResponseEntity<List<RestaurantDTO>> getAllRestaurants() {
//        log.info("Request for all restaurants");
//        List<RestaurantDTO> restaurants = restaurantService.getAllRestaurants();
//        return ResponseEntity.ok(restaurants);
//    }
//
//    // === JWT HELPERS using JACKSON (Robust) ===
//    private String extractUserIdFromToken(String authHeader) {
//        JsonNode payload = decodeJwtPayload(authHeader);
//        if (payload == null) return null;
//
//        // Try userId
//        JsonNode userIdNode = payload.get("userId");
//        if (userIdNode != null && !userIdNode.isNull()) {
//            return userIdNode.asText();
//        }
//        // Fallback: JWT standard "sub"
//        JsonNode sub = payload.get("sub");
//        if (sub != null && !sub.isNull()) {
//            return sub.asText();
//        }
//        log.warn("JWT: userId/sub missing in payload - {}", payload);
//        return null;
//    }
//
//    private String extractUserRoleFromToken(String authHeader) {
//        JsonNode payload = decodeJwtPayload(authHeader);
//        if (payload == null) return null;
//
//        // roles: [ "RESTAURANT", ...]
//        JsonNode rolesNode = payload.get("roles");
//        if (rolesNode != null && rolesNode.isArray()) {
//            return rolesNode.toString();
//        }
//        // authorities: [ ... ]
//        JsonNode auths = payload.get("authorities");
//        if (auths != null && auths.isArray()) {
//            return auths.toString();
//        }
//        log.warn("JWT: roles/authorities missing in payload - {}", payload);
//        return null;
//    }
//
//    private JsonNode decodeJwtPayload(String authHeader) {
//        if (authHeader == null || !authHeader.startsWith("Bearer ")) return null;
//        try {
//            String[] parts = authHeader.substring(7).split("\\.");
//            if (parts.length != 3) return null;
//            byte[] decoded = Base64.getUrlDecoder().decode(parts[1]);
//            String jsonPayload = new String(decoded, StandardCharsets.UTF_8);
//            return objectMapper.readTree(jsonPayload);
//        } catch (Exception e) {
//            log.warn("JWT decode failed: {}", e.getMessage());
//            return null;
//        }
//    }
//}


//package com.example.Restaurant.Controller;
//
//import com.example.Restaurant.Dto.*;
//import com.example.Restaurant.Exception.InvalidCredentialsException;
//import com.example.Restaurant.Service.RestaurantService;
//import jakarta.validation.Valid;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//import lombok.extern.slf4j.Slf4j;
//
//import com.fasterxml.jackson.databind.JsonNode;
//import com.fasterxml.jackson.databind.ObjectMapper;
//
//import java.nio.charset.StandardCharsets;
//import java.util.Base64;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//@CrossOrigin(
//        origins = {"http://localhost:4200", "http://127.0.0.1:4200"},
//        allowCredentials = "true",
//        allowedHeaders = {"*"},
//        methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE, RequestMethod.OPTIONS}
//)
//@RestController
//@RequestMapping("/api/restaurants")
//@Slf4j
//public class RestaurantController {
//
//    @Autowired
//    private RestaurantService restaurantService;
//
//    private final ObjectMapper objectMapper = new ObjectMapper();
//
//    // === REGISTRATION ===
//    @PostMapping("/register")
//    public ResponseEntity<AuthResponseDTO> register(@Valid @RequestBody RestaurantRegisterDTO dto) {
//        log.info("Restaurant registration request for email: {}", dto.getEmail());
//        try {
//            AuthResponseDTO response = restaurantService.register(dto);
//            log.info("Restaurant registered successfully: {}", dto.getEmail());
//            return ResponseEntity.ok(response);
//        } catch (Exception e) {
//            log.error("Registration failed for {}: {}", dto.getEmail(), e.getMessage());
//            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
//        }
//    }
//
//    // === LOGIN ===
//    @PostMapping("/login")
//    public ResponseEntity<RestaurantLoginResponseDTO> login(@Valid @RequestBody RestaurantLoginDTO dto) throws InvalidCredentialsException {
//        log.info("Restaurant login for email: {}", dto.getEmail());
//        try {
//            RestaurantLoginResponseDTO response = restaurantService.loginWithToken(dto);
//            log.info("Restaurant logged in successfully: {}", dto.getEmail());
//            return ResponseEntity.ok(response);
//        } catch (InvalidCredentialsException e) {
//            log.warn("Invalid credentials for: {}", dto.getEmail());
//            throw e;
//        } catch (Exception e) {
//            log.error("Login error for {}: {}", dto.getEmail(), e.getMessage());
//            throw new InvalidCredentialsException("Login failed");
//        }
//    }
//
//    // === PROFILE via JWT ===
//    @GetMapping("/profile")
//    public ResponseEntity<?> getMyProfile(@RequestHeader(value = "Authorization", required = false) String authHeader) {
//        log.info("Restaurant profile request.");
//        log.info("Authorization header: {}", authHeader != null ? "[TOKEN_PRESENT]" : "NO_TOKEN");
//
//        String userId = extractUserIdFromToken(authHeader);
//        String userRole = extractUserRoleFromToken(authHeader);
//
//        log.info("Decoded JWT - userId: {}, role(s): {}", userId, userRole);
//
//        if (userId == null) {
//            log.warn("No userId found in JWT.");
//            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Authentication required");
//        }
//        if (userRole == null || !userRole.contains("RESTAURANT")) {
//            log.warn("No RESTAURANT role. userId: {}, roles: {}", userId, userRole);
//            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Restaurant role required");
//        }
//
//        try {
//            Long restaurantId = Long.valueOf(userId);
//            RestaurantDTO restaurant = restaurantService.getRestaurantById(restaurantId);
//
//            if (restaurant == null) {
//                log.warn("Restaurant not found for userId: {}", userId);
//                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Restaurant not found");
//            }
//
//            Map<String, Object> response = new HashMap<>();
//            response.put("restaurantName", restaurant.getName());
//            response.put("restaurantLocation", restaurant.getLocation());
//            response.put("email", restaurant.getEmail());
//            response.put("id", restaurant.getId());
//
//            log.info("Returning restaurant profile for userId: {}", userId);
//            return ResponseEntity.ok(response);
//
//        } catch (Exception e) {
//            log.error("Profile error for userId {}: {}", userId, e.getMessage());
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Server error");
//        }
//    }
//
//    // RESTAURANT DETAILS (identical to /profile)
//    @GetMapping("/details")
//    public ResponseEntity<?> getRestaurantDetails(@RequestHeader(value = "Authorization", required = false) String authHeader) {
//        log.info("Restaurant details request.");
//        return getMyProfile(authHeader);
//    }
//
//    // === GET (BY ID) ===
//    @GetMapping("/{id}")
//    public ResponseEntity<RestaurantDTO> getRestaurantById(@PathVariable Long id) {
//        log.info("Request for restaurant by ID: {}", id);
//        try {
//            RestaurantDTO restaurant = restaurantService.getRestaurantById(id);
//            if (restaurant == null) {
//                log.warn("Not found: restaurant id {}", id);
//                return ResponseEntity.notFound().build();
//            }
//            return ResponseEntity.ok(restaurant);
//        } catch (Exception e) {
//            log.error("Error fetching restaurant {}: {}", id, e.getMessage());
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
//        }
//    }
//
//    // === GET ALL RESTAURANTS ===
//    @GetMapping
//    public ResponseEntity<List<RestaurantDTO>> getAllRestaurants() {
//        log.info("Request for all restaurants");
//        try {
//            List<RestaurantDTO> restaurants = restaurantService.getAllRestaurants();
//            log.info("Returning {} restaurants", restaurants.size());
//            return ResponseEntity.ok(restaurants);
//        } catch (Exception e) {
//            log.error("Error fetching restaurants: {}", e.getMessage());
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
//        }
//    }
//
//    // === JWT HELPERS using JACKSON (Robust) ===
//    private String extractUserIdFromToken(String authHeader) {
//        JsonNode payload = decodeJwtPayload(authHeader);
//        if (payload == null) return null;
//
//        // Try userId
//        JsonNode userIdNode = payload.get("userId");
//        if (userIdNode != null && !userIdNode.isNull()) {
//            return userIdNode.asText();
//        }
//        // Fallback: JWT standard "sub"
//        JsonNode sub = payload.get("sub");
//        if (sub != null && !sub.isNull()) {
//            return sub.asText();
//        }
//        log.warn("JWT: userId/sub missing in payload - {}", payload);
//        return null;
//    }
//
//    private String extractUserRoleFromToken(String authHeader) {
//        JsonNode payload = decodeJwtPayload(authHeader);
//        if (payload == null) return null;
//
//        // roles: [ "RESTAURANT", ...]
//        JsonNode rolesNode = payload.get("roles");
//        if (rolesNode != null && rolesNode.isArray()) {
//            return rolesNode.toString();
//        }
//        // authorities: [ ... ]
//        JsonNode auths = payload.get("authorities");
//        if (auths != null && auths.isArray()) {
//            return auths.toString();
//        }
//        log.warn("JWT: roles/authorities missing in payload - {}", payload);
//        return null;
//    }
//
//    private JsonNode decodeJwtPayload(String authHeader) {
//        if (authHeader == null || !authHeader.startsWith("Bearer ")) return null;
//        try {
//            String[] parts = authHeader.substring(7).split("\\.");
//            if (parts.length != 3) return null;
//            byte[] decoded = Base64.getUrlDecoder().decode(parts[1]);
//            String jsonPayload = new String(decoded, StandardCharsets.UTF_8);
//            return objectMapper.readTree(jsonPayload);
//        } catch (Exception e) {
//            log.warn("JWT decode failed: {}", e.getMessage());
//            return null;
//        }
//    }
//}

package com.example.Restaurant.Controller;

import com.example.Restaurant.Dto.*;
import com.example.Restaurant.Exception.InvalidCredentialsException;
import com.example.Restaurant.Service.RestaurantService;
import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import lombok.extern.slf4j.Slf4j;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.nio.charset.StandardCharsets;
import java.util.*;

@CrossOrigin(
        origins = {"http://localhost:4200", "http://127.0.0.1:4200"},
        allowCredentials = "true",
        allowedHeaders = {"*"},
        methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE, RequestMethod.OPTIONS}
)
@RestController
@RequestMapping("/api/restaurants")
@Slf4j
public class RestaurantController {

    @Autowired
    private RestaurantService restaurantService;

    private final ObjectMapper objectMapper = new ObjectMapper();

    // === REGISTRATION (PUBLIC) ===
    @PostMapping("/register")
    public ResponseEntity<AuthResponseDTO> register(@Valid @RequestBody RestaurantRegisterDTO dto) {
        log.info("🔐 Restaurant registration request for email: {}", dto.getEmail());
        try {
            AuthResponseDTO response = restaurantService.register(dto);
            log.info("✅ Restaurant registered successfully: {}", dto.getEmail());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("❌ Registration failed for {}: {}", dto.getEmail(), e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(
                    new AuthResponseDTO("Registration failed: " + e.getMessage())
            );
        }
    }

    // === LOGIN (PUBLIC) ===
    // === LOGIN (PUBLIC) ===
    @PostMapping("/login")
    public ResponseEntity<?> login(@Valid @RequestBody RestaurantLoginDTO dto) {
        log.info("🔐 Restaurant login request for email: {}", dto.getEmail());
        try {
            RestaurantLoginResponseDTO response = restaurantService.loginWithToken(dto);
            log.info("✅ Restaurant logged in successfully: {}", dto.getEmail());

            // 🔥 FIXED: Use correct getter method names that match your DTO fields
            Map<String, Object> loginResponse = new HashMap<>();
            loginResponse.put("id", response.getRestaurantId());           // ✅ getRestaurantId()
            loginResponse.put("name", response.getRestaurantName());       // ✅ getRestaurantName()
            loginResponse.put("location", response.getRestaurantLocation()); // ✅ getRestaurantLocation()
            loginResponse.put("token", response.getJwtToken());            // ✅ getJwtToken()
            loginResponse.put("message", "Login successful");

            return ResponseEntity.ok(loginResponse);
        } catch (InvalidCredentialsException e) {
            log.warn("❌ Invalid credentials for: {}", dto.getEmail());
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("message", "Invalid email or password");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(errorResponse);
        } catch (Exception e) {
            log.error("❌ Login error for {}: {}", dto.getEmail(), e.getMessage());
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("message", "Login failed. Please try again.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }

    // === GET ALL RESTAURANTS (PUBLIC - FOR CUSTOMERS) ===
    @GetMapping
    public ResponseEntity<List<RestaurantDTO>> getAllRestaurants(
            @RequestHeader(value = "Authorization", required = false) String authHeader) {

        log.info("🏪 PUBLIC REQUEST: Get all restaurants");
        log.info("🔍 Authorization header present: {}", authHeader != null ? "YES" : "NO");
        log.info("🔍 Request from customer browsing restaurants");

        try {
            List<RestaurantDTO> restaurants = restaurantService.getAllRestaurants();
            log.info("✅ Successfully returning {} restaurants to customer", restaurants.size());

            // Log restaurant details for debugging
            restaurants.forEach(restaurant ->
                    log.debug("📋 Restaurant: ID={}, Name={}, Location={}",
                            restaurant.getId(), restaurant.getName(), restaurant.getLocation())
            );

            return ResponseEntity.ok(restaurants);
        } catch (Exception e) {
            log.error("❌ Error fetching restaurants: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ArrayList<>());
        }
    }

    // === GET RESTAURANT BY ID (PUBLIC - FOR CUSTOMERS) ===
    @GetMapping("/{id}")
    public ResponseEntity<RestaurantDTO> getRestaurantById(@PathVariable Long id) {
        log.info("🏪 PUBLIC REQUEST: Get restaurant by ID: {}", id);
        try {
            RestaurantDTO restaurant = restaurantService.getRestaurantById(id);
            if (restaurant == null) {
                log.warn("❌ Restaurant not found: id {}", id);
                return ResponseEntity.notFound().build();
            }
            log.info("✅ Returning restaurant: {}", restaurant.getName());
            return ResponseEntity.ok(restaurant);
        } catch (Exception e) {
            log.error("❌ Error fetching restaurant {}: {}", id, e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    // === RESTAURANT PROFILE (PROTECTED) ===
    @GetMapping("/profile")
    public ResponseEntity<?> getMyProfile(@RequestHeader(value = "Authorization", required = false) String authHeader) {
        log.info("🔐 PROTECTED: Restaurant profile request");
        log.info("Authorization header: {}", authHeader != null ? "[TOKEN_PRESENT]" : "NO_TOKEN");

        String userId = extractUserIdFromToken(authHeader);
        String userRole = extractUserRoleFromToken(authHeader);

        log.info("Decoded JWT - userId: {}, role(s): {}", userId, userRole);

        if (userId == null) {
            log.warn("❌ No userId found in JWT");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(
                    Map.of("message", "Authentication required")
            );
        }
        if (userRole == null || !userRole.contains("RESTAURANT")) {
            log.warn("❌ No RESTAURANT role. userId: {}, roles: {}", userId, userRole);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(
                    Map.of("message", "Restaurant role required")
            );
        }

        try {
            Long restaurantId = Long.valueOf(userId);
            RestaurantDTO restaurant = restaurantService.getRestaurantById(restaurantId);

            if (restaurant == null) {
                log.warn("❌ Restaurant not found for userId: {}", userId);
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(
                        Map.of("message", "Restaurant not found")
                );
            }

            Map<String, Object> response = new HashMap<>();
            response.put("restaurantName", restaurant.getName());
            response.put("restaurantLocation", restaurant.getLocation());
            response.put("email", restaurant.getEmail());
            response.put("id", restaurant.getId());

            log.info("✅ Returning restaurant profile for userId: {}", userId);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            log.error("❌ Profile error for userId {}: {}", userId, e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(
                    Map.of("message", "Server error")
            );
        }
    }

    // === RESTAURANT DETAILS (PROTECTED) ===
    @GetMapping("/details")
    public ResponseEntity<?> getRestaurantDetails(@RequestHeader(value = "Authorization", required = false) String authHeader) {
        log.info("🔐 PROTECTED: Restaurant details request");
        return getMyProfile(authHeader);
    }

    // === DEBUGGING ENDPOINTS ===
    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> healthCheck() {
        Map<String, Object> health = new HashMap<>();
        health.put("status", "UP");
        health.put("service", "Restaurant Service");
        health.put("timestamp", System.currentTimeMillis());
        health.put("message", "Restaurant service is running successfully");
        health.put("port", "8082");

        log.info("🏥 Health check requested");
        return ResponseEntity.ok(health);
    }

    @GetMapping("/debug/security")
    public ResponseEntity<Map<String, Object>> debugSecurity() {
        Map<String, Object> debug = new HashMap<>();
        debug.put("message", "Security debug endpoint");
        debug.put("publicEndpoints", Arrays.asList(
                "GET /api/restaurants",
                "GET /api/restaurants/{id}",
                "POST /api/restaurants/register",
                "POST /api/restaurants/login"
        ));
        debug.put("protectedEndpoints", Arrays.asList(
                "GET /api/restaurants/profile",
                "GET /api/restaurants/details"
        ));
        debug.put("timestamp", System.currentTimeMillis());

        log.info("🔍 Security debug endpoint accessed");
        return ResponseEntity.ok(debug);
    }

    // === JWT HELPERS ===
    private String extractUserIdFromToken(String authHeader) {
        JsonNode payload = decodeJwtPayload(authHeader);
        if (payload == null) return null;

        JsonNode userIdNode = payload.get("userId");
        if (userIdNode != null && !userIdNode.isNull()) {
            return userIdNode.asText();
        }

        JsonNode sub = payload.get("sub");
        if (sub != null && !sub.isNull()) {
            return sub.asText();
        }

        log.warn("JWT: userId/sub missing in payload - {}", payload);
        return null;
    }

    private String extractUserRoleFromToken(String authHeader) {
        JsonNode payload = decodeJwtPayload(authHeader);
        if (payload == null) return null;

        JsonNode rolesNode = payload.get("roles");
        if (rolesNode != null && rolesNode.isArray()) {
            return rolesNode.toString();
        }

        JsonNode auths = payload.get("authorities");
        if (auths != null && auths.isArray()) {
            return auths.toString();
        }

        log.warn("JWT: roles/authorities missing in payload - {}", payload);
        return null;
    }

    private JsonNode decodeJwtPayload(String authHeader) {
        if (authHeader == null || !authHeader.startsWith("Bearer ")) return null;
        try {
            String[] parts = authHeader.substring(7).split("\\.");
            if (parts.length != 3) return null;
            byte[] decoded = Base64.getUrlDecoder().decode(parts[1]);
            String jsonPayload = new String(decoded, StandardCharsets.UTF_8);
            return objectMapper.readTree(jsonPayload);
        } catch (Exception e) {
            log.warn("JWT decode failed: {}", e.getMessage());
            return null;
        }
    }
}

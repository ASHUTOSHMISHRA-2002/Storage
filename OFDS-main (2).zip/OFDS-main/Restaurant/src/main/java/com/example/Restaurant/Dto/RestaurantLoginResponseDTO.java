package com.example.Restaurant.Dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RestaurantLoginResponseDTO {
    private Long restaurantId;
    private String restaurantName;
    private String restaurantLocation;
    private String jwtToken; // 👍 preserved as-is
}

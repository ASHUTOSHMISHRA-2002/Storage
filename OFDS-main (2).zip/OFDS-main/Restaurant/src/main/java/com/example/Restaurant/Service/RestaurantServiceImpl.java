//package com.example.Restaurant.Service;
//
//import lombok.RequiredArgsConstructor;
//import lombok.extern.slf4j.Slf4j;
//
//import java.util.Collections;
//import java.util.List;
//import java.util.Optional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.stereotype.Service;
//
//import com.example.Restaurant.Dto.*; // Assuming RestaurantDTO is here
//import com.example.Restaurant.Entity.Restaurant;
//import com.example.Restaurant.Exception.*; // Assuming ResourceNotFoundException and DuplicateRestaurantException are here
//import com.example.Restaurant.Repository.RestaurantRepository;
//import com.example.Restaurant.Util.AppConstants;
//
//
///**
// * Implementation of the RestaurantService interface.
// * Handles business logic for restaurant registration, authentication, and retrieval.
// */
//@Service
//@RequiredArgsConstructor
//@Slf4j
//public class RestaurantServiceImpl implements RestaurantService {
//
//
//    private final RestaurantRepository restaurantRepository;
//    private final PasswordEncoder passwordEncoder;
//
//    /**
//     * Registers a new restaurant in the system.
//     *
//     * @param registerDTO The restaurant registration details.
//     * @return AuthResponseDTO containing the registration result.
//     * @throws DuplicateRestaurantException If the email is already registered.
//     */
//    @Override
//    public AuthResponseDTO register(RestaurantRegisterDTO dto) {
//        if (restaurantRepository.existsByEmail(dto.getEmail())) {
//            throw new DuplicateRestaurantException(AppConstants.EMAIL_ALREADY_EXISTS);
//        }
//        Restaurant restaurant = new Restaurant();
//        restaurant.setName(dto.getName());
//        restaurant.setLocation(dto.getLocation());
//        restaurant.setEmail(dto.getEmail());
//        restaurant.setPassword(passwordEncoder.encode(dto.getPassword()));
//        restaurantRepository.save(restaurant);
//        return new AuthResponseDTO(AppConstants.REGISTRATION_SUCCESS);
//    }
//
//    /**
//     * Authenticates a restaurant login attempt.
//     *
//     * @param loginDTO The restaurant login credentials.
//     * @return AuthResponseDTO containing authentication response.
//     * @throws InvalidCredentialsException If the email or password is incorrect.
//     */
//    @Override
//    public AuthResponseDTO login(RestaurantLoginDTO dto) {
//        Restaurant restaurant = restaurantRepository.findByEmail(dto.getEmail())
//                .orElseThrow(() -> new InvalidCredentialsException(AppConstants.INVALID_CREDENTIALS));
//
//        if (!restaurant.getPassword().equals(dto.getPassword())) {
//            throw new InvalidCredentialsException(AppConstants.INVALID_CREDENTIALS);
//        }
//        return new AuthResponseDTO(AppConstants.LOGIN_SUCCESS);
//    }
//
//    /**
//     * Retrieves details of a restaurant by its ID.
//     *
//     * @param id The ID of the restaurant.
//     * @return RestaurantDTO containing the restaurant's details.
//     * @throws ResourceNotFoundException If no restaurant is found with the given ID.
//     */
//    @Override
//    public RestaurantDTO getRestaurantById(Long id) {
//        Restaurant restaurant = restaurantRepository.findById(id)
//                .orElseThrow(() -> new RestaurantNotFoundException(AppConstants.RESTAURANT_NOT_FOUND + id));
//
//        RestaurantDTO restaurantDTO = new RestaurantDTO();
//        restaurantDTO.setId(restaurant.getId());
//        restaurantDTO.setName(restaurant.getName());
//        restaurantDTO.setLocation(restaurant.getLocation());
//        restaurantDTO.setEmail(restaurant.getEmail());
//        return restaurantDTO;
//    }
//
//    public Optional<UserAuthDetailsDTO> findUserAuthDetailsByIdentifier(String identifier) {
//        log.info("Attempting to find customer auth details for identifier: {}", identifier);
//
//        Optional<Restaurant> restaurantOptional = restaurantRepository.findByEmail(identifier);
//        log.info("{}",restaurantOptional);
//        if (restaurantOptional.isEmpty()) {
//        	restaurantOptional = restaurantRepository.findByEmail(identifier);
//        }
//
//        if (restaurantOptional.isPresent()) {
//            Restaurant restaurant = restaurantOptional.get();
//            UserAuthDetailsDTO dto = new UserAuthDetailsDTO(
//            		restaurant.getId(),
//            		restaurant.getName(),
//            		restaurant.getEmail(),
//            		restaurant.getPassword(),
//                    Collections.singletonList("RESTAURANT")
//            );
//            log.debug("Found customer auth details for identifier: {}", identifier);
//            return Optional.of(dto);
//        } else {
//            log.warn("Customer auth details not found for identifier: {}", identifier);
//            return Optional.empty();
//        }
//    }
//
//
//    @Override
//    public List<RestaurantDTO> getAllRestaurants(){
//
//    	List<Restaurant> allRestaurants = restaurantRepository.findAll();
//
//		return allRestaurants.stream()
//                .map(restaurant -> {
//                    RestaurantDTO dto = new RestaurantDTO();
//                    dto.setId(restaurant.getId());
//                    dto.setName(restaurant.getName());
//                    dto.setLocation(restaurant.getLocation());
//                    dto.setEmail(restaurant.getEmail());
//                    return dto;
//                })
//                .toList();
//
//    }
//}


package com.example.Restaurant.Service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Base64;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.Restaurant.Dto.*;
import com.example.Restaurant.Entity.Restaurant;
import com.example.Restaurant.Exception.*;
import com.example.Restaurant.Repository.RestaurantRepository;
import com.example.Restaurant.Util.AppConstants;

@Service
@RequiredArgsConstructor
@Slf4j
public class RestaurantServiceImpl implements RestaurantService {

    private final RestaurantRepository restaurantRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public AuthResponseDTO register(RestaurantRegisterDTO dto) {
        log.info("Attempting to register restaurant with email: {}", dto.getEmail());

        if (restaurantRepository.existsByEmail(dto.getEmail())) {
            log.warn("Registration failed - email already exists: {}", dto.getEmail());
            throw new DuplicateRestaurantException(AppConstants.EMAIL_ALREADY_EXISTS);
        }

        try {
            Restaurant restaurant = new Restaurant();
            restaurant.setName(dto.getName());
            restaurant.setLocation(dto.getLocation());
            restaurant.setEmail(dto.getEmail());
            restaurant.setPassword(passwordEncoder.encode(dto.getPassword()));

            Restaurant savedRestaurant = restaurantRepository.save(restaurant);
            log.info("Restaurant registered successfully with ID: {} and email: {}",
                    savedRestaurant.getId(), dto.getEmail());

            return new AuthResponseDTO(AppConstants.REGISTRATION_SUCCESS);
        } catch (Exception e) {
            log.error("Registration failed for email {}: {}", dto.getEmail(), e.getMessage());
            throw new RuntimeException("Registration failed: " + e.getMessage());
        }
    }

    @Override
    public AuthResponseDTO login(RestaurantLoginDTO dto) {
        log.info("Legacy login attempt for email: {}", dto.getEmail());

        Restaurant restaurant = restaurantRepository.findByEmail(dto.getEmail())
                .orElseThrow(() -> new InvalidCredentialsException(AppConstants.INVALID_CREDENTIALS));

        if (!passwordEncoder.matches(dto.getPassword(), restaurant.getPassword())) {
            log.warn("Invalid password for email: {}", dto.getEmail());
            throw new InvalidCredentialsException(AppConstants.INVALID_CREDENTIALS);
        }

        log.info("Legacy login successful for email: {}", dto.getEmail());
        return new AuthResponseDTO(AppConstants.LOGIN_SUCCESS);
    }

    @Override
    public RestaurantLoginResponseDTO loginWithToken(RestaurantLoginDTO dto) throws InvalidCredentialsException {
        log.info("Login with token attempt for email: {}", dto.getEmail());

        Restaurant restaurant = restaurantRepository.findByEmail(dto.getEmail())
                .orElseThrow(() -> {
                    log.warn("Restaurant not found for email: {}", dto.getEmail());
                    return new InvalidCredentialsException(AppConstants.INVALID_CREDENTIALS);
                });

        if (!passwordEncoder.matches(dto.getPassword(), restaurant.getPassword())) {
            log.warn("Invalid password for email: {}", dto.getEmail());
            throw new InvalidCredentialsException(AppConstants.INVALID_CREDENTIALS);
        }

        try {
            // Create a proper JWT-like token
            String jwtToken = createJwtToken(restaurant);

            log.info("Login successful for restaurant ID: {} with email: {}", restaurant.getId(), dto.getEmail());

            return new RestaurantLoginResponseDTO(
                    restaurant.getId(),
                    restaurant.getName(),
                    restaurant.getLocation(),
                    jwtToken
            );
        } catch (Exception e) {
            log.error("Token generation failed for restaurant {}: {}", restaurant.getId(), e.getMessage());
            throw new RuntimeException("Login failed: " + e.getMessage());
        }
    }

    /**
     * 🔥 FIXED: Create proper JWT-like token structure
     */
    private String createJwtToken(Restaurant restaurant) {
        try {
            // Create JWT-like structure: header.payload.signature
            String header = "{\"alg\":\"none\",\"typ\":\"JWT\"}";
            String payload = String.format(
                    "{\"userId\":%d,\"sub\":\"%s\",\"email\":\"%s\",\"roles\":[\"RESTAURANT\"],\"iat\":%d,\"exp\":%d}",
                    restaurant.getId(),
                    restaurant.getId(),
                    restaurant.getEmail(),
                    System.currentTimeMillis() / 1000,
                    (System.currentTimeMillis() / 1000) + (24 * 60 * 60) // 24 hours
            );
            String signature = "fake-signature";

            String encodedHeader = Base64.getUrlEncoder().withoutPadding().encodeToString(header.getBytes());
            String encodedPayload = Base64.getUrlEncoder().withoutPadding().encodeToString(payload.getBytes());
            String encodedSignature = Base64.getUrlEncoder().withoutPadding().encodeToString(signature.getBytes());

            String jwtToken = encodedHeader + "." + encodedPayload + "." + encodedSignature;

            log.debug("Generated JWT token for restaurant {}: {}", restaurant.getId(),
                    jwtToken.substring(0, Math.min(50, jwtToken.length())) + "...");

            return jwtToken;
        } catch (Exception e) {
            log.error("Error creating JWT token for restaurant {}: {}", restaurant.getId(), e.getMessage());
            throw new RuntimeException("Token creation failed: " + e.getMessage());
        }
    }

    @Override
    public RestaurantDTO getRestaurantById(Long id) {
        log.info("Retrieving restaurant details for ID: {}", id);

        Restaurant restaurant = restaurantRepository.findById(id)
                .orElseThrow(() -> {
                    log.warn("Restaurant not found with ID: {}", id);
                    return new RestaurantNotFoundException(AppConstants.RESTAURANT_NOT_FOUND + id);
                });

        RestaurantDTO restaurantDTO = new RestaurantDTO();
        restaurantDTO.setId(restaurant.getId());
        restaurantDTO.setName(restaurant.getName());
        restaurantDTO.setLocation(restaurant.getLocation());
        restaurantDTO.setEmail(restaurant.getEmail());

        log.debug("Retrieved restaurant details for ID: {}", id);
        return restaurantDTO;
    }

    @Override
    public Optional<UserAuthDetailsDTO> findUserAuthDetailsByIdentifier(String identifier) {
        log.info("Finding user auth details for identifier: {}", identifier);

        Optional<Restaurant> restaurantOptional = restaurantRepository.findByEmail(identifier);

        if (restaurantOptional.isPresent()) {
            Restaurant restaurant = restaurantOptional.get();
            UserAuthDetailsDTO dto = new UserAuthDetailsDTO(
                    restaurant.getId(),
                    restaurant.getName(),
                    restaurant.getEmail(),
                    restaurant.getPassword(),
                    Collections.singletonList("RESTAURANT")
            );
            log.debug("Found user auth details for identifier: {}", identifier);
            return Optional.of(dto);
        } else {
            log.warn("User auth details not found for identifier: {}", identifier);
            return Optional.empty();
        }
    }

    @Override
    public UserAuthDetailsDTO getUserAuthDetails(Long userId) {
        log.info("Getting user auth details for user ID: {}", userId);

        Restaurant restaurant = restaurantRepository.findById(userId)
                .orElseThrow(() -> {
                    log.warn("Restaurant not found with ID: {}", userId);
                    return new RestaurantNotFoundException("Restaurant not found with ID: " + userId);
                });

        UserAuthDetailsDTO dto = new UserAuthDetailsDTO(
                restaurant.getId(),
                restaurant.getName(),
                restaurant.getEmail(),
                restaurant.getPassword(),
                Collections.singletonList("RESTAURANT")
        );

        log.debug("Retrieved user auth details for user ID: {}", userId);
        return dto;
    }

    @Override
    public List<RestaurantDTO> getAllRestaurants() {
        log.info("Retrieving all restaurants");

        try {
            List<Restaurant> allRestaurants = restaurantRepository.findAll();

            List<RestaurantDTO> restaurantDTOs = allRestaurants.stream()
                    .map(restaurant -> {
                        RestaurantDTO dto = new RestaurantDTO();
                        dto.setId(restaurant.getId());
                        dto.setName(restaurant.getName());
                        dto.setLocation(restaurant.getLocation());
                        dto.setEmail(restaurant.getEmail());
                        return dto;
                    })
                    .toList();

            log.info("Retrieved {} restaurants successfully", restaurantDTOs.size());
            return restaurantDTOs;
        } catch (Exception e) {
            log.error("Error retrieving all restaurants: {}", e.getMessage());
            throw new RuntimeException("Failed to retrieve restaurants: " + e.getMessage());
        }
    }
}

//package com.example.Restaurant.Service;
//
//import java.util.List;
//import java.util.Optional;
//
//import com.example.Restaurant.Dto.*;
//import com.example.Restaurant.Exception.InvalidCredentialsException;
//
///**
// * Service interface for managing restaurant-related operations.
// * Defines methods for restaurant registration, authentication, and retrieval.
// */
//public interface RestaurantService {
//
//    /**
//     * Registers a new restaurant.
//     *
//     * @param registerDTO The restaurant registration details.
//     * @return AuthResponseDTO containing authentication response.
//     */
//    AuthResponseDTO register(RestaurantRegisterDTO registerDTO);
//
//    /**
//     * Authenticates a restaurant login.
//     *
//     * @param loginDTO The restaurant login credentials.
//     * @return AuthResponseDTO containing authentication response.
//     * @throws InvalidCredentialsException If login credentials are incorrect.
//     */
//    AuthResponseDTO login(RestaurantLoginDTO loginDTO) throws InvalidCredentialsException;
//
//    /**
//     * Retrieves details of a restaurant by its ID.
//     *
//     * @param id The ID of the restaurant.
//     * @return RestaurantDTO containing the restaurant's details.
//     * @throws ResourceNotFoundException If no restaurant is found with the given ID.
//     */
//    RestaurantDTO getRestaurantById(Long id);
//
//	Optional<UserAuthDetailsDTO> findUserAuthDetailsByIdentifier(String email);
//
//	List<RestaurantDTO> getAllRestaurants();
//}
//



package com.example.Restaurant.Service;

import java.util.List;
import java.util.Optional;

import com.example.Restaurant.Dto.*;
import com.example.Restaurant.Exception.InvalidCredentialsException;

/**
 * Service interface for managing restaurant-related operations.
 * Defines methods for restaurant registration, authentication, and retrieval.
 */
public interface RestaurantService {

    /**
     * Registers a new restaurant.
     *
     * @param registerDTO The restaurant registration details.
     * @return AuthResponseDTO containing authentication response.
     */
    AuthResponseDTO register(RestaurantRegisterDTO registerDTO);

    /**
     * Authenticates a restaurant login (legacy method).
     *
     * @param loginDTO The restaurant login credentials.
     * @return AuthResponseDTO containing authentication response.
     * @throws InvalidCredentialsException If login credentials are incorrect.
     */
    AuthResponseDTO login(RestaurantLoginDTO loginDTO) throws InvalidCredentialsException;

    /**
     * ✅ NEW: Authenticates a restaurant login and returns JWT token.
     *
     * @param loginDTO The restaurant login credentials.
     * @return RestaurantLoginResponseDTO containing restaurant details and JWT token.
     * @throws InvalidCredentialsException If login credentials are incorrect.
     */
    RestaurantLoginResponseDTO loginWithToken(RestaurantLoginDTO loginDTO) throws InvalidCredentialsException;

    /**
     * Retrieves details of a restaurant by its ID.
     *
     * @param id The ID of the restaurant.
     * @return RestaurantDTO containing the restaurant's details.
     */
    RestaurantDTO getRestaurantById(Long id);

    /**
     * Finds user authentication details by email identifier.
     *
     * @param email The email identifier.
     * @return Optional<UserAuthDetailsDTO> containing user auth details.
     */
    Optional<UserAuthDetailsDTO> findUserAuthDetailsByIdentifier(String email);

    /**
     * Retrieves all registered restaurants.
     *
     * @return List<RestaurantDTO> containing all restaurants.
     */
    List<RestaurantDTO> getAllRestaurants();

    /**
     * ✅ NEW: Get user authentication details by user ID.
     *
     * @param userId The user ID.
     * @return UserAuthDetailsDTO containing user auth details.
     */
    UserAuthDetailsDTO getUserAuthDetails(Long userId);
}

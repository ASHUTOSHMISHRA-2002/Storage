# OFDS
Online Food Delivery System—a modular platform enabling customer registration, menu browsing, order placement, delivery tracking, and payment processing. Built using Java (Spring Boot) with a REST API architecture, supporting integration with React frontend and relational databases.
